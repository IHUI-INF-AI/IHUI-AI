\pset pager off
\echo === Q9a: xai 最近 8 轮同步 ===
SELECT id, sync_started_at, sync_finished_at, success, total_models, new_models, removed_models, sync_type
FROM ai_model_sync_log WHERE provider_code='xai' ORDER BY sync_started_at DESC LIMIT 8;

\echo === Q9b: 库内当前时刻 ===
SELECT now() AS db_now;
