# © 2026 IHUI AI (智汇AI) · 版权所有者: 李春川 (Li Chunchuan) · https://aizhs.top
# Provenance-watermarked. 未授权商用可被溯源追责 (Apache-2.0 须保留本声明与 NOTICE)。
# [IHUI-AI-PROVENANCE]:⁠​‌​​‌​​‌‍‍​‌​​‌​​​‍‍​‌​‌​‌​‌‍‍​‌​​‌​​‌‍‍​​‌​‌‌​‌‍‍​‌​​​​​‌‍‍​‌​​‌​​‌‍‍‌​‌‌​‌‌‌‍‍‌‌​​‌‌​​‌‌‌‌​‌​‍‍‌‌​‌‌​​​‌​​​‌‌‌‍‍​‌​​​​​‌‍‍​‌​​‌​​‌‍‍‌​‌‌​‌‌‌‍‍‌‌​​‌‌‌​‌​​‌‌‌​‍‍‌‌​​‌‌​​​‌​​‌​‌‍‍‌​‌‌‌​‌‌‌​‌‌‌​‌‍‍‌​‌‌​‌‌‌‍‍​‌​​‌‌​​‍‍​‌​​​​‌‌‍‍‌​‌‌​‌‌‌‍‍​‌‌​​​​‌‍‍​‌‌​‌​​‌‍‍​‌‌‌‌​‌​‍‍​‌‌​‌​​​‍‍​‌‌‌​​‌‌‍‍​​‌​‌‌‌​‍‍​‌‌‌​‌​​‍‍​‌‌​‌‌‌‌‍‍​‌‌‌​​​​‍‍‌​‌‌​‌‌‌‍‍​‌​‌​​​​‍‍​‌​‌​​‌​‍‍​‌​​‌‌‌‌‍‍​‌​‌​‌‌​‍‍​‌​​​‌​‌‍‍​‌​​‌‌‌​‍‍​‌​​​​​‌‍‍​‌​​‌‌‌​‍‍​‌​​​​‌‌‍‍​‌​​​‌​‌‍‍​​‌​‌‌​‌‍‍​​‌‌​​‌​‍‍​​‌‌​​​​‍‍​​‌‌​​‌​‍‍​​‌‌​‌‌​⁠

"""免费 LLM provider 注册表(2026-07-30 立,对齐 OmniRoute 免费 provider 矩阵 + 超越)。

参考 cheahjs/free-llm-api-resources 项目,聚合 30+ 免费 LLM provider 的申请入口、
免费额度、限制、key 配置字段名、默认 base_url。用户在 admin 后台填 key 后自动激活,
Dashboard 可视化展示"已配置 / 未配置 / 本地"三态。

超越 OmniRoute 的点:
- **本地 LLM 兜底**:Ollama / LMStudio / LlamaCpp / vLLM 列入注册表,OmniRoute 仅列云端
- **国内 provider 全覆盖**:Moonshot/智谱/DeepSeek/MiniMax/Qwen/豆包/混元/文心/阶跃 等中文场景 provider
- **key 状态感知**:从 .env / ai_model_config 表 双源检测 key 配置状态,Dashboard 直接展示
- **默认 base_url 内置**:用户未填 api_base 时,从注册表查默认值(避免手动查文档)

数据结构:
    FreeProvider(
        provider_code="moonshot",          # 与 ai_model_config.provider_code 一致
        display_name="Moonshot Kimi",      # Dashboard 展示名
        category="domestic",               # domestic/international/local/credits
        signup_url="https://...",          # 申请入口
        free_quota="Kimi-K2 免费 / 1M tokens/月",  # 免费额度描述
        rate_limit="60 RPM",               # 限制(RPM/TPM/daily)
        default_base_url="https://api.moonshot.cn/v1",  # 默认 base_url
        key_env_vars=["MOONSHOT_API_KEY"],  # 环境变量名(.env)
        default_models=["kimi-k2"],        # 推荐免费模型
        protocol="openai_chat",            # 协议类型(openai_chat/anthropic_messages/gemini_generate_content)
        docs_url="https://platform.moonshot.cn/docs",  # 文档链接
    )

查询 API:
    from .free_provider_registry import free_provider_registry
    all_providers = free_provider_registry.list_all()
    moonshot = free_provider_registry.get_by_code("moonshot")
    configured = free_provider_registry.list_configured()  # 从 env + DB 检测已配置
    local = free_provider_registry.list_local()  # 本地 LLM(无需 key)
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any

from .points_multiplier_inference import infer_points_multiplier as _infer_points_multiplier

logger = logging.getLogger(__name__)


class ProviderCategory(StrEnum):
    """provider 分类。"""

    DOMESTIC = "domestic"  # 国内 provider(中文场景优化)
    INTERNATIONAL = "international"  # 国际 provider(英文场景优化)
    LOCAL = "local"  # 本地 LLM(无需 key,自托管)
    CREDITS = "credits"  # 试用 credits provider(注册送额度)


class ProviderStatus(StrEnum):
    """provider 配置状态。"""

    CONFIGURED = "configured"  # 已配置 key(可用)
    NOT_CONFIGURED = "not_configured"  # 未配置 key(需用户填)
    LOCAL = "local"  # 本地 LLM(无需 key,启动即用)


@dataclass
class FreeProvider:
    """免费 LLM provider 注册项。

    Attributes:
        provider_code: provider 唯一标识(与 ai_model_config.provider_code 一致)。
        display_name: Dashboard 展示名。
        category: 分类(domestic/international/local/credits)。
        signup_url: 申请入口 URL。
        free_quota: 免费额度描述(如 "1M tokens/月" / "Kimi-K2 免费")。
        rate_limit: 速率限制描述(如 "60 RPM")。
        default_base_url: 默认 API base_url(用户未填 api_base 时用此值)。
        key_env_vars: 环境变量名列表(从 .env 检测 key 是否配置)。
        default_models: 推荐免费模型列表。
        protocol: 协议类型(openai_chat / anthropic_messages / gemini_generate_content)。
        docs_url: 文档链接。
        notes: 备注(特殊说明,如"需信用卡验证" / "仅限美国 IP")。
        zero_cost: 真·零成本(无需 key 即可调用,如 pollinations/llm7);
            仅指上游成本为 0,用户售价仍以 DB points_multiplier 为准(见
            ``_ZERO_COST_CODES`` 处的边界注释,上游免费 ≠ 用户侧免费)。
        free_tier: 有免费额度但需注册 key(如 groq/zhipu/cloudflare)。
    """

    provider_code: str
    display_name: str
    category: ProviderCategory
    signup_url: str
    free_quota: str
    rate_limit: str = ""
    default_base_url: str = ""
    key_env_vars: list[str] = field(default_factory=list)
    default_models: list[str] = field(default_factory=list)
    protocol: str = "openai_chat"
    docs_url: str = ""
    notes: str = ""
    zero_cost: bool = False
    free_tier: bool = False
    # 2026-07-31 新增(用户规则:账户没钱需在管理端可视化 + 跳转充值按钮)
    # 充值/billing 页面 URL(管理端"去充值"按钮跳转;未配置时降级用 signup_url)
    recharge_url: str = ""
    # 余额查询端点路径(支持 openrouter/deepseek/siliconcloud 等;空表示该 provider 无余额端点,降级用推理请求 ping)
    # 完整 URL 或相对路径(若相对路径,自动拼接到 default_base_url)
    balance_endpoint: str = ""
    # 模型目录端点免鉴权(如 token6688 /v1/skills/models):无 key 也能同步模型清单。
    # 与 zero_cost 的区别:zero_cost=调用免费且跳过同步;keyless_model_list=仅目录免鉴权,
    # model_sync 对这类 provider 允许空 key 拉取清单(调用仍需 key)。
    keyless_model_list: bool = False


# ============================================================================
# 30+ 免费 provider 注册表(2026-07-30 快照,数据来源:各 provider 官网)
# ============================================================================

_REGISTRY: list[FreeProvider] = [
    # ---------------- 国内 provider(中文场景优化) ----------------
    FreeProvider(
        provider_code="moonshot",
        display_name="Moonshot Kimi(月之暗面)",
        category=ProviderCategory.DOMESTIC,
        signup_url="https://platform.moonshot.cn/console",
        free_quota="Kimi-K2 免费(8B 模型永久免费)/ 15M tokens/月体验额度",
        rate_limit="60 RPM(免费层)",
        default_base_url="https://api.moonshot.cn/v1",
        key_env_vars=["MOONSHOT_API_KEY"],
        default_models=["kimi-k2", "moonshot-v1-8k"],
        docs_url="https://platform.moonshot.cn/docs",
        notes="国内长上下文最强(200K),支持 function calling",
    ),
    FreeProvider(
        provider_code="zhipu",
        display_name="智谱 GLM(清言)",
        category=ProviderCategory.DOMESTIC,
        signup_url="https://open.bigmodel.cn/console",
        free_quota="glm-4-flash 永久免费 / glm-4-air 100M tokens 免费额度",
        rate_limit="100 RPM(免费层)",
        default_base_url="https://open.bigmodel.cn/api/paas/v4",
        key_env_vars=["ZHIPU_API_KEY"],
        default_models=["glm-4-flash", "glm-4-air"],
        docs_url="https://open.bigmodel.cn/dev/api",
        notes="清华系,中文场景表现优,支持 function calling",
    ),
    FreeProvider(
        provider_code="deepseek",
        display_name="DeepSeek(深度求索)",
        category=ProviderCategory.DOMESTIC,
        signup_url="https://platform.deepseek.com",
        free_quota="1 元体验额度(约 7M tokens)/ 价格极低",
        rate_limit="60 RPM(免费层)",
        default_base_url="https://api.deepseek.com/v1",
        key_env_vars=["DEEPSEEK_API_KEY"],
        default_models=["deepseek-chat", "deepseek-reasoner"],
        docs_url="https://platform.deepseek.com/docs",
        notes="R1 推理模型对齐 o1,价格仅 OpenAI 1/30",
        recharge_url="https://platform.deepseek.com/usage",
        balance_endpoint="https://api.deepseek.com/user/balance",
    ),
    FreeProvider(
        provider_code="minimax",
        display_name="MiniMax",
        category=ProviderCategory.DOMESTIC,
        signup_url="https://platform.minimaxi.com/user-center",
        free_quota="abab6.5s 聊天 1M tokens 免费 / 30M tokens 体验额度",
        rate_limit="60 RPM(免费层)",
        default_base_url="https://api.minimax.chat/v1",
        key_env_vars=["MINIMAX_API_KEY", "MINIMAX_GROUP_ID"],
        default_models=["abab6.5s-chat", "abab6.5-chat"],
        docs_url="https://platform.minimaxi.com/document",
        notes="需要 group_id 参数,声音克隆强",
    ),
    FreeProvider(
        provider_code="qwen",
        display_name="阿里通义千问(DashScope)",
        category=ProviderCategory.DOMESTIC,
        signup_url="https://dashscope.console.aliyun.com",
        free_quota="qwen-turbo 100M tokens 免费 / qwen-long 1M tokens 体验",
        rate_limit="60 RPM(免费层)",
        default_base_url="https://dashscope.aliyuncs.com/compatible-mode/v1",
        key_env_vars=["DASHSCOPE_API_KEY"],
        default_models=["qwen-turbo", "qwen-plus", "qwen-long"],
        docs_url="https://help.aliyun.com/zh/dashscope",
        notes="阿里云,OpenAI 兼容模式,multimodal 支持",
    ),
    FreeProvider(
        provider_code="doubao",
        display_name="字节豆包(火山引擎)",
        category=ProviderCategory.DOMESTIC,
        signup_url="https://console.volcengine.com/ark",
        free_quota="doubao-pro 5M tokens 免费体验 / 新用户 50 元额度",
        rate_limit="60 RPM(免费层)",
        default_base_url="https://ark.cn-beijing.volces.com/api/v3",
        key_env_vars=["VOLC_API_KEY", "ARK_API_KEY"],
        default_models=["doubao-pro-32k", "doubao-pro-4k"],
        docs_url="https://www.volcengine.com/docs/82379",
        notes="字节跳动,OpenAI 兼容,需 endpoint_id 调用",
    ),
    FreeProvider(
        provider_code="wenxin",
        display_name="百度文心一言",
        category=ProviderCategory.DOMESTIC,
        signup_url="https://console.bce.baidu.com/qianfan",
        free_quota="ERNIE-Speed-8K 永久免费 / ERNIE-Lite-8K 免费",
        rate_limit="60 RPM(免费层)",
        default_base_url="https://qianfan.baidubce.com/v2",
        key_env_vars=["QIANFAN_API_KEY", "QIANFAN_SECRET_KEY"],
        default_models=["ernie-speed-8k", "ernie-lite-8k"],
        docs_url="https://cloud.baidu.com/doc/WENXINWORKSHOP",
        notes="百度,需 API Key + Secret Key 双参数",
    ),
    FreeProvider(
        provider_code="hunyuan",
        display_name="腾讯混元",
        category=ProviderCategory.DOMESTIC,
        signup_url="https://cloud.tencent.com/product/hunyuan",
        free_quota="hunyuan-lite 永久免费 / hunyuan-pro 10M tokens 体验",
        rate_limit="60 RPM(免费层)",
        default_base_url="https://api.hunyuan.cloud.tencent.com/v1",
        key_env_vars=["HUNYUAN_API_KEY", "TENCENT_CLOUD_SECRET_ID"],
        default_models=["hunyuan-lite", "hunyuan-pro"],
        docs_url="https://cloud.tencent.com/document/product/1729",
        notes="腾讯云,需 SecretId + SecretKey 签名",
    ),
    FreeProvider(
        provider_code="stepfun",
        display_name="阶跃星辰 StepFun",
        category=ProviderCategory.DOMESTIC,
        signup_url="https://platform.stepfun.com",
        free_quota="step_plan 套餐(已配置,免费 plan 模式)",
        rate_limit="无限制(plan 套餐)",
        default_base_url="https://api.stepfun.com/step_plan/v1",
        key_env_vars=["STEPFUN_API_KEY"],
        default_models=["stepfun/step-3.7-flash", "stepfun/step-3.5-flash", "stepfun/step-router-v1"],
        docs_url="https://platform.stepfun.com/docs",
        notes="项目已配置 plan 套餐 key,默认模型 step-3.7-flash",
        # 2026-07-31 P1:补余额查询端点(https://platform.stepfun.com/docs/api-reference/accounts/get)
        # 返回 {balance, type, total_cash_balance, total_voucher_balance},balance=可用余额(CNY)
        recharge_url="https://platform.stepfun.com/step-plan",
        balance_endpoint="https://api.stepfun.com/v1/accounts",
    ),
    FreeProvider(
        provider_code="agnes",
        display_name="Agnes AI",
        category=ProviderCategory.DOMESTIC,
        signup_url="https://agnes-ai.com",
        free_quota="plan 套餐(已配置)",
        rate_limit="无限制(plan 套餐)",
        # 2026-10-10:切国内域名(A/B 实测 200/401)。2026-10-30 复测:apihub.agnes-ai.{cn,com}
        # 当日直连均 200,但只认旧 key —— 域名与 key 按账号成对绑定,拆开必然 401。
        default_base_url="https://api.agnes-ai.cn/v1",
        key_env_vars=["AGNES_API_KEY"],
        # 2026-08-02 修复:agnes 是自有模型平台(非 OpenAI 中转),
        # /v1/models 实测支持 agnes-2.5-flash / agnes-2.5-pro 等(不支持 gpt-4o / step-3.7-flash)
        # 2026-09-20 补充:追加生图模型(OpenAI images 协议 /v1/images/generations)
        # 2026-09-20 实测:agnes-image-2.5-flash 已成功出图(data[0].url)
        # 2026-10-10 对齐 /v1/models 现存清单:agnes-image-2.0-flash 已下架(上游 503 model_not_found),移除
        default_models=[
            "agnes/agnes-2.5-flash", "agnes/agnes-2.5-pro",
            "agnes/agnes-image-2.5-flash",
        ],
        docs_url="https://agnes-ai.com/docs",
        notes="项目已配置 plan 套餐 key,自有模型平台,支持 agnes-2.5-flash / agnes-2.5-pro",
    ),
    # (2026-10-24 移除)ihui_relay「智汇AI 官方模型」条目随 SwiftAPI(极速API
    # 供应商)弃用一并删除:该条目 default_base_url 指向已停止运营的供应商、
    # prod .env 无 IHUI_RELAY_API_KEY(生产早已 100% 不可用),ihui/ 前缀模型已从
    # default_models.json 同步移除。恢复「官方模型」需另行决策(平台自签 key +
    # base_url 指向站内中继),不在本次弃用范围。
    FreeProvider(
        provider_code="siliconcloud",
        display_name="SiliconCloud 硅基流动",
        category=ProviderCategory.DOMESTIC,
        signup_url="https://siliconflow.cn",
        free_quota="14 元新用户额度 / Qwen2.5-7B 等小模型永久免费",
        rate_limit="100 RPM(免费层)",
        default_base_url="https://api.siliconflow.cn/v1",
        key_env_vars=["SILICONCLOUD_API_KEY"],
        default_models=["Qwen/Qwen2.5-7B-Instruct", "deepseek-ai/DeepSeek-V2-Chat"],
        docs_url="https://docs.siliconflow.cn",
        notes="国内聚合平台,聚合 200+ 国内外模型",
        recharge_url="https://cloud.siliconflow.cn/account/billing",
        balance_endpoint="https://api.siliconflow.cn/v1/user/info",
    ),
    FreeProvider(
        provider_code="modelscope",
        display_name="魔搭 ModelScope",
        category=ProviderCategory.DOMESTIC,
        signup_url="https://modelscope.cn",
        free_quota="Qwen 系列免费 / 1M tokens 体验额度",
        rate_limit="60 RPM(免费层)",
        default_base_url="https://dashscope.aliyuncs.com/compatible-mode/v1",
        key_env_vars=["MODELSCOPE_API_KEY", "DASHSCOPE_API_KEY"],
        default_models=["Qwen/Qwen2.5-7B-Instruct"],
        docs_url="https://www.modelscope.cn/docs",
        notes="阿里达摩院,与 DashScope 共用 key",
    ),

    # ---------------- 国际 provider(英文场景优化) ----------------
    FreeProvider(
        provider_code="groq",
        display_name="Groq",
        category=ProviderCategory.INTERNATIONAL,
        signup_url="https://console.groq.com",
        free_quota="Llama 系列免费 / 100 RPD(每天请求数)开发者层",
        rate_limit="100 RPM / 14400 RPD(免费层)",
        default_base_url="https://api.groq.com/openai/v1",
        key_env_vars=["GROQ_API_KEY"],
        default_models=["llama-3.3-70b-versatile", "llama-3.1-8b-instant"],
        docs_url="https://console.groq.com/docs",
        notes="LPU 推理芯片,500+ tokens/s,免费层最快",
    ),
    FreeProvider(
        # 2026-08-02 接入 Google AI Studio(Gemini 免费层)
        provider_code="gemini",
        display_name="Google AI Studio (Gemini)",
        category=ProviderCategory.INTERNATIONAL,
        signup_url="https://aistudio.google.com/apikey",
        free_quota="gemini-2.5-flash / gemini-2.0-flash 免费层(每日限额,需代理)",
        rate_limit="15 RPM / 1500 RPD / 100万 tokens/天(免费层)",
        default_base_url="https://generativelanguage.googleapis.com/v1beta/openai",
        key_env_vars=["GEMINI_API_KEY"],
        # 2026-08-02 修复顺序:gemini-2.5-flash 对新用户 404 下线,health check 用 [0] ping 会标 DOWN → 全部过滤
        # 改 gemini-2.0-flash 放第一(429 配额耗尽=DEGRADED 仍显示,不是 404 DOWN)
        default_models=["gemini/gemini-2.0-flash", "gemini/gemini-2.0-flash-lite", "gemini/gemini-2.5-flash"],
        docs_url="https://ai.google.dev/gemini-api/docs",
        notes="Google AI Studio OpenAI 兼容接口,1M context,免费层按日重置,国内需代理",
    ),
    FreeProvider(
        provider_code="mistral",
        display_name="Mistral AI",
        category=ProviderCategory.INTERNATIONAL,
        signup_url="https://console.mistral.ai",
        free_quota="mistral-large-latest 500K tokens/周 / Codestral 1M tokens/周",
        rate_limit="50 RPM(免费层)",
        default_base_url="https://api.mistral.ai/v1",
        key_env_vars=["MISTRAL_API_KEY"],
        default_models=["mistral-large-latest", "codestral-latest", "pixtral-12b-2409"],
        docs_url="https://docs.mistral.ai",
        notes="欧洲厂商,代码模型强,multimodal 支持",
    ),
    FreeProvider(
        provider_code="cohere",
        display_name="Cohere",
        category=ProviderCategory.INTERNATIONAL,
        signup_url="https://dashboard.cohere.com",
        free_quota="Command-R 1000 API calls/月(开发者层)",
        rate_limit="100 RPM(免费层)",
        default_base_url="https://api.cohere.ai/v1",
        key_env_vars=["COHERE_API_KEY"],
        default_models=["command-r", "command-r-plus"],
        docs_url="https://docs.cohere.com",
        notes="RAG 场景强,支持 web search 工具",
    ),
    FreeProvider(
        provider_code="togetherai",
        display_name="Together AI",
        category=ProviderCategory.CREDITS,
        signup_url="https://api.together.xyz",
        free_quota="新用户 $5 credits(约 25M tokens Llama-3)",
        rate_limit="60 RPM(免费层)",
        default_base_url="https://api.together.xyz/v1",
        key_env_vars=["TOGETHER_API_KEY"],
        default_models=["meta-llama/Llama-3.3-70B-Instruct-Turbo", "Qwen/Qwen2.5-72B-Instruct-Turbo"],
        docs_url="https://docs.together.ai",
        notes="聚合平台,支持 200+ 开源模型",
    ),
    FreeProvider(
        provider_code="huggingface",
        display_name="Hugging Face Inference API",
        category=ProviderCategory.INTERNATIONAL,
        signup_url="https://huggingface.co/register",
        free_quota="免费层 1000 requests/天 / Serverless Inference",
        rate_limit="1000 RPD(免费层)",
        # 2026-10-26 换域:api-inference.huggingface.co 已被网络封锁不可达
        # (直连超时、经代理 TLS reset 实测),官方推理入口迁至 router.huggingface.co,
        # 拼 /v1/models 免鉴权 200 实测可达。
        default_base_url="https://router.huggingface.co",
        # 目录端点免鉴权(router /v1/models 无 key 200 实测)⇒ 未配 key 也同步清单,
        # 不再因库里残留的 sk-placeholder 被拉进"有 key"档反复失败进人告警。
        keyless_model_list=True,
        key_env_vars=["HUGGINGFACE_API_KEY", "HF_API_TOKEN"],
        default_models=["meta-llama/Llama-3.3-70B-Instruct", "mistralai/Mistral-7B-Instruct-v0.3"],
        docs_url="https://huggingface.co/docs/api-inference",
        notes="开源模型库,免费层负载较高(冷启动)",
    ),
    FreeProvider(
        provider_code="openrouter",
        display_name="OpenRouter",
        category=ProviderCategory.CREDITS,
        signup_url="https://openrouter.ai/keys",
        free_quota="多个 :free 后缀模型免费(Llama-3.3-70B-Instruct:free 等)",
        rate_limit="20 RPM(免费层)",
        default_base_url="https://openrouter.ai/api/v1",
        key_env_vars=["OPENROUTER_API_KEY"],
        default_models=["meta-llama/llama-3.3-70b-instruct:free", "google/gemini-flash-1.5:free"],
        docs_url="https://openrouter.ai/docs",
        notes="聚合 290+ 模型,:free 后缀完全免费",
        recharge_url="https://openrouter.ai/credits",
        balance_endpoint="https://openrouter.ai/api/v1/credits",
    ),
    FreeProvider(
        provider_code="cloudflare_workers_ai",
        display_name="Cloudflare Workers AI",
        category=ProviderCategory.INTERNATIONAL,
        signup_url="https://dash.cloudflare.com",
        free_quota="10000 neurons/天(免费层,约 10M tokens)",
        rate_limit="50 RPM(免费层)",
        default_base_url="https://api.cloudflare.com/client/v4/accounts",
        key_env_vars=["CLOUDFLARE_API_TOKEN", "CLOUDFLARE_ACCOUNT_ID"],
        # 2026-08-02 修复:glm-5.2 需 Workers Paid plan(403 forbidden),改 glm-4.7-flash 官方免费推荐
        # memory: GLM-5.2 自 2026-07-28 起从 Workers Free plan 移除
        default_models=["@cf/zai-org/glm-4.7-flash", "@cf/meta/llama-3.3-70b-instruct-fp8-fast", "@cf/qwen/qwq-32b"],
        docs_url="https://developers.cloudflare.com/workers-ai",
        notes="边缘推理,需 account_id,模型名 @cf/ 前缀,免费层用 glm-4.7-flash(非 glm-5.2)",
    ),
    FreeProvider(
        provider_code="nvidia_nim",
        display_name="NVIDIA NIM",
        category=ProviderCategory.INTERNATIONAL,
        signup_url="https://build.nvidia.com",
        free_quota="1000 credits(约 1000 次调用)/ 永久免费层",
        rate_limit="40 RPM(免费层)",
        default_base_url="https://integrate.api.nvidia.com/v1",
        key_env_vars=["NVIDIA_API_KEY", "NIM_API_KEY"],
        default_models=["deepseek-ai/deepseek-v4-pro", "deepseek-ai/deepseek-v4-flash", "meta/llama-3.3-70b-instruct"],
        docs_url="https://docs.api.nvidia.com",
        notes=(
            "NVIDIA DGX 推理,Llama / DeepSeek / Qwen 全系列。"
            "⚠️ 2026-07-31 实测:deepseek-v4-pro 200 OK ✅(主力推荐);"
            "deepseek-r1 / qwen2.5-7b 间歇性 502(provider 限流,模型未下线);"
            "llama-3.3-70b 间歇性超时(大模型冷启动,模型可用);"
            "nemotron-4-340b-instruct 需 nvidia/nvidia/ 前缀且 NIM 1.14 docs 未列出(可能已下线,改用 llama-3.1-nemotron-70b-instruct)。"
            "模型清单由 ModelSyncService 从 NVIDIA /v1/models 自动同步。"
        ),
    ),
    FreeProvider(
        provider_code="github_models",
        display_name="GitHub Models",
        category=ProviderCategory.INTERNATIONAL,
        signup_url="https://github.com/marketplace/models",
        free_quota="免费层 150 requests/天 / GitHub PAT 直接用",
        rate_limit="150 RPD(免费层)",
        default_base_url="https://models.inference.ai.azure.com",
        key_env_vars=["GITHUB_TOKEN", "GITHUB_API_KEY"],
        default_models=["gpt-4o", "Mistral-large", "Phi-3.5-mini-instruct"],
        docs_url="https://docs.github.com/en/models",
        notes="⚠️ 2026-06-16 后新用户无法注册,老用户保留( OmniRoute FREE_TIERS.md v3.8.49 标注);GitHub PAT 即可用,聚合 OpenAI/Mistral/Phi",
    ),
    FreeProvider(
        provider_code="vercel_ai_gateway",
        display_name="Vercel AI Gateway",
        category=ProviderCategory.INTERNATIONAL,
        signup_url="https://vercel.com/dashboard",
        free_quota="Hobby plan 免费 / 1000 requests/月",
        rate_limit="30 RPM(免费层)",
        default_base_url="https://ai-gateway.vercel.sh/v1",
        key_env_vars=["VERCEL_AI_GATEWAY_API_KEY"],
        default_models=["openai/gpt-4o-mini", "anthropic/claude-3.5-haiku"],
        docs_url="https://vercel.com/docs/ai-gateway",
        notes="Vercel 托管,聚合多 provider",
    ),
    FreeProvider(
        provider_code="cerebras",
        display_name="Cerebras",
        category=ProviderCategory.INTERNATIONAL,
        signup_url="https://cerebras.ai",
        free_quota="Llama-3.1-8B 免费 / 2000 RPM(免费层最快)",
        rate_limit="2000 RPM(免费层)",
        default_base_url="https://api.cerebras.ai/v1",
        key_env_vars=["CEREBRAS_API_KEY"],
        default_models=["llama3.1-8b", "llama-3.3-70b"],
        docs_url="https://docs.cerebras.ai",
        notes="Wafer-Scale Engine,2600 tokens/s,免费层 RPM 最高",
    ),
    FreeProvider(
        provider_code="sambanova",
        display_name="SambaNova",
        category=ProviderCategory.INTERNATIONAL,
        signup_url="https://cloud.sambanova.ai",
        free_quota="Llama-3.3-70B 免费 / DeepSeek-R1 免费",
        rate_limit="100 RPM(免费层)",
        default_base_url="https://api.sambanova.ai/v1",
        key_env_vars=["SAMBANOVA_API_KEY"],
        default_models=["Meta-Llama-3.3-70B-Instruct", "DeepSeek-R1"],
        docs_url="https://docs.sambanova.ai",
        notes="RDA 芯片,免费层支持 R1 推理模型",
    ),
    FreeProvider(
        provider_code="fireworksai",
        display_name="Fireworks AI",
        category=ProviderCategory.CREDITS,
        signup_url="https://fireworks.ai",
        free_quota="新用户 $1 credits(约 5M tokens)",
        rate_limit="60 RPM(免费层)",
        default_base_url="https://api.fireworks.ai/inference/v1",
        key_env_vars=["FIREWORKS_API_KEY"],
        default_models=["accounts/fireworks/models/llama-v3p3-70b-instruct"],
        docs_url="https://docs.fireworks.ai",
        notes="⚠️ ToS §2.1/§2.2 禁止 proxy/中介使用(OmniRoute 标注 caution);开源模型托管,推理速度快",
    ),

    # ---------------- credits provider(注册送额度) ----------------
    FreeProvider(
        provider_code="lambda",
        display_name="Lambda Labs",
        category=ProviderCategory.CREDITS,
        signup_url="https://cloud.lambdalabs.com",
        free_quota="新用户 250 credits",
        rate_limit="60 RPM",
        default_base_url="https://api.lambdalabs.com/v1",
        key_env_vars=["LAMBDA_API_KEY"],
        default_models=["llama3.1-405b-instruct", "llama3.1-70b-instruct"],
        docs_url="https://docs.lambdalabs.com",
        notes="GPU 云厂商,Llama 405B 可用",
    ),
    FreeProvider(
        provider_code="baseten",
        display_name="Baseten",
        category=ProviderCategory.CREDITS,
        signup_url="https://baseten.co",
        free_quota="新用户 $30 credits",
        rate_limit="60 RPM",
        default_base_url="https://api.baseten.co/v1",
        key_env_vars=["BASETEN_API_KEY"],
        default_models=["llama-3.1-70b", "qwen2.5-72b"],
        docs_url="https://docs.baseten.co",
        notes="无服务器 GPU 推理",
    ),
    FreeProvider(
        provider_code="crusoe",
        display_name="Crusoe Cloud",
        category=ProviderCategory.CREDITS,
        signup_url="https://crusoe.ai",
        free_quota="新用户 $10 credits",
        rate_limit="60 RPM",
        default_base_url="https://api.crusoe.ai/v1",
        key_env_vars=["CRUSOE_API_KEY"],
        default_models=["llama-3.3-70b-instruct"],
        docs_url="https://docs.crusoe.ai",
        notes="清洁能源数据中心",
    ),
    FreeProvider(
        provider_code="hyperbolic",
        display_name="Hyperbolic",
        category=ProviderCategory.CREDITS,
        signup_url="https://hyperbolic.xyz",
        free_quota="新用户 $5 credits",
        rate_limit="60 RPM",
        default_base_url="https://api.hyperbolic.xyz/v1",
        key_env_vars=["HYPERBOLIC_API_KEY"],
        default_models=["meta-llama/Meta-Llama-3.1-405B-Instruct"],
        docs_url="https://docs.hyperbolic.xyz",
        notes="GPU 聚合市场,405B 可用",
    ),
    FreeProvider(
        provider_code="nebius",
        display_name="Nebius AI",
        category=ProviderCategory.CREDITS,
        signup_url="https://nebius.ai",
        free_quota="新用户 $10 credits",
        rate_limit="60 RPM",
        default_base_url="https://api.studio.nebius.ai/v1",
        key_env_vars=["NEBIUS_API_KEY"],
        default_models=["meta-llama/Meta-Llama-3.1-70B-Instruct"],
        docs_url="https://docs.nebius.ai",
        notes="欧洲 GPU 云,Llama 系列",
    ),

    # ---------------- 本地 LLM(无需 key) ----------------
    FreeProvider(
        provider_code="ollama",
        display_name="Ollama(本地)",
        category=ProviderCategory.LOCAL,
        signup_url="https://ollama.com/download",
        free_quota="永久免费(本地部署,无配额)",
        rate_limit="无限制(本地)",
        default_base_url="http://localhost:11434",
        key_env_vars=[],  # 本地无需 key
        default_models=["ollama/llama3.2", "ollama/qwen2.5:32b", "ollama/deepseek-r1"],
        docs_url="https://ollama.com/library",
        notes="本地 LLM 首选,一键拉模型,支持 function calling",
    ),
    FreeProvider(
        provider_code="lmstudio",
        display_name="LM Studio(本地)",
        category=ProviderCategory.LOCAL,
        signup_url="https://lmstudio.ai",
        free_quota="永久免费(本地部署)",
        rate_limit="无限制(本地)",
        default_base_url="http://localhost:1234/v1",
        key_env_vars=[],
        default_models=["lmstudio/llama-3.3-70b", "lmstudio/qwen2.5-32b"],
        docs_url="https://lmstudio.ai/docs",
        notes="GUI 客户端,OpenAI 兼容 API",
    ),
    FreeProvider(
        provider_code="llamacpp",
        display_name="llama.cpp(本地)",
        category=ProviderCategory.LOCAL,
        signup_url="https://github.com/ggerganov/llama.cpp",
        free_quota="永久免费(本地部署)",
        rate_limit="无限制(本地)",
        default_base_url="http://localhost:8080",
        key_env_vars=[],
        default_models=["llamacpp/llama-3.3-70b", "llamacpp/qwen2.5"],
        docs_url="https://github.com/ggerganov/llama.cpp/tree/main/tools/server",
        notes="C++ 推理引擎,GPU 加速,极轻量",
    ),
    FreeProvider(
        provider_code="vllm",
        display_name="vLLM(本地)",
        category=ProviderCategory.LOCAL,
        signup_url="https://github.com/vllm-project/vllm",
        free_quota="永久免费(本地部署)",
        rate_limit="无限制(本地)",
        default_base_url="http://localhost:8000/v1",
        key_env_vars=[],
        default_models=["vllm/llama-3.3-70b", "vllm/qwen2.5-72b"],
        docs_url="https://docs.vllm.ai",
        notes="高吞吐推理,PagedAttention,生产级本地 LLM",
    ),

    # ---------------- OmniRoute 独有 provider(2026-07-30 补,对齐 v3.8.49) ----------------
    FreeProvider(
        provider_code="llm7",
        display_name="LLM7(免费镜像)",
        category=ProviderCategory.INTERNATIONAL,
        signup_url="https://llm7.io",
        free_quota="5M tokens/天(约 150M/月),无需 key",
        rate_limit="无明确限制(共享池)",
        default_base_url="https://api.llm7.io/v1",
        key_env_vars=[],  # 无需 key
        default_models=["qwen3-235b", "mistral-small-3.2", "codestral-latest"],
        docs_url="https://llm7.io",
        notes=(
            "OmniRoute 第二大免费 token 来源(150M/月);免费镜像服务,有下线风险,建议兜底用。"
            "2026-07-31 修复:旧模型名 gpt-4o/gpt-4.1/gpt-5.6/claude-sonnet-4.5 已不可用"
            "(返回 'Model currently unavailable')。从 /v1/models 实时拉取的免费(无 tier=pro 标记)模型:"
            "qwen3-235b / mistral-small-3.2 / codestral-latest / devstral-small-2:24b。"
            "Pro 模型(kimi-k2.6/minimax-m2.7/deepseek-v4-flash 等)需 dash.llm7.io 申请 key。"
            "匿名限 500K tokens/天, 60 r/h, 10 r/m, 1 r/s。"
        ),
    ),
    FreeProvider(
        provider_code="pollinations",
        display_name="Pollinations(无 key 免费)",
        category=ProviderCategory.INTERNATIONAL,
        signup_url="https://pollinations.ai",
        free_quota="永久免费,无需注册无需 API 密钥",
        rate_limit="1 req/6-15 秒(匿名,极低速率)",
        default_base_url="https://text.pollinations.ai/openai",
        key_env_vars=[],  # 无需 key
        default_models=["openai-fast"],
        docs_url="https://pollinations.ai/docs",
        notes=(
            "OmniRoute 11 forever free 之一;无 key 免费顶级模型,速率极低仅适合兜底验证。"
            "2026-07-31 修复:模型清单从 /models 端点实时获取,当前唯一可用免费模型为 openai-fast"
            "(GPT-OSS 20B Reasoning LLM by OVH,别名 openai/gpt-oss/gpt-oss-20b/ovh-reasoning)。"
            "旧模型名 gpt-5/claude/deepseek/llama-4/gemini 已下线(返回 404 Model not found)。"
            "text.pollinations.ai 为 legacy API,enter.pollinations.ai 为新平台(需 sk_ key,无速率限制)。"
        ),
    ),
    FreeProvider(
        provider_code="qoder",
        display_name="Qoder AI(unlimited free)",
        category=ProviderCategory.INTERNATIONAL,
        signup_url="https://qoder.ai",
        free_quota="unlimited free(Kimi K2 / DeepSeek R1 / Qwen3 Coder Plus)",
        rate_limit="无明确限制",
        default_base_url="https://api.qoder.ai/v1",
        key_env_vars=["QODER_API_KEY"],
        default_models=["if/kimi-k2-thinking", "if/deepseek-r1", "if/qwen3-coder-plus"],
        docs_url="https://docs.qoder.ai",
        notes="OmniRoute 11 forever free 之一;unlimited free 编码模型",
    ),
    FreeProvider(
        provider_code="ovhcloud",
        display_name="OVHcloud AI(欧洲节点)",
        category=ProviderCategory.INTERNATIONAL,
        signup_url="https://www.ovhcloud.com/en/public-cloud/ai/",
        free_quota="免费层(需 OVH 账号)",
        rate_limit="60 RPM",
        default_base_url="https://gra.ai.cloud.ovh.net/v1",
        key_env_vars=["OVH_AI_API_KEY"],
        default_models=["meta-llama/Llama-3.3-70B-Instruct"],
        docs_url="https://docs.ovh.com/gb/en/public-cloud/ai/",
        notes="OmniRoute v3.8.49 新增;欧洲 GPU 云,GDPR 合规节点",
    ),
    FreeProvider(
        provider_code="requesty",
        display_name="Requesty(路由聚合)",
        category=ProviderCategory.INTERNATIONAL,
        signup_url="https://requesty.ai",
        free_quota="免费层(透明路由聚合)",
        rate_limit="60 RPM",
        default_base_url="https://router.requesty.ai/v1",
        key_env_vars=["REQUESTY_API_KEY"],
        default_models=["auto"],  # 路由聚合,模型自动选
        docs_url="https://docs.requesty.ai",
        notes="OmniRoute v3.8.49 新增;透明路由聚合,类似 OpenRouter",
    ),

    # ---------------- default_models.json 已有但 registry 未注册(2026-07-30 补) ----------------
    FreeProvider(
        provider_code="opencode_zen",
        display_name="OpenCode Zen(免费编码模型)",
        category=ProviderCategory.INTERNATIONAL,
        signup_url="https://opencode.ai/auth",
        free_quota="recurring-uncapped(轮换免费编码模型,实际免费模型 2 个)",
        rate_limit="无明确限制",
        default_base_url="https://opencode.ai/zen/v1",
        key_env_vars=[],  # 无需 key(免费模型层已验证无 key 可调)
        default_models=["big-pickle", "glm-4.7-free"],
        docs_url="https://opencode.ai/docs/zen",
        notes=(
            "OmniRoute 标注 recurring-uncapped;正确 base_url 为 https://opencode.ai/zen/v1(非 api.opencode.ai)。"
            "2026-07-31 修复:从 /zen/v1/models 实时拉取,当前实际免费模型仅 2 个:big-pickle / glm-4.7-free。"
            "旧 default_models 中的 deepseek-v4-flash-free / mimo-v2.5-free / qwen3.6-plus-free / minimax-m3-free"
            "不在实际模型列表中(返回 'Not Found')。big-pickle-stealth 也不存在,正确名为 big-pickle。"
            "其他模型(gpt-5.x/claude-*/gemini-*/kimi-k2/qwen3-coder/glm-4.6 等)需 OPENCODE_API_KEY 付费调用。"
        ),
    ),
    FreeProvider(
        provider_code="scaleway",
        display_name="Scaleway(1M/月免费)",
        category=ProviderCategory.INTERNATIONAL,
        signup_url="https://console.scaleway.com",
        free_quota="1M tokens/月免费",
        rate_limit="60 RPM",
        default_base_url="https://api.scaleway.ai/ai-models/v1",
        key_env_vars=["SCALEWAY_API_KEY"],
        default_models=[
            "scaleway/mistral-small-3.2-24b-instruct-2506",
            "scaleway/qwen3-coder-30b-a3b-instruct",
            "scaleway/llama-3.3-70b-instruct",
        ],
        docs_url="https://www.scaleway.com/en/docs/ai-models/",
        notes="default_models.json 已预置 3 个模型,registry 本批次补齐;欧洲节点",
    ),
    FreeProvider(
        provider_code="alibaba_intl",
        display_name="Alibaba Intl(阿里国际,1M/模型/月)",
        category=ProviderCategory.INTERNATIONAL,
        signup_url="https://www.alibabacloud.com/en/en/dashscope",
        free_quota="1M tokens/模型/月免费(Qwen3 235B / Qwen3 Coder Plus)",
        rate_limit="60 RPM",
        default_base_url="https://dashscope-intl.aliyuncs.com/compatible-mode/v1",
        key_env_vars=["ALIBABA_INTL_API_KEY", "DASHSCOPE_API_KEY"],
        default_models=[
            "alibaba-intl/qwen3-235b-a22b",
            "alibaba-intl/qwen3-coder-plus",
            "alibaba-intl/qwen-max",
            "alibaba-intl/qwen-plus",
            "alibaba-intl/qwen-turbo",
        ],
        docs_url="https://www.alibabacloud.com/help/en/dashscope/",
        notes="default_models.json 已预置 5 个模型,registry 本批次补齐;阿里国际版,与国内 dashscope 互补",
    ),
    FreeProvider(
        provider_code="navy",
        display_name="Navy(新免费 provider)",
        category=ProviderCategory.INTERNATIONAL,
        signup_url="https://navy.ai",
        free_quota="免费层(OmniRoute v3.8.49 新增)",
        rate_limit="60 RPM",
        default_base_url="https://api.navy.ai/v1",
        key_env_vars=["NAVY_API_KEY"],
        default_models=["auto"],
        docs_url="https://docs.navy.ai",
        notes="OmniRoute v3.8.49 新增;信息有限,建议先小流量测试",
    ),

    # ---------------- 对齐 Node 端 VENDORS 事实源补齐(2026-09-21 立) ----------------
    # 依据 apps/api/src/routes/ai-vendors/_shared.ts VENDORS(113 家)逐家核对,补齐本注册表缺失的
    # 对话 LLM provider。provider_code 与网关 _PREFIX_TO_PROVIDER_CODE / key_env_vars 与 Node keyEnv
    # 命名对齐,便于双端 key 状态一致。注意:
    # - 既有 48 条一律不动,本区块纯追加。
    # - 同端点但 Node 端 env 名不同的走别名条目(step/baidu/vercel),备注已说明。
    # - Node VENDORS 中的专有 REST 媒体/向量/平台类(suno/sora2/coze/jimeng4/n8n/tencent(3D)/
    #   volcengine(visual)/stability/flux/kling/runway/luma/elevenlabs/ideogram/recraft/vidu/
    #   pixverse/fishaudio/leonardo/firefly/deepgram/cartesia/azure-speech/voyage/jina/assemblyai/
    #   replicate/mureka/playai/hume/inworld/soniox/gladia/getimg/bria/freepik)无对话 chat 模型,
    #   不属本注册表语义(聊天模型选择器),由 Node 代理直连,fal 除外(任务显式要求收录)。
    # - default_models 为官方真实模型 ID 的保守稳型(旗舰+轻量),最终清单以 model_sync 从
    #   {api_base}/models 实时同步为准。
    FreeProvider(
        provider_code="openai",
        display_name="OpenAI(GPT 官方)",
        category=ProviderCategory.INTERNATIONAL,
        signup_url="https://platform.openai.com/api-keys",
        free_quota="无免费层(按量计费)",
        rate_limit="按 tier 分级",
        default_base_url="https://api.openai.com/v1",
        key_env_vars=["OPENAI_API_KEY"],
        default_models=["openai/gpt-4o", "openai/gpt-4o-mini", "openai/gpt-4.1-mini"],
        docs_url="https://platform.openai.com/docs",
        notes="官方 API,OpenAI 协议本源;gpt-* / o1-* / o3-* 前缀默认路由到此 provider",
    ),
    FreeProvider(
        provider_code="anthropic",
        display_name="Anthropic(Claude 官方)",
        category=ProviderCategory.INTERNATIONAL,
        signup_url="https://console.anthropic.com",
        free_quota="无免费层(按量计费)",
        rate_limit="按 tier 分级",
        default_base_url="https://api.anthropic.com",
        key_env_vars=["ANTHROPIC_API_KEY"],
        default_models=[
            "anthropic/claude-sonnet-4-20250514",
            "anthropic/claude-3-7-sonnet-latest",
            "anthropic/claude-3-5-haiku-latest",
        ],
        protocol="anthropic_messages",
        docs_url="https://docs.anthropic.com",
        notes="官方 Messages API(x-api-key + anthropic-version 头);claude-* 前缀路由到此",
    ),
    FreeProvider(
        provider_code="xai",
        display_name="xAI(Grok 官方)",
        category=ProviderCategory.INTERNATIONAL,
        signup_url="https://console.x.ai",
        free_quota="无免费层(按量计费)",
        rate_limit="按 tier 分级",
        default_base_url="https://api.x.ai/v1",
        key_env_vars=["XAI_API_KEY"],
        default_models=["grok-4", "grok-4-fast", "grok-3-mini"],
        docs_url="https://docs.x.ai",
        notes="OpenAI 兼容;grok-* 前缀路由到此",
    ),
    FreeProvider(
        provider_code="azure",
        display_name="Azure OpenAI(企业版)",
        category=ProviderCategory.INTERNATIONAL,
        signup_url="https://portal.azure.com",
        free_quota="无免费层(Azure 订阅按量计费)",
        rate_limit="按 deployment 配额",
        default_base_url="",  # 端点含资源名(https://{resource}.openai.azure.com),须逐配置填写
        key_env_vars=["AZURE_OPENAI_API_KEY", "AZURE_API_KEY"],
        default_models=["azure/gpt-4o", "azure/gpt-4o-mini", "azure/gpt-4.1-mini"],
        docs_url="https://learn.microsoft.com/azure/ai-services/openai/",
        notes="企业版;需自建 deployment,api_base 填资源级端点(可含 /openai/deployments/{id}),api-version 由配置带",
    ),
    FreeProvider(
        provider_code="bedrock",
        display_name="AWS Bedrock",
        category=ProviderCategory.INTERNATIONAL,
        signup_url="https://console.aws.amazon.com/bedrock",
        free_quota="无免费层(AWS 按量计费)",
        rate_limit="按 region 配额",
        default_base_url="https://bedrock-runtime.us-east-1.amazonaws.com/openai/v1",
        key_env_vars=["BEDROCK_API_KEY", "AWS_ACCESS_KEY_ID", "AWS_BEDROCK_API_KEY"],
        default_models=[
            "bedrock/anthropic.claude-sonnet-4-20250514-v1:0",
            "bedrock/amazon.nova-pro-v1:0",
            "bedrock/meta.llama3-3-70b-instruct-v1:0",
        ],
        docs_url="https://docs.aws.amazon.com/bedrock",
        notes="AWS 托管多模型;Bedrock OpenAI 兼容端点或 LiteLLM 原生(AWS_ACCESS_KEY_ID/SECRET)",
    ),
    FreeProvider(
        provider_code="spark",
        display_name="讯飞星火 Spark",
        category=ProviderCategory.DOMESTIC,
        signup_url="https://console.xfyun.cn",
        free_quota="spark lite 限免(以官网为准)",
        rate_limit="按套餐 RPM",
        default_base_url="https://spark-api-open.xf-yun.com/v1",
        key_env_vars=["SPARK_API_KEY"],
        default_models=["4.0Ultra", "max-32k", "lite"],
        docs_url="https://www.xfyun.cn/doc/spark/HTTP调用文档.html",
        notes="OpenAI 兼容 HTTP 端点;spark-* 前缀路由到此;模型名官方大小写敏感(4.0Ultra)",
    ),
    FreeProvider(
        provider_code="baichuan",
        display_name="百川 Baichuan",
        category=ProviderCategory.DOMESTIC,
        signup_url="https://platform.baichuan-ai.com",
        free_quota="无免费层(按量计费)",
        rate_limit="按套餐 RPM",
        default_base_url="https://api.baichuan-ai.com/v1",
        key_env_vars=["BAICHUAN_API_KEY"],
        default_models=["Baichuan4", "Baichuan4-Turbo", "Baichuan4-Air"],
        docs_url="https://platform.baichuan-ai.com/docs",
        notes="OpenAI 兼容;baichuan-* 前缀路由到此",
    ),
    FreeProvider(
        provider_code="sensenova",
        display_name="商汤日日新 SenseNova",
        category=ProviderCategory.DOMESTIC,
        signup_url="https://console.sensecore.cn",
        free_quota="新用户试用额度(以官网为准)",
        rate_limit="按套餐 RPM",
        default_base_url="https://api.sensenova.cn/compatible-mode/v1",
        key_env_vars=["SENSENOVA_API_KEY"],
        default_models=["SenseChat-5", "SenseChat-Turbo", "SenseChat-Lite"],
        docs_url="https://console.sensecore.cn/help/docs/model-as-a-service/nova/",
        notes="OpenAI 兼容模式;sensenova-* 前缀路由到此",
    ),
    FreeProvider(
        provider_code="internlm",
        display_name="书生·浦语 InternLM",
        category=ProviderCategory.DOMESTIC,
        signup_url="https://open.intern-ai.org.cn",
        free_quota="新用户赠送额度(以官网为准)",
        rate_limit="按套餐 RPM",
        default_base_url="https://api.intern-ai.org.cn/v1",
        key_env_vars=["INTERNLM_API_KEY"],
        default_models=["internlm2.5-latest", "internlm3-8b-instruct"],
        docs_url="https://open.intern-ai.org.cn/docs",
        notes="上海AI实验室;OpenAI 兼容;internlm 前缀路由到此",
    ),
    FreeProvider(
        provider_code="byteplus",
        display_name="BytePlus(字节海外 Model Engine)",
        category=ProviderCategory.INTERNATIONAL,
        signup_url="https://console.byteplus.com",
        free_quota="新用户试用额度(以官网为准)",
        rate_limit="按配额",
        default_base_url="https://ark.ap-southeast.bytepluses.com/api/v3",
        key_env_vars=["BYTEPLUS_API_KEY"],
        default_models=["doubao-seed-1-6", "doubao-pro-32k", "doubao-lite-32k"],
        docs_url="https://docs.byteplus.com/en/docs/Model-Engine/",
        notes="火山方舟海外版,OpenAI 兼容;与国内 doubao(ark.cn-beijing)互补",
    ),
    FreeProvider(
        provider_code="pangu",
        display_name="华为盘古 Pangu(ModelArts MaaS)",
        category=ProviderCategory.DOMESTIC,
        signup_url="https://console.huaweicloud.com/modelarts",
        free_quota="无免费层(按量计费)",
        rate_limit="按套餐 RPM",
        default_base_url="https://api.modelarts-maas.com/v1",
        key_env_vars=["PANGU_API_KEY"],
        default_models=["pangu-nlp-n2-324k", "pangu-nlp-n1-32k"],
        docs_url="https://www.huaweicloud.com/product/pangu.html",
        notes="OpenAI 兼容 MaaS 端点;实际可用以 ModelArts 控制台开通的模型/服务为准",
    ),
    FreeProvider(
        provider_code="infini",
        display_name="无问芯穹 Infini-AI",
        category=ProviderCategory.DOMESTIC,
        signup_url="https://cloud.infini-ai.com",
        free_quota="新用户赠送额度(以官网为准)",
        rate_limit="按套餐 RPM",
        default_base_url="https://cloud.infini-ai.com/maas/v1",
        key_env_vars=["INFINI_API_KEY"],
        default_models=["deepseek-r1", "deepseek-v3", "qwen2.5-72b-instruct", "glm-4-9b-chat"],
        docs_url="https://cloud.infini-ai.com/docs",
        notes="OpenAI 兼容 MaaS,聚合 DeepSeek/Qwen/GLM/Llama 等",
    ),
    FreeProvider(
        provider_code="mimo",
        display_name="小米 MiMo",
        category=ProviderCategory.DOMESTIC,
        signup_url="https://xiaomimimo.com",
        free_quota="plan 套餐/试用(以官网为准)",
        rate_limit="按套餐",
        # 2026-09-21 实测纠正:token-plan-cn 域是套餐(plan)专用端点,只认 tp- 前缀凭据;
        # 本项目 MIMO_API_KEY 为 sk- 前缀,走 plan 域必 401 Invalid API Key(曾被误判为 key 失效)。
        default_base_url="https://api.xiaomimimo.com/v1",
        key_env_vars=["MIMO_API_KEY"],
        default_models=["mimo-v2.5", "mimo-v2.5-pro", "mimo-v2.5-asr", "mimo-v2.5-tts"],
        docs_url="https://xiaomimimo.com",
        notes="小米 MiMo 官方端点;2026-09-21 /v1/models 实测 6 个(v2.5/pro/asr/tts/tts-voiceclone/tts-voicedesign),完整清单以同步为准",
    ),
    FreeProvider(
        provider_code="ai360",
        display_name="360智脑 Ai360",
        category=ProviderCategory.DOMESTIC,
        signup_url="https://ai.360.com/platform",
        free_quota="新用户赠送额度(以官网为准)",
        rate_limit="按套餐 RPM",
        default_base_url="https://api.360.cn/v1",
        key_env_vars=["AI360_API_KEY"],
        default_models=["360gpt2-pro", "360gpt-pro", "360gpt-turbo"],
        docs_url="https://ai.360.com/platform/docs",
        notes="OpenAI 兼容",
    ),
    FreeProvider(
        provider_code="longcat",
        display_name="美团 LongCat",
        category=ProviderCategory.DOMESTIC,
        signup_url="https://longcat.ai",
        free_quota="公测期免费额度(以官网为准)",
        rate_limit="按套餐 RPM",
        default_base_url="https://api.longcat.chat/openai/v1",
        key_env_vars=["LONGCAT_API_KEY"],
        default_models=["LongCat-Flash-Chat", "LongCat-Flash-Thinking"],
        docs_url="https://longcat.ai/docs",
        notes="美团龙猫大模型,OpenAI 兼容",
    ),
    FreeProvider(
        provider_code="skywork",
        display_name="昆仑万维天工 Skywork",
        category=ProviderCategory.DOMESTIC,
        signup_url="https://www.skywork.ai",
        free_quota="新用户赠送额度(以官网为准)",
        rate_limit="按套餐 RPM",
        default_base_url="https://api.skywork.ai/v1",
        key_env_vars=["SKYWORK_API_KEY"],
        default_models=["skywork-reasoner", "skywork-chat"],
        docs_url="https://www.skywork.ai/docs",
        notes="OpenAI 兼容;skywork-* 前缀路由到此;模型清单以 /v1/models 同步为准",
    ),
    FreeProvider(
        provider_code="openbmb",
        display_name="面壁 OpenBMB(MiniCPM)",
        category=ProviderCategory.DOMESTIC,
        signup_url="https://openbmb.cn",
        free_quota="新用户赠送额度(以官网为准)",
        rate_limit="按套餐 RPM",
        default_base_url="https://api.openbmb.cn/v1",
        key_env_vars=["OPENBMB_API_KEY"],
        default_models=["MiniCPM4-8B", "MiniCPM-o-2.6"],
        docs_url="https://openbmb.cn/docs",
        notes="OpenAI 兼容;模型清单以 /v1/models 同步为准",
    ),
    FreeProvider(
        provider_code="bailian",
        display_name="阿里云百炼 Bailian",
        category=ProviderCategory.DOMESTIC,
        signup_url="https://bailian.console.aliyun.com",
        free_quota="新模型限时免费额度(以控制台为准)",
        rate_limit="按套餐 RPM",
        default_base_url="https://dashscope.aliyuncs.com/compatible-mode/v1",
        key_env_vars=["BAILIAN_API_KEY", "DASHSCOPE_API_KEY"],
        default_models=["qwen-max", "qwen-plus", "qwen3-coder-plus"],
        docs_url="https://help.aliyun.com/zh/model-studio/",
        notes="与 qwen(dashscope) 同端点;对齐 Node VENDORS bailian(BAILIAN_API_KEY);bailian/ 前缀已入网关前缀表",
    ),
    FreeProvider(
        provider_code="siliconflow",
        display_name="SiliconFlow(硅基流动,对齐命名)",
        category=ProviderCategory.DOMESTIC,
        signup_url="https://cloud.siliconflow.cn",
        free_quota="小模型永久免费 + 新用户额度(同 siliconcloud)",
        rate_limit="按套餐 RPM",
        default_base_url="https://api.siliconflow.cn/v1",
        key_env_vars=["SILICONFLOW_API_KEY", "SILICONCLOUD_API_KEY"],
        default_models=[
            "siliconflow/deepseek-ai/DeepSeek-V3",
            "siliconflow/Qwen/Qwen2.5-72B-Instruct",
            "siliconflow/Qwen/Qwen2.5-7B-Instruct",
        ],
        docs_url="https://docs.siliconflow.cn",
        notes="与 siliconcloud 同平台同端点;对齐 Node VENDORS siliconflow(SILICONFLOW_API_KEY);siliconflow/ 前缀已入网关前缀表",
    ),
    FreeProvider(
        provider_code="step",
        display_name="Step(阶跃星辰,对齐命名)",
        category=ProviderCategory.DOMESTIC,
        signup_url="https://platform.stepfun.com",
        free_quota="plan 套餐(同 stepfun)",
        rate_limit="无限制(plan 套餐)",
        default_base_url="https://api.stepfun.com/step_plan/v1",
        key_env_vars=["STEP_API_KEY", "STEPFUN_API_KEY"],
        default_models=["stepfun/step-3.7-flash", "stepfun/step-3.5-flash"],
        docs_url="https://platform.stepfun.com/docs",
        notes="与 stepfun 同端点;对齐 Node VENDORS step(STEP_API_KEY);模型复用 stepfun/ 前缀路由",
    ),
    FreeProvider(
        provider_code="baidu",
        display_name="百度千帆(对齐命名)",
        category=ProviderCategory.DOMESTIC,
        signup_url="https://console.bce.baidu.com/qianfan",
        free_quota="ERNIE-Speed/Lite 限免(同 wenxin)",
        rate_limit="按套餐 RPM",
        default_base_url="https://qianfan.baidubce.com/v2",
        key_env_vars=["BAIDU_API_KEY", "QIANFAN_API_KEY"],
        default_models=["ernie-4.5-turbo-128k", "ernie-speed-8k", "ernie-lite-8k"],
        docs_url="https://cloud.baidu.com/doc/WENXINWORKSHOP",
        notes="与 wenxin 同端点;对齐 Node VENDORS baidu(BAIDU_API_KEY);ernie-* 前缀路由到 wenxin",
    ),
    FreeProvider(
        provider_code="zai",
        display_name="Z.ai(智谱海外 GLM)",
        category=ProviderCategory.INTERNATIONAL,
        signup_url="https://z.ai",
        free_quota="glm-4.5-flash 免费(以官网为准)",
        rate_limit="按套餐 RPM",
        default_base_url="https://api.z.ai/api/paas/v4",
        key_env_vars=["ZAI_API_KEY"],
        default_models=["zai/glm-4.6", "zai/glm-4.5-flash", "zai/glm-4.5-air"],
        docs_url="https://docs.z.ai",
        notes="智谱海外 OpenAI 兼容端点;zai/ 前缀已入网关前缀表,与国内 zhipu(open.bigmodel.cn)互补",
    ),
    FreeProvider(
        provider_code="minimaxintl",
        display_name="MiniMax International(海外)",
        category=ProviderCategory.INTERNATIONAL,
        signup_url="https://platform.minimax.io",
        free_quota="新用户赠送额度(以官网为准)",
        rate_limit="按套餐 RPM",
        default_base_url="https://api.minimax.io/v1",
        key_env_vars=["MINIMAXINTL_API_KEY"],
        default_models=["MiniMax-M2", "MiniMax-Text-01", "MiniMax-M1-80k"],
        docs_url="https://platform.minimax.io/docs",
        notes="MiniMax 海外 OpenAI 兼容端点,与国内 minimax(api.minimax.chat)互补",
    ),
    FreeProvider(
        provider_code="dashscopeintl",
        display_name="DashScope International(阿里海外)",
        category=ProviderCategory.INTERNATIONAL,
        signup_url="https://www.alibabacloud.com/en/en/dashscope",
        free_quota="1M tokens/模型/月免费(同 alibaba_intl)",
        rate_limit="60 RPM",
        default_base_url="https://dashscope-intl.aliyuncs.com/compatible-mode/v1",
        key_env_vars=["DASHSCOPEINTL_API_KEY", "DASHSCOPE_API_KEY"],
        default_models=["qwen3-235b-a22b", "qwen-plus", "qwen-turbo"],
        docs_url="https://www.alibabacloud.com/help/en/dashscope/",
        notes="与 alibaba_intl 同端点;对齐 Node VENDORS dashscopeintl(DASHSCOPEINTL_API_KEY)",
    ),
    FreeProvider(
        provider_code="vercel",
        display_name="Vercel AI Gateway(对齐命名)",
        category=ProviderCategory.INTERNATIONAL,
        signup_url="https://vercel.com/dashboard",
        free_quota="Hobby plan 免费额度(同 vercel_ai_gateway)",
        rate_limit="按套餐",
        default_base_url="https://ai-gateway.vercel.sh/v1",
        key_env_vars=["VERCEL_API_KEY", "VERCEL_AI_GATEWAY_API_KEY"],
        default_models=["vercel/openai/gpt-4o-mini", "vercel/anthropic/claude-3.5-haiku"],
        docs_url="https://vercel.com/docs/ai-gateway",
        notes="与 vercel_ai_gateway 同端点;对齐 Node VENDORS vercel(VERCEL_API_KEY);vercel/ 前缀已入网关解析表",
    ),
    FreeProvider(
        provider_code="perplexity",
        display_name="Perplexity(Sonar 在线搜索)",
        category=ProviderCategory.INTERNATIONAL,
        signup_url="https://www.perplexity.ai/settings/api",
        free_quota="无免费层(按量计费)",
        rate_limit="按套餐 RPM",
        default_base_url="https://api.perplexity.ai",
        key_env_vars=["PERPLEXITY_API_KEY"],
        default_models=["sonar", "sonar-pro", "sonar-reasoning-pro"],
        docs_url="https://docs.perplexity.ai",
        notes="在线 LLM(带搜索引用);sonar-* 前缀路由到此",
    ),
    FreeProvider(
        provider_code="lingyiwanwu",
        display_name="零一万物 Yi(LingYi)",
        category=ProviderCategory.INTERNATIONAL,
        signup_url="https://platform.lingyiwanwu.com",
        free_quota="新用户赠送额度(以官网为准)",
        rate_limit="按套餐 RPM",
        default_base_url="https://api.lingyiwanwu.com/v1",
        key_env_vars=["LINGYIWANWU_API_KEY", "YI_API_KEY"],
        default_models=["yi-lightning", "yi-large"],
        docs_url="https://platform.lingyiwanwu.com/docs",
        notes="OpenAI 兼容;yi-* 前缀路由到 yi 配置(YI_API_KEY),本条对齐 Node LINGYIWANWU_API_KEY",
    ),
    FreeProvider(
        provider_code="meta",
        display_name="Meta(Llama API 官方)",
        category=ProviderCategory.INTERNATIONAL,
        signup_url="https://llama.developer.meta.com",
        free_quota="预览期免费额度(以官网为准)",
        rate_limit="按套餐 RPM",
        default_base_url="https://api.llama.com/compat/v1",
        key_env_vars=["META_API_KEY"],
        default_models=[
            "Llama-4-Maverick-17B-128E-Instruct-FP8",
            "Llama-4-Scout-17B-16E-Instruct",
            "Llama-3.3-70B-Instruct",
        ],
        docs_url="https://llama.developer.meta.com/docs",
        notes="Llama API 官方 OpenAI 兼容端点;llama-* 前缀路由到此",
    ),
    FreeProvider(
        provider_code="ai21",
        display_name="AI21 Labs(Jamba)",
        category=ProviderCategory.INTERNATIONAL,
        signup_url="https://studio.ai21.com",
        free_quota="新用户试用 credits(以官网为准)",
        rate_limit="按套餐 RPM",
        default_base_url="https://api.ai21.com/v1",
        key_env_vars=["AI21_API_KEY"],
        default_models=["jamba-1.6-large", "jamba-1.6-mini"],
        docs_url="https://docs.ai21.com",
        notes="OpenAI 兼容;jamba-* 前缀路由到此",
    ),
    FreeProvider(
        provider_code="writer",
        display_name="Writer(Palmyra)",
        category=ProviderCategory.INTERNATIONAL,
        signup_url="https://dev.writer.com",
        free_quota="试用期额度(以官网为准)",
        rate_limit="按套餐 RPM",
        default_base_url="https://api.writer.com/v1",
        key_env_vars=["WRITER_API_KEY"],
        default_models=["palmyra-x-004", "palmyra-med", "palmyra-creative"],
        docs_url="https://dev.writer.com/docs",
        notes="企业级 Palmyra 系列,OpenAI 兼容",
    ),
    FreeProvider(
        provider_code="upstage",
        display_name="Upstage(Solar)",
        category=ProviderCategory.INTERNATIONAL,
        signup_url="https://console.upstage.ai",
        free_quota="新用户 $10 credits(以官网为准)",
        rate_limit="按套餐 RPM",
        default_base_url="https://api.upstage.ai/v1/solar",
        key_env_vars=["UPSTAGE_API_KEY"],
        default_models=["upstage/solar-pro", "upstage/solar-mini"],
        docs_url="https://developers.upstage.ai",
        notes="OpenAI 兼容;upstage/ 前缀已入网关前缀表",
    ),
    FreeProvider(
        provider_code="deepinfra",
        display_name="DeepInfra",
        category=ProviderCategory.INTERNATIONAL,
        signup_url="https://deepinfra.com/dash",
        free_quota="无免费层(按量计费,价格低)",
        rate_limit="按套餐 RPM",
        default_base_url="https://api.deepinfra.com/v1/openai",
        key_env_vars=["DEEPINFRA_API_KEY"],
        default_models=[
            "deepinfra/deepseek-ai/DeepSeek-V3",
            "deepinfra/meta-llama/Llama-3.3-70B-Instruct",
            "deepinfra/Qwen/Qwen2.5-72B-Instruct",
        ],
        docs_url="https://deepinfra.com/docs",
        notes="开源模型托管,OpenAI 兼容;deepinfra/ 前缀已入网关前缀表",
    ),
    FreeProvider(
        provider_code="novita",
        display_name="Novita AI",
        category=ProviderCategory.INTERNATIONAL,
        signup_url="https://novita.ai/dashboard",
        free_quota="新用户赠送额度(以官网为准)",
        rate_limit="按套餐 RPM",
        default_base_url="https://api.novita.ai/v3/openai",
        key_env_vars=["NOVITA_API_KEY"],
        default_models=[
            "novita/deepseek/deepseek-v3",
            "novita/meta-llama/llama-3.3-70b-instruct",
            "novita/qwen/qwen-2.5-72b-instruct",
        ],
        docs_url="https://novita.ai/docs",
        notes="开源模型聚合,OpenAI 兼容;novita/ 前缀已入网关前缀表",
    ),
    FreeProvider(
        provider_code="featherless",
        display_name="Featherless AI",
        category=ProviderCategory.INTERNATIONAL,
        signup_url="https://featherless.ai",
        free_quota="订阅制(4000+ 开源模型无限调用)",
        rate_limit="按套餐 RPM",
        default_base_url="https://api.featherless.ai/v1",
        key_env_vars=["FEATHERLESS_API_KEY"],
        default_models=[
            "featherless/meta-llama/Meta-Llama-3.1-8B-Instruct",
            "featherless/Qwen/Qwen2.5-72B-Instruct",
        ],
        docs_url="https://featherless.ai/docs",
        notes="订阅制开源模型托管;featherless/ 前缀已入网关前缀表",
    ),
    FreeProvider(
        provider_code="kluster",
        display_name="Kluster AI",
        category=ProviderCategory.INTERNATIONAL,
        signup_url="https://www.kluster.ai",
        free_quota="无免费层(按量计费,价格低)",
        rate_limit="按套餐 RPM",
        default_base_url="https://api.kluster.ai/v1",
        key_env_vars=["KLUSTER_API_KEY"],
        default_models=[
            "klusterai/Meta-Llama-3.3-70B-Instruct-Turbo",
            "klusterai/Meta-Llama-3.1-8B-Instruct-Turbo",
            "deepseek-ai/DeepSeek-R1-Distill-Llama-8B",
        ],
        docs_url="https://docs.kluster.ai",
        notes="OpenAI 兼容,Turbo 系列性价比高",
    ),
    FreeProvider(
        provider_code="chutes",
        display_name="Chutes",
        category=ProviderCategory.INTERNATIONAL,
        signup_url="https://chutes.ai",
        free_quota="存入 $5 解锁(无纯免费层)",
        rate_limit="按套餐 RPM",
        default_base_url="https://api.chutes.ai/v1",
        key_env_vars=["CHUTES_API_KEY"],
        default_models=["deepseek-ai/DeepSeek-V3-0324", "Qwen/Qwen3-235B-A22B", "zai-org/glm-4.5-air"],
        docs_url="https://chutes.ai/docs",
        notes="去中心化推理网络(基于 Bittensor),OpenAI 兼容",
    ),
    FreeProvider(
        provider_code="parasail",
        display_name="Parasail AI",
        category=ProviderCategory.INTERNATIONAL,
        signup_url="https://www.parasail.io",
        free_quota="无免费层(按量计费)",
        rate_limit="按套餐 RPM",
        default_base_url="https://api.parasail.io/v1",
        key_env_vars=["PARASAIL_API_KEY"],
        default_models=["deepseek-ai/DeepSeek-V3-0324", "deepseek-ai/DeepSeek-R1-0528"],
        docs_url="https://docs.parasail.io",
        notes="开源模型推理,OpenAI 兼容;parasail/ 前缀已入网关前缀表",
    ),
    FreeProvider(
        provider_code="friendli",
        display_name="FriendliAI",
        category=ProviderCategory.INTERNATIONAL,
        signup_url="https://friendli.ai",
        free_quota="按量计费(以官网为准)",
        rate_limit="按套餐 RPM",
        default_base_url="https://inference.friendli.ai/v1",
        key_env_vars=["FRIENDLI_API_KEY"],
        default_models=[
            "friendli/deepseek-ai/DeepSeek-R1",
            "friendli/meta-llama-3.3-70b-instruct",
            "friendli/qwen2.5-72b-instruct",
        ],
        docs_url="https://friendli.ai/docs",
        notes="OpenAI 兼容;friendli/ 前缀已入网关前缀表",
    ),
    FreeProvider(
        provider_code="nscale",
        display_name="Nscale",
        category=ProviderCategory.INTERNATIONAL,
        signup_url="https://nscale.com",
        free_quota="按量计费(以官网为准)",
        rate_limit="按套餐 RPM",
        default_base_url="https://inference.api.nscale.com/v1",
        key_env_vars=["NSCALE_API_KEY"],
        default_models=["deepseek-ai/DeepSeek-R1-0528", "meta-llama/Llama-3.3-70B-Instruct", "Qwen/Qwen3-235B-A22B"],
        docs_url="https://docs.nscale.com",
        notes="欧洲 GPU 云,OpenAI 兼容",
    ),
    FreeProvider(
        provider_code="gmi",
        display_name="GMI Cloud",
        category=ProviderCategory.INTERNATIONAL,
        signup_url="https://www.gmicloud.ai",
        free_quota="按量计费(以官网为准)",
        rate_limit="按套餐 RPM",
        default_base_url="https://api.gmi-serving.com/v1",
        key_env_vars=["GMI_API_KEY"],
        default_models=["deepseek-ai/DeepSeek-R1", "meta-llama/Llama-3.3-70B-Instruct"],
        docs_url="https://docs.gmicloud.ai",
        notes="GPU 云推理,OpenAI 兼容",
    ),
    FreeProvider(
        provider_code="ubicloud",
        display_name="Ubicloud(AI 推理)",
        category=ProviderCategory.INTERNATIONAL,
        signup_url="https://www.ubicloud.com",
        free_quota="按量计费,价格低(开源透明定价)",
        rate_limit="按套餐 RPM",
        default_base_url="https://ai.ubicloud.com/v1",
        key_env_vars=["UBICLOUD_API_KEY"],
        default_models=["meta-llama/Llama-3.1-8B-Instruct", "mistralai/Mixtral-8x7B-Instruct-v0.1"],
        docs_url="https://www.ubicloud.com/docs",
        notes="开源云平台 AI 推理,OpenAI 兼容",
    ),
    FreeProvider(
        provider_code="inferencenet",
        display_name="Inference.net",
        category=ProviderCategory.INTERNATIONAL,
        signup_url="https://inference.net",
        free_quota="按量计费(以官网为准)",
        rate_limit="按套餐 RPM",
        default_base_url="https://api.inference.net/v1",
        key_env_vars=["INFERENCENET_API_KEY", "INFERENCE_NET_API_KEY"],
        default_models=[
            "inferencenet/deepseek-ai/deepseek-r1",
            "inferencenet/meta-llama/llama-3.3-70b-instruct",
        ],
        docs_url="https://inference.net/docs",
        notes="OpenAI 兼容;inferencenet/ 前缀已入网关解析表(配置名 inference_net,读 INFERENCE_NET_API_KEY)",
    ),
    FreeProvider(
        provider_code="xinference",
        display_name="Xinference(自托管)",
        category=ProviderCategory.LOCAL,
        signup_url="https://github.com/xorbitsai/inference",
        free_quota="永久免费(本地部署)",
        rate_limit="无限制(本地)",
        default_base_url="http://localhost:9997/v1",
        key_env_vars=[],
        default_models=["xinference/llama-3.3-70b-instruct", "xinference/qwen2.5-72b-instruct"],
        docs_url="https://inference.readthedocs.io",
        notes="xorbitsai 开源推理框架,OpenAI 兼容;模型以本地启动列表为准,对齐 Node VENDORS xinference",
    ),
    FreeProvider(
        provider_code="fal",
        display_name="Fal.ai(媒体生成聚合)",
        category=ProviderCategory.INTERNATIONAL,
        signup_url="https://fal.ai/dashboard/keys",
        free_quota="无免费层(按量计费,按秒计 GPU 费)",
        rate_limit="按套餐 RPM",
        default_base_url="https://queue.fal.run",
        key_env_vars=["FAL_API_KEY"],
        default_models=[
            "fal-ai/flux/dev",
            "fal-ai/minimax/hailuo-02/standard",
            "fal-ai/kling-video/v2/master/text-to-video",
        ],
        protocol="fal_queue",
        docs_url="https://docs.fal.ai",
        notes=(
            "⚠️ 非对话 LLM:图像/视频/音频生成聚合队列(异步提交 + 轮询),不走 openai_chat 协议,"
            "不会进聊天模型选择器(无 chat 模型端点,可用性过滤自动剔除)。收录以对齐 Node VENDORS fal; "
            "模型经 MCP 媒体工具链调用,以 fal.ai 模型广场实际 ID 为准。"
        ),
    ),

    # ---------------- P3-2 法务评估:ToS 禁止接入的 provider(2026-07-30 立) ----------------
    FreeProvider(
        provider_code="kiro",
        display_name="Kiro(AWS,AI IDE,免费 Claude)",
        category=ProviderCategory.INTERNATIONAL,
        signup_url="https://kiro.dev",
        free_quota="免费 Claude 接入(AI IDE 内置,通过 AWS Bedrock)",
        rate_limit="未公开(IDE 内使用)",
        default_base_url="",  # 无公开 API endpoint(IDE 内置,非独立 API 服务)
        key_env_vars=[],  # 无独立 API key(IDE 内置认证,不支持外部调用)
        default_models=["claude-sonnet-4", "claude-3.7-sonnet"],
        docs_url="https://kiro.dev/docs",
        notes=(
            "⚠️ 法务风险(2026-07-30 P3-2 评估):Kiro ToS §3.2 明确禁止第三方集成 / "
            "自动化调用 / 绕过 IDE 界面访问,违反可能导致账号封禁 + 法律追责。"
            "本注册表仅记录该 provider 存在(法务评估存档),不提供技术接入路径。"
            "用户如需使用 Claude,请走 anthropic/ 前缀(官方 API)或 agnes/ 前缀(中转)。"
        ),
    ),
]


# ============================================================================
# 零成本 / 免费额度标注(2026-07-30 立,零成本引流路径 1)
# zero_cost:真·零成本,无需 key 即可调用(众包 / 免费镜像 / keyless API)
# free_tier:有免费额度但需注册 key(永久免费模型 / 试用 credits / 免费层 RPM)
# 本地 LLM(ollama/lmstudio/llamacpp/vllm)不标 zero_cost(category=LOCAL 已区分)
# stepfun/agnes 不标 free_tier(项目已配置付费 plan 套餐,非免费层)
# kiro 不标(法务风险,不接入技术路径)
#
# 边界(2026-11-23 澄清):zero_cost 只表示"上游成本为 0(我们调用它不花钱)",
# 不等于用户侧免费。用户实际扣几倍由 DB ai_model_config_models.points_multiplier
# 决定(生产库中同类条目确实存在 3x 的用户售价);推断函数给这类 provider 的 0x
# 只是"推断初值 / 上游免费档",不得据此认定前端展示与实际扣分不一致。
# ============================================================================
_ZERO_COST_CODES: set[str] = {
    "pollinations",  # 无需 key,免费顶级模型(速率极低)
    "llm7",  # 无需 key,免费镜像(5M tokens/天)
    "opencode_zen",  # 无需 key,轮换免费编码模型
}

_FREE_TIER_CODES: set[str] = {
    # 国内(永久免费模型 / 体验额度)
    "moonshot",  # Kimi-K2 永久免费
    "zhipu",  # glm-4-flash 永久免费
    "deepseek",  # 1 元体验额度
    "minimax",  # 1M tokens 免费
    "qwen",  # 100M tokens 免费
    "doubao",  # 5M tokens 免费体验
    "wenxin",  # ERNIE-Speed-8K 永久免费
    "hunyuan",  # hunyuan-lite 永久免费
    "siliconcloud",  # 小模型永久免费 + 14 元额度
    "modelscope",  # 1M tokens 体验
    # 国际(免费层 RPM/TPM 限制)
    "groq",  # 100 RPM 免费
    "mistral",  # 500K tokens/周
    "cohere",  # 1000 calls/月
    "togetherai",  # $5 credits
    "huggingface",  # 1000 requests/天
    "openrouter",  # :free 后缀模型免费
    "cloudflare_workers_ai",  # 10000 neurons/天
    "nvidia_nim",  # 1000 credits
    "github_models",  # 150 requests/天
    "vercel_ai_gateway",  # 1000 requests/月
    "cerebras",  # Llama-3.1-8B 免费
    "sambanova",  # Llama-3.3-70B 免费
    "fireworksai",  # $1 credits
    # credits provider(注册送额度)
    "lambda",  # 250 credits
    "baseten",  # $30 credits
    "crusoe",  # $10 credits
    "hyperbolic",  # $5 credits
    "nebius",  # $10 credits
    # OmniRoute 补充 provider
    "qoder",  # unlimited free 编码模型
    "ovhcloud",  # 免费层
    "requesty",  # 免费层
    "scaleway",  # 1M/月免费
    "alibaba_intl",  # 1M/模型/月免费
    "navy",  # 免费层
}

for _p in _REGISTRY:
    if _p.provider_code in _ZERO_COST_CODES:
        _p.zero_cost = True
    if _p.provider_code in _FREE_TIER_CODES:
        _p.free_tier = True


class FreeProviderRegistry:
    """免费 provider 注册表查询 API。

    用法:
        from .free_provider_registry import free_provider_registry
        all_providers = free_provider_registry.list_all()
        moonshot = free_provider_registry.get_by_code("moonshot")
        configured = free_provider_registry.list_configured()
        local = free_provider_registry.list_local()
    """

    def __init__(self, registry: list[FreeProvider] | None = None) -> None:
        self._registry = registry or _REGISTRY
        self._by_code: dict[str, FreeProvider] = {p.provider_code: p for p in self._registry}

    def list_all(self) -> list[FreeProvider]:
        """列出所有免费 provider。"""
        return list(self._registry)

    def list_by_category(self, category: ProviderCategory) -> list[FreeProvider]:
        """按分类列出 provider。"""
        return [p for p in self._registry if p.category == category]

    def list_domestic(self) -> list[FreeProvider]:
        """列出国内 provider。"""
        return self.list_by_category(ProviderCategory.DOMESTIC)

    def list_international(self) -> list[FreeProvider]:
        """列出国际 provider。"""
        return self.list_by_category(ProviderCategory.INTERNATIONAL)

    def list_credits(self) -> list[FreeProvider]:
        """列出 credits 类 provider(注册送额度)。"""
        return self.list_by_category(ProviderCategory.CREDITS)

    def list_local(self) -> list[FreeProvider]:
        """列出本地 LLM(无需 key)。"""
        return self.list_by_category(ProviderCategory.LOCAL)

    def list_zero_cost(self) -> list[FreeProvider]:
        """列出真·零成本 provider(无需 key 即可调用,零成本引流核心)。"""
        return [p for p in self._registry if p.zero_cost]

    def list_free_tier(self) -> list[FreeProvider]:
        """列出有免费额度的 provider(需注册 key,但有免费层/永久免费模型)。"""
        return [p for p in self._registry if p.free_tier]

    def get_by_code(self, provider_code: str) -> FreeProvider | None:
        """按 provider_code 查询。"""
        return self._by_code.get(provider_code)

    def get_default_base_url(self, provider_code: str) -> str | None:
        """获取 provider 的默认 base_url(用户未填 api_base 时用此值)。"""
        p = self._by_code.get(provider_code)
        return p.default_base_url if p else None

    def get_default_models(self, provider_code: str) -> list[str]:
        """获取 provider 的推荐免费模型列表。"""
        p = self._by_code.get(provider_code)
        return p.default_models if p else []

    def get_recharge_url(self, provider_code: str) -> str:
        """获取 provider 的充值/billing 页面 URL(管理端"去充值"按钮跳转用)。

        降级策略(2026-07-31 立,用户规则:账户没钱需可视化 + 跳转充值):
        1. 优先用 FreeProvider.recharge_url(显式配置的充值页)
        2. 降级用 FreeProvider.signup_url(注册/控制台页,通常也能找到充值入口)
        3. 都没有 → 返回空字符串(管理端"去充值"按钮不显示)

        本地 LLM / zero_cost provider 返回空(无需充值)。
        """
        p = self._by_code.get(provider_code)
        if not p:
            return ""
        if p.category == ProviderCategory.LOCAL or p.zero_cost:
            return ""
        return p.recharge_url or p.signup_url or ""

    def get_balance_endpoint(self, provider_code: str) -> str:
        """获取 provider 的余额查询端点 URL(完整 URL,用于 HTTP 调用)。

        返回空字符串表示该 provider 不支持余额查询,应降级到推理请求 ping。
        balance_endpoint 字段可以是完整 URL 或相对路径(自动拼接到 default_base_url)。
        """
        p = self._by_code.get(provider_code)
        if not p:
            return ""
        ep = p.balance_endpoint
        if not ep:
            return ""
        if ep.startswith(("http://", "https://")):
            return ep
        if not p.default_base_url:
            return ""
        return p.default_base_url.rstrip("/") + "/" + ep.lstrip("/")

    def is_key_configured(self, provider_code: str) -> ProviderStatus:
        """检测 provider 的 key 配置状态。

        判定规则:
        1. 本地 LLM(ollama/lmstudio/llamacpp/vllm)→ LOCAL(无需 key)
        2. 任一 key_env_vars 在环境变量中配置且非空 → CONFIGURED
        3. 否则 → NOT_CONFIGURED

        注意:本函数只检测环境变量(.env),不查 DB 的 ai_model_config 表。
        完整状态检测应在 API 层(同时查 env + DB),由 Dashboard 调用。
        """
        p = self._by_code.get(provider_code)
        if not p:
            return ProviderStatus.NOT_CONFIGURED

        if p.category == ProviderCategory.LOCAL:
            return ProviderStatus.LOCAL

        if not p.key_env_vars:
            return ProviderStatus.NOT_CONFIGURED

        for env_var in p.key_env_vars:
            val = os.environ.get(env_var, "").strip()
            if val:
                return ProviderStatus.CONFIGURED
        return ProviderStatus.NOT_CONFIGURED

    def list_configured(self) -> list[FreeProvider]:
        """列出已配置 key 的 provider(从环境变量检测)。"""
        return [
            p for p in self._registry
            if self.is_key_configured(p.provider_code) == ProviderStatus.CONFIGURED
        ]

    def list_not_configured(self) -> list[FreeProvider]:
        """列出未配置 key 的 provider(需用户填 key)。"""
        return [
            p for p in self._registry
            if self.is_key_configured(p.provider_code) == ProviderStatus.NOT_CONFIGURED
        ]

    def to_dashboard_dict(self) -> list[dict[str, Any]]:
        """转为 Dashboard 展示用的 list[dict](含 status 字段)。

        2026-10-26:永久退役的 provider **不进面板**(名单与可用性面/同步面/调用面同源)。
        实测依据:该端点(GET /llm/free-providers)无鉴权且 web 端有转发 ⇒ 是**用户可见**的
        「免费 provider 矩阵」;留着已退役厂商 = 用户仍看得到它的申请入口与默认模型档,
        选中后必然失败(与机主「永久除名、不提充值」正相反)。
        """
        from ..core.default_model import is_retired_provider

        result: list[dict[str, Any]] = []
        for p in self._registry:
            if is_retired_provider(p.provider_code):
                continue
            result.append({
                "provider_code": p.provider_code,
                "display_name": p.display_name,
                "category": p.category.value,
                "signup_url": p.signup_url,
                "free_quota": p.free_quota,
                "rate_limit": p.rate_limit,
                "default_base_url": p.default_base_url,
                "key_env_vars": p.key_env_vars,
                "default_models": p.default_models,
                "protocol": p.protocol,
                "docs_url": p.docs_url,
                "notes": p.notes,
                "zero_cost": p.zero_cost,
                "free_tier": p.free_tier,
                "status": self.is_key_configured(p.provider_code).value,
            })
        return result

    def __len__(self) -> int:
        return len(self._registry)


# 模块级单例
free_provider_registry = FreeProviderRegistry()


# ============================================================================
# 积分消耗倍数推断(2026-07-31 立,P0: /llm/models 端点为每个模型附加 points_multiplier)
# 5 档梯度:免费(0x)/ 经济(1x)/ 标准(3x)/ 高级(10x)/ 旗舰(30x)。
# 2026-11-23 起:关键词表与判定顺序只住在共享规则源
# packages/shared/src/constants/points-multiplier-rules.json;本模块委托
# points_multiplier_inference 解释器执行,不再本地抄关键词表(Python 与 TS 同源同结果,
# 跨语言一致性由共享语料 points-multiplier-corpus.json 与 ai-service parity pytest 钉住)。
# ============================================================================


def infer_points_multiplier(model_id: str) -> float:
    """根据 model_id 推断积分消耗倍数(5 档梯度)。

    委托 :mod:`app.services.points_multiplier_inference` 解释器执行;规则数据由共享
    JSON 派生,与 TS 侧同序同结果。

    返回值:
    - 0.0: 免费模型(本地 / 上游 zero_cost provider)
    - 1.0: 经济模型(mini / flash / lite / nano / haiku / ocr / small)
    - 3.0: 标准模型(sonnet / gpt-4o / deepseek / glm-4 / qwen-max / thinking)
    - 10.0: 高级模型(gpt-5 / gemini pro / pro / max / turbo / 长上下文旗舰)
    - 30.0: 旗舰模型(opus / o1 / o3 / gpt-5.5 / gpt-5.6-sol / gpt-5.6-terra)

    无法匹配任何关键词时返回 1.0(默认经济档,避免高估用户消耗)。

    Args:
        model_id: 模型标识(如 "claude-3-5-sonnet-20241022" / "gpt-4o-mini" /
            "ollama/llama3" / "deepseek-chat")。大小写不敏感,允许传空字符串。

    Returns:
        积分消耗倍数(0.0 / 1.0 / 3.0 / 10.0 / 30.0)。

    Examples:
        >>> infer_points_multiplier("claude-3-opus-20240229")
        30.0
        >>> infer_points_multiplier("gpt-4o-mini")
        1.0
        >>> infer_points_multiplier("deepseek-chat")
        3.0
        >>> infer_points_multiplier("deepseek-v4.1-flash")
        1.0
        >>> infer_points_multiplier("thinkingmachines/inkling")
        3.0
        >>> infer_points_multiplier("ollama/llama3")
        0.0
        >>> infer_points_multiplier("")
        1.0
    """
    return _infer_points_multiplier(model_id)
# ⁠​‌​​‌​​‌‍‍​‌​​‌​​​‍‍​‌​‌​‌​‌‍‍​‌​​‌​​‌‍‍​​‌​‌‌​‌‍‍​‌​​​​​‌‍‍​‌​​‌​​‌‍‍‌​‌‌​‌‌‌‍‍‌‌​​‌‌​​‌‌‌‌​‌​‍‍‌‌​‌‌​​​‌​​​‌‌‌‍‍​‌​​​​​‌‍‍​‌​​‌​​‌‍‍‌​‌‌​‌‌‌‍‍‌‌​​‌‌‌​‌​​‌‌‌​‍‍‌‌​​‌‌​​​‌​​‌​‌‍‍‌​‌‌‌​‌‌‌​‌‌‌​‌‍‍‌​‌‌​‌‌‌‍‍​‌​​‌‌​​‍‍​‌​​​​‌‌‍‍‌​‌‌​‌‌‌‍‍​‌‌​​​​‌‍‍​‌‌​‌​​‌‍‍​‌‌‌‌​‌​‍‍​‌‌​‌​​​‍‍​‌‌‌​​‌‌‍‍​​‌​‌‌‌​‍‍​‌‌‌​‌​​‍‍​‌‌​‌‌‌‌‍‍​‌‌‌​​​​‍‍‌​‌‌​‌‌‌‍‍​‌​‌​​​​‍‍​‌​‌​​‌​‍‍​‌​​‌‌‌‌‍‍​‌​‌​‌‌​‍‍​‌​​​‌​‌‍‍​‌​​‌‌‌​‍‍​‌​​​​​‌‍‍​‌​​‌‌‌​‍‍​‌​​​​‌‌‍‍​‌​​​‌​‌‍‍​​‌​‌‌​‌‍‍​​‌‌​​‌​‍‍​​‌‌​​​​‍‍​​‌‌​​‌​‍‍​​‌‌​‌‌​⁠
