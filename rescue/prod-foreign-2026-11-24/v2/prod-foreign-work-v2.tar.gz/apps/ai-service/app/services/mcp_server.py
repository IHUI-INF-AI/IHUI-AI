# © 2026 IHUI AI (智汇AI) · 版权所有者: 李春川 (Li Chunchuan) · https://aizhs.top
# Provenance-watermarked. 未授权商用可被溯源追责 (Apache-2.0 须保留本声明与 NOTICE)。
# [IHUI-AI-PROVENANCE]:⁠​‌​​‌​​‌‍‍​‌​​‌​​​‍‍​‌​‌​‌​‌‍‍​‌​​‌​​‌‍‍​​‌​‌‌​‌‍‍​‌​​​​​‌‍‍​‌​​‌​​‌‍‍‌​‌‌​‌‌‌‍‍‌‌​​‌‌​​‌‌‌‌​‌​‍‍‌‌​‌‌​​​‌​​​‌‌‌‍‍​‌​​​​​‌‍‍​‌​​‌​​‌‍‍‌​‌‌​‌‌‌‍‍‌‌​​‌‌‌​‌​​‌‌‌​‍‍‌‌​​‌‌​​​‌​​‌​‌‍‍‌​‌‌‌​‌‌‌​‌‌‌​‌‍‍‌​‌‌​‌‌‌‍‍​‌​​‌‌​​‍‍​‌​​​​‌‌‍‍‌​‌‌​‌‌‌‍‍​‌‌​​​​‌‍‍​‌‌​‌​​‌‍‍​‌‌‌‌​‌​‍‍​‌‌​‌​​​‍‍​‌‌‌​​‌‌‍‍​​‌​‌‌‌​‍‍​‌‌‌​‌​​‍‍​‌‌​‌‌‌‌‍‍​‌‌‌​​​​‍‍‌​‌‌​‌‌‌‍‍​‌​‌​​​​‍‍​‌​‌​​‌​‍‍​‌​​‌‌‌‌‍‍​‌​‌​‌‌​‍‍​‌​​​‌​‌‍‍​‌​​‌‌‌​‍‍​‌​​​​​‌‍‍​‌​​‌‌‌​‍‍​‌​​​​‌‌‍‍​‌​​​‌​‌‍‍​​‌​‌‌​‌‍‍​​‌‌​​‌​‍‍​​‌‌​​​​‍‍​​‌‌​​‌​‍‍​​‌‌​‌‌​⁠

"""MCP 服务端。

定义 11 个工具、3 个资源、3 个提示词,并提供统一的查询/调用接口。
工具实现为真实文件系统/网络操作,无外部依赖时返回降级结果。
"""

import asyncio
import contextvars
import difflib
import functools
import json
import math
import os
import re
import shlex
import stat
import sys
import time
from collections.abc import Awaitable, Callable, Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any, Final, Literal, TypedDict, cast
from urllib.parse import parse_qs, quote_plus, urlparse

# 会话寻址投递的 kind 值域单源(§0.6):工具 schema 的 enum 与 handler 校验同吃这一份白名单
from app.services.agent_comm import _NAMABLE_MESSAGE_TYPES

if TYPE_CHECKING:
    from .agent_orchestrator import AgentOrchestrator

# 语义压缩回捞层(只读检索工具):复用 vector_memory 单例做语义回捞
# 2026-10-21(五开关按用户生效):本模块 exec_policy_mode 的档位一律经
# `agent_security_prefs.resolve_security_config(主体)` 解析 —— 进程默认 ⊕ 该用户显式覆盖。
# 主体唯一来源是 `call_tool` 的 `user_id` 形参(承载层注入)与 agent_loop_v2 在执行工具前
# 发布的作用域;**绝不**读 arguments 里的 `__user_id`(那是 handler 入参,模型可填的形状)。
# 读侧登记 + 编辑前脏判定(2026-10-31,工程化落地 §0.11;遵循统一工程规范
# `cc_file_read_state_cache` / Qoder `file-history`,并在"本仓多会话共写一棵树"这一轴上
# 超越):read_file 成功后登记 (会话, 路径) → 内容指纹;file_edit 落盘前判一次脏 ——
# 默认只在返回体点名(fresh/stale/never_read/undetermined 四档不并桶),显式严格档才拒写。
# 会话身份只取 call_tool 覆盖注入的 `__session_id`(承载层写入,模型自报会被覆盖);
# 判据本体在 app/core/file_read_state.py,本模块只接线、不复算(§0.6)。
from app.core.background_tasks import spawn
from app.core.bounded_ttl_store import BoundedTtlDict
from app.core.command_policy_merge import PolicyOutcome, adjudicate_command
from app.core.file_read_state import (
    judge_read_state,
    read_state_field,
    record_read,
    record_self_write,
)
from app.core.internal_ticket import internal_service_headers
from app.core.vault import filter_vault_env as _filter_vault_env
from app.utils.atomic_io import write_bytes_atomic

from .agent_security_prefs import (
    current_security_principal,
    resolve_security_config,
    security_principal_scope,
)
from .command_streamer import (
    FRAME_READ_EOF,
    FRAME_READ_LINE,
    FRAME_READ_TOO_LARGE,
    PROTOCOL_FRAME_LIMIT_BYTES,
    read_protocol_frame,
)
from .context_recall import context_recall
from .engine_tool_bridge import resolve_engine_tool
from .exec_policy import PolicyDecision, RuleDecision
from .exec_policy import evaluate as exec_policy_evaluate

# 票78「同文件写冲突治理:串行化」档:per-path 写互斥锁 + 写前基线漂移判定。
# 算法本体在 file_write_gate 单一实现(注入式纪律,对齐 stale-lock-claim);
# 本模块只接线 —— 三个写工具(write_file/file_edit/resolve_conflict)的写段
# 共用同一把 per-path 锁,write_file 写前走五态判定(drifted 拦截,force 逃生门)。
from .file_write_gate import classify_write_conflict, get_path_write_lock
from .merge3 import merge3_for_edit

# 1-2 补丁冲突处理:3-way merge 引擎(纯函数,无 IO)
from .merge3 import resolve_conflicts as _merge3_resolve_conflicts

# 批58(三十):敏感目录黑名单收敛为单一权威源(与 file_editor 共用同一常量与匹配函数)。
# 此前本模块的路径校验完全不做敏感目录判定,导致三个写工具可写 .git/hooks/。
from .path_guard import find_sensitive_segment, sensitive_error_message

# V3 #75 后半:懒索引护栏用**枚举层同一份**有界探测出口(该模块只依赖标准库,
# 无重依赖、无回环,所以可以在顶层 import;函数内再 import 一次只会造成两个出处)。
from .rg_fallback_parity import SizeProbe, probe_code_file_count

# P0-2 凭据保险库接线(2026-10-26):run_command 解析/脱敏/环境过滤经此单例
from .session_security import (
    get_session_vault as _get_session_vault,
)
from .session_security import (
    get_vault_store as _get_vault_store,
)

# Qoder 行为对齐(2026-11-08):会话级技能作用域 + 会话待办板。
# 二者都是进程内会话状态(键 (user_id, session_id)),不是产品数据源;
# 设计口径见各自模块头注(skill_scope.py / session_todo.py)。
from .session_todo import format_todos as _format_todos
from .session_todo import normalize_todos as _normalize_todos
from .session_todo import todo_board as _todo_board
from .skill_scope import activate_skill_scope as _activate_skill_scope
from .skill_scope import describe_scope as _describe_skill_scope
from .skill_scope import release_skill_scope as _release_skill_scope

# 阶段化遥测(缺口表 T9 §10 #3,2026-11-05 Z19):段清单/结论词表/结构化结论行的唯一
# 出处在这里,消费方(本模块的 _tool_search_codebase)不自立段名,也不自带第二份词表。
from .stage_telemetry import UNJUDGED, StageRecorder

# 工具面能力门(缺口表 #7,2026-11-01):列表面与执行面共用同一把尺(单源在 tool_surface,
# 它只依赖 capability_matrix ⇒ 与本模块无回环)。
from .tool_surface import capability_denial as _tool_capability_denial
from .tool_surface import filter_visible_tools as _filter_visible_tools

# 工具面惰性装载(缺口表 ⑤,2026-11-05):按具名预算表决定"本轮哪些 schema 进列表"。
# 判据与能力门/模式收窄全部 import 复用(单源见 tool_surface_budget 头注),本模块只负责
# 在列表面这一处把它接上;**执行面一律不受影响**(_TOOLS/_TOOL_HANDLERS 一条不动)。
from .tool_surface_budget import RoundContext as _SurfaceRoundContext
from .tool_surface_budget import apply_tool_surface_budget as _apply_tool_surface_budget

# 2026-07-22 P1 鲁棒性加固:MCP tool 全局超时,防 handler 无限挂起
MCP_GLOBAL_TIMEOUT = 120

# ---------------------------------------------------------------------------
# 工具层安全护栏(Phase 0 · W2:确定性防御,非审批流)
# ---------------------------------------------------------------------------

# 0-2 call_tool 出口统一输出护栏:所有工具返回结果按 token 上限截断,
# 默认 8000 token,env TOOL_OUTPUT_MAX_TOKENS 可覆盖。
_TOOL_OUTPUT_TRUNCATE_MARKER = "…[已截断,共截断 {n} token,可用分页/范围参数获取更多]"
# 受保护 key:其字符串值不被截断,确保 ok/status/error 等控制字段完整
_TRUNCATION_PROTECTED_KEYS = frozenset(
    {"ok", "status", "error", "errorCode", "tool", "matched"}
)


def _get_tool_output_max_tokens() -> int:
    """工具输出 token 上限(env TOOL_OUTPUT_MAX_TOKENS,默认 8000)。"""
    try:
        return max(1, int(os.environ.get("TOOL_OUTPUT_MAX_TOKENS", "8000")))
    except (TypeError, ValueError):
        return 8000


def _estimate_tokens_len(text: str) -> int:
    """轻量 token 估算:len//4(无外部依赖,与 context_compaction 降级策略一致)。"""
    return len(text) // 4


def _network_denial_message(denial_reason: str | None, url: str) -> str:
    """批58(十六):网络审批拒绝的用户可读消息(遵循统一工程规范)。

    把审批门的机器原因码(denied / not_allowed / not_allowed_local)翻译为
    "为什么不能在此处放行"的可读文案,避免模型反复重试同一目标。原因码缺失/
    翻译失败时回退到原有通用文案(与接线前逐零差异)。
    """
    host = ""
    try:
        from urllib.parse import urlparse

        raw = (url or "").strip()
        host = (
            urlparse(raw if "://" in raw else f"https://{raw}").hostname or ""
        ).lower()
    except (ValueError, TypeError):  # pragma: no cover - 解析失败仅影响文案
        host = ""
    try:
        from app.core.network_policy_decision import denied_network_policy_message

        return denied_network_policy_message(str(denial_reason or "denied"), host)
    except Exception:  # noqa: BLE001 - 文案失败绝不改变拒绝语义
        return "网络审批门拒绝: 该目标未获授权(对齐统一规范)"


# ---------------------------------------------------------------------------
# 批58(w3):5 个"已写但零生产引用"模块的真接线(env 开关,默认 off,异常隔离,
# off 时逐字节等价)。风格对齐 agent_loop_v2._auto_compact_window_enabled_from_env。
# 模块路径(均在 app/core/):
#   elicitation_pause.py / mcp_openai_file.py / world_state_tools.py /
#   permission_profiles.py / permissions_instructions.py
# ---------------------------------------------------------------------------


def _mcp_elicitation_pause_enabled_from_env() -> bool:
    """elicitation 计数暂停开关(env MCP_ELICITATION_PAUSE_ENABLED,默认 off)。

    遵循统一工程规范。on/1/true/yes 时启用;默认 off
    时不持有服务实例、不参与任何计数(与现状逐零差异)。
    """
    return os.environ.get(
        "MCP_ELICITATION_PAUSE_ENABLED", "false"
    ).strip().lower() in ("on", "1", "true", "yes")


def _mcp_openai_file_rewrite_enabled_from_env() -> bool:
    """OpenAI 文件参数重写开关(env MCP_OPENAI_FILE_REWRITE_ENABLED,默认 off)。

    遵循统一工程规范。on 时按声明字段把本地路径重写为远端文件载荷;
    默认 off 时工具参数完全不变(逐字节等价)。
    """
    return os.environ.get(
        "MCP_OPENAI_FILE_REWRITE_ENABLED", "false"
    ).strip().lower() in ("on", "1", "true", "yes")


def _mcp_world_state_tools_enabled_from_env() -> bool:
    """延迟工具命名空间开关(env MCP_WORLD_STATE_TOOLS_ENABLED,默认 off)。

    遵循统一工程规范。on 时把延迟工具声明并入工具清单;
    默认 off 时清单逐字节不变。
    """
    return os.environ.get(
        "MCP_WORLD_STATE_TOOLS_ENABLED", "false"
    ).strip().lower() in ("on", "1", "true", "yes")


def _mcp_permission_profiles_enabled_from_env() -> bool:
    """权限档案开关(env MCP_PERMISSION_PROFILES_ENABLED,默认 off)。

    遵循统一工程规范。on 时解析生效档案参与审批决策;解析失败走现状
    默认(降级跳过)。
    """
    return os.environ.get(
        "MCP_PERMISSION_PROFILES_ENABLED", "false"
    ).strip().lower() in ("on", "1", "true", "yes")


def _mcp_permissions_instructions_enabled_from_env() -> bool:
    """权限指令片段开关(env MCP_PERMISSIONS_INSTRUCTIONS_ENABLED,默认 off)。

    遵循统一工程规范。on 时把权限指令片段并入回执;默认 off
    时不注入任何片段(逐字节等价)。
    """
    return os.environ.get(
        "MCP_PERMISSIONS_INSTRUCTIONS_ENABLED", "false"
    ).strip().lower() in ("on", "1", "true", "yes")


# 模块级可注入配置(测试/生产可注入,默认 None = 不触发改写,off 逐字节等价)
_MCP_OPENAI_FILE_INPUT_FIELDS: dict[str, list[str]] | None = None
_MCP_WORLD_STATE_DEFERRED_NAMESPACES: dict[str, str] | None = None
_MCP_PERMISSION_PROFILES: dict[str, Any] | None = None
_MCP_PERMISSION_PROFILES_ACTIVE: str | None = None


# elicitation 服务懒构造单例(构造失败标记 False,避免反复尝试)
_ELICITATION_SERVICE: Any = None


def _get_elicitation_service() -> Any | None:
    """懒构造 ElicitationService;失败/禁用返回 None(降级不启用)。"""
    global _ELICITATION_SERVICE
    if _ELICITATION_SERVICE is None:
        try:
            from app.core.elicitation_pause import ElicitationService

            _ELICITATION_SERVICE = ElicitationService()
        except Exception as e:  # noqa: BLE001 - 模块缺失降级为不启用
            logger.warning("ElicitationService 构造失败(降级不启用): %s", e)
            _ELICITATION_SERVICE = False
    return _ELICITATION_SERVICE or None


async def _openai_file_default_uploader(
    field_name: str, index: int | None, file_path: str
) -> Any:
    """OpenAI 文件上传器默认实现(无真实文件存储时的确定性占位)。

    生产侧应注入真实上传器(经同层机制覆盖本函数);此处保证默认行为可降级、
    不破坏 offline 工具调用(下载地址直接回退为本地路径)。
    """
    from app.core.mcp_openai_file import UploadedFile

    _name = file_path.replace("\\", "/").split("/")[-1] or "file"
    return UploadedFile(download_url=file_path, file_id=file_path, file_name=_name)


def _tool_result_token_estimate(obj: object) -> int:
    """递归估算工具结果中所有字符串值的 token 总数(轻量 len//4)。"""
    if isinstance(obj, str):
        return _estimate_tokens_len(obj)
    total = 0
    if isinstance(obj, dict):
        for v in obj.values():
            total += _tool_result_token_estimate(v)
    elif isinstance(obj, (list, tuple, set)):
        for v in obj:
            total += _tool_result_token_estimate(v)
    return total


def _truncate_tool_output(
    result: dict[str, Any],
    *,
    tool_name: str | None = None,
    session_id: str | None = None,
) -> dict[str, Any]:
    """call_tool 出口统一输出护栏:将超 token 预算的字符串值截断。

    策略(确定性、保持 dict 结构与控制字段完整):
    - 总 token <= 预算 → 原样返回,不加 truncated 标志
    - 超限 → 收集全部字符串叶子(受保护 key 除外),按长度降序贪心截断,
      直到总 token <= 预算;每个被截断字符串追加标记,并置顶层 truncated=True

    批次 2(2026-11-06):截断前先把**完整结果**落盘为工件(`tool_output_artifacts`),
    并在返回体追加 `output_artifact`(bytes/chars/digest/offset/next/complete)与
    `output_continuation` 指引。此前标记只写"可用分页参数获取更多"却没有任何续读
    凭据,模型只能重跑工具 —— 现在任何调用面(main chat / agent loop / supertool)
    都拿到同一份可续读凭据。

    注意:截断量为近似(标记本身占少量 token),已在边界内;目的是防上下文膨胀,
    不保证精确等于预算(误差 < 标记长度)。
    """
    if not isinstance(result, dict):
        return result
    max_tokens = _get_tool_output_max_tokens()
    total = _tool_result_token_estimate(result)
    if total <= max_tokens:
        return result

    # 完整结果先落盘(force=True:token 估算是逐串 floor 求和,与整串估算可能差 1-2,
    # 但只要进入截断分支就必须有工件,不能出现"截断了却没有续读凭据")。
    artifact: dict[str, Any] | None = None
    try:
        from .tool_output_artifacts import maybe_spill_tool_output, serialize_tool_payload

        artifact = maybe_spill_tool_output(
            serialize_tool_payload(result),
            tool_name=tool_name or str(result.get("tool") or ""),
            session_id=session_id,
            keep_chars=0,
            force=True,
        )
    except Exception as e:  # noqa: BLE001 - 工件面异常不许影响工具返回
        logger.warning("[mcp] 工具输出工件落盘失败(降级为纯截断): %s", e)

    # 收集 (parent_container, key, string) 引用(parent 为可变 dict/list)
    leaves: list[tuple[Any, Any, str]] = []

    def _collect(obj: Any, parent: Any, key: Any) -> None:
        if isinstance(obj, str):
            if isinstance(parent, dict) and key in _TRUNCATION_PROTECTED_KEYS:
                return
            leaves.append((parent, key, obj))
        elif isinstance(obj, dict):
            for k, v in obj.items():
                _collect(v, obj, k)
        elif isinstance(obj, list):
            for i, v in enumerate(obj):
                _collect(v, obj, i)

    _collect(result, None, None)
    # 按长度降序,优先截断最大块,最贴近原始信息分布
    leaves.sort(key=lambda item: len(item[2]), reverse=True)

    remaining = total - max_tokens
    plan: list[tuple[Any, Any, int]] = []
    truncated_tokens = 0
    for _parent, _key, s in leaves:
        if remaining <= 0:
            break
        t = _estimate_tokens_len(s)
        if t <= 0:
            continue
        need = min(remaining, t)
        allow = max(0, t - need)
        keep_chars = allow * 4
        # 占位估算:用单字符近似标记开销,真实标记在回填时写入
        new_t = _estimate_tokens_len(s[:keep_chars] + "X")
        delta = t - new_t
        truncated_tokens += delta
        remaining -= delta
        plan.append((_parent, _key, keep_chars))

    if not plan:
        return result  # 边界:所有字符串均为受保护 key 或空,无法截断
    marker = _TOOL_OUTPUT_TRUNCATE_MARKER.format(n=truncated_tokens)
    for parent, key, keep_chars in plan:
        parent[key] = parent[key][:keep_chars] + marker
    result["truncated"] = True
    if artifact is not None:
        # 续读凭据:offset=0 = 从头分页(正文是逐串截断而非前缀截断,给 0 才不丢信息)。
        result["output_artifact"] = {
            "artifact_id": artifact.get("artifactId"),
            "digest": artifact.get("digest"),
            "bytes": artifact.get("bytes"),
            "chars": artifact.get("chars"),
            "offset": 0,
            "next": 0,
            "complete": False,
            "truncated_on_disk": bool(artifact.get("truncatedOnDisk")),
        }
        result["output_continuation"] = (
            f"完整输出已落盘(共 {artifact.get('chars')} 字符)。用 "
            f'read_tool_output(artifact_id="{artifact.get("artifactId")}", offset=0) '
            "分页续读,直到返回 complete=true。"
        )
    return result


# 0-5 run_command 危险命令硬门(env DANGEROUS_COMMAND_BLOCKED 默认 true)
def _is_dangerous_command_blocked() -> bool:
    """危险命令拦截是否开启(env DANGEROUS_COMMAND_BLOCKED,默认 true)。"""
    val = os.environ.get("DANGEROUS_COMMAND_BLOCKED", "true").strip().lower()
    return val not in ("0", "false", "no", "off", "")


def _get_run_command_hard_timeout() -> int:
    """run_command 执行硬超时上限秒(env RUN_COMMAND_TIMEOUT_S,默认 120)。"""
    try:
        return max(1, int(os.environ.get("RUN_COMMAND_TIMEOUT_S", "120")))
    except (TypeError, ValueError):
        return 120


def _match_destructive_command(command: str) -> str | None:
    """确定性检测破坏性命令。命中返回模式名,未命中返回 None。

    覆盖 Windows(format/diskpart/reg delete/shutdown/bcdedit/vssadmin delete/
    cipher /w/rd /s/del /f /s /q 宽路径/Remove-Item -Recurse -Force 作用于根)
    与 Unix(rm -rf //~/rm -rf ~/mkfs/dd of=/dev//chmod -R 777 //fork bomb/shutdown)。
    """
    c = command or ""

    def _at_start(pat: str) -> bool:
        # 命令起始锚点:行首或空白/链分隔符(&|;`、左括号、空格)之后
        return bool(re.search(r"(?i)(?:^|[\s&|;`(])" + pat, c))

    # Windows
    if _at_start(r"(?:cmd\s+/[cC]\s+)?format\b"):
        return "win_format"
    if _at_start(r"diskpart\b"):
        return "win_diskpart"
    if _at_start(r"reg\s+delete\b"):
        return "win_reg_delete"
    if _at_start(r"(?:shutdown|shutdown\.exe|halt|poweroff|reboot)\b"):
        return "shutdown"
    if _at_start(r"bcdedit\b"):
        return "win_bcdedit"
    if re.search(r"(?i)(?:^|[\s&|;`])vssadmin\b[^|]*?delete\b", c):
        return "win_vssadmin_delete"
    if re.search(r"(?i)(?:^|[\s&|;`])cipher\b[^|]*?/w\b", c):
        return "win_cipher_w"
    if re.search(r"(?i)(?:^|[\s&|;`])(?:rd|rmdir)\b[^|]*?/s\b", c):
        return "win_rd_s"
    # del /f /s /q(顺序无关,宽路径)
    if _at_start(r"del\b") and all(f in c for f in ("/f", "/s", "/q")):
        return "win_del_fsq"
    # Remove-Item -Recurse -Force 作用于盘符/用户根/unix 根/家目录
    # 路径可出现在 flags 之前或之后,故拆为独立条件判断(更稳健)
    if _at_start(r"Remove-Item\b"):
        has_recurse = re.search(r"(?i)-Recurse\b", c) is not None
        has_force = re.search(r"(?i)-Force\b", c) is not None
        has_root = re.search(r"(?i)(?:[a-z]:\\|C:\\Users|/|~)", c) is not None
        if has_recurse and has_force and has_root:
            return "win_remove_item_root"
    # Unix
    if re.search(
        r"(?i)(?:^|[\s&|;`])(?:sudo\s+)?rm\b[^|]*?-[rR][fF]\b[^|]*?(?:\s/[^\s]*|\s~)",
        c,
    ):
        return "unix_rm_rf_root"
    if re.search(
        r"(?i)(?:^|[\s&|;`])(?:sudo\s+)?rm\b[^|]*?-[rR]\s+-[fF]\b[^|]*?(?:\s/[^\s]*|\s~)",
        c,
    ):
        return "unix_rm_rf_home"
    if _at_start(r"(?:mkfs|mkfs\.\w+)\b"):
        return "unix_mkfs"
    if re.search(r"(?i)(?:^|[\s&|;`])dd\b[^|]*?of=/dev/", c):
        return "unix_dd_dev"
    if re.search(r"(?i)(?:^|[\s&|;`])chmod\b[^|]*?-R\b[^|]*?777\b[^|]*?(?:\s/|/[^|]*$)", c):
        return "unix_chmod_777_root"
    if ":(){ :|:& };:" in c or re.search(
        r":\(\s*\)\s*\{\s*:\s*\|\s*:\s*&\s*\}\s*;\s*:", c
    ):
        return "unix_fork_bomb"
    return None


# 0-6 dispatch_subagent 治理
# 全局并发上限(模块级 Semaphore,env SUBAGENT_MAX_CONCURRENT,默认 5)
_SUBAGENT_MAX_CONCURRENT = max(1, int(os.environ.get("SUBAGENT_MAX_CONCURRENT", "5")))
_SUBAGENT_SEMAPHORE = asyncio.Semaphore(_SUBAGENT_MAX_CONCURRENT)
# 嵌套深度上限(≤2):contextvar 记录当前深度,子代理执行时 +1,超限拒绝
_SUBAGENT_MAX_DEPTH = 2
#: 子代理钩子(第 36 项):每个 start/stop 点的硬上限。钩子是外部脚本,
#: 不能让一份卡住的配置把整条派发链拖慢到超时。
_SUBAGENT_HOOK_TIMEOUT_SECONDS: Final[float] = 5.0
_SUBAGENT_HOOK_RUNTIME: Any = None
_subagent_depth: contextvars.ContextVar[int] = contextvars.ContextVar(
    "subagent_depth", default=0
)


def _get_subagent_timeout() -> int:
    """单子代理超时秒(env SUBAGENT_TIMEOUT_S,默认 300)。"""
    try:
        return max(1, int(os.environ.get("SUBAGENT_TIMEOUT_S", "300")))
    except (TypeError, ValueError):
        return 300


# ===== 统一多智能体编排(2026-11-16,遵循统一工程规范)=====
# 唯一入口是 orchestrate_agents(旧名 dispatch_subagent 仅保留 handler 兼容):
# 主 agent 按任务性质自主选择 —— 单任务 single / 互不依赖 parallel /
# 前后依赖 pipeline / 多视角决策 debate·vote·critique / 复杂目标 decompose /
# 团队聚合 team。六种编排模式与既有单/并行派发共用同一套治理
# (agents 白名单、数量上限、并发信号量、嵌套深度、超时、工单结算、输出截断)。
_DISPATCH_MODES: Final[tuple[str, ...]] = (
    "single",
    "parallel",
    "pipeline",
    "debate",
    "vote",
    "critique",
    "decompose",
    "team",
    "recursive",
)
_ORCHESTRATION_MODES: Final[tuple[str, ...]] = (
    "pipeline",
    "debate",
    "vote",
    "critique",
    "decompose",
    "team",
    "recursive",
)
# 单次编排的参与者/步骤/轮次上限(防一次调用打满并发与 token 预算)
_ORCHESTRATION_MAX_AGENTS = 5
_ORCHESTRATION_MAX_STEPS = 6
_ORCHESTRATION_MAX_ROUNDS = 3
_DECOMPOSE_STRATEGIES: Final[tuple[str, ...]] = (
    "sequential",
    "parallel",
    "dag",
    "recursive",
)
# team 模式的聚合策略(与 agent_teams.ResultAggregator 的封闭集同源)
_TEAM_AGGREGATIONS: Final[tuple[str, ...]] = ("merge", "best_of", "consensus")
# team 贡献者的输出契约:best_of/consensus 需要稳定的结论与评分才能择优/求共识。
_TEAM_OUTPUT_CONTRACT: Final = (
    "\n\n请在回答末尾严格追加两行,便于团队聚合:\n"
    "结论：<一句话结论>\n"
    "评分：<0-100 的整数>"
)


# D08②(2026-10-24):agent 间换手消息(完成/受阻/求助)的结构化事件。
# 票面要求 SSE **复用既有 subagent_* 帧族、禁新帧**,故这里只产出一条消息的**载荷字段**;
# 帧名仍由 llm.py 的 subagent_progress / subagent_end 承载。字段集:
#   kind(done|blocked|help) / agent_id / summary / [token_usage] / ts
# agent_id 由调用层给定(llm.py 持有真正的子代理实例 id);token_usage 仅在真实拿到时写入,
# 不用 0 冒充"有用量"(与仓内"取不到必须显式缺席"口径一致)。
_SUBAGENT_HANDOFF_KINDS: Final = ("done", "blocked", "help")


def _subagent_handoff_event(
    kind: str,
    agent_id: str,
    summary: str,
    *,
    token_usage: dict[str, Any] | None = None,
    ts: str | None = None,
) -> dict[str, Any]:
    """构造一条子 agent 换手消息(纯函数,不写帧、不产生副作用)。"""
    if kind not in _SUBAGENT_HANDOFF_KINDS:
        raise ValueError(f"unknown subagent handoff kind: {kind!r}")
    from datetime import UTC, datetime

    evt: dict[str, Any] = {
        "kind": kind,
        "agent_id": agent_id,
        "summary": str(summary or "")[:200],
        "ts": ts or datetime.now(UTC).isoformat(),
    }
    if token_usage is not None:
        evt["token_usage"] = token_usage
    return evt


def _subagent_handoff_kind(*, ok: bool, needs_help: bool = False) -> str:
    """完成/受阻/求助三档的唯一映射:显式求助优先,其次按成败分 done / blocked。"""
    if needs_help:
        return "help"
    return "done" if ok else "blocked"


import contextlib

from .skills import skill_registry
from .subagent_resident_lease import (
    build_resident_prefix,
    normalize_path_key,
    read_resident_text,
    resident_lease_registry,
)

# ---------------------------------------------------------------------------
# 安全常量(2026-07-22 P0 Round 2 鲁棒性加固)
# ---------------------------------------------------------------------------

# 工作区根目录白名单:MCP read_file/write_file 只允许读写白名单内文件
# 从 env MCP_WORKSPACE_ROOTS 读取(分隔符 os.pathsep),默认当前工作目录
#
# 2026-07-27 修复:_WORKSPACE_ROOTS 原在模块加载时通过 os.environ.get 求值,
# 但 main.py 同步 settings → os.environ 在第 71-77 行(模块导入之后),
# 导致 MCP_WORKSPACE_ROOTS 永远读到 os.getcwd()=apps/ai-service/,
# 相对路径 apps/ai-service/pyproject.toml 被拼成 apps/ai-service/apps/ai-service/... 前缀重复。
# 修复:改为函数式延迟读取,在 _validate_path_in_workspace 调用时才求值,
# 此时 main.py 已完成 settings → os.environ 同步。


def _get_workspace_roots() -> list[str]:
    """工作区根目录白名单(延迟读取 os.environ,确保 main.py 已同步 .env)。

    2026-10-31 修:空值回落 cwd —— 与 `app/services/sandbox.py::_workspace_roots`
    的既有口径对齐(那份注释明写"空值按 config.py 契约回落 cwd",是同一配置键的
    正确解析)。此前的 `os.environ.get(KEY, cwd)` 只在**键缺失**时回落,而本仓
    `.env` 与 `.env.example` 都写着 `MCP_WORKSPACE_ROOTS=`(键在、值为空)⇒ 返回
    空列表 ⇒ `routers/patch.py` 的 fail-closed 把**全部补丁请求**打成 503,
    生产上补丁应用功能完全不可用。回落目标仍是服务端自身工作目录(有界根),
    不是放行任意路径。
    """
    raw = (os.environ.get("MCP_WORKSPACE_ROOTS", "") or "").strip()
    roots = [os.path.abspath(r) for r in raw.split(os.pathsep) if r.strip()]
    return roots or [os.path.abspath(os.getcwd())]


# ---------------------------------------------------------------------------
# D201 多根工作区:会话级附加目录(2026-10-02 立,票 D201;遵循统一工程规范
# 的 add_directories 控制帧 —— 会话中途追加目录,追加后该目录内文件可被会话读写,
# 移除即失效)。
#
# 进程级白名单 MCP_WORKSPACE_ROOTS 是启动期一次性设定;本节补**会话级覆盖层**:
# 键 = (已验证主体, 会话 ID)(llm.py 主对话链 主体 = JWT 主体、会话 = conversationId;
# engine 链 = thread.user_id / EngineThread.session_id),值 = 该会话追加的绝对目录元组。
# 2026-11-01 安全强化(严重):键此前只有会话 ID,而 conversationId 是客户端自报的
# metadata 字段 ⇒ 一次未鉴权的登记就能把任意目录挂到**别人**的同名会话上。
#
# 注入方式:call_tool 在派发 handler 前把当前会话的附加目录写进 ContextVar,
# _validate_path_in_workspace 在进程级白名单之外兜底查它(handler 与其 await 链
# 同处一个 asyncio task,ContextVar 天然传播;不同会话并发互不可见)。
# 两态纪律:deny-by-default 不变 —— 不在白名单、也不在该会话附加集内的路径照旧拒绝;
# 附加集只做"扩",不做"收"(白名单内的路径不因附加集而变严)。
_SESSION_EXTRA_ROOTS: "BoundedTtlDict" = BoundedTtlDict(
    # 2026-11-01 安全强化:这一族值不是普通缓存,而是**文件系统授权**。
    # 原先是无上限 dict,且 `clear_session_extra_roots` 全仓**零调用方**
    # (移除路径根本没接线)⇒ 一次会话追加过的目录会永久留在生效表里:
    # 内存线性增长之外,更要紧的是"会话级扩权"变成进程级常驻扩权
    # (会话 id 被复用/猜到即可拿到别人追加过的工作区)。
    # 逐出/过期都做成"读不到即失效"(deny-by-default 不变),
    # 并把清理挂在写与读这两条必然发生的路径上 —— 不依赖有人来调 sweep(§0.9)。
    max_keys=5000,
    ttl_seconds=6 * 3600.0,
)
_ACTIVE_SESSION_EXTRA_ROOTS: contextvars.ContextVar[tuple[str, ...]] = (
    contextvars.ContextVar("active_session_extra_roots", default=())
)


# 2026-11-01 安全强化(严重):附加目录**必须是服务端已登记的根之内**。
#
# 原准入只判"绝对路径 + 存在 + 是目录"(见下方历史注释),于是 `POST /llm/conversations/
# {id}/directories` 传 `{"paths":["/"]}` 就把该会话的工具根扩到整盘;`read_file` 用
# `relative_to(root)` 判包含性 ⇒ `/proc/self/environ`、其他租户目录全部放行。
# 而 conversation_id 在对话链里就是客户端自报的 metadata 字段 —— 可整写。
#
# 现在的判据是两层:
#   ① 该目录必须落在**本服务的允许根**内(MCP_WORKSPACE_ROOTS ∪ IHUI_WORKSPACE_ROOTS
#      ∪ 该用户自己的 workspace 目录,见 `_extra_directory_allowed_roots`);
#   ② 系统根/伪文件系统(/、C:\、/proc、/etc、/sys …)即使被配成白名单也一律拒 ——
#      "整盘"不是工作区,把根配进来只会把 ① 变成恒真。
# 符号链接先 `resolve(strict=False)` 再判:判定对象是链接的目标,不是链接自身。
_SYSTEM_ROOT_SEGMENTS: Final[frozenset[str]] = frozenset(
    {"proc", "sys", "dev", "etc", "boot", "bin", "sbin", "lib", "lib32", "lib64", "usr"}
)
_WINDOWS_SYSTEM_ROOTS: Final[tuple[str, ...]] = (
    "c:\\windows",
    "c:\\program files",
    "c:\\program files (x86)",
    "c:\\programdata",
)


def _is_system_root(resolved: Path) -> bool:
    """路径本身是文件系统根 / 系统目录 / 伪文件系统(逐段判,故 /proc/self 也算)。"""
    if resolved.parent == resolved:  # 文件系统根("/"、C:\ 与 UNC 根)
        return True
    text = str(resolved).replace("/", "\\").casefold()
    if any(text == root or text.startswith(root + "\\") for root in _WINDOWS_SYSTEM_ROOTS):
        return True
    parts = [p.casefold() for p in resolved.parts[1:]]
    return bool(parts) and parts[0] in _SYSTEM_ROOT_SEGMENTS


def _extra_directory_allowed_roots(user_id: str | None) -> list[str]:
    """附加目录的允许根集合(服务端登记值,客户端不可整写)。

    三源合并:
      · ``MCP_WORKSPACE_ROOTS`` —— 工具侧既有的白名单根(空值按既有契约回落 cwd,
        与 ``_get_workspace_roots`` 同源,不另造一份解析);
      · ``IHUI_WORKSPACE_ROOTS`` —— 工作区登记根(``services/workspace_roots.py`` 的
        唯一出口,LSP/knowledge 面同吃这一份);
      · 该用户自己的 workspace 目录 —— 仅在部署显式配置
        ``IHUI_USER_WORKSPACE_ROOT`` 时参与(未配置即不参与,不凭空造一个目录出来)。
    去重保序;判定用 resolve(strict=False) 归一后的字符串。
    """
    roots: list[str] = []

    def _add(candidate: str) -> None:
        if not candidate:
            return
        normalized = str(Path(candidate).resolve(strict=False))
        if normalized not in roots:
            roots.append(normalized)

    for root in _get_workspace_roots():
        _add(root)
    try:
        from .workspace_roots import registered_workspace_roots

        for root in registered_workspace_roots():
            _add(root)
    except Exception:  # noqa: BLE001 - 登记根读不出来时按"只剩 MCP 根"降级(更严,不是更松)
        logger.warning("[mcp] 读取 IHUI_WORKSPACE_ROOTS 失败,附加目录仅按 MCP 根判定")
    if user_id:
        base = (os.environ.get("IHUI_USER_WORKSPACE_ROOT", "") or "").strip()
        safe_user = "".join(c for c in str(user_id) if c.isalnum() or c in "-_")[:64]
        if base and safe_user:
            _add(str(Path(base).resolve(strict=False) / safe_user))
    return roots


def _validate_extra_directory(
    path: str,
    *,
    allowed_roots: list[str] | tuple[str, ...] | None = None,
    user_id: str | None = None,
) -> tuple[bool, str]:
    """附加目录准入校验:非空、绝对路径、真实存在且是目录、**落在允许根内**、resolve 归一。

    ``allowed_roots`` 缺省 ⇒ 由 ``user_id`` 推导(``_extra_directory_allowed_roots``)。
    显式传值时按传入集合判(内部调用点/测试自备)。
    """
    if not path or not path.strip():
        return False, "附加目录路径为空"
    p = Path(path)
    if not p.is_absolute():
        return False, f"附加目录必须是绝对路径: {path}"
    # 读不到 ≠ 不存在:exists()/is_dir() 在 EACCES 时按 OSError 上抛,
    # 若落到"不存在"分支,用户会以为目录真的没了(登记流程会静默当它不存在)。
    try:
        resolved = p.resolve(strict=False)
        resolved_stat = resolved.stat()
    except FileNotFoundError:
        return False, f"附加目录不存在: {path}"
    except OSError as exc:
        return False, f"附加目录读不到,不能把它说成不存在: {path} ({exc.errno})"
    if not stat.S_ISDIR(resolved_stat.st_mode):
        return False, f"附加目录不是目录: {path}"
    if _is_system_root(resolved):
        return False, f"附加目录是系统根/伪文件系统,禁止登记: {path}"
    roots = (
        [str(Path(r).resolve(strict=False)) for r in allowed_roots]
        if allowed_roots is not None
        else _extra_directory_allowed_roots(user_id)
    )
    for root in roots:
        try:
            resolved.relative_to(root)
        except ValueError:
            continue
        return True, str(resolved)
    return False, (
        f"附加目录不在允许根内: {path}"
        "(仅允许 MCP_WORKSPACE_ROOTS / IHUI_WORKSPACE_ROOTS / 本人 workspace 目录之内)"
    )


def _session_extra_root_key(user_id: str | None, session_id: str) -> str:
    """登记表键 = ``(主体, 会话)`` 的复合串(``\\x00`` 分隔,两段都不可含它)。

    2026-11-01 安全强化(严重):键此前只有 session_id,而 session_id
    (= conversationId)是客户端可整写的 metadata 字段 ⇒ A 用户给会话 X 登记的目录,
    B 用户跑会话 X 时同样生效("谁先说谁定根")。主体取承载层已验签的 user_id
    (HTTP 链 = JWT 主体,engine 链 = thread.user_id);空主体归到独立的 unowned
    命名空间 —— 只由内部链路使用,HTTP 侧永远带主体。
    """
    owner = (user_id or "").strip().replace("\x00", "")
    session = (session_id or "").strip().replace("\x00", "")
    return f"{owner}\x00{session}"


def set_session_extra_roots(
    session_id: str,
    dirs: list[str],
    *,
    user_id: str | None = None,
    allowed_roots: list[str] | tuple[str, ...] | None = None,
) -> tuple[str, ...]:
    """**整表替换**某 (主体, 会话) 的附加目录集(空列表 = 清空)。返回生效集。

    逐个过准入校验,任一非法整表拒绝(ValueError)—— 不做"合法的留下、非法的丢弃"
    的部分生效(那会把"少追加了"伪装成成功)。移除语义 = 用不含该目录的新表替换。
    """
    resolved: list[str] = []
    for d in dirs:
        ok, info = _validate_extra_directory(d, allowed_roots=allowed_roots, user_id=user_id)
        if not ok:
            raise ValueError(f"附加目录准入被拒: {info}")
        if info not in resolved:
            resolved.append(info)
    key = _session_extra_root_key(user_id, session_id)
    if not (session_id or "").strip():
        raise ValueError("session_id 为空,无法登记附加目录")
    if resolved:
        _SESSION_EXTRA_ROOTS.set(key, tuple(resolved))
    else:
        _SESSION_EXTRA_ROOTS.pop(key, None)
    return tuple(resolved)


def clear_session_extra_roots(session_id: str, *, user_id: str | None = None) -> None:
    """移除某 (主体, 会话) 的全部附加目录(移除即失效,不留残根)。"""
    _SESSION_EXTRA_ROOTS.pop(_session_extra_root_key(user_id, session_id), None)


def get_session_extra_roots(
    session_id: str | None, *, user_id: str | None = None
) -> tuple[str, ...]:
    """读某 (主体, 会话) 的附加目录集(未登记/已过期/主体不符 ⇒ 空元组)。

    deny-by-default:主体没给或与登记时的主体不一致,一律读不到 —— 扩权不跨用户、
    不跨会话、不永生。
    """
    sid = session_id or ''
    if not sid.strip():
        return ()
    return _SESSION_EXTRA_ROOTS.get(_session_extra_root_key(user_id, sid), ()) or ()


def _active_extra_roots() -> tuple[str, ...]:
    """当前工具调用生效的附加目录集(call_tool 按会话注入 ContextVar)。"""
    return _ACTIVE_SESSION_EXTRA_ROOTS.get()

# 工具权限矩阵:admin 专属工具(role >= 1),其他工具所有用户可用
# 危险工具:写文件 / 执行命令 / 数据库查询 / git 操作 / 自动化配置 / 电脑控制 / 截图(SSRF 入口)
_ADMIN_ONLY_TOOLS: set[str] = {
    "write_file", "run_command", "sandbox_session", "terminal", "db_query", "git_operations",
    # 2026-11-24 shadow workspace:多文件事务写,危险面与 write_file 同档
    "apply_patch_set",
    "configure_automation_task",
    # 2026-07-24 file_edit:写文件操作(精细编辑),必须 admin
    "file_edit",
    # 1-2(2026-09-08):resolve_conflict 也写盘(按块落盘解决结果),必须 admin
    "resolve_conflict",
    # computer_* 系列:控制电脑是高危操作,需 admin
    "computer_screenshot_screen", "computer_mouse_move", "computer_mouse_click",
    "computer_keyboard_type", "computer_mouse_scroll", "computer_keyboard_press",
    "computer_keyboard_hotkey", "computer_active_window",
    "computer_clipboard_get", "computer_clipboard_set",
    # 2026-07-24 安全加固:screenshot_url 是 SSRF 入口(Playwright 访问任意 URL),
    # 即使有 _validate_url_ssrf 校验,仍限定 admin 调用,defense-in-depth
    "screenshot_url",
    # AIS-051:两个浏览器自检工具与 screenshot_url 同等 SSRF 能力(任意 URL 拉页面
    # + 截图),此前不在角色矩阵里 ⇒ role=0 的旁路。与 screenshot_url 同档收口。
    "browser_selfcheck_screenshot", "browser_selfcheck",
    # AIS-050 defense-in-depth:upload_file 把本地内容外传第三方存储。对话链的
    # intend 路由与 tool 选择表都不含它(role=0 正常链路不依赖);本地路径分支已过
    # 工作区+敏感文件判据,这里再加角色档。voice_clone 不能加:对话链 role=0 直接
    # 依赖它(conversation._MEDIA_INTENT_PATTERNS["token6688_voice_clone"])。
    # 用户 2026-11-08 逐条裁定:voice_clone 属"贵资源",用归属闸+计费闸治理
    # (tests/test_voice_clone_owner_credit_ais050.py),整只入档会挡死正常对话链。
    # 2026-07-24 扩展工具(自研核心能力):
    # fetch_url:SSRF 入口 + 可探测内网;
    # review_pr:GitHub API + 可能暴露源代码;schedule_task:调度后台任务
    # 2026-09-08 全模态深度适配:image_generation 移出 admin 专属(与 video/music/tts
    # 媒体工具对齐)。原因:对话链 conversation → call_tool 不传 user_role(默认 0),
    # 留在名单里 = 对话内图片生成永远 PERMISSION_DENIED,全模态自动路由断链。
    "fetch_url",
    # 2026-09 Firecrawl 极致融合:crawl_site 多页/SSRF 密集/资源重, 同 fetch_url 限 admin;
    # fetch_readable/map_site/extract_web(单页只读)不限, 避免对话链 user_role=0 断链
    "crawl_site",
    "review_pr",
    "schedule_task",
    # 2026-10-31:定时任务的查询/撤销与创建同档。底层 scheduler_service.list_tasks(None)
    # 不带任何归属过滤、remove_task 也无归属校验 ⇒ 放给 role 0 就是跨用户枚举 + 任意撤销,
    # 与 schedule_task 已限定 admin 的口径不一致即漏洞(defense-in-depth,同 screenshot_url)。
    "list_scheduled_tasks", "cancel_scheduled_task",
    # 2026-10-31:延迟唤醒同档。add_task 无归属校验、任务记录无归属字段,
    # 与 schedule_task/list/cancel 口径不一致即漏洞(defense-in-depth)。
    "schedule_wakeup",
    # 2026-10-31 安全强化第 10 批:generate_test 同档 —— 它把 arguments.code 原样落盘
    # 为可 import 的 source.py 并起 pytest 真执行(pytest 收集时即执行模块级代码),
    # 等价"提交任意 Python 代码由服务进程执行";留在 role 0 可用名单就是任意角色 RCE。
    "generate_test",
    # 2026-11-01(G-NotebookEdit 补齐):notebook_edit 写盘(.ipynb 单元格级改写),
    # 与 write_file/file_edit/resolve_conflict 同档;写回腿复用 _tool_write_file。
    "notebook_edit",
}

# agent_control 内部调用密钥(从 settings 读取,确保 .env 配置生效)
# 2026-07-22 修复:原 os.environ.get 在模块加载时求值,main.py 同步 os.environ 晚于本模块导入 → 永远为空
# 改为函数调用时动态读取,确保 .env 配置已加载
def _get_agent_control_secret() -> str:
    from ..core.config import settings
    return settings.agent_control_internal_secret or os.environ.get("AGENT_CONTROL_INTERNAL_SECRET", "")

# ---------------------------------------------------------------------------
# 1-2 补丁冲突处理:文件 base 版本跟踪(3-way merge 的公共祖先)
# ---------------------------------------------------------------------------
# read_file / write_file / file_edit 成功后记录「agent 视角的最新内容」;
# file_edit 匹配失败(0 命中)且 old_string 在 base 中存在时,判定为
# 「快照之后被外部修改」→ 走 merge3 三方合并(干净合并 / 冲突块)。
# 内存 dict(resolved_path → content),上限 256 文件(超限淘汰最旧)。
_FILE_BASE_CONTENT: dict[str, str] = {}
_FILE_BASE_MAX = 256
# AIS-082:read_file 单次读取上限,与写侧(write_file)的 10MB 门对齐。读侧此前
# 无上限 → 整文件进内存并全量进 _FILE_BASE_CONTENT(最多 256 份),GB 级文件直接 OOM。
_READ_FILE_MAX_BYTES = 10 * 1024 * 1024
# 大文件分页读(对齐 外部实现 read 的有界分页):调用方传 offset/limit 时按行窗口返回。
# 不传时保持旧的整文件语义,避免改变既有调用方与测试的契约。
_READ_WINDOW_MAX_LINES = 2000
_READ_WINDOW_MAX_LINE_CHARS = 2000
_READ_WINDOW_MAX_BYTES = 50 * 1024


def _render_read_window(content: str, offset: int, limit: int) -> dict[str, Any]:
    """把整文件内容渲染成带行号的单页窗口。

    约束:每行最多 2000 字符(超出以省略号收尾),整页最多 50KB;页脚给出
    总行数与下一页 offset,模型不必猜。行号从 1 起,与编辑器/IDE 一致。
    """
    lines = content.splitlines()
    total = len(lines)
    if offset > total and not (total == 0 and offset == 1):
        return {
            "ok": False,
            "errorCode": "OFFSET_OUT_OF_RANGE",
            "error": f"offset={offset} 超出文件行数(共 {total} 行);offset 从 1 开始。",
            "totalLines": total,
        }
    rendered: list[str] = []
    used = 0
    truncated_by_bytes = False
    last = min(offset - 1 + limit, total)
    for idx in range(offset - 1, last):
        text = lines[idx]
        if len(text) > _READ_WINDOW_MAX_LINE_CHARS:
            text = (
                text[:_READ_WINDOW_MAX_LINE_CHARS]
                + f"… (本行超过 {_READ_WINDOW_MAX_LINE_CHARS} 字符,已截断)"
            )
        line = f"{idx + 1}: {text}"
        cost = len(line.encode("utf-8")) + (1 if rendered else 0)
        if used + cost > _READ_WINDOW_MAX_BYTES:
            truncated_by_bytes = True
            break
        used += cost
        rendered.append(line)
    end_line = offset + len(rendered) - 1 if rendered else offset - 1
    if truncated_by_bytes:
        footer = (
            f"(至字节上限,已显示第 {offset}-{end_line} 行,共 {total} 行;"
            f"用 offset={end_line + 1} 继续。)"
        )
    elif end_line < total:
        footer = f"(已显示第 {offset}-{end_line} 行,共 {total} 行;用 offset={end_line + 1} 继续。)"
    else:
        footer = f"(文件结束,共 {total} 行)"
    body = "\n".join(rendered)
    return {
        "ok": True,
        "content": f"{body}\n\n{footer}" if body else footer,
        "offset": offset,
        "totalLines": total,
        "truncatedByBytes": truncated_by_bytes,
    }


def _normalize_eol(text: str) -> str:
    """EOL 归一化:CRLF → LF(1-2 生产修复)。

    read_file 文本模式经 universal newlines 得到 LF 视角,而 Windows
    编辑器/工具写盘常为 CRLF;若 base(LF)与磁盘内容(CRLF)直接进
    merge3 逐行比较,会整文件误判为单侧全改。base 存储与 merge3
    计算统一用 LF,写盘前再按磁盘原行尾风格还原。
    """
    return text.replace("\r\n", "\n")


def _restore_eol(text: str, original: str) -> str:
    """按磁盘原行尾风格还原合并结果:原文件 CRLF 则 LF → CRLF,否则保持 LF。"""
    if "\r\n" in original:
        return text.replace("\r\n", "\n").replace("\n", "\r\n")
    return text


def _record_file_base(resolved_path: str, content: str) -> None:
    """记录/刷新文件的 base 版本(agent 视角最新内容,统一 LF 归一化存储)。"""
    normalized = _normalize_eol(content)
    if resolved_path in _FILE_BASE_CONTENT:
        _FILE_BASE_CONTENT.pop(resolved_path)
    _FILE_BASE_CONTENT[resolved_path] = normalized
    while len(_FILE_BASE_CONTENT) > _FILE_BASE_MAX:
        _FILE_BASE_CONTENT.pop(next(iter(_FILE_BASE_CONTENT)))


def _reset_file_base_store() -> None:
    """清空 base 版本跟踪(测试隔离用)。"""
    _FILE_BASE_CONTENT.clear()


# ---------------------------------------------------------------------------
# `context://` 统一命名空间(2026-11-23 接线)
#
# 对照行为(round8 取证):Trae 的 ContextFS 给每个上下文来源一个统一虚拟 URI,
# 但解析与鉴权分两步、允许「已解析未鉴权」的半态。本仓不复制其实现,只用已复现的
# 判据 `app.core.context_fs.resolve_context_uri` 把两件事一次收口,并把半态显式拒绝。
#
# 接线层只做一件事:把**已判 allowed** 的虚拟 URI 降成工作区**相对路径**,继续交给
# 原有白名单 + symlink + 敏感文件三层判据 —— 虚拟命名空间只换名字,不换任何一条
# 真实安全判据(否则等于给模型开了一条绕过 read_file 黑名单的新入口)。
_CONTEXT_URI_PREFIX: Final[str] = "context://"
# 虚拟根段名:必须与宿主路径无关。判据会把 ``roots[ns]`` **原样拼进 canonical_path**
# (context_fs.py 第 10 步),所以这里传宿主目录就会把盘符/绝对路径写进"虚拟 URI";
# 接线层因此在下面加了一道防御断言,见 _deref_context_uri_alias。
_CONTEXT_VIRTUAL_ROOT: Final[str] = "root"
# 工具 schema 的可发现性提示(四处引用同一份,不在每个 schema 里各写一句 §0.6)。
_CONTEXT_URI_HINT: Final[str] = (
    "也可用 context://workspace/<相对路径>(与裸相对路径等价,仍过白名单/逃逸/敏感判据)"
)


def _deref_context_uri_alias(path: str, roots: list[str]) -> tuple[bool, str]:
    """把 ``context://workspace/<rel>`` 降成工作区相对路径(非 context URI 原样返回)。

    Returns:
        (True, 相对路径) —— 已判 allowed(workspace 是当前唯一有根的命名空间);
        (False, 错误文案) —— denied / unjudged,文案点名 reason 机器码与 detail。
    """
    if path[: len(_CONTEXT_URI_PREFIX)].casefold() != _CONTEXT_URI_PREFIX:
        # 不沾 context 的路径走原路,行为逐字节不变;但非规范大小写(context:/ Context:/)
        # 仍进判据,由 resolve_context_uri 给 case_variant / wrong_scheme 的机器码。
        if not path.casefold().startswith("context:"):
            return True, path
    from app.core.context_fs import DEFAULT_NAMESPACES, Verdict, resolve_context_uri

    # 只在 workspace 开着根;session/artifact/skill 三档注册但无根 ⇒ unjudged/
    # missing_namespace_root —— 这正是「取不到输入不默认放行」,不是缺陷。
    ns_roots: dict[str, str] = {"workspace": _CONTEXT_VIRTUAL_ROOT} if roots else {}
    verdict = resolve_context_uri(
        path, ns_roots, {"allowed_namespaces": list(DEFAULT_NAMESPACES)}
    )
    if verdict.get("verdict") != Verdict.ALLOWED.value:
        refusal = "被拒绝" if verdict.get("verdict") == Verdict.DENIED.value else "未判定"
        return False, (
            f"context URI {refusal}({verdict.get('reason')}): {verdict.get('detail')}"
        )
    canonical = verdict.get("canonical_path") or ""
    prefix = f"{_CONTEXT_URI_PREFIX}workspace/{_CONTEXT_VIRTUAL_ROOT}/"
    # 防御断言:虚拟 URI 的每一段都不得带宿主成分(盘符冒号 / 反斜杠)。判据本身不校验
    # root 段的形状,把宿主路径塞进 roots 就会产出"看着像虚拟 URI、其实是宿主路径"的
    # canonical —— 那正是判据注释里禁止的用法,所以在唯一消费者这里钉死。
    body = canonical[len(_CONTEXT_URI_PREFIX):]
    if any(("\\" in seg) or (":" in seg) for seg in body.split("/")):
        return False, f"context URI 的虚拟路径含宿主成分(盘符/反斜杠),拒绝: {canonical}"
    if not canonical.startswith(prefix):
        return False, f"context URI 只支持 workspace 命名空间: {path}"
    rel = canonical[len(prefix):]
    if not rel:
        return False, f"context URI 缺文件路径: {path}"
    return True, rel


def _validate_path_in_workspace(
    path: str, extra_roots: tuple[str, ...] | None = None
) -> tuple[bool, str]:
    """校验路径在工作区白名单内,防 symlink 穿越。

    extra_roots:D201 会话级附加目录集。None(缺省)= 取 ContextVar 里 call_tool
    注入的当前会话附加集;显式传元组 = 调用方自备(call_tool 之外直接调用校验的
    面,如 agent_loop_v2 自愈链,其执行点不在 call_tool 的 ContextVar 作用域内)。
    空元组 = 无附加集,行为与 D201 之前逐字节一致。

    Returns:
        (ok, resolved_path) 或 (False, error_message)
    """
    from pathlib import Path

    if not path:
        return False, "路径为空"
    try:
        # 2026-07-27 修复路径重复拼接:ai-service 进程 cwd 通常是 apps/ai-service/,
        # 用户传相对路径 apps/ai-service/pyproject.toml 时 Path().resolve() 会拼成
        # apps/ai-service/apps/ai-service/pyproject.toml(前缀重复)。
        # 修复策略:相对路径优先在所有 _WORKSPACE_ROOTS 下查找存在的文件,
        # 命中即用;都找不到才退回到 cwd resolve(保留原行为兼容绝对路径)。
        p = Path(path)
        # D201:白名单根 ⊕ 当前会话附加目录集 —— 两个集合对读路径完全同权
        # (相对路径探测与绝对路径包含性判定都用同一份合并集)。
        roots = _get_workspace_roots() + list(
            _active_extra_roots() if extra_roots is None else extra_roots
        )
        # context:// 虚拟命名空间:先过已复现判据(形状/逃逸/半态),通过后降成相对路径
        # 走下面全部真实判据(白名单 + symlink + 敏感黑名单)。失败即在此收口。
        ctx_ok, ctx_path = _deref_context_uri_alias(path, roots)
        if not ctx_ok:
            return False, ctx_path
        path = ctx_path
        p = Path(path)
        # 跨平台:POSIX 上没有盘符概念,`Z:/no/such/x` 会被当成相对路径拼到 cwd 下,
        # 于是"根外路径"被误判成"根内不存在的文件"(PATH_NOT_ALLOWED 退化成
        # FILE_NOT_FOUND —— Linux CI 的媒体上传用例即此,Windows 上则因 is_absolute()
        # 为真走包含性判定、本来就是对的)。盘符只指向它自己的卷,不可能落在 POSIX
        # 工作区根内,所以先判越界,不让它进相对路径探测。
        if os.name != "nt" and re.match(r"^[A-Za-z]:[\\/]", path):
            return False, f"路径不在工作区白名单内: {path}(允许根目录: {roots})"
        if not p.is_absolute():
            for root in roots:
                candidate = (Path(root) / path).resolve(strict=False)
                # R8 复评发现1(高):相对分支此前只判 exists() 无包含性复查 ——
                # `..\..\api\src\x.ts` 解析到根外且存在即放行,role-0 可
                # 读服务器任意非黑名单文件(跨服务源码/跨租户工作区)。补
                # relative_to 包含性,与绝对/回退分支同判据。
                try:
                    candidate.relative_to(Path(root))
                except ValueError:
                    continue
                # 2026-11-09:读不到 ≠ 不存在。exists()/stat() 在 EACCES 时按 OSError
                # 上抛;若当成"这个根里没有"继续试下一个根,就会把 blocked/keep.txt
                # 静默换成 other/keep.txt —— 换的是文件,不是路径写法。
                try:
                    candidate.stat()
                except FileNotFoundError:
                    continue
                except OSError:
                    return False, "路径读不到,不能把它说成不在这个工作区里再换一个根"
                resolved_str = str(candidate)
                return True, resolved_str
        # resolve(strict=False) 解析 symlink + .. ,但不要求路径存在
        resolved = Path(path).resolve(strict=False)
        resolved_str = str(resolved)
        # 检查 resolved 是否在任一白名单根目录下(防 symlink 穿越到 /etc/passwd 等)
        for root in roots:
            try:
                resolved.relative_to(root)
                return True, resolved_str
            except ValueError:
                continue
        return False, (
            f"路径不在工作区白名单内: {path}"
            f"(允许根目录: {roots})"
        )
    except Exception as e:
        return False, f"路径解析失败: {e}"


def _validate_write_path_in_workspace(
    path: str, extra_roots: tuple[str, ...] | None = None
) -> tuple[bool, str]:
    """**写工具专用**路径校验:白名单根 + symlink 解析 + 敏感目录黑名单。

    与 ``_validate_path_in_workspace`` 的差别只有最后一层:本函数额外拒绝落在
    敏感目录(.git / node_modules / .venv / venv / dist / build / __pycache__ /
    .next)内的路径(判定源见 ``path_guard``)。

    为什么只给写路径加这一层,而不直接加进 ``_validate_path_in_workspace``:
    后者另有 10 个调用点(read_file / list_files / run_command 的 cwd /
    vision_analyze / 媒体 save_path 三兄弟等),读路径与 cwd 在业务上允许触及
    .git、node_modules(agent 需要查看依赖源码、读取仓库状态),在黑名单加在
    那里会**顺带改变读行为**,属于超出修复范围的语义变更。真实危害集中在「写」:
    写入 .git/hooks/ 即等价于任意代码执行。因此本层只覆盖三个写工具
    (write_file / file_edit / resolve_conflict)——它们与
    ``file_editor.validate_path`` 属同一语义面(源代码编辑),后者的黑名单行为
    正是本层对齐的目标,两条编辑路径从此不会再有策略分歧。

    媒体落盘(save_path 三兄弟)**刻意不加**本层:其后缀已被限定为图片/音频/视频
    扩展名,无法落成 .git/hooks/pre-commit 这类可执行文本;而"把生成产物写进
    build/ 目录"是合理构建用法,加了会误伤。

    Returns:
        (True, resolved_path) 或 (False, error_message)
    """
    ok, info = _validate_path_in_workspace(path, extra_roots)
    if not ok:
        return False, info
    # 对**解析后**路径判定:这样 symlink 指向 .git 的情况同样被拦住。
    if find_sensitive_segment(info):
        return False, sensitive_error_message(info)
    return True, info


# 2026-07-24 安全加固:敏感文件读取黑名单(防 MCP read_file 泄露凭证)
# 2026-11-01 安全强化(严重):黑名单从"按扩展名/文件名"升级为"**目录级** + 形态补全"。
#
# 漏的是什么:此前只按 basename 判,而真实落盘的密钥/库根本不带那些后缀 ——
# `data/credentials_key`、`data/checkin_fernet_key`(无扩展名)、`data/sessions.db`
# (`.db` 不在表里)、`.uploads/publish/<他人>/*`(只有图片后缀)全部不命中。
# `read_file` 又不在 `_ADMIN_ONLY_TOOLS` 里 ⇒ 任意登录用户
# `POST /api/mcp/tools/call {"name":"read_file","arguments":{"path":"data/sessions.db"}}`
# 即可整库拉走(会话令牌、凭据密文)。
#
# 判据分两层,顺序固定:
#   ① 目录级:相对**命中根**的第一段命中 `_SENSITIVE_DIR_SEGMENTS` 即拒。
#      先 resolve(strict=False) 再判 ⇒ `a/../data/x`、symlink 指进 data/ 同样命中;
#      按"相对根的第一段"而不是"路径里任一段",是因为工作区里另有一层同名目录
#      (如 `src/data/fixture.json`)不该被整目录封死。
#   ② 文件级:basename 形态(`_SENSITIVE_FILE_PATTERNS` / `_SENSITIVE_FILE_EXTENSIONS`)。
_SENSITIVE_FILE_PATTERNS = (
    ".env",                # .env / .env.production / .env.local
    ".npmrc",              # npm token
    ".pypirc",             # pip token
    ".netrc",              # HTTP 凭证
    "id_rsa", "id_dsa", "id_ecdsa", "id_ed25519",  # SSH 私钥
    "credentials.json",    # GCP/AWS 凭证
    "service_account.json",  # GCP 服务账号
)
_SENSITIVE_FILE_EXTENSIONS = (
    ".key", ".pem", ".crt", ".pfx", ".p12",  # 私钥/证书
    ".keystore", ".jks",  # Java 密钥库
    ".kdbx",  # KeePass 数据库
    ".db", ".sqlite", ".sqlite3",  # 会话库/凭据库(2026-11-01 补:data/sessions.db 曾全放行)
)
# 目录级 denylist:相对根的第一段命中即整目录拒(不猜文件名,新文件天然覆盖)
_SENSITIVE_DIR_SEGMENTS: Final[frozenset[str]] = frozenset(
    {"data", ".uploads", "logs", ".ihui-agent", ".git"}
)


def _is_sensitive_file(path: str, *, roots: list[str] | tuple[str, ...] | None = None) -> bool:
    """检查路径是否为敏感文件/敏感目录内文件(可能含 API key/私钥/凭证/会话库)。

    判定对象是**已 resolve 的路径**(调用方 `_validate_path_in_workspace` 已归一);
    ``roots`` 缺省 = 进程白名单根 ⊕ 当前会话附加根(与实际可读面同源)。

    Returns:
        True = 拒绝读取。
    """
    resolved = Path(path)
    candidate_roots = list(
        roots if roots is not None else (_get_workspace_roots() + list(_active_extra_roots()))
    )
    for root in candidate_roots:
        try:
            relative = resolved.relative_to(Path(root).resolve(strict=False))
        except (ValueError, OSError):
            continue
        if relative.parts and relative.parts[0].casefold() in _SENSITIVE_DIR_SEGMENTS:
            return True

    basename = resolved.name.casefold()
    # 精确匹配 + 前缀匹配(如 .env 匹配 .env / .env.local / .env.production / .envrc)
    for pat in _SENSITIVE_FILE_PATTERNS:
        if basename == pat or basename.startswith(pat + ".") or basename.startswith(pat + "_"):
            return True
        if pat == ".env" and basename.startswith(".env"):
            return True  # `.env*` 全族(.envrc / .env.bak / .env_prod)
        if pat.startswith("id_") and basename.startswith(pat):
            return True  # id_rsa.pub / id_rsa_backup / id_rsa2 同族
    # 无扩展名密钥:`credentials_key` / `checkin_fernet_key` / `signing_key`
    if basename.endswith("_key"):
        return True
    # 扩展名匹配
    return any(basename.endswith(ext) for ext in _SENSITIVE_FILE_EXTENSIONS)


def _validate_media_local_path(path: str) -> tuple[bool, str, str]:
    """媒体工具本地 path 分支的统一入口校验(AIS-050)。

    与 ``read_file`` 同一套判据、同一份实现:先过 ``_validate_path_in_workspace``
    (白名单根 + symlink 穿越),再判 ``_is_sensitive_file``(敏感目录/文件)。
    调用方必须用返回的 resolved 路径去 open/上传,不得再用原始入参。
    """
    ok, info = _validate_path_in_workspace(path)
    if not ok:
        return False, info, "PATH_NOT_ALLOWED"
    if _is_sensitive_file(info):
        return False, sensitive_error_message(info), "SENSITIVE_FILE_BLOCKED"
    return True, info, ""


# ---------------------------------------------------------------------------
# 数据模型
# ---------------------------------------------------------------------------


@dataclass
class MCPTool:
    """MCP 工具定义。"""

    name: str
    description: str
    input_schema: dict[str, Any]


@dataclass
class MCPResource:
    """MCP 资源定义。"""

    uri: str
    name: str
    description: str
    mime_type: str = "application/json"


@dataclass
class MCPPrompt:
    """MCP 提示词定义。"""

    name: str
    description: str
    arguments: list[dict[str, Any]]


# ---------------------------------------------------------------------------
# 工具实现(11 个)
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# 懒索引护栏(V3 #75 后半:2026-09-27 按实测成本重定档)
# ---------------------------------------------------------------------------
#
# 旧形态有两处毛病,都是量出来的而不是审美观:
#
#  1. `_LAZY_INDEX_MAX_FILES = 2000` 自 2026-09-07 起就是个**无依据字面量**,而它读的
#     分母 `len(indexer._collect_code_files(root))` 被 `MAX_FILES_PER_INDEX=5000`
#     **先截断再计数** —— 实测本机工作树该值恒等于 5000(真实代码文件 31,672;
#     同一份代码在另一次检出上是 244,765)。于是"1,500 文件的小仓"与"24 万文件的
#     monorepo"在护栏眼里同形:一个会饱和的分母既定不了阈值,也解释不了超限。
#  2. 非目录 / 冷却 / 超限 / 索引失败**四种不同的事全部 `return []`**,调用方与模型
#     只能读成"语义搜索没找到东西",而真相往往是"这个仓库从没被索引"。
#     护栏的失效方向因此改成:**宁可显式回一个降级标记,不可静默冒充"没找到"**
#     (§5e"失败必须响"与本模块 `enum_degraded` 是同一条禁令)。
#
# ---- 实测依据(2026-09-27,G:\IHUI-AI 真仓 + 同盘受控合成树)----
# 取证脚本:`apps/ai-service/scripts/measure_lazy_index_guardrail.py`(只读仓库、
# 零网络、零生产库,`--json` 出机器可读读数,可重跑)。关键读数:
#
#   轴 A 枚举(护栏探测自己要不付得起的钱)
#     真仓 31,672 个代码文件:ripgrep 0.302s / python-walk 1.442s,两通道结果集
#     逐字相等(对称差 0);受控合成树 2k/10k/50k 档 → rg 0.029/0.043/0.078s、
#     walk 0.031/0.139/0.649s。劣通道(python-walk)按真仓摊薄 = **0.0455 ms/file**。
#     枚举结果集 Python 侧峰值 ≈100 B/file(50,000 文件 → 4.77 MB)。
#     ⇒ **枚举从来不是这条护栏的理由**,即便 10 万文件级也只值 1.5s 与 10 MB 量级。
#
#   轴 B 每文件下游成本(`index_repository` 里**本地可测**那段:读 + sha256 + 切片,
#     真仓 1,200 个真实文件等距抽样)= **0.541 ms/file**,产出 **6.86 切片/file**
#     ⇒ 每文件 6.86 / EMBEDDING_BATCH_SIZE 次上游 embedding 批量。
#     比轴 A 贵 12 倍 —— 这才是护栏该守的东西,与 codebase_indexer 对自己那个
#     `MAX_FILES_PER_INDEX` 的复评结论同向("本常量不动,它守的是下游每文件成本")。
#
#   未实测(如实登记,不伪装成测量):embedding **单批墙钟延迟**与写库延迟 ——
#     取证不许打真实 LLM API、更不许写生产库(§5 测试隔离铁律)。因此第三条轴按
#     **调用次数**封顶(`_LAZY_INDEX_EMBED_BATCH_BUDGET`),不按秒数。
#     本机 venv 未装 tree-sitter,量到的是降级切片路径的成本;而生产用的就是同一条
#     路径(`_tree_sitter_available=False`),所以这一格不是"另一条路的数"。
#
# 三条轴各自换算的文件数上限由 `lazy_index_file_limits()` **现算**,不写字面量。
# 实测结论:binding 的是 embedding 批量轴(约 870 文件),本地墙钟轴约 5.1 万文件、
# 索引硬上限轴 5,000 文件都不 binding ⇒ 新阈值比旧的 2000 **更小**。这不是收紧给人
# 添麻烦:2,000 文件 ≈ 686 个 embedding 批量,而 `_generate_embeddings_batch` 是
# **逐批串行**的,任何一批 ≥100ms 的上游延迟都会把这次懒索引拖过 `MCP_GLOBAL_TIMEOUT`
# —— 旧值从来就不是一个能守住的预算,只是没人量过。超限时的行为从"静默空表"变成
# "带数字的显式降级标记",这才是本票的后半交付。
_LAZY_INDEX_COOLDOWN_SECONDS = 600.0
_LAZY_INDEX_LAST_RUN: dict[str, float] = {}

#: 每文件本地成本(读 + sha256 + 切片),ms。实测 2026-09-27,真仓 1,200 文件样本。
_LAZY_INDEX_LOCAL_MS_PER_FILE: Final[float] = 0.541
#: 枚举的每文件成本,取**劣通道** python-walk(部署机解析不到 rg 时走的就是它),ms。
#: 实测 2026-09-27:真仓 1.442s / 31,672 file = 0.0455;合成树边际 0.01289。取上界。
_LAZY_INDEX_ENUM_WORST_MS_PER_FILE: Final[float] = 0.0455
#: 每文件切片数(→ embedding 批量数)。实测 2026-09-27:8,232 切片 / 1,200 文件。
_LAZY_INDEX_CHUNKS_PER_FILE: Final[float] = 6.86
#: 一次懒索引允许占掉的 handler 墙钟份额。依据:本工具的总闸是 `MCP_GLOBAL_TIMEOUT`
#: (见文件上方,120s),而懒索引只是 search_codebase 的**补救支路** —— 主路正则检索
#: 与索引后的重搜还得在同一次调用里跑完 ⇒ 取 1/4 = 30s。
#: 这是**策略档**不是测量结果,写清楚而不是伪装成实测。
_LAZY_INDEX_HANDLER_BUDGET_SHARE: Final[float] = 0.25
_LAZY_INDEX_LOCAL_BUDGET_SECONDS: Final[float] = MCP_GLOBAL_TIMEOUT * _LAZY_INDEX_HANDLER_BUDGET_SHARE
#: 一次懒索引允许的上游 embedding 批量调用数。**policy,非实测** —— 单批延迟本机量不到
#: (取证不许打真实 LLM API),所以这一轴按次数封顶。取 300 的依据:按实测
#: 0.343 batch/file 折算 ≈ 874 个代码文件,与 `_LAZY_INDEX_LOCAL_BUDGET_SECONDS`
#: 在"每批哪怕只有 100ms"的下界下同量级。**改这个数必须同时改本句依据。**
_LAZY_INDEX_EMBED_BATCH_BUDGET: Final[int] = 300


@dataclass(frozen=True)
class LazyIndexLimits:
    """三条成本轴各自换算出的文件数上限,以及哪一条 binding。

    三个数都**留在结构里**而不是折成一个裸常量:把阈值写成单个整数,正是本票要修
    的那个形状 —— 下一个人只看见 874,看不见它是三条轴取最小值。

    两个预算(``local_budget_seconds`` / ``embed_batch_budget``)也**随对象传进判定函数**:
    判定若去读模块级常量,那它就是"看着纯、实际带隐藏输入"的函数 —— 测试改档只能
    monkeypatch 全局,而 monkeypatch 漏一处就测了个假分支(本票第一版就中过这一枪:
    `_limits_with(batch_budget=20)` 造出来的便宜档被判定函数里的模块常量盖掉,
    "超限必拒"那条用例于是允许了索引)。
    """

    by_local_wall: int
    by_embedding_batches: int
    by_index_hard_cap: int
    #: 换算系数一并带出,超限时原样交给调用方展示
    per_file_ms: float
    embedding_batches_per_file: float
    local_budget_seconds: float
    embed_batch_budget: int
    #: 判定用的**探测上限**依据:三条轴的最小值(下面 max_files)
    handler_budget_share: float = _LAZY_INDEX_HANDLER_BUDGET_SHARE

    @property
    def max_files(self) -> int:
        return max(0, min(self.by_local_wall, self.by_embedding_batches, self.by_index_hard_cap))

    @property
    def binding_axis(self) -> str:
        if self.by_index_hard_cap <= min(self.by_local_wall, self.by_embedding_batches):
            return "index_hard_cap(MAX_FILES_PER_INDEX)"
        if self.by_embedding_batches <= min(self.by_local_wall, self.by_local_wall):
            return "embedding_batch_budget"
        return "local_wall_budget"

    def describe(self) -> str:
        return (
            f"懒索引文件数上限 {self.max_files}(binding={self.binding_axis}):"
            f" 本地墙钟轴 {self.by_local_wall}@{self.per_file_ms:.3f}ms/file"
            f"(预算 {self.local_budget_seconds:.0f}s)、"
            f" embedding 批量轴 {self.by_embedding_batches}"
            f"@{self.embedding_batches_per_file:.3f}batch/file"
            f"(预算 {self.embed_batch_budget} 次)、"
            f" 索引硬上限轴 {self.by_index_hard_cap}"
        )


def lazy_index_file_limits(*, index_hard_cap: int, embedding_batch_size: int) -> LazyIndexLimits:
    """把实测/策略系数换算成三条轴的文件数上限(纯函数:两个入参现传,不读全局)。

    `index_hard_cap` 与 `embedding_batch_size` 由调用方从 `codebase_indexer` 取。
    刻意**不在模块顶层 import** 那两个常量:mcp_server 与 codebase_indexer 之间是
    函数级延迟导入的既有约定;更根本的理由是 —— 懒索引的上限必须跟着索引上限一起动,
    在这儿抄一份字面量就会漂移(本仓记过最多次的失效型)。
    """
    if index_hard_cap < 1 or embedding_batch_size < 1:
        raise ValueError(
            f"index_hard_cap / embedding_batch_size 必须 ≥ 1,实得 {index_hard_cap}/{embedding_batch_size}"
        )
    per_file_ms = _LAZY_INDEX_LOCAL_MS_PER_FILE + _LAZY_INDEX_ENUM_WORST_MS_PER_FILE
    batches_per_file = _LAZY_INDEX_CHUNKS_PER_FILE / embedding_batch_size
    return LazyIndexLimits(
        by_local_wall=int(_LAZY_INDEX_LOCAL_BUDGET_SECONDS * 1000.0 // per_file_ms),
        by_embedding_batches=int(_LAZY_INDEX_EMBED_BATCH_BUDGET // batches_per_file),
        by_index_hard_cap=index_hard_cap,
        per_file_ms=per_file_ms,
        embedding_batches_per_file=batches_per_file,
        local_budget_seconds=_LAZY_INDEX_LOCAL_BUDGET_SECONDS,
        embed_batch_budget=_LAZY_INDEX_EMBED_BATCH_BUDGET,
        handler_budget_share=_LAZY_INDEX_HANDLER_BUDGET_SHARE,
    )


#: 护栏结论的状态。**"确实没有语义命中"只有一种状态**,其余每一格都必须带 reason ——
#: 旧契约把它们全部塌缩成 `[]`,于是"这个仓库没被索引"读起来和"仓库里没有答案"同形。
LazyIndexStatus = Literal[
    "searched",                # 建了索引并重搜,拿到结果
    "empty-after-index",       # 真·没有语义命中(唯一允许空结果不带理由的一格)
    "skipped-not-a-dir",
    # 读不到 ≠ 不存在:目录在但 stat 被拒(EACCES 等)时单列一格,
    # 否则用户会把"权限挡住了"读成"这个目录本来就没有"。
    "skipped-unreadable",
    "skipped-cooldown",
    "skipped-no-code-files",
    "skipped-over-limit",
    # 2026-10-03 数据出域合规整改:用户尚未同意"代码内容发往外部 embedding 服务",
    # 故不建索引(建索引会把源码切片送 llm_gateway.embed → 外部服务出域)。
    # 状态单列一格而不是并进 over-limit:两者给出的用户动作完全不同 ——
    # over-limit 是"仓库太大,建议缩小范围",not-consented 是"请先在设置里授权"。
    "skipped-not-consented",
    # 工作区开关：取消、显式关闭、自动关闭、开关文件读不出来。和「没同意出域」分开，
    # 否则用户会去设置里找授权，而真正挡住的是这个目录的索引开关。
    "skipped-index-cancelled",
    "skipped-index-policy",
    "failed",
]


@dataclass(frozen=True)
class LazyIndexGuard:
    """超限判定的结论 + 全部中间量(不得只回一个布尔)。"""

    allow: bool
    status: LazyIndexStatus
    reason: str | None
    files: int
    files_is_lower_bound: bool
    predicted_local_seconds: float
    predicted_embedding_batches: int
    limits: LazyIndexLimits

    def describe_scale(self) -> str:
        n = f"≥{self.files}" if self.files_is_lower_bound else str(self.files)
        return f"{n} 个代码文件,预计本地 {self.predicted_local_seconds:.1f}s / embedding 批量 {self.predicted_embedding_batches} 次"


def evaluate_lazy_index_guard(probe: SizeProbe, limits: LazyIndexLimits) -> LazyIndexGuard:
    """有界探测 + 实测成本 → 这个目录要不要为它建索引(纯函数:零 I/O、零网络、零 DB)。

    三条判定顺序有意为之:

    1. **撞到索引硬上限即拒**(`is_lower_bound`):探测上限取 `硬上限 + 1`,所以这一格
       的含义是"文件数**严格超过** `MAX_FILES_PER_INDEX`"⇒ 真实规模未知且必然超,
       即使动手索引也只会得到一个**静默不完整**的全仓索引(索引面按该上限截断)。
       "看起来索引好了、其实只有一半"比不索引更坏,所以这一格先于成本轴判,
       而且**只有这一格**配得上"仓库太大"这句话 —— 成本轴超限说的是"这次不该顺手做",
       两者混成一格就会把 874 文件的小仓也报成"巨仓"(第一版就是这么错的)。
    2. 空树:确实没有任何可索引的代码文件 —— 这是真·没有,不是护栏拦截,理由照样写。
    3. 成本轴:预计本地墙钟 / embedding 批量数超预算即拒,**理由里带实测数字**;
       走到这一格时 `probe.count` 一定是精确值(未被硬上限截断)。

    任何 `allow=False` 都必须有 `reason` —— 这条由 `verdict()` 内部直接判死,
    不靠约定:没有原因的拒绝就是旧契约那个静默 `[]` 换了个皮。
    """
    predicted_local = probe.count * limits.per_file_ms / 1000.0
    predicted_batches = math.ceil(probe.count * limits.embedding_batches_per_file)

    def verdict(allow: bool, status: LazyIndexStatus, reason: str | None) -> LazyIndexGuard:
        if not allow and not reason:
            raise AssertionError(f"护栏拒绝({status})必须带 reason,否则又退化成静默失败")
        return LazyIndexGuard(
            allow=allow,
            status=status,
            reason=reason,
            files=probe.count,
            files_is_lower_bound=probe.is_lower_bound,
            predicted_local_seconds=round(predicted_local, 3),
            predicted_embedding_batches=predicted_batches,
            limits=limits,
        )

    if probe.is_lower_bound:
        return verdict(
            False,
            "skipped-over-limit",
            f"代码文件数超过索引硬上限(至少 {probe.count} 个 > 上限 "
            f"{limits.by_index_hard_cap};{probe.describe()})。真实规模未测(探测按上限截断),"
            f"懒索引即便执行也只会覆盖其中一个静默子集,故不触发。"
            f"要全仓语义检索请对子目录显式调用 index_codebase,"
            f"或用 file_search / search_codebase 的正则通道。",
        )
    if probe.count == 0:
        return verdict(
            False,
            "skipped-no-code-files",
            f"目录内没有任何可索引的代码文件({probe.describe()}),无需建索引 —— "
            f"这一格是真·空,不是被护栏拦下。",
        )
    if predicted_batches > limits.embed_batch_budget:
        return verdict(
            False,
            "skipped-over-limit",
            f"预计 embedding 批量 {predicted_batches} 次 > 预算 {limits.embed_batch_budget} 次;"
            f"{limits.describe()};{probe.describe()}。懒索引不触发,"
            f"本次检索回落到正则通道。",
        )
    if predicted_local > limits.local_budget_seconds:
        return verdict(
            False,
            "skipped-over-limit",
            f"预计本地索引墙钟 {predicted_local:.1f}s > 预算 {limits.local_budget_seconds:.0f}s"
            f"(= MCP_GLOBAL_TIMEOUT × {limits.handler_budget_share});"
            f"{limits.describe()};{probe.describe()}。懒索引不触发。",
        )
    return verdict(True, "searched", None)


@dataclass(frozen=True)
class LazyIndexOutcome:
    """一次懒索引尝试的完整结论。

    旧契约返回裸 `list[dict]`,而"没找到""没建""建坏了""在冷却"四件事都是空表;
    本类型把状态与理由一起交出去,调用方**必须**把它投影进响应体
    (见 `_tool_search_codebase` 返回的 `semantic_index` 字段)。
    """

    results: list[dict[str, Any]]
    status: LazyIndexStatus
    reason: str | None
    #: 规模读数(None = 没走到探测那一步,例如非目录 / 冷却中)
    guard: LazyIndexGuard | None = None

    def as_response_field(self) -> dict[str, Any]:
        """投影成工具响应里那一格(可 JSON 化,不含任何仓库内容)。"""
        out: dict[str, Any] = {"status": self.status, "reason": self.reason}
        if self.guard is not None:
            out |= {
                "code_files": self.guard.files,
                "code_files_is_lower_bound": self.guard.files_is_lower_bound,
                "predicted_local_seconds": self.guard.predicted_local_seconds,
                "predicted_embedding_batches": self.guard.predicted_embedding_batches,
                "max_files_allowed": self.guard.limits.max_files,
                "binding_axis": self.guard.limits.binding_axis,
            }
        return out


async def _lazy_index_and_research(
    indexer: Any,
    query: str,
    path: str,
    max_results: int,
    internal_user_id: str | None = None,
    *,
    symbol_name: str | None = None,
) -> LazyIndexOutcome:
    """懒索引:语义通道空结果且 path 为本地目录时,尽力做一次 Merkle 增量索引后重搜。

    护栏见上方 `evaluate_lazy_index_guard`(2026-09-27 按实测成本重定档)。
    背景:此前 index_repository 无任何调用方,codebase_chunks 表永远是空的,
    语义/混合检索在生产运行时形同虚设(2026-09-07 审计发现并根治)。

    返回 `LazyIndexOutcome` 而不是裸 list:**任何**"这轮没有语义结果"都说得出为什么。
    `indexer` 保持 `Any` 是既有的鸭子类型约定(测试用 SimpleNamespace 替身注入),
    只用到 `index_repository` / `search` 两个方法。
    """
    # 触达 codebase_indexer 的**同一份**过滤表与上限,而不是在这里抄第二份:
    # 这两个下划线名是私有的,但复制它们的后果更严重 —— 护栏的分母与索引面一旦不是
    # 同一批文件,阈值就只是在量一个不存在的东西(本票修的正是这一型)。
    from .codebase_indexer import (
        _EXT_TO_LANG,
        _IGNORED_DIRS,
        EMBEDDING_BATCH_SIZE,
        MAX_FILES_PER_INDEX,
    )

    try:
        root = Path(path).resolve()
        # 读不到 ≠ 不存在:exists()/is_dir() 在 EACCES 时按 OSError 上抛,
        # 若落到"不是目录"这一格,用户会以为该目录真的没有(与"不可读被当成空结果"同源)。
        root_kind, root_stat = _classify_path(str(root))
        if root_kind == "unread":
            return LazyIndexOutcome(
                results=[],
                status="skipped-unreadable",
                reason=f"传入的 path 读不到,不能把它说成不是目录({path}),未尝试建索引",
            )
        if (
            root_kind != "present"
            or root_stat is None
            or not stat.S_ISDIR(root_stat.st_mode)
        ):
            return LazyIndexOutcome(
                results=[],
                status="skipped-not-a-dir",
                reason=f"传入的 path 不是可读目录({path}),未尝试建索引",
            )
        from .workspace_index_policy import indexing_decision, workspace_key

        index_decision = indexing_decision(workspace_key(str(root)))
        if not index_decision.allow_index:
            return LazyIndexOutcome(
                results=[],
                status=(
                    "skipped-index-cancelled"
                    if index_decision.phase == "cancelled"
                    else "skipped-index-policy"
                ),
                reason=index_decision.reason,
            )
        now = time.monotonic()
        # ── 2026-10-03 数据出域合规整改:同意闸在建索引**之前** ──
        # 懒索引会把源码切片送外部 embedding 服务(codebase_indexer →
        # llm_gateway.embed → litellm.aembedding),属代码出域。用户未就此明确
        # 同意时不得建索引,本轮直接给"未授权"这一格结论,让主搜索回落到正则
        # 通道(功能降级但零出域)。放在探测之前是刻意的:探测本身只数文件个数
        # 不读内容,放行它无害,但**建索引这一步必须卡死**,故此处即返回。
        if not _code_index_egress_allowed(internal_user_id):
            return LazyIndexOutcome(
                results=[],
                status="skipped-not-consented",
                reason=(
                    "尚未同意将代码内容用于外部语义索引(该操作会把源码发往外部 "
                    "embedding 服务)。如需开启,请在设置中授权;本轮已回落到关键词检索。"
                ),
            )
        # 2026-09-10 修复:缺省哨兵不得用 0.0 —— monotonic() 从进程/系统启动起计,
        # 新启动机器上可能小于冷却窗口,0.0 哨兵会误判为"冷却中"而跳过索引。
        # 改为显式区分"从未运行"(None)与"运行过"(时间戳)。
        last = _LAZY_INDEX_LAST_RUN.get(str(root))
        if last is not None and now - last < _LAZY_INDEX_COOLDOWN_SECONDS:
            return LazyIndexOutcome(
                results=[],
                status="skipped-cooldown",
                reason=(
                    f"该目录 {_LAZY_INDEX_COOLDOWN_SECONDS:.0f}s 内已尝试过懒索引,本轮跳过"
                    f"(再过 {_LAZY_INDEX_COOLDOWN_SECONDS - (now - last):.0f}s 才会重试)"
                ),
            )
        limits = lazy_index_file_limits(
            index_hard_cap=MAX_FILES_PER_INDEX, embedding_batch_size=EMBEDDING_BATCH_SIZE
        )
        # 探测上限 = 索引硬上限 + 1:这一维只回答"有没有超过能完整索引的规模",
        # 成本轴另算。取 +1 是为了把"正好等于上限"(可以完整索引)与"超过"(只能
        # 得到静默子集)分开 —— 用 max_files 当探测上限会把前者误判成后者。
        # 探测本身有界(实测真仓 0.26s),所以"问一句多大"不会变成走一遍全树。
        probe = probe_code_file_count(
            root,
            ignored_dirs=_IGNORED_DIRS,
            suffixes=tuple(_EXT_TO_LANG),
            limit=limits.by_index_hard_cap + 1,
        )
        guard = evaluate_lazy_index_guard(probe, limits)
        _LAZY_INDEX_LAST_RUN[str(root)] = now  # 拒绝路径也记冷却,避免每轮重付探测成本
        if not guard.allow:
            return LazyIndexOutcome(results=[], status=guard.status, reason=guard.reason, guard=guard)
        await indexer.index_repository(str(root), incremental=True, internal_user_id=internal_user_id)
        # 2026-10-03:检索同样带归属(api 侧按 owner_uuid 隔离检索面)
        # Z37:重搜这一跳必须带上同一枚符号过滤位 —— 不带就等于「建完索引后把整仓 topK
        # 端回来再指望装配层挑」,那正是本票要拆掉的先截后滤。缺省档连关键字都不多发。
        research_kwargs: dict[str, Any] = {"top_k": max_results, "internal_user_id": internal_user_id}
        if symbol_name:
            research_kwargs["symbol_name"] = symbol_name
        results = cast(
            list[dict[str, Any]],
            await indexer.search(query, **research_kwargs),
        )
        if results:
            return LazyIndexOutcome(results=results, status="searched", reason=None, guard=guard)
        # 建完索引仍然零命中:这是唯一"空但没有理由"合法的一格 —— 仍然给一句
        # 可读的话,因为它与"护栏拦下了"必须在响应面上分得开。
        return LazyIndexOutcome(
            results=[],
            status="empty-after-index",
            reason=f"已为 {probe.count} 个代码文件建/更新索引,语义通道仍无命中",
            guard=guard,
        )
    except Exception as e:  # noqa: BLE001 - 故意兜住:懒索引不得把主搜索打挂
        # 但"兜住"不等于"咽下"。旧实现 `except Exception: return []` 把建索引失败
        # 也伪装成"没有结果";现在原因进 reason,并打 warning。
        logger.warning("懒索引失败(本次回落到正则通道): %s: %s", type(e).__name__, e)
        return LazyIndexOutcome(
            results=[],
            status="failed",
            reason=f"懒索引执行失败:{type(e).__name__}: {str(e)[:200]}",
        )


def _code_index_egress_allowed(internal_user_id: str | None) -> bool:
    """该用户是否已同意"源码发往外部 embedding 服务"(2026-10-03 出域闸)。

    判据全部委托 `code_index_consent.has_consent`,本函数只做**归属**保障:
    同意是 per-user 的,而工具入参里的 `__user_id` 由服务端注入(G6,LLM 不可控),
    因此不需要也不接受"调用方自称已获授权"这类入参 —— 那样任何 agent 都能
    给自己造授权。未登录态(internal_user_id 为空)在全局默认未开时按未同意处理。
    """
    try:
        from .code_index_consent import has_consent

        return has_consent(internal_user_id)
    except Exception:  # noqa: BLE001
        # 同意存储异常时必须倒向"不出域"(fail-closed),绝不能因读不到就放行。
        logger.error("读取代码索引出域同意失败,本轮按『未授权』处理(不建索引)", exc_info=True)
        return False


async def _tool_index_codebase(arguments: dict[str, Any]) -> dict[str, Any]:
    """index_codebase: 对本地代码库建立/刷新语义索引(Merkle 增量)。

    ⚠ 该操作会把源码切片发往外部 embedding 服务计算向量(代码出域)。
    2026-10-03 起须用户已明确授权(见 code_index_consent);未授权时本工具
    不做任何索引,原样返回带 reason 的结论,不做静默降级。

    search_codebase 的语义/混合通道(pgvector + BM25 RRF)依赖本索引;
    首次语义搜索前建议显式调用,或依赖 search_codebase 的懒索引自动触发。
    """
    path = str(arguments.get("path", "")).strip()
    repo_id = str(arguments.get("repo_id", "")).strip() or None
    force_full = bool(arguments.get("force_full", False))
    # 服务端注入的调用者身份(G6,LLM 不可控),透传给内部服务鉴权通道
    internal_user_id = arguments.get("__user_id") or None
    if not path:
        return {"tool": "index_codebase", "ok": False, "error": "path 不能为空"}
    # AIS-080:与 read_file 同一套工作区白名单校验;根外目录不得进入索引 / embedding。
    ok_path, path_info = _validate_path_in_workspace(path)
    if not ok_path:
        return {
            "tool": "index_codebase",
            "ok": False,
            "error": path_info,
            "errorCode": "PATH_NOT_ALLOWED",
        }
    path = path_info
    from .workspace_index_policy import (
        apply_workspace_index,
        indexing_decision,
        workspace_key,
    )

    keyed = workspace_key(path)
    control = arguments.get("index_control")
    if control is not None:
        if not isinstance(control, str) or not control:
            return {
                "tool": "index_codebase",
                "ok": False,
                "phase": "unjudged",
                "allowIndex": False,
                "error": "index_control 没量到",
            }
        try:
            switched = apply_workspace_index(keyed, control)
        except ValueError:
            return {
                "tool": "index_codebase",
                "ok": False,
                "phase": "unjudged",
                "allowIndex": False,
                "error": "未知的索引开关动作",
            }
        return {
            "tool": "index_codebase",
            "ok": False,
            "phase": switched.phase,
            "allowIndex": switched.allow_index,
            "reason": switched.reason,
        }
    held = indexing_decision(keyed)
    if not held.allow_index:
        return {
            "tool": "index_codebase",
            "ok": False,
            "skipped": held.phase,
            "phase": held.phase,
            "allowIndex": False,
            "error": held.reason,
        }
    # 2026-10-03 数据出域合规整改:同意闸。建索引会把源码切片发往外部 embedding
    # 服务,未获授权时**在读任何文件之前**就返回 —— 连文件都不碰,更谈不上出域。
    # 这里刻意不接受"调用方传入已授权"之类的入参:同意必须来自服务端侧的
    # per-user 记录,否则任何 agent 都能给自己造授权(与 wiki 闸同一纪律)。
    if not _code_index_egress_allowed(internal_user_id):
        return {
            "tool": "index_codebase",
            "ok": False,
            "skipped": "not-consented",
            "error": (
                "尚未同意将代码内容用于外部语义索引:该操作会把源码切片发往外部 "
                "embedding 服务。请在设置中授权后重试。"
            ),
        }
    try:
        from .codebase_indexer import codebase_indexer
        result = await codebase_indexer.index_repository(
            path, repo_id=repo_id, incremental=not force_full,
            internal_user_id=internal_user_id,
        )
        return {
            "tool": "index_codebase",
            "ok": len(result.errors) == 0,
            "repo_id": result.repo_id,
            "files_scanned": result.files_scanned,
            "files_indexed": result.files_indexed,
            "files_unchanged": result.files_unchanged,
            "files_deleted": result.files_deleted,
            "chunks_created": result.chunks_created,
            "chunks_vectorized": result.chunks_vectorized,
            "merkle_root": result.merkle_root,
            # 这三代"必须在响应上可见"的字段此前一律被手挑清单吃掉:实现里写了,端上读不到,
            # 于是"降级/自证失败/被租约挡住"与"一切正常"在响应上长得一模一样。
            # 配套用例逐字段断言,新增字段不许再靠人记得手抄。
            "traversal_engine": result.traversal_engine,
            "traversal_duration_s": result.traversal_duration_s,
            "traversal_files_seen": result.traversal_files_seen,
            "traversal_degraded_reason": result.traversal_degraded_reason,
            "snapshot_state": result.snapshot_state,
            "snapshot_detail": result.snapshot_detail,
            "lock_state": result.lock_state,
            "lock_detail": result.lock_detail,
            # P84:ignore 剪枝回执(剪了多少 / 谁判的 / 哪些"跟踪但被忽略"被保留)
            "files_ignored": result.files_ignored,
            "ignored_by": result.ignored_by,
            "files_tracked_ignored_kept": result.files_tracked_ignored_kept,
            "tracked_ignored_kept": result.tracked_ignored_kept,
            "ignore_notes": result.ignore_notes,
            # P85:改名判定(精确改名不重嵌入;近同候选只改"删+增"的读法)
            "files_renamed": result.files_renamed,
            "rename_candidates": result.rename_candidates,
            "rename_note": result.rename_note,
            # T12 缺口表 #1:目录级递归前像差分(整枝搬家只报最浅一枝;歧义族不报)
            "dir_rhash_note": result.dir_rhash_note,
            "dirs_moved": result.dirs_moved,
            "errors": result.errors[:10],
            "message": (
                f"索引完成: 扫描 {result.files_scanned} 文件, "
                f"新建 {result.files_indexed}, 未变更 {result.files_unchanged}, "
                f"切片 {result.chunks_created}"
            ),
        }
    except Exception as e:
        return {"tool": "index_codebase", "ok": False, "error": str(e)[:300]}


async def _tool_auto_rebuild_codebase(arguments: dict[str, Any]) -> dict[str, Any]:
    """auto_rebuild_codebase: 跑一轮自动重建(开关缺省关闭,预算有天花板)。

    ⚠ 与 `index_codebase` 同一条出域同意闸:重建同样把源码切片发往外部 embedding。
    未同意时**在读任何文件之前**就返回,与 index_codebase 一致。

    语义分三层,不许混成一句"跑完了":
    - 开关没开 ⇒ `skipped=True` + `reason`(运维要知道是"没开"而不是"没活干");
    - 开了但候选空 ⇒ `candidates_total=0`,不是失败;
    - 跑了 ⇒ 逐仓 `results`,失败数单列(`ok=False` 但不抛)。
    """
    internal_user_id = arguments.get("__user_id") or None
    try:
        max_age_days = int(arguments.get("max_age_days") or 30)
    except (TypeError, ValueError):
        return {
            "tool": "auto_rebuild_codebase",
            "ok": False,
            "error": "max_age_days 必须是整数",
        }
    if max_age_days < 0:
        return {
            "tool": "auto_rebuild_codebase",
            "ok": False,
            "error": "max_age_days 必须是非负整数",
        }
    if not _code_index_egress_allowed(internal_user_id):
        return {
            "tool": "auto_rebuild_codebase",
            "ok": False,
            "skipped": "not-consented",
            "error": (
                "尚未同意将代码内容用于外部语义索引:自动重建会把源码切片发往外部 "
                "embedding 服务。请在设置中授权后重试。"
            ),
        }
    try:
        from .codebase_indexer import codebase_indexer

        result = await codebase_indexer.auto_rebuild_once(
            max_age_days=max_age_days,
            internal_user_id=internal_user_id,
        )
    except Exception as e:  # noqa: BLE001 — 工具面必须把异常翻成一行结论,不炸 MCP 循环
        return {"tool": "auto_rebuild_codebase", "ok": False, "error": str(e)[:300]}
    skipped = bool(result.get("skipped"))
    # `ok` 这个名字在两层含义不同:调度层 `run_auto_rebuild` 的 `ok` 是**成功数**,
    # 工具面的 `ok` 是**布尔结论**。直接 `**result` 会让成功数 1 覆盖布尔 True,
    # 调用方读到 `ok:1` 无法判断是"通过"还是"成功了一个"。这里显式分流:
    # 工具面 `ok` 只出布尔,成功数另立 `okCount`。
    ok_count = int(result.get("ok") or 0) if not skipped else 0
    payload = {k: v for k, v in result.items() if k != "ok"}
    return {
        "tool": "auto_rebuild_codebase",
        **payload,
        "ok": (not skipped) and int(result.get("failed") or 0) == 0,
        "okCount": ok_count,
    }


def _git_check_ignore(root: Path, rels: list[str]) -> set[str]:
    """用这份仓库自己的 gitignore 丢掉路径。不是 git 仓或 git 失败则一条都不丢。"""
    if not rels:
        return set()
    import subprocess

    from .process_tree import CREATE_NO_WINDOW

    payload = "\n".join(rel.replace("\\", "/") for rel in rels) + "\n"
    try:
        proc = subprocess.run(
            ["git", "-C", str(root), "check-ignore", "--stdin"],
            input=payload,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=30,
            creationflags=CREATE_NO_WINDOW,
        )
    except (OSError, subprocess.TimeoutExpired):
        return set()
    if proc.returncode not in (0, 1):
        return set()
    ignored: set[str] = set()
    for line in (proc.stdout or "").splitlines():
        norm = line.strip().strip('"').replace("\\", "/")
        if norm:
            ignored.add(norm)
    return ignored


def _search_codebase_keyword_sync(
    root: Any, query: str, pattern: str, max_results: int, symbol_type: str,
    code_exts: set[str], ignored_dirs: set[str], symbol_patterns: dict[str, Any],
    on_walk_error: Callable[[OSError], None] | None = None,
    on_unread_file: Callable[[], None] | None = None,
) -> tuple[list[dict[str, Any]], int]:
    """同步执行关键词腿:os.walk + 一次性 git check-ignore + 文件读取/符号匹配。

    BUG-9:整段含同步文件系统遍历 / 子进程 / 阻塞读,必须经
    ``await asyncio.to_thread(_search_codebase_keyword_sync, ...)`` 调用,
    否则大仓库一次搜索会把事件循环(全部 SSE / 健康检查 / 调度)卡死,
    ``asyncio.wait_for`` 也抢不到同步阻塞。原先**每个目录**起一次
    ``git check-ignore`` 子进程(成百上千次进程启动);这里先把全部相对路径收齐,
    一次 ``--stdin`` 批量传入(台账收口要点),N 次降为 1 次。

    读不到不等于没有:调用方可传 on_walk_error / on_unread_file。不传时保持
    os.walk 的默认静默,返回形状不变。FileNotFoundError 是遍历期消失,不计未读。
    """
    import fnmatch
    import os

    patterns = [p.strip() for p in pattern.split(",") if p.strip()] if pattern else []
    query_lower = query.lower()
    matches: list[dict[str, Any]] = []
    count = 0

    # ① 一次 os.walk 收齐全部目录/文件相对路径(纯遍历,无子进程)
    snapshots: list[tuple[str, list[str], list[str]]] = []
    all_rels: list[str] = []
    for dirpath, dirnames, filenames in os.walk(root, onerror=on_walk_error):
        dirnames[:] = [d for d in dirnames if d not in ignored_dirs]
        file_rels = [
            os.path.relpath(os.path.join(dirpath, fname), root).replace("\\", "/")
            for fname in filenames
        ]
        snapshots.append((dirpath, filenames, file_rels))
        all_rels.extend(
            os.path.relpath(os.path.join(dirpath, d), root).replace("\\", "/")
            for d in dirnames
        )
        all_rels.extend(file_rels)

    # ② 一次 --stdin 批量过 gitignore(替代原先逐目录的 N 次 subprocess.run)
    ignored = _git_check_ignore(root, all_rels)

    # ③ 逐文件按 ignored 过滤 + 读取 + 符号匹配
    for dirpath, filenames, file_rels in snapshots:
        for fname, rel_posix in zip(filenames, file_rels, strict=False):
            if count >= max_results:
                return matches, count
            if rel_posix in ignored:
                continue
            if patterns:
                if not any(fnmatch.fnmatch(fname, p) for p in patterns):
                    continue
            else:
                ext = os.path.splitext(fname)[1].lower()
                if ext not in code_exts:
                    continue

            fpath = os.path.join(dirpath, fname)
            try:
                with open(fpath, encoding="utf-8", errors="ignore") as f:
                    content = f.read()
            except FileNotFoundError:
                continue
            except OSError:
                if on_unread_file is not None:
                    on_unread_file()
                continue

            lines = content.splitlines()
            rel_path = os.path.relpath(fpath, root)
            if query_lower not in content.lower():
                continue

            symbol_matches: list[tuple[int, str, str]] = []
            for sym_type, sym_re in symbol_patterns.items():
                if symbol_type and sym_type != symbol_type:
                    continue
                for m in sym_re.finditer(content):
                    sym_name = m.group(1)
                    if sym_name.lower() == query_lower or query_lower in sym_name.lower():
                        line_no = content.count("\n", 0, m.start()) + 1
                        line_text = lines[line_no - 1] if 0 < line_no <= len(lines) else ""
                        symbol_matches.append((line_no, sym_type, line_text))

            line_matches: list[tuple[int, str]] = []
            for i, line_text in enumerate(lines):
                if query_lower in line_text.lower():
                    line_matches.append((i + 1, line_text))

            seen_lines: set[int] = {ln_no for ln_no, _, _ in symbol_matches}
            for ln_no, ln_text in line_matches:
                if ln_no not in seen_lines:
                    symbol_matches.append((ln_no, "reference", ln_text))
                    seen_lines.add(ln_no)

            if not symbol_matches:
                continue

            for line_no, sym_type, line_text in symbol_matches[:10]:
                start = max(0, line_no - 3)
                end = min(len(lines), line_no + 2)
                preview = "\n".join(
                    f"{start + j + 1}: {lines[start + j]}" for j in range(end - start)
                )
                matches.append({
                    "path": rel_path,
                    "file": fname,
                    "line": line_no,
                    "symbol_type": sym_type,
                    "code": line_text.strip()[:200],
                    "preview": preview[:500],
                })
                count += 1
                if count >= max_results:
                    break

    return matches, count


async def _tool_list_symbol_definitions(arguments: dict[str, Any]) -> dict[str, Any]:
    """list_symbol_definitions: 按符号名取**跨文件**定义簇(P0-8 第四批,2026-11-23)。

    与 search_codebase 的分工:那个工具回答"哪里像这个符号"(检索/排序/预览),
    本工具回答"这个符号在仓库里被定义在哪几处"(输入就是符号名本身,不需要先检索)。
    数据源 = api 的实体表读面(`GET /api/v1/codebase/repo/:repoId/entities`),
    经 knowledge_fs.list_symbols 单源消费(§0.6,本处不复制 HTTP 与三态判据)。

    repo_id 缺省时按 path 推导 —— 与 index_codebase 同一份 `_default_repo_id`,
    否则 agent 得先知道一枚它拿不到的 hash 才能用这个工具。

    归属:只认服务端注入的 `__user_id`(与 search_codebase 一字不差的纪律);
    缺身份直接拒绝,不起"匿名查全部"的默认。
    """
    name = str(arguments.get("name", "") or "").strip()
    if not name:
        return {
            "tool": "list_symbol_definitions",
            "ok": False,
            "errorCode": "missing_argument",
            "error": "name 必填:本工具按符号名逐字相等取定义位置,不做模糊匹配",
        }
    internal_user_id = arguments.get("__user_id") or None
    if not internal_user_id:
        return {
            "tool": "list_symbol_definitions",
            "ok": False,
            "errorCode": "missing_identity",
            "error": "未注入调用者身份:代码索引按归属隔离,拒绝无身份查询",
        }
    path = str(arguments.get("path", ".") or ".")
    repo_id = str(arguments.get("repo_id", "") or "").strip()
    if not repo_id:
        from .codebase_indexer import _default_repo_id

        repo_id = _default_repo_id(Path(path).resolve())
    try:
        limit = int(arguments.get("limit", 50))
    except (TypeError, ValueError):
        return {
            "tool": "list_symbol_definitions",
            "ok": False,
            "errorCode": "invalid_argument",
            "error": "limit 必须是正整数",
        }
    from .knowledge_fs import knowledge_fs

    data = await knowledge_fs.list_symbols(repo_id, name, internal_user_id, limit=limit)
    status = str(data.get("status") or "unjudged")
    out: dict[str, Any] = {
        "tool": "list_symbol_definitions",
        "ok": status == "ok",
        "status": status,
        "repo_id": repo_id,
        "name": name,
        "count": int(data.get("count") or 0),
        "definitions": data.get("definitions") or [],
    }
    if data.get("detail"):
        # 空集三因三分(path_missing / catalog_missing / upstream_unavailable)的原委一字不改地透传:
        # 调用方据此决定"重建索引"还是"换个符号",而不是把三种因都读成"不存在"。
        out["detail"] = data["detail"]
    return out


async def _tool_list_project_rules(arguments: dict[str, Any]) -> dict[str, Any]:
    """list_project_rules: 规则选择面的只读诊断(2026-11-24,Cursor 规则 picker 等价)。

    会话注入只带正文与「可请求目录」,人被问"为什么这条规则没生效"时没有观测口。
    本工具把 **selected / agentRequested / excluded / budget** 一次列清,并且只回
    locator、原因与长度,不回正文(避免把诊断工具变成第二个注入面)。
    """
    from ..core.project_rules import DEFAULT_BUDGET_CHARS, select_rules

    tool = "list_project_rules"
    path = str(arguments.get("path", ".") or ".")
    try:
        root = Path(path).resolve(strict=True)
    except OSError:
        return {
            "tool": tool,
            "ok": False,
            "errorCode": "workspace_missing",
            "error": f"工作区不存在或不可达: {path}",
        }
    budget = DEFAULT_BUDGET_CHARS
    raw_budget = arguments.get("budgetChars")
    if raw_budget is not None:
        try:
            parsed_budget = int(raw_budget)
        except (TypeError, ValueError):
            parsed_budget = 0
        if parsed_budget <= 0:
            return {
                "tool": tool,
                "ok": False,
                "errorCode": "invalid_budget",
                "error": "budgetChars 必须是正整数",
            }
        budget = parsed_budget
    raw_targets = arguments.get("targetPaths")
    if raw_targets is not None and not isinstance(raw_targets, list):
        return {
            "tool": tool,
            "ok": False,
            "errorCode": "invalid_targets",
            "error": "targetPaths 必须是字符串数组",
        }
    targets = [str(x) for x in raw_targets] if isinstance(raw_targets, list) else None
    selection = select_rules(root, targets, budget_chars=budget)
    return {
        "tool": tool,
        "ok": True,
        "selected": [
            {
                "locator": rule.rel_path,
                "description": rule.description,
                "reason": rule.reason,
                "matchedPaths": list(rule.matched_paths),
                "bodyChars": len(rule.body),
            }
            for rule in selection.selected
        ],
        "agentRequested": [
            {
                "locator": rule.locator,
                "description": rule.description,
                "scope": "user" if rule.locator.startswith("user:") else "project",
            }
            for rule in selection.agent_requested
        ],
        "excluded": [{"locator": item.rel_path, "reason": item.reason} for item in selection.excluded],
        "budget": {
            "chars": selection.budget_chars,
            "used": selection.used_chars,
            "truncated": selection.truncated,
        },
        "counts": {
            "selected": len(selection.selected),
            "agentRequested": len(selection.agent_requested),
            "excluded": len(selection.excluded),
        },
    }


async def _tool_read_project_rule(arguments: dict[str, Any]) -> dict[str, Any]:
    """read_project_rule: 按 locator 取一条项目/用户规则正文(2026-11-24 第二档)。

    Cursor 的 Agent Requested 规则只把 description 给模型,正文按需取 —— 本工具就是
    那个"按需取"的口;locator 来自注入的「[项目规则·可请求]」目录。
    安全判据与发现档同源(`app/core/project_rules.read_rule_body`):拒符号链接、拒越界、
    拒超限、拒坏 frontmatter;失败返回机器可读 errorCode,不返回空串。
    """
    locator = str(arguments.get("locator", "") or "").strip()
    if not locator:
        return {
            "tool": "read_project_rule",
            "ok": False,
            "errorCode": "missing_argument",
            "error": "locator 必填:取自「[项目规则·可请求]」目录(例如 .cursor/rules/a.mdc)",
        }
    path = str(arguments.get("path", ".") or ".")
    try:
        root = Path(path).resolve(strict=True)
    except OSError:
        return {
            "tool": "read_project_rule",
            "ok": False,
            "errorCode": "workspace_missing",
            "error": f"工作区不存在或不可达: {path}",
        }
    from ..core.project_rules import RuleLookupError, read_rule_body

    try:
        loaded = read_rule_body(root, locator)
    except RuleLookupError as exc:
        return {
            "tool": "read_project_rule",
            "ok": False,
            "errorCode": exc.code,
            "error": f"规则取不到({exc.code});不返回空正文冒充「规则为空」",
        }
    return {
        "tool": "read_project_rule",
        "ok": True,
        "locator": loaded.locator,
        "description": loaded.description,
        "body": loaded.body,
        "globs": list(loaded.globs),
        "alwaysApply": loaded.always_apply,
        "scope": loaded.scope,
    }


async def _tool_find_import_edges(arguments: dict[str, Any]) -> dict[str, Any]:
    """find_import_edges: 按名字查导入关系(P0-8 第八批,2026-11-23)。

    两档方向(**不猜**):
    - `direction='from'`(缺省):这个**文件**导入了谁 —— target 是仓库相对路径;
    - `direction='to'`:谁导入了这个**名字** —— target 是 import 名字原文。

    猜"这是路径还是名字"会把两件不同的事混成一件(同一个词可能既是文件名前缀又是
    符号名),所以方向必须由调用方给出。数据源 = api 边表读面,经
    `knowledge_fs.list_imports` 单源消费(§0.6,本处不复制 HTTP 与三态判据)。

    repo_id 缺省按 path 推导 —— 与 index_codebase 同一份 `_default_repo_id`。
    归属只认服务端注入的 `__user_id`,缺身份直接拒绝。
    """
    target = str(arguments.get("target", "") or "").strip()
    if not target:
        return {
            "tool": "find_import_edges",
            "ok": False,
            "errorCode": "missing_argument",
            "error": "target 必填:from 档填仓库相对路径,to 档填 import 名字原文",
        }
    internal_user_id = arguments.get("__user_id") or None
    if not internal_user_id:
        return {
            "tool": "find_import_edges",
            "ok": False,
            "errorCode": "missing_identity",
            "error": "未注入调用者身份:代码索引按归属隔离,拒绝无身份查询",
        }
    direction = str(arguments.get("direction", "from") or "from")
    if direction not in ("from", "to"):
        return {
            "tool": "find_import_edges",
            "ok": False,
            "errorCode": "invalid_argument",
            "error": "direction 只支持 from / to",
        }
    path = str(arguments.get("path", ".") or ".")
    repo_id = str(arguments.get("repo_id", "") or "").strip()
    if not repo_id:
        from .codebase_indexer import _default_repo_id

        repo_id = _default_repo_id(Path(path).resolve())
    try:
        limit = int(arguments.get("limit", 50))
    except (TypeError, ValueError):
        return {
            "tool": "find_import_edges",
            "ok": False,
            "errorCode": "invalid_argument",
            "error": "limit 必须是正整数",
        }
    from .knowledge_fs import knowledge_fs

    data = await knowledge_fs.list_imports(
        repo_id, target, internal_user_id, direction=direction, limit=limit
    )
    status = str(data.get("status") or "unjudged")
    out: dict[str, Any] = {
        "tool": "find_import_edges",
        "ok": status == "ok",
        "status": status,
        "repo_id": repo_id,
        "target": target,
        "direction": direction,
        "count": int(data.get("count") or 0),
        "edges": data.get("edges") or [],
    }
    if data.get("detail"):
        # 空集原委透传:path_missing / catalog_missing(含"TS 不产边"这层二义)/
        # upstream_unavailable 三档不同,调用方据此决定"重建索引"还是"换策略"
        out["detail"] = data["detail"]
    return out


async def _tool_search_codebase(arguments: dict[str, Any]) -> dict[str, Any]:
    """search_codebase: 代码符号搜索(关键词腿 + 语义腿并跑,RRF 融合)。

    专注于代码符号(函数/类/方法定义 + 引用)的搜索,支持:
    - query: 符号名或关键词(如函数名、类名)
    - path: 搜索根目录(默认当前目录)
    - pattern: 文件名 glob 限定(默认 *.py/*.ts/*.tsx/*.js/*.jsx/*.go/*.rs/*.java)
    - max_results: 最大返回数(默认 50)
    - symbol_type: 符号类型过滤(def/class/func/function/interface/type,默认空=全部)
    - symbol_name: 符号名**精确**过滤(逐字相等、大小写敏感;Z28 格 1)。默认空 ⇒ 过滤链
      根本不发起,返回体与旧实现逐字节相同;非空时命中集只保留"被定义符号名逐字等于该值"
      的片(不做前缀/包含匹配 —— 那是 query 那一维已有的语义)。
      **Z37 起该位已下推到检索腿**:symbol_name 随首跳进 HTTP 请求体
      (`POST /api/v1/codebase/search` 的 `symbolName`),等值条件在 api 侧进 SQL `WHERE`、
      发生在 `LIMIT` 之前,且该档的取回预算脱离 topK(单源 = api 的 `rowBudget()`)。
      装配层的逐字过滤**保留**(不是回落):关键词腿是本地文件系统扫描,不经 HTTP,
      下推覆盖不到它;对已下推的语义腿而言这一层是幂等的,两侧不一致的次数读进
      `stats.symbol_pushdown_disagree`。api 侧取不到响应 ⇒ `stats.symbol_filter`
      落 `unjudged:<原委>` 并让语义腿具名失败,不静默当成本地过滤成功。
      符号档另有一处**必须出声的口径变化**:`max_results` 不再截断出参(Z28 那格
      「先截后滤」缺口的另一半),命中条数只受 api 那份行预算约束;
      段账 detail 与 `stats.symbol_filter` 都点名当下是哪一档,缺省档一字不动。
    - 忽略常见依赖/构建/缓存目录
    - 忽略二进制文件
    - 返回: 文件路径 + 行号 + 符号类型 + 代码行 + 上下文预览

    2026-11-01 票 #10(验收尺 `scripts/check-retrieval-quality.mjs`):两条腿**并发都跑**,
    名次由 `reranker.rrf_fuse`(`k` 取 `rag.resolve_rrf_k()`)给出 —— 与 `rag._retrieve`
    同一份融合实现、同一口径,旧契约「语义失败/无结果 ⇒ 静默回落 regex」已废除。
    降级一律具名出声,`mode` 五档(命名与 rag 侧 `stats["mode"]` 同族):
      rrf-fusion             两腿都取到、都给了结果,名次来自 RRF
      single-source:vector   只有语义腿给出结果(另一腿空或取不到)
      single-source:keyword  只有关键词腿给出结果(同上)
      empty                  两腿都取到且都判空 —— "查过了,没有"
      unjudged               至少一腿取不到,且没有任何腿给出结果 —— 判不出,不冒充 empty
    `empty` 与 `unjudged` 分档是刻意的:前者是可以据此下"仓库里没有"结论的判定,
    后者不能(§0.3「没判」绝不写成"判过")。
    """
    query = arguments.get("query", "")
    path = arguments.get("path", ".")
    pattern = arguments.get("pattern", "")
    max_results = int(arguments.get("max_results", 50))
    symbol_type = arguments.get("symbol_type", "").strip().lower()
    # Z28 格 1:符号名精确过滤位(可选入参)。空 = 不发起,行为与旧实现逐字节相同。
    symbol_name = str(arguments.get("symbol_name", "") or "").strip()
    # 2026-11-01 票 #10:语义腿开关(默认 True)。False 是调用方的显式选择,
    # 不当作"腿坏了"—— 它以 status=skipped 如实进 reasons,mode 落在 single-source:keyword。
    use_semantic = arguments.get("use_semantic", True)
    # V3 #75 后半:语义通道这一轮**为什么**没给结果,必须随响应回去。
    # 2026-11-01 票 #10:异常分支同样赋值 —— 旧实现只在成功路径赋值,
    # 于是语义腿炸掉时这一格恒 null,异常只剩一句 debug 日志(尺子点名的那一型)。
    # None = 没走到懒索引那一步;非 None 时 status/reason 一定可读。
    semantic_index_field: dict[str, Any] | None = None
    # 2026-10-03 数据出域合规整改:调用者身份(服务端注入,LLM 不可伪造)。
    # 语义检索与懒索引都按归属隔离,不传则 api 侧 401 → 语义腿拿不到结果,
    # 关键词腿照常工作(功能降级但不泄露,且正则路径不碰数据库)。
    _caller_user_id = arguments.get("__user_id") or None
    # 遥测出参(与 rag._retrieve 的 stats 同族):降级原因回到返回体,不许只留在日志里。
    stats: dict[str, Any] = {}
    # 2026-11-05 Z19(缺口表 T9 §10 #3):逐段结论 + 耗时 + 计数。段清单与结论词表只在
    # `app/services/stage_telemetry.py` 一处声明(§0.6),这里只是消费方;每段落一条
    # `[stage_result]` 结构化结论行,没走到的段由 finalize() 补 `unjudged`(不许缺项)。
    stages = StageRecorder("search_codebase")
    # validate 段的手表取在入参检查之前:早退路径也要能报"这一段花了多久"
    validate_clock = stages.clock()

    # 默认代码文件扩展名(若未指定 pattern)
    _CODE_EXTS = {
        ".py", ".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs",
        ".go", ".rs", ".java", ".kt", ".swift", ".c", ".h", ".cpp", ".cc", ".hpp",
        ".cs", ".rb", ".php", ".scala", ".clj", ".el", ".ex", ".exs",
        ".vue", ".svelte", ".astro",
        ".sql", ".sh", ".bash", ".zsh", ".ps1",
        ".yml", ".yaml", ".toml", ".json", ".xml", ".html", ".css", ".scss",
    }
    # 忽略目录
    _IGNORED_DIRS = {
        "node_modules", ".git", "__pycache__", ".venv", "venv",
        "dist", "build", ".next", ".turbo", ".cache", "coverage",
        ".mypy_cache", ".pytest_cache", ".ruff_cache", ".tox", "env",
    }
    # 符号定义模式(按语言)
    # 匹配 def/class/func/function/interface/type 等关键字后跟符号名
    _SYMBOL_PATTERNS = {
        "def": re.compile(r"^\s*(?:async\s+def|def)\s+(\w+)", re.MULTILINE),  # Python
        "class": re.compile(r"^\s*(?:abstract\s+class|class|interface|trait)\s+(\w+)", re.MULTILINE),
        "func": re.compile(r"^\s*func\s+(\w+)", re.MULTILINE),  # Go
        "function": re.compile(r"^\s*(?:export\s+)?(?:async\s+)?function\s+(\w+)", re.MULTILINE),  # JS/TS
        "interface": re.compile(r"^\s*(?:export\s+)?interface\s+(\w+)", re.MULTILINE),  # TS
        "type": re.compile(r"^\s*(?:export\s+)?type\s+(\w+)", re.MULTILINE),  # TS
    }

    if not query:
        stages.record(
            "validate", "failed",
            duration_ms=validate_clock.elapsed_ms(),
            count=0,
            detail="搜索关键词为空,两腿均未发起",
        )
        return {
            "tool": "search_codebase",
            "query": query,
            "path": path,
            "matches": [],
            "mode": "unjudged",
            "degraded": True,
            "reasons": [
                {"leg": "query", "status": "missing", "detail": "搜索关键词为空,两腿均未发起"},
            ],
            "stats": stats,
            # 早退路径同样出满六段:后五段是"没走到",由 finalize() 显式记 unjudged(不许缺项)
            "stages": stages.finalize(),
            "message": "搜索关键词为空",
            "ok": False,
        }
    # AIS-080:与 read_file 同一套工作区白名单校验 —— 根外目录不得进入关键词扫描 /
    # 懒索引 / 语义检索。相对路径也走这里;后续统一使用校验返回的 resolved 路径。
    ok_path, path_info = _validate_path_in_workspace(path)
    if not ok_path:
        stages.record(
            "validate", "failed",
            duration_ms=validate_clock.elapsed_ms(),
            count=0,
            detail="路径不在工作区白名单",
        )
        stats["path_validation"] = "blocked"
        return {
            "tool": "search_codebase",
            "query": query,
            "path": path,
            "matches": [],
            "mode": "unjudged",
            "degraded": True,
            "reasons": [
                {"leg": "path", "status": "blocked", "detail": path_info},
            ],
            "stats": stats,
            "stages": stages.finalize(),
            "message": "路径不在工作区白名单",
            "ok": False,
            "errorCode": "PATH_NOT_ALLOWED",
        }
    path = path_info
    stages.record(
        "validate",
        "ok",
        count=1,
        duration_ms=validate_clock.elapsed_ms(),
        **({"detail": f"symbol_name 精确过滤已启用:{symbol_name}"} if symbol_name else {}),
    )

    def _fusion_key(match: dict[str, Any]) -> str:
        """融合去重键:位置 + 归一后的符号类型(行级命中,同文件不同行不得折成一枚)。

        用的是 `rrf_fuse` 在册的 `key_fn` 扩展点,不是第二套融合判据:它的默认
        `_default_key` 按 id→path→content 前缀取值,直接用在行级命中上会把一个
        文件里的多处命中吃掉只剩第一处。
        - 键里必须带符号类型:一行 `interface User {` 会被关键词腿同时记成
          "class" 与 "interface" 两枚命中(同 path 同行),只按 path:line 取值
          就把它们折成一枚(实测撞上的正是 TS interface 那一例)。
        - 两腿的符号类型词汇表不同源(关键词腿 `_SYMBOL_PATTERNS` 用 def/func,
          索引侧 `_SYMBOL_NODE_TYPES` 用 function),不归一就永远撞不到同一枚键,
          融合退化成两腿并集;归一只作用在这把键上,不改任何一条腿的输出。
        """
        sym = str(match.get("symbol_type", ""))
        sym = {"def": "function", "func": "function"}.get(sym, sym)
        return f"loc:{match.get('path', '')}:{match.get('line', 0)}:{sym}"

    def _symbol_exact_hit(item: dict[str, Any]) -> bool:
        """symbol_name 精确过滤的单点判据(逐字相等,大小写敏感)。

        - 语义腿的命中自带 `symbol_name`(索引列直取)⇒ 直接与入参逐字比。
        - 关键词腿的命中只有 `symbol_type` + 代码行 ⇒ 复用本函数**在册**的
          `_SYMBOL_PATTERNS` 从代码行抽出"被定义的那个符号名"再逐字比;
          抽不出(纯引用行 sym_type=reference)⇒ 不命中,不猜。
        - 不引入第二份符号正则,也不把"包含"当"相等"。
        """
        raw = item.get("symbol_name")
        if isinstance(raw, str) and raw:
            return raw == symbol_name
        code_line = str(item.get("code") or "")
        for sym_re in _SYMBOL_PATTERNS.values():
            found = sym_re.search(code_line)
            if found and found.group(1) == symbol_name:
                return True
        return False

    async def _semantic_leg() -> dict[str, Any]:
        """语义腿(pgvector ANN;空结果时走懒索引补救)。

        归属判据一字未动:`internal_user_id` 仍只认服务端注入的 `__user_id`,
        源码出域同意闸仍在 `_lazy_index_and_research` 内部把关(未同意 ⇒ 不建索引)。
        本腿把异常转成 status/reason 交回装配层:一腿坏了不许带走整次检索,
        但**必须**出声 —— 旧实现只写一句 debug 日志、异常分支连 `semantic_index_field`
        都不赋值,于是响应里那一格恒 null(验收尺点名的 silent-degrade 载体)。
        """
        nonlocal semantic_index_field
        if not use_semantic:
            return {
                "status": "skipped",
                "matches": [],
                "reason": "use_semantic=False(调用方显式关闭语义腿)",
            }
        try:
            from .codebase_indexer import SymbolFilterUndetermined, codebase_indexer
            # 2026-10-03:检索按归属隔离(见 _caller_user_id 处注释)
            # Z37 下推:符号档才追加 `symbol_name` 这一枚关键字入参 —— 缺省档连**调用形状**
            # 都与今天逐字相同(在册替身里那些把签名收紧成 query/top_k/internal_user_id 的
            # fake_search 因此结构上不可能被本票碰坏)。
            search_kwargs: dict[str, Any] = {"top_k": max_results, "internal_user_id": _caller_user_id}
            if symbol_name:
                search_kwargs["symbol_name"] = symbol_name
            semantic_results = await codebase_indexer.search(query, **search_kwargs)
            if symbol_name:
                # 走到这里 = 首跳判过了(`search()` 在未判定时抛 SymbolFilterUndetermined)。
                stats["symbol_filter"] = "pushed"
            # 2026-09-07 立:懒索引——空结果且 path 为本地目录时,增量索引后重搜一次
            # (根治:此前 index_repository 无调用方,语义/混合检索在生产运行时永远空表)
            if not semantic_results:
                lazy_clock = stages.clock()
                lazy = await _lazy_index_and_research(
                    codebase_indexer,
                    query,
                    path,
                    max_results,
                    internal_user_id=_caller_user_id,
                    **({"symbol_name": symbol_name} if symbol_name else {}),
                )
                semantic_results = lazy.results
                semantic_index_field = lazy.as_response_field()
                if symbol_name and lazy.status == "failed":
                    # 懒索引把重搜异常咽成 status="failed" 是在册兜底(缺省档一字不动),
                    # 符号档不借这一格把「取不到」读成「库里没有」⇒ 就地转具名未判定(§0.3)。
                    raise SymbolFilterUndetermined(
                        f"symbol_name={symbol_name} 懒索引重搜未判定:{lazy.reason}"
                    )
                stages.record(
                    "lazy_index",
                    "ok" if semantic_results else "empty",
                    duration_ms=lazy_clock.elapsed_ms(),
                    count=len(semantic_results),
                    detail=f"status={lazy.status}: {lazy.reason}",
                )
            leg_matches: list[dict[str, Any]] = []
            # Z37:符号档不在本侧补 topK 那一刀。api 的 `rowBudget()` 早把该档的取回预算
            # 脱钩出 topK(Z36 单源 = SYMBOL_SCOPED_ROW_CAP),这里再 `[:max_results]`
            # 就是把刚摆正的次序重新削成「先截后滤」(§0.6:预算只许那份判据算一次)。
            # 缺省档口径逐字节不变:仍然 top_k = max_results、仍然先截。
            scoped_semantic = list(semantic_results)
            for r in scoped_semantic if symbol_name else scoped_semantic[:max_results]:
                content_preview = r.get("content", "")
                if len(content_preview) > 500:
                    content_preview = content_preview[:500]
                leg_matches.append({
                    "path": r.get("filePath", ""),
                    "file": r.get("filePath", "").rsplit("/", 1)[-1],
                    "line": r.get("lineStart", 0),
                    "symbol_type": r.get("symbolType", "semantic"),
                    "symbol_name": r.get("symbolName", ""),
                    "code": content_preview[:200],
                    "preview": content_preview,
                    "score": round(r.get("score", 0), 4),
                })
            return {
                "status": "ok",
                "matches": leg_matches,
                "reason": semantic_index_field.get("reason") if semantic_index_field else None,
            }
        except TimeoutError as e:
            semantic_index_field = {"status": "timeout", "reason": f"{type(e).__name__}: {e}"}
            stats["vector_leg"] = "timeout"
            if symbol_name:
                stats["symbol_filter"] = f"unjudged:TimeoutError:{e}"
            return {
                "status": "timeout",
                "matches": [],
                "reason": f"语义腿超时: {type(e).__name__}: {e}",
            }
        except Exception as e:  # noqa: BLE001 - 本腿失败不带走整次检索,但必须出声
            semantic_index_field = {"status": "failed", "reason": f"{type(e).__name__}: {e}"}
            stats["vector_leg"] = "failed"
            # Z37:符号档的「取不到响应」必须在这一格落名(含 `SymbolFilterUndetermined`,
            # 它由检索腿在首跳未判定时抛出)。缺省档不写这一格 ⇒ 出参形状逐字节不变。
            if symbol_name:
                stats["symbol_filter"] = f"unjudged:{type(e).__name__}:{e}"
            logger.warning(
                "search_codebase 语义腿失败(状态与原因已进返回体,不再静默回落): %s: %s",
                type(e).__name__,
                e,
            )
            return {
                "status": "failed",
                "matches": [],
                "reason": f"语义腿异常: {type(e).__name__}: {e}",
            }

    async def _keyword_leg() -> dict[str, Any]:
        """关键词腿(真实文件系统 regex 符号 + 引用扫描,不碰数据库)。"""
        try:
            from pathlib import Path

            root = Path(path).resolve()
            # 读不到 ≠ 不存在:Path.exists() 会把权限/IO 错误吞成 False。统一走
            # _classify_path,权限问题显式报"读不到",不把排查方向带偏成"路径写错了"。
            kind, st = _classify_path(str(root))
            if kind == "unread":
                return {
                    "status": "unavailable",
                    "matches": [],
                    "truncated": False,
                    "reason": f"路径读不到: {path}",
                }
            if kind == "missing":
                return {
                    "status": "unavailable",
                    "matches": [],
                    "truncated": False,
                    "reason": f"路径不存在: {path}",
                }
            if st is not None and not stat.S_ISDIR(st.st_mode):
                return {
                    "status": "unavailable",
                    "matches": [],
                    "truncated": False,
                    "reason": f"路径不是目录: {path}",
                }

            # BUG-9:整段同步遍历 + 子进程 + 阻塞读统一挪到线程池,事件循环不再被
            # 大仓库搜索卡死(wait_for 抢不到同步阻塞);git check-ignore 一次批量(见 helper)。
            # 读不到的计数住在本帧:遍历在线程里跑,钩子把次数加回来。
            unread_dirs = 0
            unread_files = 0

            def _on_walk_error(err: OSError) -> None:
                nonlocal unread_dirs
                if isinstance(err, FileNotFoundError):
                    return
                unread_dirs += 1

            def _on_unread_file() -> None:
                nonlocal unread_files
                unread_files += 1

            matches, count = await asyncio.to_thread(
                _search_codebase_keyword_sync,
                root, query, pattern, max_results, symbol_type,
                _CODE_EXTS, _IGNORED_DIRS, _SYMBOL_PATTERNS,
                _on_walk_error, _on_unread_file,
            )
            note = None
            if unread_dirs or unread_files:
                note = (
                    f"有 {unread_dirs} 个目录、{unread_files} 个文件读不到,"
                    "不能把检索说成完整"
                )
            if not matches and note:
                return {
                    "status": "unjudged",
                    "matches": [],
                    "truncated": False,
                    "reason": note,
                }
            return {
                "status": "ok",
                "matches": matches,
                "truncated": count >= max_results,
                "reason": note,
            }
        except Exception as e:  # noqa: BLE001 - 本腿失败不带走整次检索,但必须出声
            stats["keyword_leg"] = "failed"
            logger.warning(
                "search_codebase 关键词腿失败(状态与原因已进返回体): %s: %s",
                type(e).__name__,
                e,
            )
            return {
                "status": "failed",
                "matches": [],
                "truncated": False,
                "reason": f"关键词腿异常: {type(e).__name__}: {e}",
            }

    # 双腿并发启动(照 rag._retrieve 的先例:两条腿各自 create_task 再 await,
    # 不是串行 await 两次把延迟叠成两倍)
    #
    # 2026-11-05 Z19:每段的手表取在**协程自己被调度的那一刻**,不是取在 await 返回那一刻 ——
    # 两腿并发 ⇒ 两条时间区间天然重叠,`stages` 是"各段各自花了多久"的读数,
    # **不是**把总时长切成互斥的六份(那种口径本仓只有一份,见 core/turn_timing.py)。
    # 腿内一行未改:状态/命中数从腿的既有返回契约里读,不另起第二份判据。
    async def _instrumented(stage: str, leg: "Awaitable[dict[str, Any]]") -> dict[str, Any]:
        clock = stages.clock()
        out: dict[str, Any] = await leg
        stages.record(
            stage,
            str(out.get("status") or UNJUDGED),
            duration_ms=clock.elapsed_ms(),
            count=len(out.get("matches") or []),
            detail=out.get("reason"),
        )
        return out

    vec_task = asyncio.create_task(_instrumented("semantic_leg", _semantic_leg()))
    kw_task = asyncio.create_task(_instrumented("keyword_leg", _keyword_leg()))
    vec = await vec_task
    kw = await kw_task
    # 语义腿被调用方显式关闭时,懒索引是"跟着一起没发起"——按票面要显式出声,不许缺项
    if vec.get("status") == "skipped":
        stages.record("lazy_index", "skipped", count=0, detail="语义腿被调用方关闭,懒索引随之不发起")

    reasons: list[dict[str, Any]] = [
        {"leg": "vector", "status": vec["status"], "detail": vec["reason"]},
        {"leg": "keyword", "status": kw["status"], "detail": kw["reason"]},
    ]
    answered = [
        (label, leg)
        for label, leg in (("vector", vec), ("keyword", kw))
        if leg["status"] == "ok"
    ]
    missing_legs = [
        label
        for label, leg in (("vector", vec), ("keyword", kw))
        if leg["status"] != "ok"
    ]
    hit_legs = [(label, leg["matches"]) for label, leg in answered if leg["matches"]]

    if len(hit_legs) == 2:
        mode = "rrf-fusion"
    elif len(hit_legs) == 1:
        mode = f"single-source:{hit_legs[0][0]}"
    elif missing_legs:
        # 有腿没答上 + 答上来的腿是空的 ⇒ 判不出"这里没有",不得冒充 empty(§0.3)
        mode = "unjudged"
    else:
        mode = "empty"

    degraded = mode not in ("rrf-fusion", "empty")
    stats["mode"] = mode
    stats["legs_answered"] = [label for label, _leg in answered]
    stats["legs_unavailable"] = missing_legs
    stats["degraded"] = degraded

    if not hit_legs and kw["status"] in ("unavailable", "failed"):
        # 入参层面的路径错误 / 关键词腿自身炸了,且语义腿也没给出结果:
        # 沿用既有对外契约(ok=False + "搜索失败: …"),但 mode/reasons 一并回去。
        detail = str(kw["reason"] or "关键词腿不可用")
        stages.record("fuse", "skipped", count=0, detail=f"两腿都没给出结果,融合无从发起:{detail}")
        stages.record("assemble", "skipped", count=0, detail="融合未发起,装配段随之跳过")
        return {
            "tool": "search_codebase",
            "query": query,
            "path": path,
            "matches": [],
            "total": 0,
            "mode": mode,
            "degraded": degraded,
            "reasons": reasons,
            "stats": stats,
            "stages": stages.finalize(),
            "use_semantic": bool(use_semantic),
            "semantic_index": semantic_index_field,
            "message": f"搜索失败: {detail}",
            "ok": False,
            "error": detail,
        }

    from .rag import resolve_rrf_k
    from .reranker import rrf_fuse

    rankings: list[list[dict[str, Any]]] = [leg_matches for _label, leg_matches in hit_legs]
    labels: list[str] = [label for label, _leg_matches in hit_legs]
    fuse_clock = stages.clock()
    fused = rrf_fuse(rankings, k=resolve_rrf_k(), labels=labels, key_fn=_fusion_key)
    stages.record(
        "fuse", "ok" if fused else "empty",
        duration_ms=fuse_clock.elapsed_ms(), count=len(fused),
    )

    asm_clock = stages.clock()
    # 精确过滤位在截断**之前**生效:先截再滤会把"名次在 topK 之后但符号名逐字命中"的片
    # 直接筛掉(那是召回损失,不是过滤)。未启用过滤时截断口径与旧实现逐字节相同。
    #
    # Z37:符号档这一格也**不再按 max_results 收尾** —— 过滤位已下推到检索腿,行预算归
    # api 侧 `rowBudget()` 单源(Z36 立 SYMBOL_SCOPED_ROW_CAP),本侧再补一刀就是把刚
    # 摆正的次序再削一次。`max_results` 在符号档因此降级为「非符号档的出参上限」,
    # 这不是静默改动:段账 detail 与 stats.symbol_filter 都点名了当下走的是哪一档。
    candidates = fused if symbol_name else fused[:max_results]
    matches: list[dict[str, Any]] = []
    pushdown_disagree = 0
    for f in candidates:
        item = dict(f.item)
        if symbol_name and not _symbol_exact_hit(item):
            # 「两侧逐字一致」做成**量出来的读数**,不是硬断言:被本侧摘掉的片若来自已下推的
            # 语义腿,说明 api 那份过滤位与本侧判据读出了不同结果 —— 记数点名,不因此判死。
            if "vector" in f.fused_from:
                pushdown_disagree += 1
            continue
        item["fused_from"] = "+".join(f.fused_from)
        item["rrf_score"] = round(f.score, 6)
        matches.append(item)
    if symbol_name:
        stats["symbol_pushdown_disagree"] = pushdown_disagree
        stats.setdefault(
            "symbol_filter",
            # 语义腿压根没跑(use_semantic=False)时不存在「下推」这件事,只有装配层本地过滤;
            # 跑了却没写下结论 = 没走到给 stats 赋值的那一行,按未判定记,不冒充 pushed。
            "not-attempted:use_semantic=False" if not use_semantic else "unjudged:语义腿未给出结论",
        )
    stages.record(
        "assemble", "ok" if matches else "empty",
        duration_ms=asm_clock.elapsed_ms(), count=len(matches),
        **(
            {
                "detail": (
                    f"symbol_name={symbol_name} 逐字精确过滤后剩 {len(matches)} 片"
                    f"(已下推检索腿:{stats.get('symbol_filter')};max_results={max_results} "
                    f"在符号档不截断,不一致读数 {pushdown_disagree})"
                )
            }
            if symbol_name
            else {}
        ),
    )

    truncated = bool(kw.get("truncated")) or len(fused) > max_results
    return {
        "tool": "search_codebase",
        "query": query,
        "path": path,
        "pattern": pattern,
        "symbol_type": symbol_type,
        **({"symbol_name": symbol_name} if symbol_name else {}),
        "use_semantic": bool(use_semantic),
        "matches": matches,
        "total": len(matches),
        "truncated": truncated,
        "mode": mode,
        "degraded": degraded,
        "reasons": reasons,
        "stats": stats,
        # 逐段结论/耗时/计数(Z19):段序固定,跳过段显式 skipped,没走到的段显式 unjudged
        "stages": stages.finalize(),
        # V3 #75 后半 + 票 #10:语义通道那一步的结论必须一起回去(异常分支也在册),
        # 没有这一格,模型读到的就是"找到 N 个匹配"而看不见"语义腿压根没答上来"。
        "semantic_index": semantic_index_field,
        "message": f"代码检索命中 {len(matches)} 条(模式 {mode})"
                   + ("(已截断)" if truncated else "")
                   + ("" if not missing_legs else f";未答上来的腿={','.join(missing_legs)}"),
        "ok": True,
    }


async def _tool_knowledge_lookup(arguments: dict[str, Any]) -> dict[str, Any]:
    """knowledge_lookup: 统一知识查询(多源并发,代码库 + RAG + 词法多跳 + 图谱 + 跨会话历史)。

    包装 app.services.knowledge_lookup.knowledge_lookup(),供 LLM 通过 MCP 协议
    查外部知识,减少 hallucination + 重复 token 消耗。

    LLM 可控参数:
    - query (required): 自然语言查询
    - top_k_per_source (optional): 每源 top-K,默认 5,1-20

    服务端注入(G6,2026-07-26,从 call_tool 的 user_id/session_id 透传,LLM 不可控):
    - __user_id: 从 FastAPI request.state.user_id 注入;非空时启用 long_term_memory 源
      (跨会话历史检索),None 时跳过 LTM(与 G5 旧行为一致,service 层无 request 上下文)
    - __session_id: 从 request 上下文注入;非空时限定 RAG 检索会话范围

    服务端固定(不暴露给 LLM,安全考虑):
    - repo_id/api_token/source_priority: None(用 knowledge_lookup 默认值)

    返回:
        {tool, query, hits, errors, duration_ms, ok}
        hits: list[{source, score, content}](不含 raw,避免 LLM 上下文冗长)
        空 query → ok=False
        三源全失败 → ok=False + errors(降级不抛异常)
    """
    query = str(arguments.get("query", "")).strip()
    if not query:
        return {
            "tool": "knowledge_lookup",
            "query": "",
            "hits": [],
            "errors": [],
            "duration_ms": 0.0,
            "ok": False,
            "message": "query 不能为空",
        }

    top_k = int(arguments.get("top_k_per_source", 5))
    # 防御性 clamp(1-20,即使 LLM 传越界值也安全)
    top_k = max(1, min(20, top_k))

    # G6(2026-07-26):从 arguments 提取 call_tool 注入的 session context
    # (LLM 不可控,从 FastAPI request 透传;None 时 knowledge_lookup 跳过 LTM 源)
    user_id = arguments.get("__user_id")
    session_id = arguments.get("__session_id")

    try:
        from .knowledge_lookup import knowledge_lookup
        result = await knowledge_lookup(
            query,
            user_id=user_id,  # G6:None 跳过 LTM,非空启用跨会话历史检索
            repo_id=None,
            session_id=session_id,  # G6:None 时 RAG 跨会话,非空限定会话范围
            top_k_per_source=top_k,
            source_priority=None,  # 用默认 [codebase, rag, long_term_memory]
            api_token=None,
        )
    except ValueError as e:
        # source_priority 不合法(理论上不会,因为没传,但防御性处理)
        return {
            "tool": "knowledge_lookup",
            "query": query,
            "hits": [],
            "errors": [{"source": "knowledge_lookup", "error": f"ValueError: {e}"}],
            "duration_ms": 0.0,
            "ok": False,
            "message": f"参数校验失败: {e}",
        }

    # 序列化 hits(不含 raw,避免 LLM 上下文冗长)
    hits_serialized = [
        {
            "source": h.source,
            "score": round(h.score, 4),
            "content": h.content,
        }
        for h in result.hits
    ]

    return {
        "tool": "knowledge_lookup",
        "query": result.query,
        "hits": hits_serialized,
        "errors": result.errors,
        "duration_ms": result.duration_ms,
        "total_hits": len(hits_serialized),
        "ok": len(hits_serialized) > 0 or len(result.errors) == 0,
        "message": (
            f"找到 {len(hits_serialized)} 条知识"
            if hits_serialized
            else (
                "三源全失败,无知识返回"
                if result.errors and not hits_serialized
                else "无匹配知识(各源空结果)"
            )
        ),
    }


async def _tool_read_tool_output(arguments: dict[str, Any]) -> dict[str, Any]:
    """read_tool_output(批次 2):按 offset 分页续读落盘的工具输出工件。

    只读、无副作用;artifactId 严格校验(见 tool_output_artifacts)。失败返回稳定
    `error` 词而不是抛异常 —— 抛异常会被误记成"工具执行失败"并污染审计终态。
    """
    from .tool_output_artifacts import read_tool_output_page

    artifact_id = arguments.get("artifact_id")
    if not isinstance(artifact_id, str) or not artifact_id:
        return {
            "tool": "read_tool_output",
            "ok": False,
            "error": "unknown_artifact",
            "artifactId": "",
        }
    try:
        offset = int(arguments.get("offset") or 0)
    except (TypeError, ValueError):
        offset = 0
    raw_limit = arguments.get("limit")
    try:
        limit = int(raw_limit) if raw_limit is not None else 4000
    except (TypeError, ValueError):
        limit = 4000
    page = read_tool_output_page(artifact_id, offset=max(0, offset), limit=limit)
    return {"tool": "read_tool_output", **page}


_SHADOW_LSP_SUFFIXES: Final = {".py", ".pyi", ".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs", ".json"}


class _ShadowLspValidator:
    """影子校验器:内置语法 + 可用时的语言服务诊断(404/不可用自动回退)。

    语言服务诊断取自既有 `get_diagnostics` 判据(白名单工作区 + containment + 可用性),
    不另造 AST;影子文件位于真实工作区内,工作区根仍为调用方给的 root。
    """

    def __init__(self, workspace: str) -> None:
        self.workspace = workspace
        self.engine_name = "builtin"
        self.metadata: dict[str, Any] = {
            "requested": True,
            "files": 0,
            "unavailable": False,
            "errors": 0,
        }

    async def __call__(self, shadow_root: Path, rel_paths: tuple[str, ...]) -> list[dict[str, Any]]:
        from .shadow_workspace import builtin_validate

        diagnostics = list(await builtin_validate(shadow_root, rel_paths))
        seen = {
            (item.get("file"), item.get("line"), item.get("column"), item.get("message"))
            for item in diagnostics
        }
        for rel in rel_paths:
            if Path(rel).suffix.lower() not in _SHADOW_LSP_SUFFIXES:
                continue
            result = await _tool_get_diagnostics(
                {"workspacePath": self.workspace, "file": str(shadow_root / rel), "limit": 100}
            )
            if not result.get("ok"):
                self.metadata["unavailable"] = True
                continue
            self.metadata["files"] += 1
            for item in result.get("diagnostics", []):
                entry = {**item, "file": rel, "source": item.get("source") or "lsp"}
                key = (entry.get("file"), entry.get("line"), entry.get("column"), entry.get("message"))
                if key in seen:
                    continue
                seen.add(key)
                diagnostics.append(entry)
        if self.metadata["files"]:
            self.engine_name = "lsp+builtin"
        self.metadata["errors"] = sum(
            1 for item in diagnostics if str(item.get("severity", "")).lower() == "error"
        )
        return diagnostics


async def _tool_apply_patch_set(arguments: dict[str, Any]) -> dict[str, Any]:
    """apply_patch_set:影子副本校验 + 多文件全成功或全恢复(2026-11-24)。

    与 write_file 的分工:write_file 是单文件原子写;本工具负责"一组文件一起改"。
    落盘前先把拟写内容写进影子目录跑校验,真实工作区在 valid 之前逐字节不变;
    任一写失败逆序回滚。校验器可注入(语言服务同一函数面),内置覆盖 py/json/toml。
    """
    from .agent_security_prefs import current_security_principal
    from .shadow_workspace import apply_patch_set

    if not current_security_principal():
        return {"tool": "apply_patch_set", "ok": False, "error": "principal_required"}
    workspace = arguments.get("path")
    if not isinstance(workspace, str) or not workspace.strip():
        return {"tool": "apply_patch_set", "ok": False, "status": "rejected", "errorCode": "workspace_missing"}
    patches = arguments.get("patches")
    if not isinstance(patches, list):
        return {"tool": "apply_patch_set", "ok": False, "status": "rejected", "errorCode": "invalid_patches"}
    from pathlib import Path as _Path

    from .read_access import check_access

    for raw in patches:
        if not isinstance(raw, dict):
            continue
        rel = str(raw.get("path") or "")
        denied, rule, errors = check_access(_Path(workspace), rel)
        if denied:
            where = rule.where() if rule is not None else ".cursorignore:unreadable"
            return {
                "tool": "apply_patch_set",
                "ok": False,
                "status": "rejected",
                "errorCode": "CURSORIGNORE_DENIED",
                "error": f"路径被 .cursorignore 排除({where}),整批不落",
                "rule": where,
                "ruleErrors": errors,
            }

    async def _skip_validation(_shadow: Any, _rels: tuple[str, ...]) -> list[dict[str, Any]]:
        return []

    if arguments.get("validate", True) is False:
        validator: Any = _skip_validation
        engine_name = "skipped"
    elif arguments.get("languageServer", True) is not False:
        validator = _ShadowLspValidator(workspace)
        engine_name = None
    else:
        validator = None
        engine_name = None
    result = await apply_patch_set(
        workspace,
        patches,
        validator=validator,
        dry_run=bool(arguments.get("dryRun")),
        engine_name=engine_name,
    )
    return {"tool": "apply_patch_set", **result}


def _cursorignore_denial(resolved_path: str) -> dict[str, Any] | None:
    """`.cursorignore` 访问面 deny(读/写/索引同源;2026-11-24 定档)。

    只认工作区根的 `.cursorignore`;命中或规则文件读不动都返回拒绝体。
    """
    from .read_access import access_denied_for_resolved

    roots = _get_workspace_roots() + list(_active_extra_roots())
    denial = access_denied_for_resolved(resolved_path, roots)
    if denial is None:
        return None
    return {
        "errorCode": "CURSORIGNORE_DENIED",
        "error": f"路径被 .cursorignore 排除({denial.where}),AI 不得读取/写入",
        "rule": denial.where,
        "ruleErrors": list(denial.errors),
    }


async def _tool_read_file(arguments: dict[str, Any]) -> dict[str, Any]:
    """read_file: 读取文件内容(路径必须在工作区白名单内,防 symlink 穿越)。"""
    path = arguments.get("path", "")
    ok, info = _validate_path_in_workspace(path)
    if not ok:
        return {"tool": "read_file", "path": path, "content": "", "ok": False, "error": info}
    resolved_path = info
    # 大文件分页:offset/limit 任一显式给出即进入窗口模式;不传保持整文件旧契约。
    windowed = arguments.get("offset") is not None or arguments.get("limit") is not None
    offset, limit = 1, _READ_WINDOW_MAX_LINES
    if windowed:
        try:
            offset = int(arguments.get("offset", 1))
            limit = int(arguments.get("limit", _READ_WINDOW_MAX_LINES))
        except (TypeError, ValueError):
            return {
                "tool": "read_file", "path": resolved_path, "content": "", "ok": False,
                "error": "offset/limit 必须是整数", "errorCode": "INVALID_ARGUMENT",
            }
        if offset < 1 or limit < 1 or limit > _READ_WINDOW_MAX_LINES:
            return {
                "tool": "read_file", "path": resolved_path, "content": "", "ok": False,
                "error": f"offset 从 1 开始,limit 必须在 1-{_READ_WINDOW_MAX_LINES} 之间",
                "errorCode": "INVALID_ARGUMENT",
            }
    # 2026-07-24 安全加固:敏感文件读取拦截(防 .env/*.key/*.pem 泄露 API key/私钥)
    # 工作区白名单只防路径穿越,不防敏感文件内容泄露;此处补敏感文件名黑名单。
    if _is_sensitive_file(resolved_path):
        return {
            "tool": "read_file",
            "path": resolved_path,
            "content": "",
            "ok": False,
            "error": "拒绝读取敏感文件(可能含 API key/私钥/凭证)",
            "errorCode": "SENSITIVE_FILE_BLOCKED",
        }
    denied = _cursorignore_denial(str(resolved_path))
    if denied is not None:
        return {
            "tool": "read_file",
            "path": resolved_path,
            "content": "",
            "ok": False,
            **denied,
        }
    # 读不到 ≠ 不存在:先量一次路径,权限/IO 错误单独报 UNREADABLE,不落到 open()
    # 的模糊异常上(否则会被上游当成"文件不存在"或"内容为空")。
    kind, _ = _classify_path(str(resolved_path))
    if kind == "unread":
        return {
            "tool": "read_file",
            "path": resolved_path,
            "content": "",
            "ok": False,
            "error": f"{resolved_path} 读不到(无权限或 IO 错误),不能当成文件不存在。",
            "errorCode": "UNREADABLE",
        }
    try:
        # 2026-08-06 生产修复:目录路径显式报错。
        # Windows 上 open() 目录返回模糊的 PermissionError([Errno 13] Permission denied),
        # 用户/模型误以为是权限问题(实际是"把目录当文件读")。
        # 改为明确错误 + 引导使用 search_codebase 探索目录结构。
        import os as _os
        if _os.path.isdir(resolved_path):
            return {
                "tool": "read_file",
                "path": resolved_path,
                "content": "",
                "ok": False,
                "error": f"{resolved_path} 是一个目录,read_file 只能读取文件。请改用 search_codebase 探索目录结构。",
                "errorCode": "IS_A_DIRECTORY",
            }
        # AIS-082:读前先量大小(与写侧 10MB 门对齐),超限直接拒读,不进内存也不进 base 缓存
        size = _os.path.getsize(resolved_path)
        if size > _READ_FILE_MAX_BYTES:
            return {
                "tool": "read_file",
                "path": resolved_path,
                "content": "",
                "size": size,
                "ok": False,
                "error": (
                    f"文件 {size} 字节超过 read_file 单次上限 {_READ_FILE_MAX_BYTES} 字节;"
                    "请改用 read_tool_output 分页读取或先缩小文件。"
                ),
                "errorCode": "FILE_TOO_LARGE",
            }
        with open(resolved_path, encoding="utf-8") as f:
            content = f.read()
        # 1-2:记录 base 版本(agent 视角),供 file_edit 3-way merge 判断并发修改
        _record_file_base(resolved_path, content)
        # A 格读侧登记(2026-10-31 接线):编辑前脏判定的唯一凭据;失败绝不打断读取
        try:
            record_read(arguments.get("__session_id"), resolved_path, content)
        except Exception:  # noqa: BLE001 - 登记层故障不得让读失败
            pass
        if windowed:
            window = _render_read_window(content, offset, limit)
            if not window.get("ok"):
                return {
                    "tool": "read_file", "path": resolved_path, "content": "", "ok": False,
                    "error": window["error"], "errorCode": window["errorCode"],
                    "totalLines": window["totalLines"],
                }
            return {
                "tool": "read_file", "path": resolved_path, "content": window["content"],
                "ok": True, "offset": window["offset"], "totalLines": window["totalLines"],
                "truncatedByBytes": window["truncatedByBytes"],
            }
        return {"tool": "read_file", "path": resolved_path, "content": content, "ok": True}
    except Exception as e:
        return {"tool": "read_file", "path": resolved_path, "content": "", "ok": False, "error": str(e)}


async def _tool_list_files(arguments: dict[str, Any]) -> dict[str, Any]:
    """list_files: 列出目录内容(路径必须在工作区白名单内,防 symlink 穿越)。

    2026-08-06 立:LLM(stepfun step_plan 等)高频调用 list_files 列目录,
    此前无此工具导致"未知工具"工具执行失败(会话 83633a7c 实测)。
    只返回一层条目(name/type/size),超大目录截断 500 项,避免响应爆炸。
    """
    path = arguments.get("path", ".")
    ok, info = _validate_path_in_workspace(path)
    if not ok:
        return {"tool": "list_files", "path": path, "ok": False, "error": info}
    resolved = info
    import os as _os
    not_a_directory = {
        "tool": "list_files", "path": resolved, "ok": False,
        "error": f"{resolved} 不是目录,list_files 只能列出目录。请用 read_file 读取文件。",
        "errorCode": "NOT_A_DIRECTORY",
    }
    # 读不到 ≠ 不是目录:isdir() 在 EACCES 时会吞成 False,把权限问题说成
    # "这是文件",模型就会改用 read_file 去读一个目录。必须分开报。
    try:
        mode = _os.stat(resolved).st_mode
    except FileNotFoundError:
        return not_a_directory
    except OSError as exc:
        return {
            "tool": "list_files", "path": resolved, "ok": False,
            "error": f"目录读不到,不能把它说成不是目录 ({getattr(exc, 'errno', None)})",
            "errorCode": "UNREADABLE",
        }
    if not stat.S_ISDIR(mode):
        return not_a_directory
    try:
        names = sorted(_os.listdir(resolved))
        entries = []
        for name in names:
            full = _os.path.join(resolved, name)
            try:
                is_dir = _os.path.isdir(full)
                entries.append({
                    "name": name,
                    "type": "dir" if is_dir else "file",
                    "size": None if is_dir else _os.path.getsize(full),
                })
            except OSError:
                entries.append({"name": name, "type": "unknown", "size": None})
        return {
            "tool": "list_files",
            "path": resolved,
            "ok": True,
            "entries": entries[:500],
            "total": len(entries),
            "truncated": len(entries) > 500,
        }
    except Exception as e:
        return {"tool": "list_files", "path": resolved, "ok": False, "error": str(e)}


async def _tool_render_repo_tree(arguments: dict[str, Any]) -> dict[str, Any]:
    """render_repo_tree: 按 token 预算渲染目录骨架(工程化落地 goal-b47,对齐 mtree renderTree)。

    枚举不在此层重抄一遍:实现层 `repo_tree_render.render_workspace_tree` 吃
    `rg_fallback_parity.enumerate_code_files` 单源出口,所以忽略目录/扩展名白名单/
    文件数护栏与懒索引护栏是同一套;本层只做路径护栏 + 参数体检 + 核算面透传。
    """
    from pathlib import Path as _Path

    from .repo_tree_render import DEFAULT_MAX_TOKENS, MIN_MAX_TOKENS, render_workspace_tree

    path = arguments.get("path", ".")
    ok, info = _validate_path_in_workspace(path)
    if not ok:
        return {
            "tool": "render_repo_tree",
            "path": path,
            "ok": False,
            "error": info,
            "errorCode": "PATH_NOT_ALLOWED",
        }
    resolved = info
    if not os.path.isdir(resolved):
        return {
            "tool": "render_repo_tree",
            "path": resolved,
            "ok": False,
            "error": f"{resolved} 不是目录,render_repo_tree 只渲染目录骨架。",
            "errorCode": "NOT_A_DIRECTORY",
        }
    raw_budget = arguments.get("maxTokens", DEFAULT_MAX_TOKENS)
    try:
        max_tokens = int(raw_budget) if raw_budget is not None else DEFAULT_MAX_TOKENS
    except (TypeError, ValueError):
        return {
            "tool": "render_repo_tree",
            "path": resolved,
            "ok": False,
            "error": f"maxTokens 不是整数:{raw_budget!r}",
            "errorCode": "BAD_MAX_TOKENS",
        }
    max_tokens = max(max_tokens, MIN_MAX_TOKENS)
    raw_scope = arguments.get("scope")
    scope = raw_scope if isinstance(raw_scope, str) and raw_scope.strip() else None
    try:
        out = render_workspace_tree(_Path(resolved), max_tokens=max_tokens, scope=scope)
    except Exception as e:
        return {
            "tool": "render_repo_tree",
            "path": resolved,
            "ok": False,
            "error": str(e),
            "errorCode": "RENDER_FAILED",
        }
    return {"tool": "render_repo_tree", "path": resolved, "ok": True, **out.to_dict()}


def _classify_path(path: str) -> tuple[str, os.stat_result | None]:
    """missing = 确实没有; unread = 读失败; present = 量到了。"""
    try:
        st = os.stat(path)
    except FileNotFoundError:
        return "missing", None
    except OSError:
        return "unread", None
    return "present", st


def _classify_existing_file(path: str) -> tuple[str, os.stat_result | None]:
    """普通文件才算 present。目录或读失败都不是「文件不存在」。"""
    kind, st = _classify_path(path)
    if kind != "present" or st is None:
        return kind, None
    if not stat.S_ISREG(st.st_mode):
        return "unread", None
    return "present", st


def _note_ai_before(tool: str, path: str, hunk: str, arguments: Mapping[str, Any]) -> None:
    """闸门已经放行、字节还没落地时记 before_edit。记失败不拦这次写入。"""
    try:
        from .ai_code_attribution_store import log_host_before_edit

        log_host_before_edit(tool, path, hunk, arguments)
    except Exception as exc:  # noqa: BLE001 - 检查点失败不得拦已经放行的写入
        import logging

        logging.getLogger(__name__).warning("写前检查点没记下(不拦写入): %s", exc)


def _note_ai_edit(tool: str, path: str, hunk: str, arguments: Mapping[str, Any]) -> None:
    """写成功之后记归属。会话号只取宿主注入的 __session_id。"""
    try:
        from .ai_code_attribution_store import note_host_edit

        note_host_edit(tool, path, hunk, arguments)
    except Exception as exc:  # noqa: BLE001 - 记账失败不得把已写完的文件说成没写成
        import logging

        logging.getLogger(__name__).warning("归属记账失败(不影响已完成的写入): %s", exc)


async def _tool_write_file(arguments: dict[str, Any]) -> dict[str, Any]:
    """write_file: 写入文件内容(路径必须在工作区白名单内,防 symlink 穿越)。

    票78 写冲突治理(串行化档):写段持 per-path 互斥锁;写前做基线漂移判定 ——
    base(read_file/write_file 记录的 agent 视角)与现盘不一致、且拟写内容又不
    等于现盘时,视为并发修改,返回 CONCURRENT_MODIFICATION 不写盘(盲覆盖会丢
    别人的改动)。逃生门:force=true 显式表态「知情覆盖」。五态判定语义见
    file_write_gate.classify_write_conflict。
    """
    path = arguments.get("path", "")
    content = arguments.get("content", "")
    force = bool(arguments.get("force", False))
    ok, info = _validate_write_path_in_workspace(path)
    if not ok:
        return {"tool": "write_file", "path": path, "ok": False, "error": info}
    resolved_path = info
    denied = _cursorignore_denial(str(resolved_path))
    if denied is not None:
        return {"tool": "write_file", "path": resolved_path, "ok": False, **denied}
    try:
        async with get_path_write_lock(resolved_path):
            # 写前基线漂移判定(判定与写盘同锁内完成,判定结果对写盘时刻负责)
            baseline = _FILE_BASE_CONTENT.get(resolved_path)
            presence, _st = _classify_existing_file(resolved_path)
            if presence == "unread":
                return {
                    "tool": "write_file",
                    "path": resolved_path,
                    "ok": False,
                    "errorCode": "UNREADABLE",
                    "error": "目标读不到,不能覆盖",
                }
            disk_now: str | None = None
            if presence == "present":
                try:
                    with open(resolved_path, encoding="utf-8") as f:
                        disk_now = _normalize_eol(f.read())
                except OSError:
                    return {
                        "tool": "write_file",
                        "path": resolved_path,
                        "ok": False,
                        "errorCode": "UNREADABLE",
                        "error": "目标读不到,不能覆盖",
                    }
                except (UnicodeDecodeError, ValueError):
                    disk_now = None  # 二进制 → 判不了,交 classify 归 undecidable
            # 先读再写(严格档):覆盖现有文件时,本会话没读过就是盲写;
            # 读过但盘上变了就是 stale。新建文件(presence=missing)不受此门限制。
            read_state: Mapping[str, Any] | None = None
            try:
                read_state = judge_read_state(
                    arguments.get("__session_id"), resolved_path, arguments=arguments
                )
            except Exception:  # noqa: BLE001 - 判定层故障不得让写失败
                read_state = None
            if (
                read_state is not None
                and read_state.get("blocking")
                and not force
            ):
                _current = read_state.get("current")
                _exists_now = (
                    isinstance(_current, Mapping)
                    and _current.get("status") == "ok"
                )
                # judge 取不到 current 时退回写前 presence;两者都不把"创建"当盲覆盖。
                if _current is None:
                    _exists_now = presence == "present"
                if _exists_now:
                    code = (
                        "FS_NOT_OBSERVED"
                        if read_state.get("verdict") == "never_read"
                        else "STALE_READ_CONFIRMATION_REQUIRED"
                    )
                    return {
                        "tool": "write_file",
                        "path": resolved_path,
                        "ok": False,
                        "errorCode": code,
                        "error": str(
                            read_state.get("message")
                            or "严格档拒绝覆盖未经读取的文件;请先 read_file 后重试。"
                        ),
                        "readState": read_state_field(read_state),
                    }
            verdict = classify_write_conflict(
                disk_now, baseline, _normalize_eol(content)
            )
            if verdict == "drifted" and not force:
                return {
                    "tool": "write_file",
                    "path": resolved_path,
                    "ok": False,
                    "errorCode": "CONCURRENT_MODIFICATION",
                    "error": (
                        "检测到并发修改:现盘内容与本会话记录的 base 版本不一致,"
                        "且拟写入内容与现盘不同 —— 直接覆盖会丢失他人改动。"
                        "请先 read_file 重新读取后再写;若确认要覆盖,携带 force=true 重试"
                    ),
                    "concurrency": {"verdict": verdict, "forced": False},
                }
            _note_ai_before("write_file", resolved_path, content, arguments)
            # 原子写:同目录临时件 + os.replace(崩溃/断电只留旧完整文件或新完整文件,
            # 不会留下被截断的目标);父目录自动创建,避免模型先跑一条 mkdir 命令。
            Path(resolved_path).parent.mkdir(parents=True, exist_ok=True)
            write_bytes_atomic(resolved_path, content.encode("utf-8"))
            # 1-2:写盘后刷新 base(agent 视角最新内容)
            _record_file_base(resolved_path, content)
            # C 格自我写入登记:本会话自己的改动不报成他席覆盖;失败不影响写
            try:
                record_self_write(arguments.get("__session_id"), resolved_path, content)
            except Exception:  # noqa: BLE001 - 登记层故障不得让写失败
                pass
            _note_ai_edit("write_file", resolved_path, content, arguments)
            payload: dict[str, Any] = {
                "tool": "write_file",
                "path": resolved_path,
                "bytes_written": len(content.encode("utf-8")),
                "ok": True,
                "concurrency": {"verdict": verdict, "forced": bool(force and verdict == "drifted")},
            }
            if read_state is not None:
                payload["readState"] = read_state_field(read_state)
            return payload
    except Exception as e:
        return {"tool": "write_file", "path": resolved_path, "ok": False, "error": str(e)}


async def _tool_file_edit(arguments: dict[str, Any]) -> dict[str, Any]:
    """file_edit: 精细编辑文件,精确替换 old_string 为 new_string,带 conflict 检测。

    自研 Edit 工具:replace_all=false 时要求 old_string 唯一匹配,
    多个匹配报 AMBIGUOUS_MATCH 错误,避免误改多处。
    """
    def _err(code: str, msg: str, **extra: Any) -> dict[str, Any]:
        return {"tool": "file_edit", "file_path": resolved_path, "ok": False,
                "error": msg, "errorCode": code, **extra}

    path = arguments.get("file_path", "")
    old_string = arguments.get("old_string", "")
    new_string = arguments.get("new_string", "")
    replace_all = bool(arguments.get("replace_all", False))

    if not old_string:
        return {"tool": "file_edit", "file_path": path, "ok": False,
                "error": "old_string 不能为空", "errorCode": "INVALID_ARGUMENT"}

    ok, info = _validate_write_path_in_workspace(path)
    if not ok:
        return {"tool": "file_edit", "file_path": path, "ok": False,
                "error": info, "errorCode": "PATH_NOT_ALLOWED"}
    resolved_path = info
    denied = _cursorignore_denial(str(resolved_path))
    if denied is not None:
        return {"tool": "file_edit", "file_path": resolved_path, "ok": False, **denied}

    try:
        # AIS-083:读盘 → 匹配计数 → 3-way 合并 → 写回必须整体在同一把 per-path
        # 锁内。锁只覆盖写回时,两个并发编辑会各自基于同一旧快照合并,后写者静默
        # 覆盖先写者的改动。
        async with get_path_write_lock(resolved_path):
            presence, _st = _classify_existing_file(resolved_path)
            if presence == "unread":
                return _err("UNREADABLE", "文件读不到,不能把它说成不存在")
            if presence == "missing":
                return _err("FILE_NOT_FOUND", "文件不存在")
            if os.path.getsize(resolved_path) > 10 * 1024 * 1024:
                return _err("FILE_TOO_LARGE", "文件大于 10MB,拒绝编辑")
            with open(resolved_path, "rb") as f:
                raw = f.read()

            if b"\x00" in raw:
                return _err("BINARY_FILE", "文件含 NUL 字节,判定为二进制文件")
            try:
                content = raw.decode("utf-8")
            except UnicodeDecodeError as e:
                return _err("BINARY_FILE", f"文件非 UTF-8: {e}")

            count = content.count(old_string)
            strategy = "direct"
            if count == 0:
                # 1-2 3-way merge:old_string 在磁盘内容 0 命中,但在 base(agent 上次
                # 看到的版本)中存在 → 快照后文件被外部修改。尝试三方合并:
                # 干净合并 → 自动应用;双侧修改冲突 → 返回 CONFLICT(不写盘),
                # 由 resolve_conflict 工具按块决策(局部拒绝)。
                base = _FILE_BASE_CONTENT.get(resolved_path)
                if base is not None and old_string in base:
                    # 1-2 EOL 归一化:base 统一 LF 存储,磁盘内容归一化后参与合并,
                    # 避免 CRLF/LF 行尾差异导致整文件误判(合并结果写盘前按磁盘风格还原)
                    current_lf = _normalize_eol(content)
                    mr = merge3_for_edit(base, current_lf, old_string, new_string, replace_all=replace_all)
                    if mr.clean:
                        new_content = _restore_eol(mr.merged, content)
                        strategy = "auto_merged_3way"
                        replaced_count = base.count(old_string) if replace_all else 1
                    else:
                        return _err(
                            "CONFLICT",
                            (
                                f"检测到并发修改冲突:old_string 在磁盘当前内容中 0 命中,"
                                f"但 base 版本存在,3-way merge 产生 {mr.conflict_count()} 个冲突块"
                                f"(文件未修改)。可调用 resolve_conflict 工具,携带相同的 "
                                f"file_path/old_string/new_string 与 choices 数组"
                                f"(每冲突块 'ours'=采用本次修改 / 'theirs'=保留磁盘现状)按块决策。"
                            ),
                            conflict_count=mr.conflict_count(),
                            strategy="3way_merge",
                        )
                else:
                    return _err("NOT_FOUND", "未找到要替换的字符串", match_count=0)
            elif not replace_all and count >= 2:
                return _err("AMBIGUOUS_MATCH", f"找到 {count} 处匹配,需指定 replace_all=true 或提供更长上下文", match_count=count)
            elif replace_all:
                new_content = content.replace(old_string, new_string)
                replaced_count = count
            else:
                new_content = content.replace(old_string, new_string, 1)
                replaced_count = 1

            backup_path = resolved_path + ".bak"
            # B 格编辑前脏判定(2026-10-31 接线):默认只在返回体点名(fresh/stale/never_read/
            # undetermined 四档不并桶);显式严格档 ∧ stale 才拒写。判定层故障 ⇒ 不拦(§0.10)。
            try:
                read_state: Mapping[str, Any] | None = judge_read_state(
                    arguments.get("__session_id"), resolved_path, arguments=arguments
                )
            except Exception:  # noqa: BLE001 - 判定层故障不得让编辑失败
                read_state = None
            try:
                from .ai_code_attribution_store import note_measured_external_edit

                note_measured_external_edit(resolved_path, arguments, read_state)
            except Exception as exc:  # noqa: BLE001 - 人手改动记账失败不得拦编辑
                import logging

                logging.getLogger(__name__).warning("外部改动检查点没记下(不拦编辑): %s", exc)
            if read_state is not None and read_state.get("blocking"):
                if read_state.get("verdict") == "never_read":
                    return _err(
                        "FS_NOT_OBSERVED",
                        str(read_state.get("message") or "该文件尚未被本会话读取,严格档拒绝盲写;请先 read_file 后重试。"),
                        readState=read_state_field(read_state),
                    )
                return _err(
                    "STALE_READ_CONFIRMATION_REQUIRED",
                    str(read_state.get("message") or "文件在读后被改过(严格档),已拒绝写入;请重新 read_file 后重试。"),
                    readState=read_state_field(read_state),
                )
            _note_ai_before("file_edit", resolved_path, old_string or "file_edit", arguments)
            try:
                with open(backup_path, "wb") as bf:
                    bf.write(raw)
                # 原子替换:编辑中途崩溃不会把目标留成半截文件(.bak 仍是上一版)。
                write_bytes_atomic(resolved_path, new_content.encode("utf-8"))
            except OSError as e:
                # 失败回滚:恢复原内容(raw),删除 .bak(不保留)
                try:
                    with open(resolved_path, "wb") as rf:
                        rf.write(raw)
                except OSError:
                    pass
                with contextlib.suppress(OSError):
                    os.remove(backup_path)
                return _err("IO_ERROR", str(e))

            diff = list(difflib.unified_diff(content.splitlines(keepends=True),
                        new_content.splitlines(keepends=True), fromfile="old", tofile="new", n=2))
            # 1-2:写盘后刷新 base(agent 视角最新内容;锁内刷新,防释放锁后他人写入把 base 记旧)
            _record_file_base(resolved_path, new_content)
    except OSError as e:
        return _err("IO_ERROR", str(e))
    _note_ai_edit("file_edit", resolved_path, "".join(diff[:20]), arguments)
    result_payload: dict[str, Any] = {"tool": "file_edit", "ok": True, "file_path": resolved_path,
            "replaced_count": replaced_count, "backup_path": backup_path,
            "strategy": strategy,
            "diff_preview": "".join(diff[:20])}
    if read_state is not None:
        result_payload["readState"] = read_state_field(read_state)
    return result_payload


async def _tool_resolve_conflict(arguments: dict[str, Any]) -> dict[str, Any]:
    """resolve_conflict:按块解决 file_edit 报告的 3-way merge 冲突(1-2 局部拒绝)。

    与触发 CONFLICT 的 file_edit 携带相同 file_path/old_string/new_string;
    choices 按冲突块顺序指定 'ours'(采用 agent 修改)/'theirs'(保留磁盘
    现状=拒绝该块修改)。choices 不足的块缺省 'ours'。
    """
    def _err(code: str, msg: str, **extra: Any) -> dict[str, Any]:
        return {"tool": "resolve_conflict", "file_path": resolved_path, "ok": False,
                "error": msg, "errorCode": code, **extra}

    path = arguments.get("file_path", "")
    old_string = arguments.get("old_string", "")
    new_string = arguments.get("new_string", "")
    choices_raw = arguments.get("choices", [])
    replace_all = bool(arguments.get("replace_all", False))
    choices = [str(c) for c in choices_raw] if isinstance(choices_raw, list) else []

    if not old_string:
        return {"tool": "resolve_conflict", "file_path": path, "ok": False,
                "error": "old_string 不能为空", "errorCode": "INVALID_ARGUMENT"}

    ok, info = _validate_write_path_in_workspace(path)
    if not ok:
        return {"tool": "resolve_conflict", "file_path": path, "ok": False,
                "error": info, "errorCode": "PATH_NOT_ALLOWED"}
    resolved_path = info

    try:
        presence, _st = _classify_existing_file(resolved_path)
        if presence == "unread":
            return _err("UNREADABLE", "文件读不到,不能把它说成不存在")
        if presence == "missing":
            return _err("FILE_NOT_FOUND", "文件不存在")
        if os.path.getsize(resolved_path) > 10 * 1024 * 1024:
            return _err("FILE_TOO_LARGE", "文件大于 10MB,拒绝编辑")
        with open(resolved_path, "rb") as f:
            raw = f.read()
    except OSError as e:
        return _err("IO_ERROR", str(e))

    try:
        content = raw.decode("utf-8")
    except (UnicodeDecodeError, ValueError) as e:
        return _err("BINARY_FILE", f"文件非 UTF-8: {e}")

    base = _FILE_BASE_CONTENT.get(resolved_path)
    if base is None or old_string not in base:
        return _err(
            "NO_BASE_VERSION",
            "无该文件的 base 版本(或 old_string 不在 base 中),无法按块解决冲突;请先 read_file 后重试 file_edit",
        )

    # 1-2 EOL 归一化:base 统一 LF 存储,磁盘内容归一化后参与合并;
    # 结果按磁盘原行尾风格还原后写盘
    resolved = _merge3_resolve_conflicts(
        base, _normalize_eol(content), old_string, new_string, choices, replace_all=replace_all
    )
    if not resolved.get("ok"):
        return _err("MERGE_FAILED", str(resolved.get("error", "合并失败")))

    final_content = _restore_eol(str(resolved["content"]), content)
    applied = list(resolved.get("applied", []))
    backup_path = resolved_path + ".bak"
    # 票78 串行化:写回段持 per-path 锁(与 write_file/file_edit 写段互斥,缩竞态窗口)
    async with get_path_write_lock(resolved_path):
        _note_ai_before("resolve_conflict", resolved_path, old_string or "resolve_conflict", arguments)
        try:
            with open(backup_path, "wb") as bf:
                bf.write(raw)
            # 原子替换:同 file_edit,冲突解决写盘也不留半截目标。
            write_bytes_atomic(resolved_path, final_content.encode("utf-8"))
        except OSError as e:
            # 失败回滚:恢复磁盘原内容
            try:
                with open(resolved_path, "wb") as rf:
                    rf.write(raw)
            except OSError:
                pass
            with contextlib.suppress(OSError):
                os.remove(backup_path)
            return _err("IO_ERROR", str(e))

        # 1-2:写盘后刷新 base(冲突已解决,agent 视角最新内容;锁内刷新,时序同 file_edit)
        _record_file_base(resolved_path, final_content)
    _note_ai_edit("resolve_conflict", resolved_path, old_string or "resolve_conflict", arguments)
    rejected = sum(1 for a in applied if a.get("choice") == "theirs")
    return {
        "tool": "resolve_conflict",
        "ok": True,
        "file_path": resolved_path,
        "conflicts": int(resolved.get("conflicts", 0)),
        "resolved": len(applied),
        "rejected_hunks": rejected,
        "backup_path": backup_path,
        "applied_choices": applied,
    }


# =====================================================================
# P0-B(2026-09-18):终端实时输出事件(terminal.delta)。
# run_command 执行期间逐行 stdout/stderr 经 hook_engine 广播,SSE 订阅端
# (agents.py /agents/tasks/stream 等,经 AGENT_SUBSCRIBE_EVENTS)映射为
# terminal-delta 推送前端 TerminalSection 实时渲染。会话上下文经
# contextvar 注入(agent_loop_v2._execute_single 调工具前 set),工具直调
# (无上下文)时 session_id 为空串,订阅端按既有约定对空 session 透传。
# 发射 fire-and-forget(不阻塞 drain 读取循环);失败降级不阻塞命令执行。
# =====================================================================

_terminal_stream_ctx: contextvars.ContextVar[dict[str, Any] | None] = (
    contextvars.ContextVar("ihui_terminal_stream_ctx", default=None)
)

# terminal.delta 帧聚合节流:每 N 行合为一帧(防高频行输出刷屏 SSE)
_TERMINAL_DELTA_BATCH_LINES = 4

# fire-and-forget 任务引用集合(防 CPython GC 提前回收,与其他 _pending 集合同模式)
_terminal_delta_tasks: set[asyncio.Task[None]] = set()


def set_terminal_stream_context(**ctx: Any) -> contextvars.Token[dict[str, Any] | None]:
    """注入终端输出事件上下文(session_id/iteration/tool_call_id 等)。"""
    return _terminal_stream_ctx.set(dict(ctx))


def reset_terminal_stream_context(token: contextvars.Token[dict[str, Any] | None]) -> None:
    """恢复终端输出事件上下文(与 set 配对使用,防跨工具泄漏)。"""
    _terminal_stream_ctx.reset(token)


# 工具执行取消事件:agent 循环在调用执行器前写入,run_command 据此杀掉子进程。
_TOOL_CANCEL_EVENT: contextvars.ContextVar[asyncio.Event | None] = contextvars.ContextVar(
    "ihui_tool_cancel_event", default=None
)


def set_tool_cancel_event(event: asyncio.Event) -> contextvars.Token[asyncio.Event | None]:
    """把本轮工具取消事件放进当前任务上下文。"""
    return _TOOL_CANCEL_EVENT.set(event)


def reset_tool_cancel_event(token: contextvars.Token[asyncio.Event | None]) -> None:
    """与 set_tool_cancel_event 配对复位。"""
    _TOOL_CANCEL_EVENT.reset(token)


async def _emit_terminal_delta(command: str, stream_name: str, text: str) -> None:
    """发射 terminal.delta 事件(失败降级不阻塞命令执行)。

    进程内直投:llm.py 主聊天流在调用终端工具前经 contextvar 注入可调用的
    `push`(同步 callable,通常为 asyncio.Queue.put_nowait)。命中时优先走
    push(payload) 并跳过 hook_engine.emit —— 增量帧由调用方直接 yield 成 SSE,
    不阻塞命令主链路、不改变既有 SSE 顺序语义。无 push(agent_loop_v2 等)
    时维持原 hook_engine 广播行为,agent 通道零回归。
    """
    if not text:
        return
    try:
        ctx = _terminal_stream_ctx.get() or {}
        # 进程内直投:优先走 push(取道与 terminal_interaction 同一份实现,禁止两处各写
        # 一遍"怎么找到 push"),不再经 hook_engine —— 增量帧由调用方直接 yield 成 SSE,
        # 不阻塞命令主链路、不改变既有 SSE 顺序语义。无 push(agent_loop_v2 等)
        # 时维持原 hook_engine 广播行为,agent 通道零回归。
        _payload: dict[str, Any] = {
            "type": "terminal_delta",
            "terminalId": ctx.get("tool_call_id") or "",
            "command": command,
            "stream": stream_name,  # stdout / stderr
            "text": text,
            "iteration": ctx.get("iteration"),
        }
        _msg_id = ctx.get("messageId")
        if _msg_id:  # 上下文带 messageId 时才带上(与 terminal_start 对齐)
            _payload["messageId"] = _msg_id
        if _push_terminal_stream_frame(_payload):
            return
        from .hook_engine import hook_engine

        session_id = str(ctx.get("session_id") or "")
        await hook_engine.emit(
            "terminal.delta",
            {
                "session_id": session_id,
                "run_id": session_id,  # workbench session 关联键(与 thinking.delta 同约定)
                "command": command,
                "stream": stream_name,  # stdout / stderr
                "text": text,
                "iteration": ctx.get("iteration"),
                "tool_call_id": ctx.get("tool_call_id"),
            },
        )
    except Exception:  # noqa: BLE001 - 事件发射失败绝不阻塞工具主链路
        pass


def _spawn_terminal_delta(command: str, stream_name: str, text: str) -> None:
    """fire-and-forget 包装:drain 循环内同步回调,实际 emit 后台执行。

    出库脱敏(2026-09-18 第十五批):实时 delta 早于汇总结果发出,若只脱敏
    汇总输出,逐行流会先于脱敏把密钥送到 SSE —— 故在此唯一咽喉点统一盖。
    """
    if not text:
        return
    try:
        from app.core.output_cleaning import redact_secrets as _redact_secrets

        text = _redact_secrets(text)
    except Exception:  # noqa: BLE001 - 脱敏失败绝不阻塞实时输出
        pass
    try:
        task = asyncio.ensure_future(
            _emit_terminal_delta(command, stream_name, text)
        )
    except RuntimeError:  # 无事件循环(理论不可达,防御)
        return
    _terminal_delta_tasks.add(task)
    task.add_done_callback(_terminal_delta_tasks.discard)


# =====================================================================
# D151(2026-09-29 立;用户 2026-09-28 批「默认开 + 单次等待上限 300s」):
# 交互式命令的「等待用户输入」态 + 键入送回的唯一登记/结算出口。
#
# 为什么住在 mcp_server:`proc.stdin` 只有执行循环拿得到,端点能做的是"把用户键入
# 交给那条已登记的 future"。所以登记表在此、盖章也在此,结算方(llm.py 的
# terminal-input 端点)只经本模块导出的唯一出口取用 —— 照 batch-59/60 的规矩
# **存带主记录**(terminalId + user_id),归属判定发生在结算点而不是注册点。
#
# 已知边界(如实登记,不当待办):判定用的是"输出静默窗口 + 尾行提示形态"两条启发式,
# 不是 tty 层真信号(run_command 走 create_subprocess_exec 管道,没有 PTY)。所以它
# **只影响是否发帧、是否多给一段等人时间**,绝不改变命令本身的执行结果口径。
# =====================================================================

#: 单次等待用户键入的上限(秒)。与 llm.py 的 _FORM_WAIT_TIMEOUT 数值相同但**刻意不共享**:
#: 表单等的是"填完整内容",这里等的是"敲一行字",两条语义各自调参。
TERMINAL_INTERACTION_WAIT_TIMEOUT_S: Final[int] = 300
#: 判定"进程在等人"的静默窗口(秒)。
TERMINAL_INTERACTION_QUIET_S: Final[float] = 2.0
#: 代答输入长度封顶(stdin 直通进程是新入口,必须限界;键入内容一律不落日志)。
TERMINAL_INTERACTION_MAX_INPUT_CHARS: Final[int] = 4096
#: 总上限护栏:命令自身超时 + 一段等待人的时间;绝不因为"有人在等"就无限挂流。
TERMINAL_INTERACTION_EXTRA_GRACE_S: Final[int] = TERMINAL_INTERACTION_WAIT_TIMEOUT_S
_TERMINAL_INTERACTION_ENV: Final[str] = "IHUI_TERMINAL_INTERACTION"
_TERMINAL_INTERACTION_POLL_S: Final[float] = 0.5
#: 尾行超过这个长度就不当"提示符"(超长行是输出噪声,不是等人)。
_TERMINAL_INTERACTION_MAX_TAIL_CHARS: Final[int] = 240

#: 尾行"像在等输入"的形态表 —— 命中才发帧并等待。**全部行尾锚定**,理由两条:
#: ① 提示符的定义就是"这行到此为止、等下面接字",句中出现的词不是提示;
#: ② 假阳的代价不是"多一帧"而是**凭空多等**(最长 300 秒),假阴的代价只是命令照常走到它
#:    原本的超时 —— 两边不对称,所以判据必须偏保守。
_TERMINAL_INTERACTION_PROMPT_RES: Final[tuple[re.Pattern[str], ...]] = (
    # y/n 类确认
    re.compile(r"(?:\[[yY]/[nN]\]|\([yY]/[nN]\)|\[[yY]es/[nN]o\])\s*$"),
    # "它明确在问"
    re.compile(r"(?i)(?:continue|proceed|are you sure)\s*\??\s*$"),
    re.compile(r"(?:是否继续|请确认|是否覆盖)\s*[?？]?\s*$"),
    # 凭据类:词边界是硬要求(少了 \b,"passwordless" 会命中),且必须收尾在冒号/尖括号
    re.compile(r"(?i)\b(?:password|passphrase|secret)\s*[:>]\s*$"),
    re.compile(r"(?:密码|口令)\s*[:：]?\s*$"),
    # "Enter your name:" / "请输入文件名:"
    re.compile(r"(?i)\b(?:enter|input|type|please)\b[^:\n]{0,50}[:?]\s*$"),
    re.compile(r"请输入[^:\n]{0,20}[:：]\s*$"),
    # shell/REPL 与 `read -p "x: "`:整行以冒号或 > 收尾
    re.compile(r"[\w ./@:\-]{1,60}[:>]\s*$"),
    re.compile(r"^\s*(?:>>>|\.\.\.|[$#>])\s*$"),
)


def terminal_interaction_enabled() -> bool:
    """交互代答开关(默认开)。关掉只影响这一维:命令执行与既有帧一字不变。"""
    raw = str(os.environ.get(_TERMINAL_INTERACTION_ENV, "")).strip().lower()
    return raw not in ("0", "false", "off", "no")


def looks_like_input_prompt(tail_text: str) -> str | None:
    """取末段输出里最后一行非空文本,判断它是否"像在等输入"。

    返回命中的提示片段(进帧给前端当"它在等什么"的说明),不命中返回 None。
    """
    tail = ""
    for line in reversed((tail_text or "").split("\n")):
        stripped = line.strip()
        if stripped:
            tail = stripped
            break
    if not tail or len(tail) > _TERMINAL_INTERACTION_MAX_TAIL_CHARS:
        return None
    for pat in _TERMINAL_INTERACTION_PROMPT_RES:
        if pat.search(tail):
            return tail
    return None


#: terminalId -> {future, user_id, session_id, command, prompt_tail, registered_at}
#: 只在"确实在等人"的窗口内存在;结算/超时/取消三条路都由等待方 pop(与 _form_sessions 同律)。
_terminal_input_pending: dict[str, dict[str, Any]] = {}


def terminal_input_waiter_count() -> int:
    """只读探针(测试与诊断用;不返回内容,键入值绝不从这一面出去)。"""
    return len(_terminal_input_pending)


def settle_terminal_input(
    session_id: str,
    terminal_id: str,
    text: str,
    caller_user_id: str | None,
) -> dict[str, Any]:
    """键入送回的唯一结算出口。

    命中条件 = terminalId 在待决表 ∧ 该条登记的**属主等于当前调用方主体**。越权与"没这条"
    **同形回包**(端点 otherwise 会变成存在性预言机),且两种情形都**绝不 set_result** ——
    "先把进程喂了再抛 403"是本仓越权用例专门要断言排掉的写法。
    """
    entry = _terminal_input_pending.get(str(terminal_id or ""))
    if not isinstance(entry, dict) or not isinstance(entry.get("future"), asyncio.Future):
        return {"settled": False, "reason": "not_found"}
    # 会话维度也要对上:terminalId 用的是工具调用的 id,跨会话撞号在小概率下仍然可能,
    # 而撞上的后果是"把 A 会话的键入喂给 B 会话的进程"。登记时空串表示未鉴权开发态,
    # 那种情况下不比对(比对一个双方都没有的字段等于没有判据)。
    entry_session = str(entry.get("session_id") or "")
    if entry_session and entry_session != str(session_id or ""):
        return {"settled": False, "reason": "not_found"}
    owner = entry.get("user_id")
    if isinstance(owner, str) and owner:
        if caller_user_id != owner:
            return {"settled": False, "reason": "not_found"}
    elif caller_user_id is not None:
        # 待决项没有主体(未鉴权的开发/进程内路径),而调用方带身份 —— 这是两条不同
        # 身份通道的偶然相遇,不予结算(与 form-response 同一条口径)。
        return {"settled": False, "reason": "not_found"}
    # 落到这里:两侧都没有主体。这是 jwt 未启用时(开发态 / ASGI in-process 测试)的
    # 回退路径,**不构成授权结论**,不是"匹配上了"。
    future = cast("asyncio.Future[str]", entry["future"])
    if future.done():
        return {"settled": False, "reason": "already_settled"}
    future.set_result(str(text)[:TERMINAL_INTERACTION_MAX_INPUT_CHARS])
    # 刻意不回显 text:键入可能是密码,返回值会进日志/响应体。
    return {"settled": True}


def _push_terminal_stream_frame(payload: dict[str, Any]) -> bool:
    """把一帧塞进宿主注入的 push 通道(delta 与 interaction **共用这一份**取道实现)。

    返回 False = 这条通道此刻不存在(例如 agent_loop_v2 路径没注入 push)。调用方必须
    据此决定后续动作,不得把"没送到"读成"送到了" —— 那是本仓最高频的失效型。
    发射本身失败一律降级吞掉:事件面故障不得打断命令主链路。
    """
    if not payload:
        return False
    try:
        ctx = _terminal_stream_ctx.get() or {}
        push = ctx.get("push")
        if callable(push):
            push(payload)
            return True
        return False
    except Exception:  # noqa: BLE001 - 事件发射失败绝不阻塞工具主链路
        return False


async def _await_terminal_input(
    terminal_id: str,
    command: str,
    prompt_tail: str,
    ctx: dict[str, Any],
    waiting_since_ms: int = 0,
) -> tuple[str | None, bool]:
    """登记待决项 → 发 terminal_interaction 帧 → 等待键入。

    返回 (键入内容 | None, 是否超时)。帧**送不出去就不等**(没有承载面的等待,
    等于把一条命令凭空挂 300 秒)。
    """
    payload: dict[str, Any] = {
        "type": "terminal_interaction",
        "terminalId": terminal_id,
        # sessionId 必须进帧:上行出口是
        # POST /llm/complete/stream/{session_id}/terminal-input,前端手里只有它自己那条流的
        # 上下文 —— 帧不带会话 id,前端就得猜(猜错的表现是"点了发送什么都没发生",不报错)。
        "sessionId": str(ctx.get("session_id") or ""),
        "promptTail": prompt_tail,
        # 静默时长是**量出来的**(观察器每 0.5s 一轮,这是判定"在等人"那一刻的 idle),
        # 不是装饰字段 —— 写死 0 会让前端那个"等了多久"的读数永远是零,与本仓
        # "不得留没有生产点的字段"那条纪律同一条禁令。
        "waitingSinceMs": max(0, int(waiting_since_ms)),
        "inputMode": "line",
        "maxInputChars": TERMINAL_INTERACTION_MAX_INPUT_CHARS,
    }
    message_id = ctx.get("messageId")
    if message_id:
        payload["messageId"] = message_id
    if not _push_terminal_stream_frame(payload):
        return (None, False)

    loop = asyncio.get_running_loop()
    future: asyncio.Future[str] = loop.create_future()
    entry: dict[str, Any] = {
        "future": future,
        # 盖章发生在注册点:owner 来自宿主注入的终端流上下文(llm.py 用令牌主体填),
        # 模型与请求体都碰不到它。
        "user_id": ctx.get("user_id"),
        "session_id": str(ctx.get("session_id") or ""),
        "command": command,
        "prompt_tail": prompt_tail,
        "registered_at": time.monotonic(),
    }
    _terminal_input_pending[terminal_id] = entry
    try:
        try:
            text = await asyncio.wait_for(future, timeout=TERMINAL_INTERACTION_WAIT_TIMEOUT_S)
            return (text, False)
        except TimeoutError:
            return (None, True)
    finally:
        # 命令结束后待决条目必删(风险面:不留一个还能被写入的把手)。
        if _terminal_input_pending.get(terminal_id) is entry:
            _terminal_input_pending.pop(terminal_id, None)


async def _watch_terminal_input(
    proc: Any,
    activity: dict[str, Any],
    state: dict[str, Any],
    terminal_id: str,
    ctx: dict[str, Any],
    command: str,
) -> None:
    """旁路观察器:探测"进程停住且尾行像提示符"→ 发帧并等人敲一行。

    它**不碰退出判定**(那归 drain),也不改 stdout/stderr 内容;state 里只累计
    interactionCount / inputWaitTimedOut 两笔账,供 tool-result 如实回灌(验收②:
    有交互必须有计数,不得静默)。
    """
    while True:
        await asyncio.sleep(_TERMINAL_INTERACTION_POLL_S)
        if getattr(proc, "returncode", None) is not None:
            return
        idle = time.monotonic() - float(activity.get("ts") or time.monotonic())
        if idle < TERMINAL_INTERACTION_QUIET_S:
            continue
        prompt = looks_like_input_prompt(str(activity.get("last_line") or ""))
        stdin_writer = getattr(proc, "stdin", None)
        if not prompt:
            # 静默但**不像**等人:立刻把写端关掉,把"命令一启动就拿到 EOF"的旧语义还给它。
            # 不做这一步,`cat` 这类读 stdin 的命令会从"马上结束"变成"挂到超时"。
            if not state.get("eofSent") and stdin_writer is not None and not stdin_writer.is_closing():
                with contextlib.suppress(Exception):
                    stdin_writer.write_eof()
                state["eofSent"] = True
            continue
        if state.get("eofSent"):
            # 写端已经交出去了:这时再发帧就是给前端一个"能代答"的假承诺,只能不等。
            return
        if activity.get("last_prompt") == prompt:
            # 同一条提示只问一次:否则没人敲也会每秒重复发帧刷屏。
            continue
        activity["last_prompt"] = prompt
        state["waiting"] = True
        try:
            text, timed_out = await _await_terminal_input(
                terminal_id, command, prompt, ctx, int(idle * 1000)
            )
            if text:
                writer = getattr(proc, "stdin", None)
                if writer is not None and not writer.is_closing():
                    writer.write((text + "\n").encode("utf-8", errors="replace"))
                    with contextlib.suppress(Exception):
                        await writer.drain()
                    state["interactionCount"] = int(state.get("interactionCount") or 0) + 1
                    # 键入之后进程会继续输出,提示窗口重新计时。
                    activity["ts"] = time.monotonic()
                    activity["last_prompt"] = None
            elif timed_out:
                state["inputWaitTimedOut"] = True
                state["inputWaitTimeoutMs"] = TERMINAL_INTERACTION_WAIT_TIMEOUT_S * 1000
                return
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001 - 观察器故障不得影响命令本身
            logger.warning("terminal interaction 观察器异常(忽略,命令继续): %s", exc)
            return
        finally:
            state["waiting"] = False


async def _drain_with_input_grace(
    drain: "asyncio.Future[Any]",
    base_timeout: float,
    state: dict[str, Any],
) -> bool:
    """等 drain 结束;返回是否超时。

    等待用户键入的那段墙钟**不计入命令超时**(那 300 秒是给人的,不是给命令的),
    但整段仍有总上限 `base_timeout + TERMINAL_INTERACTION_EXTRA_GRACE_S` ——
    "有人在等"不得把一次工具调用变成无限挂流。
    """
    started = time.monotonic()
    paused_s = 0.0
    was_waiting = False
    hard_deadline = started + base_timeout + TERMINAL_INTERACTION_EXTRA_GRACE_S
    while True:
        remaining = started + base_timeout + paused_s - time.monotonic()
        if remaining <= 0:
            return True
        try:
            await asyncio.wait_for(asyncio.shield(drain), timeout=min(remaining, 0.5))
            return False
        except TimeoutError:
            now = time.monotonic()
            waiting = bool(state.get("waiting"))
            if waiting and was_waiting:
                paused_s += 0.5
            was_waiting = waiting
            if now >= hard_deadline:
                return True
            continue
        except asyncio.CancelledError:
            raise


async def _drain_stream(
    stream: Any,
    lines_list: list[str],
    max_output: int = 10000,
    *,
    on_line: Callable[[str], None] | None = None,
    batch_lines: int = _TERMINAL_DELTA_BATCH_LINES,
) -> None:
    """逐行读取 asyncio subprocess stream,累积到 lines_list(防长命令一次性读阻塞)。

    P0-B(2026-09-18):on_line 提供时,每读一行(按 batch_lines 聚合节流)同步回调
    (供 terminal.delta 实时事件发射,回调自身 fire-and-forget 不阻塞读取)。

    P1 修复(mcp_server _tool_run_command 大输出全量累积后截断):
    原实现无大小上限,GB 级 stdout/stderr 会全量加载到内存 list,再在
    _tool_run_command 末尾截断到 max_output → 截断前 OOM 已发生。
    现在实时累计 total_size,超过 2 * max_output 硬上限立即停止读取,
    避免大输出全量加载到内存(截断点放宽到 2 倍是为了保留少量尾部上下文)。

    第三十三批(同族的另一半):上面的护栏管的是"总量",而**单行**长度无人管 ——
    `await stream.readline()` 在一行超过 asyncio 默认 65536 时抛
    LimitOverrunError,该异常沿调用方 `asyncio.gather(...)` 冒出去后被
    `contextlib.suppress(Exception)` 吞掉,表现为"这条命令的输出突然就这么多",
    既不喊"截断"也不说明原因。现在超限按**标注截断 + 计数 + 继续读下一行**处理。
    """
    total_size = 0
    size_limit = max_output * 2  # 2 倍 max_output 作为硬上限
    pending: list[str] = []
    dropped_lines = 0
    dropped_bytes = 0

    def _flush_pending() -> None:
        if pending and on_line is not None:
            on_line("\n".join(pending) + "\n")
        pending.clear()

    while True:
        frame = await read_protocol_frame(stream)
        if frame.kind == FRAME_READ_LINE:
            decoded = frame.data.decode("utf-8", errors="replace").rstrip("\r\n")
        elif frame.kind == FRAME_READ_TOO_LARGE:
            dropped_lines += 1
            dropped_bytes += frame.dropped_bytes
            note = (
                f"...(单行超过 {PROTOCOL_FRAME_LIMIT_BYTES} 字节帧预算,"
                f"已丢弃 {frame.dropped_bytes} 字节)"
            )
            logger.warning("[mcp_server] run_command %s", note)
            lines_list.append(note)
            _flush_pending()
            if not frame.resynced:
                # 残余没能对齐行尾 ⇒ 后面读到的都不是完整行,停读并如实说明。
                lines_list.append("...(超限帧残余未能对齐行尾,已停止读取该流)")
                break
            continue
        elif frame.kind == FRAME_READ_EOF:
            break
        else:
            break  # 未预期的 kind(共享出口若新增结局,这里按结束保守处理)
        lines_list.append(decoded)
        total_size += len(decoded)
        if on_line is not None:
            pending.append(decoded)
            if len(pending) >= batch_lines:
                _flush_pending()
        if total_size > size_limit:
            lines_list.append(f"\n...(输出超过 {size_limit} 字符,已截断)")
            break
    if dropped_lines:
        lines_list.append(
            f"...(本次共 {dropped_lines} 行因单行超帧预算被丢弃,"
            f"合计 {dropped_bytes} 字节)"
        )
    _flush_pending()  # 尾部残余帧


def _build_subprocess_env(user_env: dict[str, Any] | None) -> dict[str, str]:
    """构建 subprocess env:复制 os.environ,合并用户 env(禁止覆盖 PATH/HOME)。

    2026-07-24 流式升级:支持 env 参数透传,但不允许覆盖 PATH/HOME(防劫持命令查找)。

    差距⑦(2026-10-30,遵循统一工程规范
    process-hardening):出口统一剥离两类变量 —— 继承值与用户 override 同判,
    判据取 core/exec_env 单一权威源,与 agent_engine._sanitized_child_env 同尺:
    - NON_INHERITABLE_ENV_VARS(管理凭据/身份令牌,如 IHUI_ADMIN_PASSWORD);
    - 注入型前缀(LD_PRELOAD/LD_AUDIT/DYLD_*,防子进程被环境劫持)。

    G-17(2026-10-31):会话身份注入 —— 身份只从**执行上下文**取(agent_loop_v2 /
    llm.py 在调工具前经 ``set_terminal_stream_context`` 注入的 session_id),
    取不到就不注入,子进程 env 与改动前逐字节同形(绝不编造身份)。
    """
    from app.core.exec_env import scrub_injection_env_vars, scrub_non_inheritable_env_vars

    env = dict(os.environ)
    if isinstance(user_env, dict):
        for k, v in user_env.items():
            if not isinstance(k, str) or not isinstance(v, (str, int, float)):
                continue
            if k.upper() in ("PATH", "HOME", "USERPROFILE"):
                continue  # 不允许覆盖 PATH/HOME
            env[k] = str(v)
    # worker 请求级 env:在凭据保险库/注入型变量剥离之前合并,确保它走同一道守卫。
    # 这是护栏不是沙箱(同 OS 用户仍可用绝对路径绕过),见 core/worker_exec_context.py。
    from app.core.worker_exec_context import apply_worker_child_env

    env = apply_worker_child_env(env)
    # P0-2 凭据保险库:剔除凭据形环境变量(绝不外带给子进程)
    env = _filter_vault_env(env, _get_vault_store())
    # 差距⑦:凭据/身份令牌与注入型变量在**出口**剥离(用户 override 也剥)
    env = scrub_non_inheritable_env_vars(scrub_injection_env_vars(env))
    # G-17:排在所有剥离之后 —— 宿主注入的会话身份不该被用户 env 或凭据剥离改写。
    _exec_session_id = str((_terminal_stream_ctx.get() or {}).get("session_id") or "")
    if _exec_session_id:
        from app.core.exec_env import harness_version, inject_session_env

        inject_session_env(env, _exec_session_id, harness_version())
    return env


_COMMAND_POLICY_DEFAULT: dict[str, Any] = {
    # 与 app/data/command_policy.json 保持一致(文件加载失败时的回退兜底)
    "dangerous_patterns": [
        r";\s*\S", r"&&\s*\S", r"\|\|\s*\S",
        r"\brm\b", r"\brmdir\b", r"\bmv\b", r"\bcp\b", r"\bmkdir\b",
        r"\btouch\b", r"\bchmod\b", r"\bchown\b",
        r"\bcurl\b", r"\bwget\b", r"\bscp\b", r"\bssh\b",
        r"\bdd\b", r"\bmkfs\b", r"\bshutdown\b", r"\breboot\b",
        r"\bkill\b", r"\bkillall\b",
        r">\s*", r">>\s*", r"<\s*", r"\|\s*",
        r"`[^`]*`", r"\$\([^)]*\)", r"\$\{[^}]*\}",
        # AIS-081:cmd /c 内建分支的剩余元字符 —— 单 `&`(后台串联)、`^`(转义)、
        # 换行(跨行串联)都会把一条白名单命令变成多条,与 ; && || | 同级闭锁。
        r"&", r"\^", r"[\r\n]",
    ],
    "allowed_prefixes": [
        "git", "ls", "cat", "echo", "python", "python3", "node", "npm", "npx",
        "pnpm", "tsc", "ruff", "mypy", "pytest", "find", "grep", "rg", "wc",
        "head", "tail", "date", "whoami", "pwd", "which", "where", "env",
        "uname", "ver", "dir", "type", "getopt",
    ],
    "sensitive_file_markers": [".env", ".pem", ".key", "credentials", "secret", "token"],
}


@functools.lru_cache(maxsize=1)
def _load_command_policy() -> dict[str, Any]:
    """读取命令安全策略单一权威源(app/data/command_policy.json)。

    统一安全 C4(2026-09-01):策略从函数内硬编码提取为 JSON 权威源,前后端共用
    (前端用 scripts/generate-command-policy-ts.mjs 生成 TS 常量)。文件缺失/
    解析失败回退 _COMMAND_POLICY_DEFAULT(与既有内联行为一致),绝不抛异常。
    """
    try:
        policy_path = Path(__file__).resolve().parent.parent / "data" / "command_policy.json"
        with open(policy_path, encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            raise ValueError("command_policy.json 根必须是对象")
        return data
    except Exception as e:  # noqa: BLE001 - 策略加载失败回退默认,不阻塞工具
        logger.warning("command_policy.json 加载失败,回退默认策略: %s", e)
        return _COMMAND_POLICY_DEFAULT


# =====================================================================
# P0-3(2026-09-12):exec_policy 一次性审批放行登记表。
# agent_loop_v2 在用户批准 exec_policy PROMPT 命令后调用 approve_exec_command
# 登记;_tool_run_command 首次执行到该命令时消费放行(仅跳过 PROMPT 分支,
# DENY 硬拦截/危险命令硬门/黑白名单不受影响)。LLM 无法伪造——登记仅在真实
# 审批通过后由服务端代码写入,工具入参不可触及。命令串键 + 一次性消费 + 容量上限。
# =====================================================================
_EXEC_APPROVED_MAX = 128
_exec_approved_commands: set[str] = set()


def _canonical_approval_key(command: str) -> str:
    """批 41 接线:审批缓存键规范化(对齐 command_canonicalization.rs)。

    同一条命令经不同 shell 包装(bash -lc 'git status' vs 直接 git status)
    到达时归一为同一键,避免"换个包装就要再批一次"的体验损耗;
    复杂脚本归一为固定前缀形态,保证复杂脚本间不误互相命中。
    规范化失败(理论上不抛,防御性兜底)回退原始命令字符串。
    """
    try:
        from ..core.command_canonicalization import canonicalize_command_for_approval

        # posix=True 切词:剥离外层引号,使 bash -lc 'git status' 与 git status
        # 得到同形 argv(审批键空间一致);Windows 的 cmd 语义保留引号形态仅在
        # 原始执行路径使用,审批键统一用规范化形态
        argv = _approval_tokens(command)
        if not argv:
            return command
        canonical = canonicalize_command_for_approval(argv)
        try:
            return shlex.join(canonical)
        except ValueError:  # Windows 路径反斜杠等 shlex.join 限制 → 空格拼接兜底
            return " ".join(canonical)
    except Exception:  # noqa: BLE001 - 规范化失败回退原键,绝不放松审批
        return command


def approve_exec_command(command: str) -> None:
    """登记一次性 exec_policy 审批放行(由 agent_loop_v2 在用户批准后调用)。

    批 51b:双写持久层(always 档,遵循统一工程规范)——内存表保持
    一次性消费语义,持久层只做审计/恢复底账,消费后不删(一次性语义由内存表
    承担);持久层写失败静默(不阻断放行,内存表已生效)。
    """
    key = _canonical_approval_key(command)
    if len(_exec_approved_commands) >= _EXEC_APPROVED_MAX:
        _exec_approved_commands.clear()
    _exec_approved_commands.add(key)
    try:
        from . import approval_persistence as _ap

        _ap.grant(_ap.SCOPE_ALWAYS, key, _ap.KIND_EXEC_ONCE)
    except Exception:  # noqa: BLE001 - 持久化失败不阻断内存放行
        pass


def _consume_exec_approval(command: str) -> bool:
    """消费一次性放行(命中即移除并返回 True;批 41 起走规范化键)。"""
    key = _canonical_approval_key(command)
    if key in _exec_approved_commands:
        _exec_approved_commands.discard(key)
        return True
    return False


# =====================================================================
# 第十六批(2026-09-18,遵循统一工程规范):
# 「前缀放行规则」登记表。用户选择"这类命令以后都允许"时登记前 N 个 token,
# 后续同前缀命令直接放行,不再逐次弹审批 —— 一次性放行只解决一次,前缀规则
# 解决一类(git push / pnpm install / pytest 这类高频重复命令)。
# 与一次性放行同规格:仅服务端代码可写(LLM 无法经工具入参伪造),仅跳过
# PROMPT 分支,危险命令硬门 / DENY 硬红线 / 黑白名单一律不受影响。
# =====================================================================
_EXEC_ALLOWED_PREFIXES_MAX = 256
_exec_allowed_prefixes: set[tuple[str, ...]] = set()

# ---------------------------------------------------------------------------
# 2026-10-03 数据出域合规整改:不可固化的前缀(excluded from prefix-grant)
#
# 问题:前缀规则是「永久放行」机制(双写持久层,重启后仍生效)。若允许对
# 出域类命令登记前缀,则 PROMPT 确认门可被一次性绕过 —— 而且绕得比看上去更宽:
#   1. tokens=2 的默认语义下,用户为 `git push --force origin main` 点一次
#      「以后都允许」,登记的是 ("git","push"),于是**所有** git push 永久放行;
#   2. tokens=1 更极端:登记 ("git",) 就等于给 **git 全部子命令**开了万能钥匙,
#      连 DENY 红线之外的任意推送/删除都一并放行。
# 这与 2026-09 智谱 ZCode 事件同源:代码在用户未逐次确认的情况下流到了外部。
#
# 对策:下列前缀**不允许**被登记为永久放行规则。用户在审批弹窗里仍可选择
# 「仅本次放行」(走一次性放行通道,不入本表),逐次决策权保留;但「以后都允许」
# 对它们永久不可用。
#
# 判据只此一份(新形态必须加到这里,不要在别处另抄):
#   - 判在**前缀首 token 与次 token** 上,故 ("git",) 这类单 token 登记因覆盖
#     ("git","push") 而同样被拒(见 _is_non_persistable_prefix)。
# ---------------------------------------------------------------------------
_NON_PERSISTABLE_PREFIXES: frozenset[tuple[str, ...]] = frozenset(
    {
        ("git", "push"),  # 推送=代码出域,必须逐次确认
    }
)


def _is_non_persistable_prefix(prefix: tuple[str, ...]) -> bool:
    """该前缀是否覆盖了出域类不可固化命令(⇒ 禁止登记为永久放行)。

    两种覆盖形态都要拒:
      - prefix 本身就是被禁项或其更长前缀(如 ("git",)、("git","push","--force"));
      - prefix 是被禁项的前缀(如 ("git",) 是 ("git","push") 的前缀)。
    前者防止"精确登记",后者防止"用更短的万能钥匙一次放行一大片"。
    """
    for banned in _NON_PERSISTABLE_PREFIXES:
        n = min(len(prefix), len(banned))
        if n > 0 and prefix[:n] == banned[:n]:
            return True
    return False


def _command_tokens(command: str) -> list[str]:
    """命令切词(Windows 用非 posix 模式,保留引号以贴合 cmd 语义)。"""
    try:
        return shlex.split(command, posix=os.name != "nt")
    except ValueError:  # 引号不闭合等
        return command.split()


def _approval_tokens(command: str) -> list[str]:
    """批 41 接线:审批键空间统一切词(posix=True 剥外层引号)。

    bash -lc 'git status' 与 git status 在键空间同形;切词失败回退
    _command_tokens(cmd 语义),绝不放松审批。
    """
    try:
        return shlex.split(command, posix=True)
    except ValueError:
        return _command_tokens(command)


def approve_exec_prefix(command: str, tokens: int = 2) -> tuple[str, ...] | None:
    """登记前缀放行规则;返回登记的前缀(命令为空时返回 None)。

    tokens=2 是默认值:`git push --force` → ("git", "push"),即"允许所有
    git push",但不含 `git` 全部子命令(避免过度放行)。
    """
    parts = _approval_tokens(command)
    if not parts:
        return None
    # 批 41 接线:登记前同样规范化,保证登记与匹配键空间一致
    try:
        from ..core.command_canonicalization import canonicalize_command_for_approval

        parts = canonicalize_command_for_approval(parts)
    except Exception:  # noqa: BLE001 - 失败回退原切词
        pass
    prefix = tuple(parts[: max(1, tokens)])
    # 2026-10-03 数据出域合规整改:出域类命令禁止"以后都允许"(永久放行)。
    # 拒绝登记 ⇒ 该命令此后每次都重新走审批弹窗。逐次决策权不可被一次性授权
    # 代替 —— 这是 ZCode 事件的直接教训(代码在用户未逐次确认下流到外部)。
    # 注意这**不**拒绝对应的执行本身:用户在弹窗里选"仅本次放行"仍可执行。
    if _is_non_persistable_prefix(prefix):
        return None
    if len(_exec_allowed_prefixes) >= _EXEC_ALLOWED_PREFIXES_MAX:
        _exec_allowed_prefixes.clear()  # 容量上限:整体清空而非逐条淘汰(与一次性放行同策略)
    _exec_allowed_prefixes.add(prefix)
    # 批 51b:双写持久层(always 档)。重启后经 _matches_exec_prefix 的
    # 持久层查询自动恢复;写失败静默(内存表已生效,不阻断放行)。
    try:
        from . import approval_persistence as _ap

        _ap.grant(_ap.SCOPE_ALWAYS, _ap.normalize_exec_key(list(prefix)), _ap.KIND_EXEC_PREFIX)
    except Exception:  # noqa: BLE001
        pass
    # 批58(接线):exec_policy_amendments 真接线(遵循统一工程规范
    # blocking_append_allow_prefix_rule)——on 时把前缀规则同步进 ExecPolicy
    # 引擎热更新(get_or_create_manager().append_rule:内存替换+落盘 *.rules,
    # 落盘失败回滚内存并抛错,此处降级为仅内存表生效)与规则文件追加
    # (append_allow_prefix_rule 直写 rules 文件)。off 时零差异;任何失败
    # 静默降级,绝不阻断既有放行链路。
    if os.environ.get("AGENT_EXEC_POLICY_AMENDMENTS_ENABLED", "false").strip().lower() in (
        "on", "1", "true", "yes"
    ):
        try:
            from ..core.exec_policy_amendments import (
                append_allow_prefix_rule as _ea_append,
            )
            from .exec_policy import PrefixRule as _PR
            from .exec_policy import get_or_create_manager as _gocm
            from .exec_policy import rules_dir_from_env as _rules_dir_env

            _mgr = _gocm()
            _rule = _PR(pattern=tuple(prefix), decision=RuleDecision.ALLOW, source="amend")
            # append_rule 是 async(内存替换+异步落盘);approve_exec_prefix 在
            # 请求上下文中通常已有运行中 loop,直接建后台任务消费;无 loop(同步
            # 测试/脚本)时退化为 create_new_event_loop 同步跑完。两种路径均
            # 异常隔离,失败降级仅内存表生效。
            try:
                asyncio.get_running_loop()
                _amend_task = asyncio.get_event_loop().create_task(_mgr.append_rule(_rule))
                _amend_task.add_done_callback(
                    lambda t: (
                        logger.warning("exec_policy 修正案后台追加失败: %s", t.exception())
                        if not t.cancelled() and t.exception() is not None
                        else None
                    )
                )
            except RuntimeError:
                asyncio.run(_mgr.append_rule(_rule))
            _rd = _rules_dir_env()
            if _rd:
                _ea_append(Path(_rd) / "default.rules", list(prefix))
        except Exception as _amend_exc:  # noqa: BLE001 - 修正案失败降级,不阻断放行
            logger.warning("exec_policy 前缀修正案追加失败(降级仅内存表): %s", _amend_exc)
    return prefix


def _matches_exec_prefix(command: str) -> bool:
    """命令是否命中任一已登记的前缀放行规则(不消费,规则长期有效;批 41 起走规范化键)。

    批 51b:内存表未命中时回源持久层(重启恢复;fail-closed——查询异常视为未命中)。
    """
    try:
        from ..core.command_canonicalization import canonicalize_command_for_approval

        parts = canonicalize_command_for_approval(_approval_tokens(command))
    except Exception:  # noqa: BLE001 - 规范化失败回退原切词,绝不放松审批
        parts = _command_tokens(command)
    if not parts:
        return False
    # 内存表命中同样要过不可固化判据(2026-10-03)。三处都要堵,缺一即失效:
    #   登记侧 —— 阻止新增"以后都允许";
    #   内存表 —— 挡住本次进程内已登记的条目(含热更/其他调用点写入);
    #   持久层 —— 挡住上线前已落盘的存量授权(重启后恢复的那批)。
    # 只堵登记侧是最常见的疏漏:规则在进程内被写入内存表后,匹配侧不看判据
    # 就等于闸门不存在(本条即 2026-10-03 自测时实测到的真缺陷,不是假想)。
    #
    # 判据取 **本次命令** 的形态而非登记的 prefix:存量 ("git",) 这把万能钥匙对
    # `git status` 应继续有效(只读,收紧了就是过度整改,审批会变噪声、用户最终
    # 全点同意),只对 `git push ...` 这类出域形态失效。
    command_is_egress = _is_non_persistable_prefix(tuple(parts))
    for prefix in _exec_allowed_prefixes:
        if parts[: len(prefix)] == list(prefix) and not command_is_egress:
            return True
    # 批 51b:内存未命中 → 查持久层(重启恢复;fail-closed——查询异常视为未命中)。
    #
    # 2026-10-03 数据出域合规整改:持久层命中前**先过不可固化判据**。
    # 原因:本代码上线前用户可能已对 `git push` 登记过前缀规则(登记口当时没有
    # 这道闸),那些规则连同 SCOPE_ALWAYS 授权已落盘。若只在登记侧加闸而不在
    # 匹配侧加闸,历史存量规则会继续永久放行出域命令 —— 等于整改没生效。
    # 这一层用命中到的 prefix 直接判,存量与新登记一视同仁。
    try:
        from . import approval_persistence as _ap

        if command_is_egress:
            return False  # 出域命令:持久层(存量授权)一律不得放行
        persisted = _ap.check(
            _ap.normalize_exec_key(parts), _ap.KIND_EXEC_PREFIX
        )
        if persisted is not None:
            return True
        # 前缀语义:持久层键是"前 N 个 token"的归一串;完整键未命中时再试
        # 前 1/2 token 的前缀键(与内存表 tokens=2 默认语义对齐)。
        for n in (2, 1):
            if n <= len(parts):
                if _ap.check(
                    _ap.normalize_exec_key(parts[:n]), _ap.KIND_EXEC_PREFIX
                ) is not None:
                    return True
    except Exception:  # noqa: BLE001 - 持久层异常按未命中处理,绝不放松审批
        pass
    return False


def list_exec_prefix_rules() -> list[list[str]]:
    """当前生效的前缀放行规则(可观测:设置页/审计用)。"""
    return [list(p) for p in sorted(_exec_allowed_prefixes)]


def revoke_exec_prefix(prefix: list[str]) -> bool:
    """撤销一条前缀放行规则;返回该规则此前是否存在。

    批 51b:同步撤销持久层对应键(内存前缀 + 归一化键)。
    """
    key = tuple(prefix)
    existed = key in _exec_allowed_prefixes
    _exec_allowed_prefixes.discard(key)
    try:
        from . import approval_persistence as _ap

        _ap.revoke(_ap.normalize_exec_key(list(prefix)), _ap.KIND_EXEC_PREFIX)
    except Exception:  # noqa: BLE001 - 持久层失败不影响内存撤销
        pass
    return existed


# AIS-081(2026-11-08 机制修订):元字符只有在**命令确实经 shell 解释**时才有注入语义。
# 判据 = "谁在解释这串字符":
#   · Windows 内置命令(echo/dir/set...)⇒ 整串交给 `cmd /c`,由 cmd 解释;
#   · 显式 shell 壳 `cmd|cmd.exe /c|/k`、`sh|bash|zsh|dash -c|-lc` ⇒ 被调用的 shell
#     会重新解释其后的整串(Python 侧只是 create_subprocess_exec);
#   · 其余(argv 直传)⇒ `&`/`^`/`;` 只是某个可执行文件的**字面参数**,
#     `git log --grep=a&b`、`find . -name a&b` 必须放行。
# 旧实现不区分形态、对整串无差别扫描,把 `echo "a&b"`(引号内字面量)也误挡。
# 引号语义:cmd/sh 下双引号内的 `&`/`^`/`|`/`<`/`>`/`;` 是字面量,扫描跳过引号段;
# CR/LF 不因引号豁免(单行命令串里出现换行只可能是拼接)。
# 本表是内置分支的第二道独立闸(不替代既有危险模式表);测试从本模块 import,不复制。
# 刻意**不含** `%`:cmd 的 `%VAR%` 只是变量展开、不是命令分隔符,拒掉会误伤
# `echo %PATH%` / `set X=%Y%` 这类合法内置用法;` 与 `$(` 同样只是字面量,无注入语义。
WIN_BUILTIN_SHELL_METACHARACTERS: Final[tuple[str, ...]] = (
    "&", "^", "|", "<", ">", ";", "\r", "\n",
)

WIN_SHELL_BUILTINS: Final[frozenset[str]] = frozenset({
    "echo", "type", "ver", "dir", "set", "cd", "cls", "color",
    "prompt", "title", "path", "assoc", "ftype",
})

# AIS-106:file_search 按内容回读的单文件上限(超限跳过,不读进内存)。
_MAX_SEARCH_FILE_BYTES: Final[int] = 2 * 1024 * 1024

_SHELL_WRAPPER_FLAGS: Final[dict[str, frozenset[str]]] = {
    "cmd": frozenset({"/c", "/k"}),
    "cmd.exe": frozenset({"/c", "/k"}),
    "sh": frozenset({"-c"}),
    "bash": frozenset({"-c", "-lc"}),
    "zsh": frozenset({"-c"}),
    "dash": frozenset({"-c"}),
}


def _shell_interpretation_of(command: str, cmd_name: str) -> str | None:
    """返回"这串字符会被哪层 shell 解释";None = argv 直传,不做元字符判据。"""
    if sys.platform == "win32" and cmd_name in WIN_SHELL_BUILTINS:
        return "cmd /c (Windows 内置命令)"
    try:
        tokens = shlex.split(command, posix=sys.platform != "win32")
    except ValueError:
        tokens = command.split()
    if not tokens:
        return None
    head = tokens[0].rsplit("/", 1)[-1].rsplit("\\", 1)[-1].lower()
    flags = _SHELL_WRAPPER_FLAGS.get(head)
    if not flags:
        return None
    for token in tokens[1:3]:
        if token.lower() in flags:
            return f"{head} {token.lower()}"
    return None


def _first_shell_metacharacter(command: str) -> str | None:
    """在会被 shell 解释的段里找第一个元字符;双引号内的字面量跳过。"""
    in_quotes = False
    for ch in command:
        if ch == '"':
            in_quotes = not in_quotes
            continue
        if ch in ("\r", "\n"):
            return ch
        if not in_quotes and ch in WIN_BUILTIN_SHELL_METACHARACTERS:
            return ch
    return None


async def _terminate_process_tree(proc: Any) -> None:
    """终止命令进程及其子进程树(AIS-056)。

    Windows 下命令经 ``cmd /c`` 承载,``proc.kill()`` 只结束 cmd.exe,它拉起的
    编译/测试/服务子进程会继续跑并占端口。统一先 ``taskkill /F /T /PID``,
    taskkill 自身不可用时才回退单进程 kill;POSIX 维持原 kill 语义。
    """
    pid = getattr(proc, "pid", None)
    if sys.platform == "win32" and pid is not None:
        try:
            killer = await asyncio.create_subprocess_exec(
                "taskkill", "/F", "/T", "/PID", str(pid),
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL,
            )
            await killer.wait()
            return
        except Exception:
            logger.warning(
                "[mcp_server] taskkill /T 失败,回退单进程 kill: pid=%s", pid,
                exc_info=True,
            )
    with contextlib.suppress(ProcessLookupError, OSError):
        proc.kill()


async def _tool_run_command(
    arguments: dict[str, Any], cancel: asyncio.Event | None = None
) -> dict[str, Any]:
    """run_command: 运行 shell 命令(asyncio.subprocess 流式读取 stdout/stderr,长命令不超时)。

    出于安全考虑,仅允许只读/查询类命令,禁止任何修改/删除/网络写入操作。
    - command: 命令字符串(如 "git status", "ls -la", "python --version")
    - cwd: 工作目录(默认当前目录,需 _validate_path_in_workspace 校验)
    - timeout: 超时秒数(默认 60)
    - max_timeout: 超时上限(默认 600,timeout 不超过此值)
    - env: 环境变量 dict(不允许覆盖 PATH/HOME)
    - sandbox_backend: 沙箱后端(默认 local,可选 docker/ssh/modal/daytona/singularity)
    - 白名单: git/ls/cat/echo/python/node/npm/pnpm/tsc/ruff/mypy/pytest/find/grep/wc/head/tail 等
    - 禁止: rm/mv/cp/mkdir/curl/wget/dd/mkfs/>/>>/|/`/$() 等危险操作
    - 超时 → kill 进程 + 返回 partial_output + errorCode=TIMEOUT
    """
    command = arguments.get("command", "").strip()
    cwd = arguments.get("cwd", ".")
    sandbox_backend = arguments.get("sandbox_backend", "local")
    docker_image = arguments.get("docker_image", "python:3.12-slim")
    ssh_host = arguments.get("ssh_host")
    ssh_user = arguments.get("ssh_user", "root")
    user_env = arguments.get("env")

    # P0-2 凭据保险库:审批已通过 ⇒ 解析占位符为真值;子进程环境剔除凭据形变量。
    # 模型视野里只有 {{vault:NAME}},此处(工具真正执行前)才交钥匙;未知 NAME
    # 保留占位符(绝不泄漏/绝不编造)。
    _vault = _get_session_vault()
    command = _vault.resolve(command)
    if isinstance(user_env, dict):
        user_env = {k: _vault.resolve(str(v)) for k, v in user_env.items()}

    max_timeout = max(1, int(arguments.get("max_timeout", 600)))
    timeout = max(1, min(int(arguments.get("timeout", 60)), max_timeout))
    # 0-5 执行硬超时上限(env RUN_COMMAND_TIMEOUT_S,默认 120s):请求超时不得超过,
    # 防止调用方通过 timeout/max_timeout 把执行拖到失控时长
    timeout = min(timeout, _get_run_command_hard_timeout())

    if not command:
        return {
            "tool": "run_command", "command": command,
            "exit_code": -1, "stdout": "", "stderr": "",
            "ok": False, "streamed": True, "message": "命令为空",
        }

    # 0-5 确定性破坏性命令硬门(默认开启,env DANGEROUS_COMMAND_BLOCKED 可关)
    # 任何后端(local/sandbox)执行前一律拦截,命中即不执行
    if _is_dangerous_command_blocked():
        matched = _match_destructive_command(command)
        if matched:
            return {
                "ok": False, "tool": "run_command",
                "error": "dangerous_command_blocked",
                "errorCode": "DANGEROUS_COMMAND_BLOCKED",
                "matched": matched,
                "command": command,
                "message": (
                    f"命令被危险命令硬门拦截:命中破坏性模式 '{matched}'"
                    f"(安全限制,禁止执行)"
                ),
            }

    # exec_policy 策略引擎评估(在硬门之后、cwd 校验之前)
    # P0-3(2026-09-12):三档模式由安全配置决定 —— 2026-10-21 起按**当前 principal** 解析
    # (进程默认 ⊕ 该用户显式表态;取不到主体 ⇒ 恰为进程快照 = 改动前行为)。三档语义不变:
    # enforce = DENY 拒绝;PROMPT 返回审批结构(agent_loop_v2 转真实用户审批弹窗,
    #           批准后经 approve_exec_command 一次性放行重执行);
    # audit   = PROMPT 仅记录后放行(观察期);DENY 硬红线仍拒绝,不降级;
    # off     = 跳过策略引擎评估。
    # 边界(恒不受本开关影响,任何档位都不放松,用例 4a/4b 钉死):
    #   上面那段破坏性命令硬门(DANGEROUS_COMMAND_BLOCKED)与 _DESTRUCTIVE_PATTERNS、
    #   工作区/cwd 校验、黑白名单等其他防线、以及 agent_loop_v2 的审批门全局 kill
    #   switch TOOL_APPROVAL_ENABLED(优先级高于用户档)。
    _exec_mode = (
        await resolve_security_config(current_security_principal())
    ).exec_policy_mode
    # 一次性放行 或 长期前缀放行规则命中 → 跳过 PROMPT 分支
    # (第十六批:前缀规则不消费,长期有效;仅服务端可登记,LLM 无法伪造)
    # 2026-11-05(goal-b49):两种放行**分开记** —— 多档策略的 ask 档只认一次性放行
    # (本层自己走审批通道后回灌的那一张),长期前缀规则不得静默放行企业档的 ask(§0.10)。
    _exec_approved_once = _consume_exec_approval(command)
    _exec_approved = _exec_approved_once or _matches_exec_prefix(command)
    if _exec_mode != "off" and not _exec_approved:
        _exec_decision: PolicyDecision = exec_policy_evaluate(command, cwd=cwd)
        if _exec_decision.action == RuleDecision.DENY:
            if _exec_mode == "audit":
                logger.info(
                    "[exec_policy][audit] DENY 记录后放行: command=%r, rules=%s",
                    command[:200],
                    [r.pattern for r in _exec_decision.matched_rules],
                )
            else:
                return {
                    "ok": False, "tool": "run_command",
                    "error": "exec_policy_denied",
                    "errorCode": "EXEC_POLICY_DENIED",
                    "command": command,
                    "matched_rules": [
                        {"pattern": r.pattern, "reason": r.reason, "source": r.source}
                        for r in _exec_decision.matched_rules
                    ],
                    "risk_notes": _exec_decision.risk_notes,
                    "message": (
                        f"命令被策略引擎拒绝:{_exec_decision.matched_rules[0].reason if _exec_decision.matched_rules else '未匹配规则'}"
                        "(安全策略禁止执行)"
                    ),
                }
        elif _exec_decision.action == RuleDecision.PROMPT:
            if _exec_mode == "audit":
                logger.info(
                    "[exec_policy][audit] PROMPT 记录后放行: command=%r, rules=%s",
                    command[:200],
                    [r.pattern for r in _exec_decision.matched_rules],
                )
            else:
                _approval_result: dict[str, Any] = {
                    "ok": False, "tool": "run_command",
                    "error": "exec_policy_needs_approval",
                    "errorCode": "EXEC_POLICY_NEEDS_APPROVAL",
                    "command": command,
                    "matched_rules": [
                        {"pattern": r.pattern, "decision": r.decision.value, "reason": r.reason, "source": r.source}
                        for r in _exec_decision.matched_rules
                    ],
                    "risk_notes": _exec_decision.risk_notes,
                    "approval_request": {
                        "command": command,
                        "reason": "; ".join(_exec_decision.risk_notes) if _exec_decision.risk_notes else "命令需要人工审批",
                    },
                    "message": "命令需要用户审批后方可执行",
                }
                # 批58(w3):权限档案参与审批决策(遵循统一工程规范)
                # on 时解析生效档案,把档位/网络模式/启用根并入回执;解析失败走现状
                # 默认(降级跳过,绝不改变拒绝语义)。off 时回执逐字节等价。
                if _mcp_permission_profiles_enabled_from_env():
                    try:
                        from app.core.permission_profiles import resolve_permission_profile

                        if (
                            _MCP_PERMISSION_PROFILES is not None
                            and _MCP_PERMISSION_PROFILES_ACTIVE
                        ):
                            _prof = resolve_permission_profile(
                                _MCP_PERMISSION_PROFILES_ACTIVE,
                                _MCP_PERMISSION_PROFILES,
                            )
                            _net_mode = (
                                _prof.network.mode.value
                                if _prof.network and _prof.network.mode
                                else None
                            )
                            _approval_result["resolved_permission_profile"] = {
                                "name": _MCP_PERMISSION_PROFILES_ACTIVE,
                                "network_mode": _net_mode,
                                "enabled_roots": _prof.enabled_roots(),
                            }
                    except Exception as e:  # noqa: BLE001
                        logger.debug("permission_profiles 解析失败(降级跳过): %s", e)
                return _approval_result

    # ── 多档命令策略合并裁决(仓库档 ⊕ 企业档)─────────────────────────────
    # 2026-11-05(goal-b49):单一判据源 app/core/command_policy_merge.py(本仓唯一实现,
    # 测试 import 真源)。本层**只增不减**:既有 dangerous_patterns / allowed_prefixes
    # 两道防线一字未动,这里额外判的是红/黑名单 + 不可变路径 + ask/allow 的多档规则
    # (企业档优先,逐条点名来源)。
    _policy_verdict = adjudicate_command(command, _load_command_policy())
    if _policy_verdict.outcome is PolicyOutcome.UNDETERMINED:
        # 「未判定」不折成 deny/allow:独立出口,闭锁并点名原因(AGENTS §0.3)。
        return {
            "ok": False, "tool": "run_command",
            "error": "command_policy_undetermined",
            "errorCode": "COMMAND_POLICY_UNDETERMINED",
            "command": command,
            "policy_verdict": _policy_verdict.to_dict(),
            "message": f"命令策略未判定,已闭锁:{_policy_verdict.reason}",
        }
    if _policy_verdict.outcome is PolicyOutcome.DENY:
        # deny 档不可绕门:一次性放行与前缀放行都不跳过本层(与破坏性命令硬门同级)。
        return {
            "ok": False, "tool": "run_command",
            "error": "command_policy_denied",
            "errorCode": "COMMAND_POLICY_DENIED",
            "command": command,
            "matched_rules": [
                {"pattern": hit.pattern, "decision": hit.decision.value,
                 "source": hit.tier.value, "kind": hit.kind.value}
                for hit in _policy_verdict.hits
            ],
            "policy_verdict": _policy_verdict.to_dict(),
            "message": f"命令被策略拒绝:{_policy_verdict.to_explanation()}",
        }
    if _policy_verdict.outcome is PolicyOutcome.ASK and not _exec_approved_once:
        # ask 档走**既有**审批通道(EXEC_POLICY_NEEDS_APPROVAL 是 agent_loop_v2 的通道
        # 契约,不新造第二条通道);已走过本层审批(一次性放行)的命令不重复要审批,
        # 但本地长期前缀放行**不能**静默放行企业档的 ask。
        return {
            "ok": False, "tool": "run_command",
            "error": "exec_policy_needs_approval",
            "errorCode": "EXEC_POLICY_NEEDS_APPROVAL",
            "command": command,
            "matched_rules": [
                {"pattern": hit.pattern, "decision": hit.decision.value,
                 "source": hit.tier.value, "kind": hit.kind.value}
                for hit in _policy_verdict.hits
            ],
            "policy_verdict": _policy_verdict.to_dict(),
            "approval_request": {
                "command": command,
                "reason": _policy_verdict.to_explanation(),
            },
            "message": "命令命中策略 ask 档,需要用户审批后方可执行",
        }

    # worker 请求级 cwd:未传/相对路径收敛到工人目录;绝对路径仍交给下面的既有白名单校验。
    # 这是护栏不是沙箱(同 OS 用户仍可用绝对路径绕过),见 core/worker_exec_context.py。
    from app.core.worker_exec_context import effective_worker_cwd

    _worker_cwd = effective_worker_cwd(cwd if isinstance(cwd, str) else None)
    if _worker_cwd is not None:
        cwd = _worker_cwd

    # cwd 校验(非默认 . 时需在工作区白名单内,防任意目录读写)
    if cwd and cwd != ".":
        ok_cwd, cwd_info = _validate_path_in_workspace(cwd)
        if not ok_cwd:
            return {
                "tool": "run_command", "command": command,
                "exit_code": -1, "stdout": "", "stderr": "",
                "ok": False, "streamed": True,
                "errorCode": "PATH_NOT_ALLOWED",
                "message": f"cwd 不在工作区白名单: {cwd_info}",
            }
        cwd = cwd_info

    # 非 local 后端:委托 sandbox_executor(Docker/SSH/预留后端)
    if sandbox_backend != "local":
        from app.core.worker_exec_context import worker_env_overrides

        from .sandbox import sandbox_executor

        result = await sandbox_executor.execute(
            command, backend=sandbox_backend, timeout=timeout, workdir=cwd,
            docker_image=docker_image, ssh_host=ssh_host, ssh_user=ssh_user,
            env=worker_env_overrides() or None,
            # 2026-11-23 立(B1-05):同一会话的附加目录必须与 local 路径判据一致 ——
            # 否则 add_directories 在本路径(非 local 后端)不生效,形成"local 放行、docker 拒绝"。
            extra_writable_roots=list(_active_extra_roots()) or None,
        )
        # 与本地路径一致:沙箱后端输出同样出库脱敏(docker/ssh/modal 等)
        from app.core.output_cleaning import redact_secrets as _redact_secrets

        return {
            "tool": "run_command", "command": command,
            "backend": sandbox_backend,
            "exit_code": result.exit_code, "stdout": _vault.redact(_redact_secrets(result.stdout)),
            "stderr": _vault.redact(_redact_secrets(result.stderr)), "duration_ms": result.duration_ms,
            "timed_out": result.timed_out, "ok": result.exit_code == 0,
            "streamed": False,
            "message": f"backend={sandbox_backend} exit_code={result.exit_code}",
        }

    # 危险字符/操作黑名单(Shell 注入 + 破坏性操作)—— 单一权威源 command_policy.json
    _policy = _load_command_policy()
    if _is_dangerous_command_blocked():
        _DANGEROUS_PATTERNS: list[str] = list(_policy.get("dangerous_patterns") or [])
        for pat in _DANGEROUS_PATTERNS:
            if re.search(pat, command):
                return {
                    "tool": "run_command", "command": command,
                    "exit_code": -1, "stdout": "", "stderr": "",
                    "ok": False, "streamed": True,
                    "errorCode": "DANGEROUS_COMMAND",
                    "message": f"命令包含禁止的模式: {pat}(安全限制)",
                }

    # 命令前缀白名单 —— 单一权威源 command_policy.json
    _ALLOWED_PREFIXES: set[str] = set(_policy.get("allowed_prefixes") or [])
    first_token = command.split()[0] if command.split() else ""
    cmd_name = first_token.rsplit("/", 1)[-1].rsplit("\\", 1)[-1].lower()
    # Windows 可执行文件常带 .exe 后缀(sys.executable 就是 python.exe),而白名单
    # 按无后缀名登记;判定前归一,避免把合法解释器/工具整类误挡。
    cmd_lookup = cmd_name[:-4] if cmd_name.endswith(".exe") else cmd_name
    if cmd_lookup not in _ALLOWED_PREFIXES:
        return {
            "tool": "run_command", "command": command,
            "exit_code": -1, "stdout": "", "stderr": "",
            "ok": False, "streamed": True,
            "message": f"命令 '{cmd_name}' 不在白名单中(允许: {', '.join(sorted(_ALLOWED_PREFIXES))})",
        }

    _killer: asyncio.Task[None] | None = None
    proc: asyncio.subprocess.Process | None = None
    try:
        args = shlex.split(command, posix=sys.platform != "win32")
        # AIS-081(机制修订):只在真正经 shell 解释的形态下判元字符;argv 直传的
        # `&`/`^` 是字面参数(引号内的字面量同样跳过),不再无差别误挡。
        _shell_form = _shell_interpretation_of(command, cmd_name)
        if _shell_form is not None:
            _metachar = _first_shell_metacharacter(command)
            if _metachar is not None:
                return {
                    "tool": "run_command", "command": command,
                    "exit_code": -1, "stdout": "", "stderr": "",
                    "ok": False, "streamed": True,
                    "errorCode": "SHELL_METACHARACTER_BLOCKED",
                    "matched": _metachar,
                    "shell_form": _shell_form,
                    "message": (
                        f"命令经 {_shell_form} 解释,包含禁止的 shell 元字符 {_metachar!r}"
                        "(拼接会改变语义,安全限制)"
                    ),
                }
        # 差距⑦(2026-10-30):原先 user_env 缺省时传 env=None 让子进程**裸继承**
        # os.environ —— vault 过滤与凭据/注入型变量剥离全部旁路,"不带 env 参数"
        # 反而成了消毒豁免面。改为恒走消毒出口(None 与 {} 同形,行为差异只有
        # 被剥的那两类键)。
        env_for_proc = _build_subprocess_env(user_env)

        # D151(2026-09-29,用户批"默认开 + 单次等待 300s"):交互代答只在"宿主给了 push
        # 通道"时才开 —— 没有承载面的等待等于凭空挂住一条命令。
        # 已知边界(不是待办,是启发式的代价):开 PIPE 会改变"读 stdin 的命令"的结束方式
        # (原本立刻拿到 EOF)。所以观察器在**第一个静默窗口判定"不像在等人"时立即 write_eof()**,
        # 把旧语义还给它;此后若该命令又冒出提示,已关闭的写端无法再喂字,观察器不再等待。
        _term_ctx = dict(_terminal_stream_ctx.get() or {})
        _terminal_id = str(_term_ctx.get("tool_call_id") or "")
        _interaction_on = bool(
            terminal_interaction_enabled() and _terminal_id and _term_ctx.get("push")
        )

        if sys.platform == "win32" and cmd_name in WIN_SHELL_BUILTINS:
            proc = await asyncio.create_subprocess_exec(
                "cmd", "/c", command,
                cwd=cwd, env=env_for_proc,
                stdin=asyncio.subprocess.PIPE if _interaction_on else None,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                # 第三十三批:_drain_stream 按行读,不声明 limit 就是默认 65536,
                # 一条超长单行(压缩后的 JSON/base64 很常见)会抛 LimitOverrunError。
                limit=PROTOCOL_FRAME_LIMIT_BYTES,
            )
        else:
            proc = await asyncio.create_subprocess_exec(
                *args,
                cwd=cwd, env=env_for_proc,
                stdin=asyncio.subprocess.PIPE if _interaction_on else None,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                limit=PROTOCOL_FRAME_LIMIT_BYTES,  # 同上,见 _drain_stream 注释
            )

        cancel_event = cancel if cancel is not None else _TOOL_CANCEL_EVENT.get()
        if cancel_event is not None:

            async def _kill_on_cancel() -> None:
                await cancel_event.wait()
                await _terminate_process_tree(proc)

            _killer = asyncio.create_task(_kill_on_cancel())

        # 流式逐行读取 stdout/stderr(并发 drain,防长输出阻塞)
        # P0-B(2026-09-18):逐行经 terminal.delta 实时透出(4 行/帧节流,
        # fire-and-forget 不阻塞读取;上下文经 contextvar 由 agent_loop 注入)
        stdout_lines: list[str] = []
        stderr_lines: list[str] = []
        # D151 观察器读这三样:最后一行非空输出(判提示)、最近一次输出时刻(判静默)、
        # 以及本条命令的交互账本。刻意不复制 stdout 内容本身 —— 键入与输出都不落日志。
        _activity: dict[str, Any] = {"ts": time.monotonic(), "last_line": "", "last_prompt": None}
        _inter_state: dict[str, Any] = {
            "interactionCount": 0,
            "inputWaitTimedOut": False,
            "waiting": False,
            "eofSent": False,
        }

        def _note_line(stream_name: str, line_text: str) -> None:
            _activity["ts"] = time.monotonic()
            if line_text and line_text.strip():
                _activity["last_line"] = line_text
            _spawn_terminal_delta(command, stream_name, line_text)

        on_stdout_line = functools.partial(_note_line, "stdout")
        on_stderr_line = functools.partial(_note_line, "stderr")
        drain = asyncio.gather(
            _drain_stream(proc.stdout, stdout_lines, on_line=on_stdout_line),
            _drain_stream(proc.stderr, stderr_lines, on_line=on_stderr_line),
        )
        _watcher: asyncio.Future[None] | None = None
        if _interaction_on and getattr(proc, "stdin", None) is not None:
            _watcher = asyncio.ensure_future(
                _watch_terminal_input(proc, _activity, _inter_state, _terminal_id, _term_ctx, command)
            )
        timed_out = False
        try:
            try:
                timed_out = await _drain_with_input_grace(drain, float(timeout), _inter_state)
                if not timed_out:
                    await proc.wait()
            except TimeoutError:
                timed_out = True
            if timed_out:
                # 超时既可能是 wait_for 抛错,也可能是 _drain_with_input_grace 返回 True;
                # 两条都必须回收进程树,否则 cmd.exe 的子进程会继续跑(AIS-056)。
                await _terminate_process_tree(proc)
                # 取消 drain task 并等其退出(readline 会被 CancelledError 中断)
                drain.cancel()
                with contextlib.suppress(asyncio.CancelledError, Exception):
                    await drain
                try:
                    await proc.wait()
                except Exception as e:
                    logger.warning("mcp_server proc.wait 失败: %s", e, exc_info=True)
        finally:
            if _killer is not None:
                _killer.cancel()
                with contextlib.suppress(asyncio.CancelledError, Exception):
                    await _killer
            if _watcher is not None:
                _watcher.cancel()
                with contextlib.suppress(asyncio.CancelledError, Exception):
                    await _watcher

        stdout = "\n".join(stdout_lines)
        stderr = "\n".join(stderr_lines)
        max_output = 10000
        if len(stdout) > max_output:
            stdout = stdout[:max_output] + f"\n...(已截断,共 {len(stdout)} 字符)"
        if len(stderr) > max_output:
            stderr = stderr[:max_output] + f"\n...(已截断,共 {len(stderr)} 字符)"
        # 出库脱敏(2026-09-18 第十五批,遵循统一工程规范):
        # 命令输出是密钥外泄的主要通道(cat .env / env / printenv / 日志抓取),
        # 截断之后、回传之前统一盖掉已知凭据形态。
        from app.core.output_cleaning import redact_secrets as _redact_secrets

        stdout = _vault.redact(_redact_secrets(stdout))
        stderr = _vault.redact(_redact_secrets(stderr))

        _interaction_count = int(_inter_state.get("interactionCount") or 0)
        if timed_out:
            # 两种"到点"要分得开(验收②:有交互必须有计数,不得静默):
            # 命令本身跑过头 vs 它在等人、人没敲。后者回灌给模型的是"没人代答"这个事实,
            # 它才能自己决定换命令/放弃,而不是读到一条普通的超时失败。
            if _inter_state.get("inputWaitTimedOut"):
                return {
                    "tool": "run_command", "command": command,
                    "exit_code": -1,
                    "stdout": stdout, "stderr": stderr,
                    "partial_output": stdout,
                    "ok": False, "streamed": True,
                    "errorCode": "NEEDS_INPUT_TIMEOUT",
                    "interactionCount": _interaction_count,
                    "inputWaitTimeoutMs": TERMINAL_INTERACTION_WAIT_TIMEOUT_S * 1000,
                    "message": (
                        f"命令在等待键盘输入,等待 {TERMINAL_INTERACTION_WAIT_TIMEOUT_S} 秒内无人代答"
                        f"(此前已完成 {_interaction_count} 次代答),进程已终止"
                    ),
                }
            return {
                "tool": "run_command", "command": command,
                "exit_code": -1,
                "stdout": stdout, "stderr": stderr,
                "partial_output": stdout,
                "ok": False, "streamed": True,
                "errorCode": "TIMEOUT",
                "interactionCount": _interaction_count,
                "message": f"命令执行超时({timeout} 秒,已 kill 进程)",
            }

        exit_code = proc.returncode if proc.returncode is not None else -1
        _outcome: dict[str, Any] = {
            "tool": "run_command", "command": command,
            "exit_code": exit_code, "stdout": stdout, "stderr": stderr,
            "ok": exit_code == 0, "streamed": True,
            "interactionCount": _interaction_count,
            "message": f"命令退出码: {exit_code}",
        }
        return _outcome
    except FileNotFoundError:
        return {
            "tool": "run_command", "command": command,
            "exit_code": -1, "stdout": "", "stderr": f"命令未找到: {first_token}",
            "ok": False, "streamed": True,
            "message": f"命令未找到: {first_token}",
        }
    except asyncio.CancelledError:
        # P0-B(2026-09-18):外部取消(agent 循环内 abort)时 kill 进程防泄漏,
        # 再原样传播 CancelledError(交由上层中断链路处理)
        if _killer is not None:
            _killer.cancel()
        if proc is not None:
            # 已处于取消态:等待会被再次打断,交给独立 task 发 taskkill 进程树。
            # 2026-11-19 收口(门 247 W1):裸 create_task 无强引用,事件循环只握弱引用,
            # 任务可能在 GC 时被回收 ⇒ 进程树永远杀不掉。改走唯一出口 spawn()(持引用到完成)。
            spawn(_terminate_process_tree(proc))
        raise
    except Exception as e:
        return {
            "tool": "run_command", "command": command,
            "exit_code": -1, "stdout": "", "stderr": str(e),
            "ok": False, "streamed": True,
            "message": f"命令执行失败: {e}", "error": str(e),
        }


async def _tool_web_search(arguments: dict[str, Any]) -> dict[str, Any]:
    """web_search: 网页搜索(复用 DuckDuckGo Lite HTML 搜索)。

    与 search_web 功能等价,但接口更简洁(默认 5 条结果)。
    支持 `query` 单查询或 `queries` 多查询合并(与 search_web 同源)。
    无网络或解析失败时返回空结果 + 错误信息。
    """
    query = arguments.get("query", "")
    queries_raw = arguments.get("queries")
    max_results = int(arguments.get("max_results", 5))

    if not query and not isinstance(queries_raw, list):
        return {
            "tool": "web_search",
            "ok": False,
            "query": query,
            "results": [],
            "errorCode": "MISSING_PARAMS",
            "message": "搜索关键词为空",
        }

    # 复用 search_web 的实现(多查询扇出与合并口径同源)
    sub_args: dict[str, Any] = {"max_results": max_results}
    if isinstance(queries_raw, list):
        sub_args["queries"] = queries_raw
    else:
        sub_args["query"] = query
    sub_result = await _tool_search_web(sub_args)

    # 转换字段名(tool → web_search,保留 results);AIS-054:失败态必须透传,
    # 不能把检索故障包装成"成功但无结果"。
    ok = bool(sub_result.get("ok", True))
    payload: dict[str, Any] = {
        "tool": "web_search",
        "ok": ok,
        "query": sub_result.get("query", query),
        "queries": sub_result.get("queries", []),
        "max_results": max_results,
        "results": sub_result.get("results", []),
        "total": sub_result.get("total", 0),
        "truncated": bool(sub_result.get("truncated", False)),
        "message": sub_result.get("message", ""),
    }
    if not ok:
        payload["error"] = sub_result.get("error") or sub_result.get("message") or "搜索失败"
        payload["errorCode"] = sub_result.get("errorCode") or "SEARCH_FAILED"
    return payload


async def _tool_image_search(arguments: dict[str, Any]) -> dict[str, Any]:
    """image_search: 图片检索(DuckDuckGo Images,无 API key,出网腿与 web_search 同源)。"""
    from .image_search import search_images

    return await search_images(
        str(arguments.get("query", "")),
        int(arguments.get("max_results", 8)),
    )


WEB_SEARCH_MAX_QUERIES: Final = 10
_WEB_SEARCH_MAX_RESULTS_CAP: Final = 50


def _normalize_web_queries(arguments: dict[str, Any]) -> tuple[list[str], dict[str, Any] | None]:
    """归一 `query`/`queries` 两种入参(2026-11-14,遵循统一工程规范)。

    规则与 外部实现 `parseSearchArgs` 对齐:queries 非空、每项非空白、至多 10 个;
    数量上限检查在去重之前做,去重保首次出现顺序。`query` 作为单查询兼容入口,
    与 queries 同时出现时前插并以首个去重结果为准。
    """
    raw_queries = arguments.get("queries")
    collected: list[str] = []
    if raw_queries is not None:
        if not isinstance(raw_queries, list):
            return [], {
                "ok": False,
                "errorCode": "search_invalid_queries",
                "error": "queries 必须是字符串数组",
            }
        if not raw_queries:
            return [], {
                "ok": False,
                "errorCode": "search_invalid_queries",
                "error": "queries 至少包含 1 个关键词",
            }
        if len(raw_queries) > WEB_SEARCH_MAX_QUERIES:
            return [], {
                "ok": False,
                "errorCode": "search_invalid_queries",
                "error": f"queries 最多 {WEB_SEARCH_MAX_QUERIES} 个关键词",
            }
        for item in raw_queries:
            if not isinstance(item, str) or not item.strip():
                return [], {
                    "ok": False,
                    "errorCode": "search_invalid_queries",
                    "error": "每个查询都必须是非空字符串",
                }
            collected.append(item.strip())

    single = arguments.get("query")
    if isinstance(single, str) and single.strip():
        collected.insert(0, single.strip())

    # 去重保序(与 外部实现 `[...new Set(queries)]` 同义)
    return list(dict.fromkeys(collected)), None


async def _search_ddg_lite_once(
    client: Any, query: str, max_results: int
) -> list[dict[str, str]]:
    """一次 DuckDuckGo Lite 检索(只出网 + 解析,不做结果合并)。"""
    url = f"https://lite.duckduckgo.com/lite/?q={quote_plus(query)}&kl=wt-wt"
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/120.0.0.0 Safari/537.36"
        ),
    }
    resp = await client.get(url, headers=headers)
    resp.raise_for_status()
    return _parse_ddg_lite_html(resp.text, max_results)


async def _search_queries_fanout(
    queries: list[str], max_results: int
) -> list[list[dict[str, str]]]:
    """并发执行多个查询;任一失败即取消同批其余查询,等全部收口后抛出首个失败。

    与 外部实现 `runSearchQueries` 的失败语义一致:多查询是一个原子调用,**不**把
    部分成功伪装成整体成功(否则模型会以为已覆盖全部查询)。
    """
    import httpx

    tasks: list[asyncio.Task[list[dict[str, str]]]] = []
    async with httpx.AsyncClient(timeout=10.0, follow_redirects=True) as client:
        try:
            tasks = [
                asyncio.create_task(_search_ddg_lite_once(client, query, max_results))
                for query in queries
            ]
            done, pending = await asyncio.wait(
                tasks, return_when=asyncio.FIRST_EXCEPTION
            )
            failure = next(
                (task.exception() for task in done if task.exception() is not None),
                None,
            )
            if failure is not None:
                for task in pending:
                    task.cancel()
                await asyncio.gather(*pending, return_exceptions=True)
                raise failure
            return [task.result() for task in tasks]
        finally:
            for task in tasks:
                if not task.done():
                    task.cancel()


def _merge_search_pages(
    pages: list[list[dict[str, str]]], max_results: int
) -> tuple[list[dict[str, str]], bool]:
    """多查询结果合并:按名次轮转、按 URL 去重、总量截断到 max_results。

    轮转合并(而非页拼接)让每个查询的第 1 名都有机会进入结果,避免首个查询
    独占配额;返回 (results, truncated)。
    """
    seen: set[str] = set()
    merged: list[dict[str, str]] = []
    truncated = False
    ranks = max((len(page) for page in pages), default=0)
    stop = False
    for rank in range(ranks):
        for page in pages:
            if rank >= len(page):
                continue
            item = page[rank]
            url = str(item.get("url") or "")
            if url and url in seen:
                continue
            if len(merged) >= max_results:
                truncated = True
                stop = True
                break
            if url:
                seen.add(url)
            merged.append(item)
        if stop:
            break
    return merged, truncated


async def _tool_search_web(arguments: dict[str, Any]) -> dict[str, Any]:
    """search_web: DuckDuckGo HTML 搜索,返回解析后的结果列表。

    单查询 `query` 与多查询 `queries` 两种入参(2026-11-14,遵循统一工程规范):
    多查询并发扇出后按名次轮转、URL 去重合并,截断到 max_results 并置 truncated。
    无网络或解析失败时返回结构化失败 + 错误信息。
    """
    raw_single = arguments.get("query", "")
    queries, query_error = _normalize_web_queries(arguments)
    try:
        max_results = int(arguments.get("max_results", 5))
    except (TypeError, ValueError):
        max_results = 5
    max_results = max(1, min(max_results, _WEB_SEARCH_MAX_RESULTS_CAP))

    if query_error is not None:
        return {
            "tool": "search_web",
            "ok": False,
            "query": raw_single,
            "queries": [],
            "max_results": max_results,
            "results": [],
            "total": 0,
            **query_error,
            "message": str(query_error.get("error") or "查询参数非法"),
        }

    if not queries:
        return {
            "tool": "search_web",
            "ok": True,
            "query": raw_single,
            "queries": [],
            "max_results": max_results,
            "results": [],
            "message": "搜索关键词为空",
        }

    try:
        # 动态导入 httpx(未安装时降级)
        try:
            import httpx
        except ImportError:
            return {
                "tool": "search_web",
                "ok": True,
                "query": queries[0],
                "queries": queries,
                "max_results": max_results,
                "results": [],
                "message": "[stub] httpx 未安装,无法执行真实搜索",
            }

        if len(queries) == 1:
            async with httpx.AsyncClient(
                timeout=10.0, follow_redirects=True
            ) as client:
                results = await _search_ddg_lite_once(
                    client, queries[0], max_results
                )
            truncated = False
        else:
            pages = await _search_queries_fanout(queries, max_results)
            results, truncated = _merge_search_pages(pages, max_results)

        if len(queries) == 1:
            message = f"找到 {len(results)} 条结果" if results else "未找到结果"
        else:
            message = (
                f"从 {len(queries)} 个查询合并到 {len(results)} 条结果"
                if results
                else f"{len(queries)} 个查询均未找到结果"
            )
        return {
            "tool": "search_web",
            "ok": True,
            "query": queries[0],
            "queries": queries,
            "max_results": max_results,
            "results": results,
            "total": len(results),
            "truncated": truncated,
            "message": message,
        }

    except Exception as e:
        return {
            "tool": "search_web",
            "ok": False,
            "query": queries[0],
            "queries": queries,
            "max_results": max_results,
            "results": [],
            "total": 0,
            "truncated": False,
            "message": f"搜索失败: {e}",
            "error": str(e),
        }


def _parse_ddg_lite_html(html: str, max_results: int) -> list[dict[str, str]]:
    """解析 DuckDuckGo Lite HTML 结果页。

    DuckDuckGo Lite 的结果在 <a class="result-link" href="..."> 标题 </a> 中,
    摘要在 <td class="result-snippet"> 中。
    """
    results: list[dict[str, str]] = []

    # 匹配结果链接(多种可能的选择器,容错)
    # DuckDuckGo Lite: <a rel="nofollow" class="result-link" href="URL">TITLE</a>
    link_pattern = re.compile(
        r'<a[^>]*class="result-link"[^>]*href="([^"]+)"[^>]*>(.*?)</a>',
        re.IGNORECASE | re.DOTALL,
    )
    # 摘要: <td class="result-snippet">...</td>
    snippet_pattern = re.compile(
        r'<td[^>]*class="result-snippet"[^>]*>(.*?)</td>',
        re.IGNORECASE | re.DOTALL,
    )

    links = link_pattern.findall(html)
    snippets = snippet_pattern.findall(html)

    for i, (url, title_html) in enumerate(links[:max_results]):
        # 清理 HTML 标签
        title = re.sub(r"<[^>]+>", "", title_html).strip()
        snippet = ""
        if i < len(snippets):
            snippet = re.sub(r"<[^>]+>", "", snippets[i]).strip()

        # DuckDuckGo 可能用 redirect URL,提取真实 URL
        # 格式: //duckduckgo.com/l/?uddg=ENCODED_URL&rut=...
        if "uddg=" in url:
            parsed = urlparse(url)
            qs = parse_qs(parsed.query)
            if "uddg" in qs:
                url = qs["uddg"][0]
        elif url.startswith("//"):
            url = "https:" + url

        if title and url:
            results.append(
                {
                    "title": title,
                    "url": url,
                    "snippet": snippet[:300] if snippet else "",
                }
            )

    return results


# ---------------------------------------------------------------------------
# V3 #50 桩工具转正:静态分析 / 测试生成的私有辅助实现。
#
# 背景:原 _tool_analyze_code 只数行数、_tool_generate_test 拼 f-string 输出
# ``def test_placeholder(): pass`` 且返回 ok:True —— 模型把占位模板当真产物,
# 属 silently wrong。V3 #50 要求:非真实产物必须 ok:False 或 stub:true,不许
# 假装成功。转正后:analyze_code 用标准库 ast 做真实静态分析;generate_test
# 走 llm_gateway 真实生成测试代码并真执行(pytest 子进程),LLM 不可用/执行
# 环境缺失时如实返回 ok:False 或标注 executed:False,不再产出占位模板。
#
# 实现借鉴 self_healing_llm.PytestSubprocessRunner 的「生成→落盘→子进程跑→
# 解析结果」骨架(只读参考,未改动该模块),此处不直接 import 它:该模块级联
# 依赖 db_pool/self_healing,handler 需要保持独立轻量。
# ---------------------------------------------------------------------------

# 圈复杂度 top-N 报告条数与单函数超长阈值(超过行数即计入 long_functions)
_ANALYZE_COMPLEXITY_TOP_N = 5
_ANALYZE_LONG_FUNCTION_LINES = 80


def _strip_code_fences(text: str) -> str:
    """去掉 LLM 输出中的 ```/```lang markdown 围栏,返回纯代码。

    独立小实现(self_healing_llm._strip_fences 同思路),避免跨模块依赖。
    """
    text = (text or "").strip()
    if not text.startswith("```"):
        return text
    lines = text.splitlines()
    if lines and lines[0].startswith("```"):
        lines = lines[1:]
    if lines and lines[-1].strip().startswith("```"):
        lines = lines[:-1]
    return "\n".join(lines).strip()


def _analyze_python_ast(code: str) -> dict[str, Any]:
    """Python 源码的真实 AST 静态分析(纯标准库,零第三方依赖)。

    检查项(6 项,均为可落地判定,非行数统计冒充):
    1. unused_imports      未使用的 import(绑定名与代码标识符引用比对;
                           尽力而为:不做 __all__/字符串重导出语义分析)
    2. bare_except         裸 ``except:``(吞掉 KeyboardInterrupt/SystemExit)
    3. complexity_top      函数圈复杂度 top-N(1 + 分支/循环/boolop/except 计数)
    4. long_functions      超长函数(> _ANALYZE_LONG_FUNCTION_LINES 行)
    5. mutable_defaults    可变默认参数(list/dict/set 字面量/推导式作默认值)
    6. todo_fixme          TODO/FIXME 注释计数
    """
    import ast as _ast

    findings: dict[str, Any] = {}
    tree = _ast.parse(code)

    # --- 1. 未使用 import:先收集绑定名,再收集全部标识符引用 ---
    imported: dict[str, int] = {}  # 绑定名 -> 首次出现行号
    for node in _ast.walk(tree):
        if isinstance(node, _ast.Import):
            # import a.b.c 的绑定名是 a(asname 优先)
            for alias in node.names:
                name = alias.asname or alias.name.split(".")[0]
                imported.setdefault(name, node.lineno)
        elif isinstance(node, _ast.ImportFrom):
            for alias in node.names:
                if alias.name == "*":
                    continue  # star import 无法静态判定使用情况
                imported.setdefault(alias.asname or alias.name, node.lineno)
    used_names = {
        node.id for node in _ast.walk(tree) if isinstance(node, _ast.Name)
    }
    findings["unused_imports"] = [
        {"name": name, "line": line}
        for name, line in sorted(imported.items(), key=lambda kv: kv[1])
        if name not in used_names
    ]

    # --- 2. 裸 except ---
    bare_excepts = [
        {"line": node.lineno}
        for node in _ast.walk(tree)
        if isinstance(node, _ast.ExceptHandler) and node.type is None
    ]
    findings["bare_excepts"] = bare_excepts

    # --- 3/4. 圈复杂度 + 超长函数(每个函数独立统计) ---
    complexities: list[dict[str, Any]] = []
    long_functions: list[dict[str, Any]] = []
    for node in _ast.walk(tree):
        if not isinstance(node, (_ast.FunctionDef, _ast.AsyncFunctionDef)):
            continue
        complexity = 1
        for child in _ast.walk(node):
            if isinstance(
                child,
                (_ast.If, _ast.For, _ast.AsyncFor, _ast.While, _ast.ExceptHandler),
            ):
                complexity += 1
            elif isinstance(child, _ast.BoolOp):
                # and/or 链:每个额外操作数一个分支
                complexity += len(child.values) - 1
            elif isinstance(child, _ast.IfExp):
                complexity += 1
            elif isinstance(child, _ast.comprehension):
                complexity += 1 + len(child.ifs)
        complexities.append(
            {
                "name": node.name,
                "line": node.lineno,
                "complexity": complexity,
            }
        )
        end = getattr(node, "end_lineno", None) or node.lineno
        if end - node.lineno + 1 > _ANALYZE_LONG_FUNCTION_LINES:
            long_functions.append(
                {
                    "name": node.name,
                    "line": node.lineno,
                    "lines": end - node.lineno + 1,
                }
            )
    findings["complexity_top"] = sorted(
        complexities, key=lambda item: -item["complexity"]
    )[:_ANALYZE_COMPLEXITY_TOP_N]
    findings["long_functions"] = long_functions

    # --- 5. 可变默认参数(经典陷阱:默认值跨调用共享) ---
    _MUTABLE_LITERALS = (_ast.List, _ast.Dict, _ast.Set)
    _MUTABLE_COMPS = (_ast.ListComp, _ast.DictComp, _ast.SetComp)
    mutable_defaults = []
    for node in _ast.walk(tree):
        if not isinstance(node, (_ast.FunctionDef, _ast.AsyncFunctionDef)):
            continue
        defaults = list(node.args.defaults) + [
            d for d in node.args.kw_defaults if d is not None
        ]
        for default in defaults:
            bad = isinstance(default, _MUTABLE_LITERALS + _MUTABLE_COMPS) or (
                isinstance(default, _ast.Call)
                and isinstance(default.func, _ast.Name)
                and default.func.id in ("list", "dict", "set")
            )
            if bad:
                mutable_defaults.append({"name": node.name, "line": node.lineno})
                break  # 每函数只报一次
    findings["mutable_defaults"] = mutable_defaults

    # --- 6. TODO/FIXME 注释计数(行级正则,含行号) ---
    todo_pattern = re.compile(r"#\s*(TODO|FIXME)\b", re.IGNORECASE)
    todos = [
        {"line": i + 1, "tag": m.group(1).upper()}
        for i, line in enumerate(code.splitlines())
        if (m := todo_pattern.search(line))
    ]
    findings["todo_fixme"] = {"count": len(todos), "items": todos[:20]}

    return findings


def _run_pytest_on_generated_test(
    source_code: str, test_code: str, timeout: float = 60.0
) -> dict[str, Any]:
    """把被测源码与生成的测试落盘临时目录,起 pytest 子进程真执行并解析结果。

    骨架借鉴 self_healing_llm.PytestSubprocessRunner(junit-xml 精确计数 +
    stdout 兜底解析),但保持独立实现:任何异常都不外逃,以结构化结果返回。

    Returns:
        {
          "available": bool,   # pytest 执行条件是否满足
          "executed": bool,    # 是否真的跑完了 pytest
          "passed": int, "failed": int, "errors": int,
          "failures": [...],   # 失败明细(最多 10 条)
          "output_summary": str,
          "reason": str,       # available=False 时的原因
        }
    """
    import shutil as _shutil
    import subprocess as _subprocess
    import sys as _sys
    import tempfile as _tempfile
    import uuid as _uuid
    import xml.etree.ElementTree as _ET

    result: dict[str, Any] = {
        "available": True, "executed": False,
        "passed": 0, "failed": 0, "errors": 0,
        "failures": [], "output_summary": "", "reason": "",
    }
    tmpdir = ""
    try:
        # 环境判定:pytest 可执行性交给真实子进程验证(比 in-process import
        # 更准:handler 进程与子进程解释器一致,但依赖装没装只有跑了才知道)
        tmpdir = _tempfile.mkdtemp(prefix="gen_test_")
        src_path = os.path.join(tmpdir, "source.py")
        test_path = os.path.join(
            tmpdir, f"test_generated_{_uuid.uuid4().hex[:8]}.py"
        )
        with open(src_path, "w", encoding="utf-8") as f:
            f.write(source_code)
        with open(test_path, "w", encoding="utf-8") as f:
            f.write(test_code)

        junit_path = os.path.join(tmpdir, "report.xml")
        cmd = [
            _sys.executable, "-I", "-m", "pytest", test_path,
            "--junit-xml", junit_path, "-p", "no:cacheprovider", "-q",
        ]
        # 2026-10-31 安全强化第 10 批:子进程环境白名单化 —— 此前未传 env ⇒ 完整继承
        # 服务进程 os.environ(各 provider API key/JWT_SECRET/AI_CALLBACK_SECRET)。
        # 判据取 core/exec_env 六步构造器单源:CORE 白名单起步(平台核心变量)+
        # KEY/SECRET/TOKEN 形名默认排除,不造第二套。
        from app.core.exec_env import (
            ShellEnvironmentPolicy,
            ShellEnvironmentPolicyInherit,
            populate_env,
        )

        child_env = populate_env(
            list(os.environ.items()),
            ShellEnvironmentPolicy(
                inherit=ShellEnvironmentPolicyInherit.CORE,
                ignore_default_excludes=False,
            ),
        )
        proc = _subprocess.run(
            cmd, capture_output=True, text=True, timeout=timeout, cwd=tmpdir,
            env=child_env,
        )
        stdout = proc.stdout or ""
        result["output_summary"] = "\n".join(
            line for line in stdout.splitlines() if line.strip()
        )[-1500:]

        # pytest 未安装:stdout 出现 No module named pytest(exit code 1)
        if "No module named pytest" in stdout or "No module named pytest" in (
            proc.stderr or ""
        ):
            result["available"] = False
            result["reason"] = "当前 Python 环境未安装 pytest,无法真实执行"
            return result
        result["executed"] = True

        # 优先 junit-xml 精确计数;缺失/解析失败回退 stdout 行解析
        if os.path.exists(junit_path):
            try:
                root = _ET.parse(junit_path).getroot()
                suites = (
                    root.iter("testsuite") if root.tag == "testsuites" else [root]
                )
                for suite in suites:
                    result["passed"] += int(suite.get("tests", 0)) - int(
                        suite.get("failures", 0)
                    ) - int(suite.get("errors", 0)) - int(
                        suite.get("skipped", 0)
                    )
                    result["failed"] += int(suite.get("failures", 0))
                    result["errors"] += int(suite.get("errors", 0))
                    for tc in suite.iter("testcase"):
                        fail = tc.find("failure")
                        if fail is None:
                            fail = tc.find("error")
                        if fail is not None:
                            result["failures"].append({
                                "test_id": (
                                    (tc.get("classname") or "") + "::"
                                    + (tc.get("name") or "")
                                ).strip(":"),
                                "message": (
                                    fail.get("message") or fail.text or "failed"
                                ).strip()[:300],
                            })
            except _ET.ParseError:
                pass  # junit 损坏,走 stdout 兜底
        result["failures"] = result["failures"][:10]
        if not result["passed"] and not result["failed"] and not result["errors"]:
            # stdout 兜底:匹配 pytest 汇总行(如 "3 passed, 1 failed")
            m = re.search(
                r"(\d+)\s+passed(?:,\s*(\d+)\s+failed)?(?:,\s*(\d+)\s+error)?",
                stdout,
            )
            if m:
                result["passed"] = int(m.group(1))
                result["failed"] = int(m.group(2) or 0)
                result["errors"] = int(m.group(3) or 0)
        return result
    except _subprocess.TimeoutExpired:
        result["reason"] = f"pytest 执行超时({timeout}s)"
        return result
    except Exception as exc:  # noqa: BLE001 - 执行环境缺失/异常如实降级
        result["available"] = False
        result["reason"] = f"pytest 子进程执行失败: {exc}"
        return result
    finally:
        if tmpdir:
            _shutil.rmtree(tmpdir, ignore_errors=True)


async def _tool_analyze_code(arguments: dict[str, Any]) -> dict[str, Any]:
    """analyze_code: 代码静态分析(V3 #50 转正)。

    Python:ast 真实静态分析(未使用 import/裸 except/圈复杂度 top-N/超长
    函数/可变默认参数/TODO-FIXME),返回结构化 findings。
    其他语言(JS/TS 等):诚实降级为行级统计,analysis_depth 如实标注为
    "line-stats",不让行数统计冒充深度分析。
    """
    code = arguments.get("code", "")
    language = str(arguments.get("language", "text") or "text").lower()
    if not code.strip():
        return {
            "tool": "analyze_code", "ok": False,
            "error": "code 不能为空", "language": language,
        }

    lines = code.splitlines()
    metrics = {
        "lines": len(lines),
        "chars": len(code),
        "blank_lines": sum(1 for l in lines if not l.strip()),
        "comment_lines": sum(
            1
            for l in lines
            if l.strip().startswith(("#", "//", "--", "/*", "*"))
        ),
    }

    lang = "python" if language in ("python", "py", "python3") else language
    if lang == "python":
        # 真实 AST 分析;语法错误本身就是分析结论(如实报告,不算工具失败)

        try:
            findings = _analyze_python_ast(code)
        except SyntaxError as e:
            return {
                "tool": "analyze_code", "ok": True,
                "language": language, "analysis_depth": "ast",
                "metrics": metrics, "findings": {},
                "syntax_error": {
                    "line": e.lineno, "offset": e.offset,
                    "message": e.msg or str(e),
                },
                "message": "Python 语法错误,无法继续静态分析(已如实报告)",
            }
        return {
            "tool": "analyze_code", "ok": True,
            "language": language, "analysis_depth": "ast",
            "metrics": metrics, "findings": findings,
            "message": "AST 静态分析完成(未使用 import/裸 except/圈复杂度/"
                       "超长函数/可变默认参数/TODO-FIXME)",
        }

    # 非 Python:诚实降级 —— 行级统计 + 明确说明能力边界
    return {
        "tool": "analyze_code", "ok": True,
        "language": language, "analysis_depth": "line-stats",
        "metrics": metrics,
        "findings": {},
        "note": (
            f"{language} 暂无 AST 深度分析实现,已降级为行级统计"
            "(行数/空行/注释行);Python 代码可获 ast 深度分析"
        ),
        "message": f"行级统计完成(language={language},降级模式,非深度分析)",
    }


async def _tool_generate_test(arguments: dict[str, Any]) -> dict[str, Any]:
    """generate_test: LLM 生成测试并真实执行验证(V3 #50 转正)。

    流程:从 arguments 取 code/language/framework → 构造明确 prompt(可执行、
    含失败路径断言、遵循框架习惯)经 llm_gateway 真实生成 → Python 走 pytest
    子进程真执行并把通过/失败数放进返回体;JS/TS 有 node 时做语法校验,否则
    如实标注未执行。LLM 不可用(stub 模式/异常/空输出)返回 ok:False + 原因,
    不再返回占位模板假装成功。
    """
    code = arguments.get("code", "")
    language = str(arguments.get("language", "python") or "python").lower()
    framework = str(arguments.get("framework", "") or "").strip()
    if not code.strip():
        return {
            "tool": "generate_test", "ok": False,
            "error": "code 不能为空,无法生成测试",
        }

    # 各语言默认框架与约定(prompt 中写明,引导模型产出可执行测试)
    lang_norm = "python" if language in ("python", "py", "python3") else language
    if lang_norm == "python":
        framework = framework or "pytest"
    elif lang_norm in ("javascript", "js", "typescript", "ts"):
        framework = framework or "jest"

    from ..core.llm_gateway import llm_gateway

    if lang_norm == "python":
        import_rules = (
            "5. 被测源码将保存为同目录 source.py,请通过 `from source import ...` "
            "引入被测函数;不要自行写文件或依赖其他模块。"
        )
    else:
        import_rules = (
            "5. 被测源码将以内联方式放入测试文件顶部(同文件),直接使用其中函数;"
            "不要 import 不存在的外部模块。"
        )
    system_prompt = (
        "You are a senior test engineer. Output ONLY the complete test code, "
        "no markdown fences, no explanations, no placeholders. The test code "
        "will be executed verbatim."
    )
    user_prompt = (
        f"Language: {lang_norm}. Test framework: {framework}.\n"
        "Requirements:\n"
        "1. 测试必须可直接执行,不依赖网络/数据库/被测源码之外的文件。\n"
        "2. 覆盖正常路径,且至少包含一个失败路径/边界条件断言。\n"
        f"3. 严格遵循 {framework} 的命名与组织习惯(如 pytest 的 test_* "
        "函数 + assert;jest 的 describe/it + expect)。\n"
        f"{import_rules}\n\n"
        f"Source code:\n```{lang_norm}\n{code}\n```\n"
    )
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_prompt},
    ]

    # --- LLM 真实生成(失败路径全部诚实返回,不出占位模板) ---
    try:
        result = await llm_gateway.complete(messages)
    except Exception as exc:  # noqa: BLE001 - LLM 通道异常如实降级
        return {
            "tool": "generate_test", "ok": False,
            "language": lang_norm, "framework": framework,
            "analysis_depth": "llm-generated", "executed": False,
            "error": f"LLM 调用异常: {exc}",
        }
    if result.get("error") or result.get("error_message"):
        return {
            "tool": "generate_test", "ok": False,
            "language": lang_norm, "framework": framework,
            "analysis_depth": "llm-generated", "executed": False,
            "error": (
                result.get("error_message")
                or result.get("error")
                or "LLM 返回错误"
            ),
        }
    if result.get("stub"):
        # stub 模式 = 网关未配置任何真实 API key,拿到的是假响应。
        # 假响应生成不出真测试,必须 ok:False,不许假装成功(V3 #50)。
        return {
            "tool": "generate_test", "ok": False,
            "language": lang_norm, "framework": framework,
            "analysis_depth": "llm-generated", "executed": False,
            "stub": True,
            "error": (
                "LLM 网关处于 stub 模式(未配置任何 API key),无法生成真实测试"
            ),
        }
    test_code = _strip_code_fences(str(result.get("content") or ""))
    if not test_code.strip():
        return {
            "tool": "generate_test", "ok": False,
            "language": lang_norm, "framework": framework,
            "analysis_depth": "llm-generated", "executed": False,
            "error": "LLM 返回内容为空,无法生成测试",
        }

    base: dict[str, Any] = {
        "tool": "generate_test", "ok": True,
        "language": lang_norm, "framework": framework,
        "analysis_depth": "llm-generated",
        "test_code": test_code,
        "model": result.get("model", ""),
    }

    # --- 真实执行验证 ---
    if lang_norm == "python":
        # pytest 子进程真执行(结果如实放进返回体;测试本身有失败不算工具
        # 失败 —— ok 表示「生成+执行流程完成」,失败明细交给调用方判断)
        execution = await asyncio.to_thread(
            _run_pytest_on_generated_test, code, test_code
        )
        if execution.get("available") and execution.get("executed"):
            base["executed"] = True
            base["execution"] = {
                "runner": "pytest",
                "passed": execution["passed"],
                "failed": execution["failed"],
                "errors": execution["errors"],
                "failures": execution["failures"],
                "output_summary": execution["output_summary"],
            }
            base["message"] = (
                f"测试已生成并真实执行:"
                f"{execution['passed']} passed / {execution['failed']} failed"
                f" / {execution['errors']} errors"
            )
        else:
            # pytest 环境缺失:降级为语法校验,如实标注未真实执行
            import ast as _ast

            syntax_ok = True
            syntax_error = ""
            try:
                _ast.parse(test_code)
            except SyntaxError as e:
                syntax_ok = False
                syntax_error = f"line {e.lineno}: {e.msg}"
            base["executed"] = False
            base["execution"] = {
                "runner": "syntax-check(compile)",
                "syntax_ok": syntax_ok,
                "error": syntax_error,
            }
            base["message"] = (
                f"测试已生成,但 {execution.get('reason') or '执行环境缺失'};"
                "仅完成语法校验,未真实执行(结果未经验证)"
            )
        return base

    # JS/TS:有 node 则语法校验(node --check,仅支持 .js 系);否则如实标注
    if lang_norm in ("javascript", "js", "typescript", "ts"):
        import shutil as _shutil
        import subprocess as _subprocess

        is_ts = lang_norm in ("typescript", "ts")
        node_path = _shutil.which("node")
        if node_path and not is_ts:
            import tempfile as _tempfile
            import uuid as _uuid

            tmpdir = _tempfile.mkdtemp(prefix="gen_test_js_")
            js_path = os.path.join(
                tmpdir, f"gen_{_uuid.uuid4().hex[:8]}.js"
            )
            try:
                with open(js_path, "w", encoding="utf-8") as f:
                    f.write(test_code)
                # BUG-9:同步 node 子进程改真异步(对齐同文件 python 分支的 to_thread 写法)。
                proc = await asyncio.to_thread(
                    _subprocess.run,
                    [node_path, "--check", js_path],
                    capture_output=True, text=True, timeout=30,
                )
                base["executed"] = proc.returncode == 0
                base["execution"] = {
                    "runner": "node --check",
                    "syntax_ok": proc.returncode == 0,
                    "error": (proc.stderr or "").strip()[:500],
                }
                base["message"] = (
                    "测试已生成并通过 node 语法校验(未跑测试运行时,"
                    "结果未经验证)"
                    if proc.returncode == 0
                    else "测试已生成,但 node 语法校验失败(见 execution.error)"
                )
            finally:
                _shutil.rmtree(tmpdir, ignore_errors=True)
            return base
        # 无 node 或 TS(node --check 不支持 TS):如实标注未执行
        base["executed"] = False
        base["execution"] = {
            "runner": None,
            "syntax_ok": None,
            "error": (
                "TypeScript 无内置语法校验手段"
                if is_ts
                else "当前环境未安装 node,无法校验"
            ),
        }
        base["message"] = (
            "测试已生成(LLM 真实产物),但当前环境无法执行验证,"
            "结果未经验证,请人工确认"
        )
        return base

    # 其他语言:生成真实产物,但无执行手段,如实标注
    base["executed"] = False
    base["execution"] = {
        "runner": None, "syntax_ok": None,
        "error": f"{lang_norm} 暂无执行验证通道",
    }
    base["message"] = "测试已生成(LLM 真实产物),无执行通道,结果未经验证"
    return base


async def _tool_file_search(arguments: dict[str, Any]) -> dict[str, Any]:
    """file_search: 搜索文件内容(真实文件系统搜索)。

    支持:
    - pattern: 文件名 glob 匹配(默认 *)
    - query: 文件内容关键词搜索(为空则仅按文件名匹配)
    - fuzzy: true 时 query 作为文件名模糊子序列模式,按 fzf 风格相关度
      排序返回(遵循统一工程规范;忽略内容搜索)
    - path: 搜索根目录(默认当前目录)
    - max_results: 最大返回数(默认 50)
    - 忽略常见忽略目录(node_modules/.git/__pycache__/.venv/venv/dist/build)
    - 忽略二进制文件(按扩展名判断)
    """
    query = arguments.get("query", "")
    path = arguments.get("path", ".")
    pattern = arguments.get("pattern", "*")
    max_results = int(arguments.get("max_results", 50))
    fuzzy = bool(arguments.get("fuzzy", False))

    # 忽略目录(常见依赖/构建/缓存)
    _IGNORED_DIRS = {
        "node_modules", ".git", "__pycache__", ".venv", "venv",
        "dist", "build", ".next", ".turbo", ".cache", "coverage",
    }
    # 忽略二进制/大文件扩展名
    _IGNORED_EXTS = {
        ".png", ".jpg", ".jpeg", ".gif", ".bmp", ".ico", ".webp",
        ".pdf", ".zip", ".tar", ".gz", ".rar", ".7z",
        ".exe", ".dll", ".so", ".dylib", ".class", ".jar",
        ".mp3", ".mp4", ".avi", ".mov", ".wav", ".flv",
        ".woff", ".woff2", ".ttf", ".eot", ".otf",
    }

    matches: list[dict[str, Any]] = []
    try:
        import fnmatch
        import os
        from pathlib import Path

        root = Path(path).resolve()
        # 与 search_codebase 同一把尺子:读不到要明说,不能冒用"路径不存在"。
        kind, st = _classify_path(str(root))
        if kind == "unread":
            return {
                "tool": "file_search",
                "query": query,
                "path": path,
                "pattern": pattern,
                "matches": [],
                "message": f"路径读不到: {path}",
                "ok": False,
            }
        if kind == "missing":
            return {
                "tool": "file_search",
                "query": query,
                "path": path,
                "pattern": pattern,
                "matches": [],
                "message": f"路径不存在: {path}",
                "ok": False,
            }
        if st is not None and not stat.S_ISDIR(st.st_mode):
            return {
                "tool": "file_search",
                "query": query,
                "path": path,
                "pattern": pattern,
                "matches": [],
                "message": f"路径不是目录: {path}",
                "ok": False,
            }
        # AIS-106:搜索根必须落在工作区白名单(或 D201 会话附加根)内 —— 否则 role=0
        # 能用 path=/ 枚举整机目录、再用 query 回读文件内容(与 read_file 同源缺口)。
        # 放在"存在/是目录"之后:旧语义的两种报错保持原样,不变成存在性探针。
        _ok_root, _root_info = _validate_path_in_workspace(str(path))
        if not _ok_root:
            return {
                "tool": "file_search", "query": query, "path": path,
                "pattern": pattern, "matches": [], "fuzzy": fuzzy,
                "ok": False, "errorCode": "PATH_NOT_ALLOWED",
                "message": _root_info,
            }
        root = Path(_root_info)

        # AIS-106:file_search 与 read_file/search_codebase 同一工作区判据。
        # 放在存在性/目录判定之后:缺路径、非目录按旧契约如实报错,
        # 只有"确实存在且可遍历"的目录才需要过工作区这一关。
        ok_path, resolved_path = _validate_path_in_workspace(str(root))
        if not ok_path:
            return {
                "tool": "file_search",
                "query": query,
                "path": path,
                "pattern": pattern,
                "matches": [],
                "count": 0,
                "ok": False,
                "message": f"路径不允许: {resolved_path}",
            }
        path = resolved_path

        # V3 #75:两处遍历收成一个出口(原先各写一遍 os.walk = 同一个工具两份实现)。
        # 扩展名沿用本工具的**黑名单**语义(跳二进制),所以给枚举层传 suffixes=None ——
        # 把 file_search 当"只要代码"的白名单来用会静默缩小结果集,那是改行为不是提速。
        from .rg_fallback_parity import enumerate_code_files

        _rel_all, _enum_prov = enumerate_code_files(root, ignored_dirs=_IGNORED_DIRS, suffixes=None)
        searchable = [
            rp for rp in _rel_all if os.path.splitext(rp)[1].lower() not in _IGNORED_EXTS
        ]

        # 模糊文件名搜索(2026-09-18 第十一批,遵循统一工程规范):
        # query 作为子序列模式对相对路径评分排序(fzf 语义:连续命中/词首加分)
        if fuzzy and query:
            from app.core.output_cleaning import fuzzy_score

            scored: list[tuple[int, str, str]] = []
            for rel_path in searchable:
                fname = rel_path.rsplit("/", 1)[-1]
                score = fuzzy_score(query, rel_path)
                if score is None:
                    name_score = fuzzy_score(query, fname)
                    if name_score is not None:
                        score = name_score - 20  # 仅文件名命中降权
                if score is not None:
                    scored.append((score, rel_path, fname))
            scored.sort(key=lambda x: (-x[0], x[1]))
            matches = [
                {"path": rp, "file": fn, "score": sc}
                for sc, rp, fn in scored[:max_results]
            ]
            fuzzy_message = (
                f"模糊匹配 {len(scored)} 个候选,返回前 {len(matches)}(按相关度排序)"
            )
            if _enum_prov.degraded_reason:
                fuzzy_message += f";{_enum_prov.degraded_reason}"
            return {
                "tool": "file_search",
                "query": query,
                "path": path,
                "fuzzy": True,
                "matches": matches,
                "total": len(matches),
                "candidates": len(scored),
                "truncated": len(scored) > max_results,
                # V3 #75:枚举走了哪条通道、有没有降级,必须在响应里可读 ——
                # "降级只是慢一点"不成立:两条通道的结果集必须等价,不等价时得有人能发现。
                "enum_engine": _enum_prov.engine,
                "enum_degraded": _enum_prov.degraded_reason,
                "message": fuzzy_message,
                # 通道降级≠结果缺口(见下方非模糊分支同一判据)。
                "ok": not (_enum_prov.unread_dirs and not matches),
            }

        query_lower = query.lower() if query else None
        count = 0
        unread_files = 0
        # V3 #75:同一个工具的第二处遍历,现共用上面那一次枚举的结果(原先两份 os.walk)。
        for rel_path in searchable:
            fname = rel_path.rsplit("/", 1)[-1]
            if count >= max_results:
                break
            if not fnmatch.fnmatch(fname, pattern):
                continue
            fpath = os.path.join(str(root), *rel_path.split("/"))
            try:
                if query_lower:
                    try:
                        if os.path.getsize(fpath) > _MAX_SEARCH_FILE_BYTES:
                            continue
                        with open(fpath, encoding="utf-8", errors="ignore") as f:
                            content = f.read()
                        if query_lower not in content.lower():
                            continue
                        # 提取匹配行上下文
                        lines = content.splitlines()
                        line_numbers = [
                            i + 1 for i, ln in enumerate(lines) if query_lower in ln.lower()
                        ]
                        preview = ""
                        if line_numbers:
                            ln = line_numbers[0]
                            start = max(0, ln - 2)
                            end = min(len(lines), ln + 1)
                            preview = "\n".join(
                                f"{start + j + 1}: {lines[start + j]}" for j in range(end - start)
                            )
                        matches.append({
                            "path": rel_path,
                            "file": fname,
                            "line_numbers": line_numbers[:10],
                            "preview": preview[:500],
                        })
                    except (OSError, UnicodeDecodeError):
                        unread_files += 1
                        continue
                else:
                    # 无 query,仅文件名匹配
                    try:
                        size = os.path.getsize(fpath)
                    except OSError:
                        size = 0
                    matches.append({
                        "path": rel_path,
                        "file": fname,
                        "size": size,
                    })
                count += 1
            except OSError:
                unread_files += 1
                continue

        message = (
            f"在 {path} 下找到 {len(matches)} 个匹配文件"
            + ("(已截断)" if count >= max_results else "")
        )
        # 「没找到」与「没查到」是两件事:枚举/读取有缺口时,零命中不能报成成功,
        # 也不能再给"放宽 pattern"这类误导性建议(缺口不在 pattern 上)。
        # 但**通道降级不等于结果有缺口**:rg 缺失/坏掉时走 python-walk 完整遍历,
        # 两通道结果集等价(见 rg_fallback_parity),此时 0 就是真 0。只有遍历真的
        # 有目录读不到(unread_dirs>0)才算不完整 —— 把降级当缺口会让无 rg 的机器
        # (含 Linux CI)上任何零命中都报失败、并吞掉可操作建议;降级事实仍由
        # enum_engine/enum_degraded 如实留痕,不冒用 rg 的名义。
        incomplete = _enum_prov.degraded_reason if _enum_prov.unread_dirs else ""
        if unread_files:
            file_note = f"有 {unread_files} 个文件读不到,不能把检索说成没有命中"
            incomplete = f"{incomplete};{file_note}" if incomplete else file_note
        if incomplete:
            message += f";{incomplete}"
        elif not matches:
            # 零结果给可操作指引(第十四批:体验优化,避免模型盲目重试)
            message += (
                ";建议:①放宽 pattern(如 '*.py' 或 '*');"
                "②改用 fuzzy=true 做文件名模糊搜索;"
                "③确认 path 是否为期望根目录"
            )
        return {
            "tool": "file_search",
            "query": query,
            "path": path,
            "pattern": pattern,
            "matches": matches,
            "total": len(matches),
            "truncated": count >= max_results,
            "enum_engine": _enum_prov.engine,
            "enum_degraded": _enum_prov.degraded_reason,
            "message": message,
            "ok": not (incomplete and not matches),
        }
    except Exception as e:
        return {
            "tool": "file_search",
            "query": query,
            "path": path,
            "pattern": pattern,
            "matches": [],
            "message": f"搜索失败: {e}",
            "ok": False,
            "error": str(e),
        }


async def _tool_git_operations(arguments: dict[str, Any]) -> dict[str, Any]:
    """git_operations: Git 操作(真实 git 命令执行)。

    支持的 action:
      只读(所有用户): status/diff/log/branch(show)/show/stash(list)/list
      写操作(需 admin,role >= 1): branch_create/branch_switch/branch_delete/merge/
                                  rebase/stash_push/stash_pop/tag_create/tag_list
    """
    action = arguments.get("action", "status")
    repo = arguments.get("repo", ".")

    # 只读操作白名单(所有用户可用)
    _READONLY_ACTIONS = {
        "status": ["status", "--short", "--branch"],
        "diff": ["diff", "--stat"],
        "log": ["log", "--oneline", "-20"],
        "branch": ["branch", "-a"],
        "show": ["show", "--stat"],  # show 需要 ref 参数
        "stash": ["stash", "list"],
        "list": ["ls-files"],
    }

    # 写操作集合(admin only,role >= 1)Wave 8 新增
    _WRITE_ACTIONS = {
        "branch_create", "branch_switch", "branch_delete", "merge",
        "rebase", "stash_push", "stash_pop", "tag_create", "tag_list",
    }

    if action not in _READONLY_ACTIONS and action not in _WRITE_ACTIONS:
        return {
            "tool": "git_operations",
            "action": action,
            "repo": repo,
            "output": "",
            "message": (
                f"不允许的 git 操作: {action}。允许: "
                f"只读={', '.join(sorted(_READONLY_ACTIONS))}; "
                f"写操作(admin)={', '.join(sorted(_WRITE_ACTIONS))}"
            ),
            "ok": False,
        }

    # 写操作 admin 权限校验(defense-in-depth,call_tool 层已校验 _ADMIN_ONLY_TOOLS,
    # 此处再校验 __user_role 以防绕过)
    if action in _WRITE_ACTIONS:
        user_role = arguments.get("__user_role", 0)
        if user_role < 1:
            return {
                "tool": "git_operations",
                "action": action,
                "repo": repo,
                "output": "",
                "message": f"写操作 '{action}' 需要 admin 权限(role >= 1),当前 role={user_role}",
                "ok": False,
                "error": "PERMISSION_DENIED",
            }

    try:
        import subprocess

        # 2026-11-01 安全强化:`repo` 是工具入参(模型可控),旧实现直接 abspath 就当 cwd,
        # 于是 role=0 的"只读 git 面"能对服务器任意目录跑 status/ls-files/log/diff ⇒ 跨目录
        # 信息泄露。同文件 :685 那把尺子(_validate_path_in_workspace)本来就是本模块的路径
        # 归属单源,13 个调用点都在问它 —— 这一格漏挂不是"没有判据",是"判据没被问"。
        ok_repo, repo_resolved = _validate_path_in_workspace(repo)
        if not ok_repo:
            return {
                "tool": "git_operations",
                "action": action,
                "repo": repo,
                "output": "",
                "message": f"仓库路径不在工作区白名单内:{repo_resolved}",
                "ok": False,
                "error": "PATH_NOT_IN_WORKSPACE",
            }
        repo_path = repo_resolved
        # 仓库路径同样分三档:读不到 / 不存在 / 不是目录。权限错误报成"不存在"
        # 会让调用方以为仓库被盗删,而不是"当前进程没权限看它"。
        kind, st = _classify_path(str(repo_path))
        if kind == "unread":
            return {
                "tool": "git_operations",
                "action": action,
                "repo": repo,
                "output": "",
                "message": f"仓库路径读不到: {repo}",
                "ok": False,
            }
        if kind == "missing":
            return {
                "tool": "git_operations",
                "action": action,
                "repo": repo,
                "output": "",
                "message": f"仓库路径不存在: {repo}",
                "ok": False,
            }
        if st is not None and not stat.S_ISDIR(st.st_mode):
            return {
                "tool": "git_operations",
                "action": action,
                "repo": repo,
                "output": "",
                "message": f"仓库路径不是目录: {repo}",
                "ok": False,
            }

        # 构造 git 命令参数
        git_args: list[str] | None
        if action in _READONLY_ACTIONS:
            git_args = list(_READONLY_ACTIONS[action])
            # show 命令需要 ref 参数
            if action == "show":
                ref = str(arguments.get("ref", "HEAD") or "HEAD")
                _assert_safe_git_arg(ref, "ref")
                git_args.append(ref)
        else:
            # 写操作:根据 action 构造命令参数
            git_args = _build_write_action_args(action, arguments)
            if git_args is None:
                return {
                    "tool": "git_operations",
                    "action": action,
                    "repo": repo,
                    "output": "",
                    "message": f"写操作 '{action}' 参数无效或缺失必填参数",
                    "ok": False,
                }

        # BUG-9:同步 git 子进程改真异步,避免整段卡死事件循环。
        result = await asyncio.to_thread(
            subprocess.run,
            ["git"] + (git_args or []),
            cwd=repo_path,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=30,
            check=False,
        )

        output = result.stdout
        if result.stderr:
            output = (output + "\n" + result.stderr).strip() if output else result.stderr.strip()

        return {
            "tool": "git_operations",
            "action": action,
            "repo": repo,
            "output": output,
            "exit_code": result.returncode,
            "ok": result.returncode == 0,
            "message": f"git {action} 完成(exit_code={result.returncode})",
        }
    except subprocess.TimeoutExpired:
        return {
            "tool": "git_operations",
            "action": action,
            "repo": repo,
            "output": "",
            "message": "git 命令执行超时(30s)",
            "ok": False,
        }
    except FileNotFoundError:
        return {
            "tool": "git_operations",
            "action": action,
            "repo": repo,
            "output": "",
            "message": "git 命令未找到(需安装 git 并加入 PATH)",
            "ok": False,
        }
    except Exception as e:
        return {
            "tool": "git_operations",
            "action": action,
            "repo": repo,
            "output": "",
            "message": f"git 操作失败: {e}",
            "ok": False,
            "error": str(e),
        }


def _assert_safe_git_arg(value: str, label: str) -> str:
    """git argv position 段安全断言(2026-10-31 安全强化第 10 批 R5)。

    position 段(引用名/分支名/tag 名)以 `-` 开头会被 git 当**选项**解析:
    `show --output=<path>` 可写服务器任意文件、`--ext-diff` 可调外部程序。
    空白/控制符同属注入面(不可能出现在合法引用名里)。违反抛 ValueError,
    由调用方按既有错误形状返回。
    """
    v = value.strip()
    if not v or v.startswith("-") or any(c.isspace() or ord(c) < 32 for c in v):
        raise ValueError(f"非法 git {label}: {value[:80]}")
    return v


def _build_write_action_args(action: str, arguments: dict[str, Any]) -> list[str] | None:
    """构造写操作的 git 命令参数(Wave 8 新增)。

    Returns:
        git 命令参数列表,或 None(参数无效/缺失必填)。
    """
    if action == "branch_create":
        name = arguments.get("name")
        if not name:
            return None
        args = ["branch", _assert_safe_git_arg(str(name), "分支名")]
        from_ref = arguments.get("from")
        if from_ref:
            args.append(_assert_safe_git_arg(str(from_ref), "起点引用"))
        return args

    if action == "branch_switch":
        name = arguments.get("name")
        if not name:
            return None
        create = arguments.get("create", False)
        args = ["checkout"]
        if create:
            args.append("-b")
        args.append(_assert_safe_git_arg(str(name), "分支名"))
        return args

    if action == "branch_delete":
        name = arguments.get("name")
        if not name:
            return None
        force = arguments.get("force", False)
        return ["branch", "-D" if force else "-d", _assert_safe_git_arg(str(name), "分支名")]

    if action == "merge":
        branch = arguments.get("branch")
        if not branch:
            return None
        args = ["merge"]
        if arguments.get("no_ff"):
            args.append("--no-ff")
        if arguments.get("squash"):
            args.append("--squash")
        message = arguments.get("message")
        if message:
            args.extend(["-m", str(message)])
        args.append(_assert_safe_git_arg(str(branch), "分支名"))
        return args

    if action == "rebase":
        upstream = arguments.get("upstream")
        if not upstream:
            return None
        args = ["rebase", _assert_safe_git_arg(str(upstream), "上游引用")]
        branch = arguments.get("branch")
        if branch:
            args.append(_assert_safe_git_arg(str(branch), "分支名"))
        return args

    if action == "stash_push":
        args = ["stash", "push"]
        message = arguments.get("message")
        if message:
            args.extend(["-m", str(message)])
        if arguments.get("include_untracked"):
            args.append("-u")
        return args

    if action == "stash_pop":
        index = arguments.get("index", 0)
        apply = arguments.get("apply", False)
        return ["stash", "apply" if apply else "pop", f"stash@{{{int(index)}}}"]

    if action == "tag_create":
        name = arguments.get("name")
        if not name:
            return None
        safe_name = _assert_safe_git_arg(str(name), "tag 名")
        args = ["tag"]
        if arguments.get("annotated"):
            args.extend(["-a", safe_name])
            message = arguments.get("message")
            args.extend(["-m", str(message) if message else f"Tag {name}"])
        else:
            args.append(safe_name)
        return args

    if action == "tag_list":
        args = ["tag", "-l"]
        pattern = arguments.get("pattern")
        if pattern:
            args.append(_assert_safe_git_arg(str(pattern), "匹配模式"))
        return args

    return None


async def _tool_db_query(arguments: dict[str, Any]) -> dict[str, Any]:
    """db_query: 数据库只读查询(真实 postgres 查询,安全加固)。

    安全策略:
    - 仅允许 SELECT / WITH 查询(只读),禁止 INSERT/UPDATE/DELETE/DROP/ALTER 等
    - SQL 语句经正则校验,必须以 SELECT 或 WITH 开头(忽略前导空白/注释)
    - 参数化查询:arguments.params 透传给 asyncpg.fetch($1,$2... 占位符)
    - 查询超时 10s
    - 结果行数限制 max_rows(默认 100,上限 1000)
    - database_url 未配置时返回 ok=False
    - 任何异常捕获,不泄露完整 SQL 错误(仅返回简短信息)
    """
    sql = arguments.get("sql", "").strip()
    params = arguments.get("params", [])
    max_rows = min(int(arguments.get("max_rows", 100)), 1000)

    # 安全校验:仅允许 SELECT / WITH 开头
    import re
    # 去除前导 SQL 注释(-- ... 和 /* ... */)和空白
    _SQL_LEADING_COMMENT_RE = re.compile(
        r"^\s*(?:--[^\n]*\n|/\*.*?\*/\s*)*",
        re.DOTALL,
    )
    stripped = _SQL_LEADING_COMMENT_RE.sub("", sql).lstrip()
    sql_upper = stripped.upper()
    if not sql_upper.startswith("SELECT") and not sql_upper.startswith("WITH"):
        return {
            "tool": "db_query",
            "sql": sql,
            "rows": [],
            "ok": False,
            "message": "仅允许 SELECT / WITH 查询(只读),禁止写操作/DDL",
        }

    # 禁止危险关键词(在 SQL 任意位置,忽略大小写)。
    # 2026-10-31 安全强化第 10 批 R5:尾随空格匹配可被 `DELETE<换行>FROM` /
    # `DELETE/**/FROM` 绕过 → 改词边界 regex(词边界判据对 deleted_at /
    # drop_function 这类标识符不误杀:关键字后跟字母/下划线不是边界)。
    _DANGEROUS_KEYWORDS = [
        "INSERT", "UPDATE", "DELETE", "DROP", "ALTER", "CREATE",
        "TRUNCATE", "GRANT", "REVOKE", "EXEC", "EXECUTE", "MERGE",
        "VACUUM", "REINDEX", "CLUSTER",
    ]
    for kw in _DANGEROUS_KEYWORDS:
        # 词边界:DELETE\nFROM 型换行变体同杀;deleted_at 等标识符不误杀
        if re.search(r"\b" + kw + r"\b", sql_upper):
            return {
                "tool": "db_query",
                "sql": sql,
                "rows": [],
                "ok": False,
                "message": f"SQL 含禁止关键词: {kw}",
            }

    # AIS-085:READ ONLY 事务只挡写,挡不住"读 DB 主机文件"的内置函数
    # (`SELECT pg_read_file('/etc/passwd')` 是合法只读查询)。补函数名黑名单,
    # 词边界避免误杀 `pg_read_file_audit` 这类标识符;在连库之前拒绝。
    _FORBIDDEN_FUNCTIONS = [
        "PG_READ_FILE", "PG_READ_BINARY_FILE", "PG_LS_DIR", "LO_IMPORT",
    ]
    for fn in _FORBIDDEN_FUNCTIONS:
        if re.search(r"\b" + fn + r"\b", sql_upper):
            return {
                "tool": "db_query",
                "sql": sql,
                "rows": [],
                "ok": False,
                "errorCode": "SQL_FORBIDDEN_FUNCTION",
                "message": f"SQL 含禁止函数: {fn}(不允许读取数据库主机文件)",
            }

    # 检查 database_url 配置
    from app.core.config import settings
    if not settings.database_url:
        return {
            "tool": "db_query",
            "sql": sql,
            "rows": [],
            "ok": False,
            "message": "DATABASE_URL 未配置,无法执行数据库查询",
        }

    # 执行查询
    try:
        import asyncio

        import asyncpg

        # 强制只读:在事务外用 READ ONLY 模式(若 postgres 支持)
        # asyncpg 不直接支持事务只读模式,这里靠 SQL 校验 + SELECT 限制保证只读
        conn = await asyncio.wait_for(
            asyncpg.connect(settings.database_url),
            timeout=5,
        )
        try:
            # R9 复评 N2:无条件外层包裹 LIMIT —— 探针形态(词边界/剥尾注释)
            # 仍可被块注释 /* LIMIT */ 或字符串字面量 '%LIMIT%' 欺骗,判断面
            # 越少越好:剥尾行注释后整体包一层 SELECT,外层 LIMIT 恒在且与
            # 内层 LIMIT/ORDER BY/WITH 合法共存(READ ONLY 事务不变)。
            _sql_body = re.sub(r"--[^\n]*$", "", sql).strip().rstrip(";")
            sql_with_limit = (
                "SELECT * FROM (" + _sql_body + ") AS _ihui_limited_query LIMIT " + str(max_rows)
            )

            # 2026-10-31 安全强化第 10 批 R5:READ ONLY 事务兜底 —— 关键词黑名单
            # 是文本层判据,`WITH d AS (DELETE ... RETURNING ...) SELECT ...` 型
            # data-modifying CTE 曾能穿过任何黑名单;数据库层只读事务把这一整族
            # 绕过(含未来未知的写语法)结构性封死。黑名单降级为纵深第一道。
            async with conn.transaction(readonly=True):
                rows = await asyncio.wait_for(
                    conn.fetch(sql_with_limit, *params),
                    timeout=10,
                )
            # 转换为可序列化 dict 列表
            result_rows = [dict(r) for r in rows]
            # 将非 JSON 类型转为字符串
            for r in result_rows:
                for k, v in r.items():
                    if not isinstance(v, (str, int, float, bool, type(None))):
                        r[k] = str(v)
            return {
                "tool": "db_query",
                "sql": sql,
                "rows": result_rows,
                "row_count": len(result_rows),
                "truncated": len(result_rows) >= max_rows,
                "ok": True,
                "message": f"查询成功,返回 {len(result_rows)} 行",
            }
        finally:
            await conn.close()
    except TimeoutError:
        return {
            "tool": "db_query",
            "sql": sql,
            "rows": [],
            "ok": False,
            "message": "查询超时(连接 5s / 查询 10s)",
        }
    except Exception as e:
        # 仅返回错误类型,不泄露完整 SQL 错误
        err_type = type(e).__name__
        return {
            "tool": "db_query",
            "sql": sql,
            "rows": [],
            "ok": False,
            "message": f"查询失败: {err_type}",
            "error": str(e)[:200],  # 截断错误信息
        }


# ---------------------------------------------------------------------------
# AI 自动控制工具(22 个:12 browser + 10 computer,2026-07-22 立)
# 转发到 api 层 /api/agent-control/execute,由 extension/desktop 端执行
# ---------------------------------------------------------------------------

# api 层 agent-control 端点(转发到 extension/desktop 端执行)
# 2026-07-24 修复:原硬编码 http://127.0.0.1:8801(端口 8801 是 web,agent-control 路由在 api 8802)
# 改为从 settings.api_service_url 动态构建,与 .env API_SERVICE_URL 配置一致
def _get_agent_control_api_url() -> str:
    """动态构建 agent-control API URL(确保 settings 已加载 .env)。"""
    from ..core.config import settings
    return f"{settings.api_service_url}/api/agent-control/execute"


def _deliver_inline_image(
    result: dict[str, Any],
    *,
    raw_b64: str,
    label: str,
    name: str = "screenshot.png",
    remove_keys: tuple[str, ...] = (),
) -> dict[str, Any]:
    """把工具结果里的内联 base64 图片转入图片交付暂存(只留元数据,原地修改)。

    为什么必须转:call_tool 出口有 8000 token 截断护栏,10MB 截图的 base64 会被
    截成无效串(call_tool 的 _truncate_tool_output 按 token 截断文本),模型既看
    不到图,也拿不到可用数据;SSE tool-result 事件同样会被单帧撑爆。
    交付失败绝不把工具整体判失败:保留原结果并追加 image_error(模型可改用
    vision_analyze / 重试)。
    """
    import base64
    import binascii

    from .tool_image_delivery import prepare_image_bytes, stash_image

    text = raw_b64.strip()
    if text.startswith("data:"):
        _, _, text = text.partition(",")
    try:
        raw = base64.b64decode(text, validate=True)
    except (binascii.Error, ValueError) as e:
        result["image_error"] = f"内联图片 base64 解码失败: {e}"
        return result
    prepared, error = prepare_image_bytes(raw, path_label=label, name=name)
    if prepared is None or error is not None:
        result["image_error"] = (error or {}).get("error") or "图片交付失败"
        return result
    content_id = stash_image(prepared)
    for key in remove_keys:
        result.pop(key, None)
    result["image"] = {
        "content_id": content_id,
        "media_type": prepared["media_type"],
        "bytes": prepared["bytes"],
        "width": prepared["width"],
        "height": prepared["height"],
        "source_width": prepared["source_width"],
        "source_height": prepared["source_height"],
        "name": prepared["name"],
    }
    result["note"] = "图片本体随本轮 tool 结果之后的 user 多模态消息送达"
    return result


def _screenshot_b64_from_agent_result(data: Any) -> str:
    """从 agent-control 的 data 载荷里取截图 base64(兼容双层 data 与三个键名)。"""
    if not isinstance(data, dict):
        return ""
    inner = data.get("data")
    for payload in (inner, data):
        if not isinstance(payload, dict):
            continue
        for key in ("screenshot", "imageBase64", "base64"):
            value = payload.get(key)
            if isinstance(value, str) and value:
                return value
    return ""


async def _tool_agent_control(
    category: str, action: str, arguments: dict[str, Any]
) -> dict[str, Any]:
    """agent_control: AI 自动控制浏览器/电脑(转发到 extension/desktop 端执行)。

    category='browser'  → extension 端执行 DOM 操作 + 截图
    category='computer' → desktop 端执行 Tauri IPC(截图/鼠标/键盘)
    """
    import uuid

    import httpx

    # 从 arguments 提取参数(去掉 MCP tool 的元数据字段)
    timeout_ms = int(arguments.pop("timeout", 30000))
    # `__` 前缀是宿主注入的元数据(身份/会话),不是业务参数 ⇒ 不再下发到端侧
    params = {k: v for k, v in arguments.items() if not k.startswith("__")}

    # 2026-10-31 安全强化第 14 批:此前 request 不带 userId ⇒ api 层
    # findEndpointByCategory 退回"同 category 最近活跃" ——— 任意登录用户可操纵**别人**的
    # 浏览器/桌面(点击、输入、截图)。主语必须取宿主注入的已验证主体
    # (security_principal_scope,与工具执行链同一个出口),不能读 arguments 里的
    # `__user_id`(那是模型可填面,自报即越权);取不到一律拒 —— 无从定址就不能发。
    from .agent_security_prefs import current_security_principal

    caller_uid = current_security_principal()
    if not caller_uid:
        return {
            "tool": f"{category}_{action}",
            "ok": False,
            "error": "缺少调用者身份,拒绝控制他人端(无从定址)",
            "errorCode": "PRINCIPAL_REQUIRED",
        }

    request = {
        "requestId": f"mcp-{uuid.uuid4().hex[:12]}",
        "category": category,
        "action": action,
        "params": params,
        "timeout": timeout_ms,
        "userId": caller_uid,
    }

    tool_name = f"{category}_{action}"
    # 内部服务密钥从 env 读取(2026-07-22 修复:原硬编码 "internal-service")
    # api 层用 secrets.compare_digest 校验,密钥未配置时拒绝调用(fail-closed)
    if not _get_agent_control_secret():
        return {
            "tool": tool_name,
            "ok": False,
            "error": "AGENT_CONTROL_INTERNAL_SECRET 未配置,拒绝 agent_control 调用(fail-closed)",
            "errorCode": "MISSING_SECRET",
        }
    try:
        async with httpx.AsyncClient(timeout=timeout_ms / 1000 + 10) as client:
            response = await client.post(
                _get_agent_control_api_url(),
                json=request,
                headers={"Authorization": f"Bearer {_get_agent_control_secret()}"},
            )
            response.raise_for_status()
            payload = response.json()
            # api 层返回 ApiResponse<AgentActionResponse> = { code, message, data }
            data = payload.get("data", payload) if isinstance(payload, dict) else {}
            result = {
                "tool": tool_name,
                "ok": bool(data.get("success", False)),
                "action": action,
                "category": category,
                "result": data,
            }
            if action in ("screenshot", "screenshot_screen"):
                # 截图 base64 不能留在 tool 正文:8000 token 截断会把它截成无效串。
                # 取出 → 有界暂存 → 元数据交付(agent loop 追加 user 多模态消息)。
                # 覆盖 computer 与 browser 两个截图动作(载荷键名由提取器兼容)。
                shot = _screenshot_b64_from_agent_result(data)
                if shot:
                    inner = data.get("data") if isinstance(data, dict) else None
                    for holder in (inner, data):
                        if isinstance(holder, dict):
                            for key in ("screenshot", "imageBase64", "base64"):
                                holder.pop(key, None)
                    _deliver_inline_image(
                        result,
                        raw_b64=shot,
                        label=f"{category}:{action}",
                        name="screenshot.png",
                    )
            return result
    except httpx.TimeoutException:
        return {
            "tool": tool_name,
            "ok": False,
            "error": f"控制调用超时({timeout_ms}ms)",
            "errorCode": "TIMEOUT",
        }
    except Exception as e:
        err_type = type(e).__name__
        return {
            "tool": tool_name,
            "ok": False,
            "error": str(e)[:200],
            "errorCode": "EXECUTION_FAILED",
            "message": f"控制调用失败: {err_type}",
        }


def _make_agent_control_handler(category: str, action: str) -> Callable[[dict[str, Any]], Awaitable[dict[str, Any]]]:
    """生成 agent control handler 闭包,绑定 category + action。"""

    async def handler(arguments: dict[str, Any]) -> dict[str, Any]:
        return await _tool_agent_control(category, action, arguments)

    return handler


# ---------------------------------------------------------------------------
# 自动化任务配置工具(2026-07-22 新增)
# 调用 api 层 /api/self-media/automation/tasks/:taskId/config
# ---------------------------------------------------------------------------

# 2026-07-24 修复:原硬编码 8801(web),self-media/automation 路由在 api 8802
def _get_automation_api_base() -> str:
    """动态构建 self-media automation API base URL(确保 settings 已加载 .env)。"""
    from ..core.config import settings
    return f"{settings.api_service_url}/api/self-media/automation/tasks"


# ---------------------------------------------------------------------------
# 截图工具(2026-07-22 新增,WorkPanel iframe 降级)
# 直接调本服务 Playwright headless 截图,不走 agent_control 转发
# ---------------------------------------------------------------------------


async def _tool_screenshot_url(arguments: dict[str, Any]) -> dict[str, Any]:
    """对指定 URL 截图(Playwright headless Chromium)。

    用于 WorkPanel iframe 降级:当目标站点禁止 iframe 嵌入(X-Frame-Options /
    CSP frame-ancestors)时,后端截图返回 base64 给前端展示。
    """
    url = arguments.get("url")
    if not url or not isinstance(url, str):
        return {"tool": "screenshot_url", "ok": False, "error": "缺少 url 参数"}

    width = int(arguments.get("width", 1280))
    height = int(arguments.get("height", 720))
    full_page = bool(arguments.get("full_page", False))
    wait_until = str(arguments.get("wait_until", "load"))
    timeout = int(arguments.get("timeout", 15000))

    try:
        from .screenshot_service import take_screenshot

        result = await take_screenshot(
            url,
            width=width,
            height=height,
            full_page=full_page,
            wait_until=wait_until,
            timeout=timeout,
        )
        return {
            "tool": "screenshot_url",
            "ok": True,
            "url": result["url"],
            "title": result["title"],
            "can_embed": result["can_embed"],
            "screenshot_length": len(result["screenshot"]),
            "captured_at": result["captured_at"],
            # 注意:不直接返回 base64(可能很大),客户端调 HTTP 端点获取
        }
    except Exception as e:
        err_type = type(e).__name__
        return {
            "tool": "screenshot_url",
            "ok": False,
            "error": str(e)[:200],
            "errorCode": "SCREENSHOT_FAILED",
            "message": f"截图失败: {err_type}",
        }


# ===== D11 浏览器自检截图(2026-09)=====
async def _tool_browser_selfcheck_screenshot(arguments: dict[str, Any]) -> dict[str, Any]:
    """对 URL 截图自检,返回 base64 PNG + 视口尺寸 + console 错误(playwright headless)。

    复用 app.tools.browser_selfcheck.capture_screenshot(全链路异常已收敛为 {ok:False})。
    """
    url = arguments.get("url")
    if not url or not isinstance(url, str):
        return {"tool": "browser_selfcheck_screenshot", "ok": False, "error": "缺少 url 参数"}
    # AIS-051:与 screenshot_url 同一份 SSRF 判据,命中私网/回环/链路本地/非 http(s)
    # 就地拒绝,不发起任何页面访问。
    from .screenshot_service import _validate_url_ssrf

    ok_ssrf, ssrf_reason = _validate_url_ssrf(url)
    if not ok_ssrf:
        return {
            "tool": "browser_selfcheck_screenshot",
            "ok": False,
            "url": url,
            "error": f"URL 不允许访问: {ssrf_reason}",
            "errorCode": "SSRF_BLOCKED",
        }

    viewport = arguments.get("viewport")
    if viewport is not None and not isinstance(viewport, dict):
        viewport = None
    full_page = bool(arguments.get("full_page", False))
    try:
        wait_ms = int(arguments.get("wait_ms", 1500))
    except (TypeError, ValueError):
        wait_ms = 1500

    try:
        from ..tools.browser_selfcheck import capture_screenshot

        result = await capture_screenshot(url, viewport=viewport, full_page=full_page, wait_ms=wait_ms)
    except Exception as e:  # noqa: BLE001 - 双重保险,绝不上抛 agent 循环
        return {
            "tool": "browser_selfcheck_screenshot",
            "ok": False,
            "url": url,
            "error": f"{type(e).__name__}: {str(e)[:200]}",
            "errorCode": "TOOL_FAILED",
        }

    payload = {
        "tool": "browser_selfcheck_screenshot",
        "ok": result.get("ok", False),
        "url": result.get("finalUrl", url),
        "title": result.get("title", ""),
        "finalUrl": result.get("finalUrl", url),
        "width": result.get("width", 0),
        "height": result.get("height", 0),
        "consoleErrors": result.get("consoleErrors", []),
        "error": result.get("error"),
        "errorCode": result.get("errorCode"),
    }
    # 截图 base64 不进正文(截断护栏会截坏):转图片交付,主模型直接看图。
    shot = result.get("imageBase64")
    if isinstance(shot, str) and shot:
        _deliver_inline_image(
            payload, raw_b64=shot, label=url, name="selfcheck.png"
        )
    return payload


async def _tool_browser_selfcheck(arguments: dict[str, Any]) -> dict[str, Any]:
    """截图 + 视觉 LLM 逐项判定检查点 pass/fail(复用 browser_selfcheck.selfcheck_report)。"""
    url = arguments.get("url")
    if not url or not isinstance(url, str):
        return {"tool": "browser_selfcheck", "ok": False, "error": "缺少 url 参数"}
    # AIS-051:同上,与 screenshot_url 同一份 SSRF 判据,拒绝时不得触发截图/视觉链路。
    from .screenshot_service import _validate_url_ssrf

    ok_ssrf, ssrf_reason = _validate_url_ssrf(url)
    if not ok_ssrf:
        return {
            "tool": "browser_selfcheck",
            "ok": False,
            "url": url,
            "checks": [],
            "error": f"URL 不允许访问: {ssrf_reason}",
            "errorCode": "SSRF_BLOCKED",
        }

    checks = arguments.get("checks") or []
    if not isinstance(checks, list):
        checks = [str(checks)]
    checks = [str(c) for c in checks if str(c).strip()]

    try:
        from ..tools.browser_selfcheck import selfcheck_report

        result = await selfcheck_report(url, checks)
    except Exception as e:  # noqa: BLE001 - 双重保险,绝不上抛 agent 循环
        return {
            "tool": "browser_selfcheck",
            "ok": False,
            "url": url,
            "checks": [],
            "error": f"{type(e).__name__}: {str(e)[:200]}",
            "errorCode": "TOOL_FAILED",
        }

    return {
        "tool": "browser_selfcheck",
        "ok": result.get("ok", False),
        "url": result.get("url", url),
        "title": result.get("title", ""),
        "finalUrl": result.get("finalUrl", url),
        "consoleErrors": result.get("consoleErrors", []),
        "screenshot_length": result.get("screenshot_length", 0),
        "visionChecked": result.get("visionChecked", False),
        "visionModel": result.get("visionModel", ""),
        "checks": result.get("checks", []),
        "visionError": result.get("visionError"),
        "note": result.get("note"),
        "error": result.get("error"),
        "errorCode": result.get("errorCode"),
    }


# 自动化任务配置缓存(2026-07-24 立,configure_automation_task 配置记录 + 执行结果)
# key=config_id(uuid hex),value={task_id, action, execute, arguments, config_response}
# 2026-11-01 安全强化(补封顶):现读**生产代码零读取点**(只有 tests/test_configure_automation_task_real.py
# 回头读自己那一条)—— 每一枚 `configure_automation_task` 调用都往里塞一份含
# `arguments`(用户原文)的记录且永不出站,所以这一格既是没有上界的内存面,也是
# "用户投喂内容被进程无限期留住"的留存面。真值在 api 层(本表只是配置阶段回执的镜像)
# ⇒ 封顶不改变任何在用行为;测试读自己刚写的那一条,在 512 上限内不受影响。
_AUTOMATION_CONFIGS_MAX_KEYS: Final = 512
_AUTOMATION_CONFIGS_TTL_SECONDS: Final = 24 * 3600.0
_AUTOMATION_CONFIGS: "BoundedTtlDict" = BoundedTtlDict(
    max_keys=_AUTOMATION_CONFIGS_MAX_KEYS,
    ttl_seconds=_AUTOMATION_CONFIGS_TTL_SECONDS,
    slide_on_read=False,
)


async def _tool_configure_automation_task(arguments: dict[str, Any]) -> dict[str, Any]:
    """配置自媒体自动化定时任务并可选立即执行(自研定时任务编排)。

    1. 配置阶段:转发到 api 层 config 端点(koubo_daily/wechat_daily),缓存到 _AUTOMATION_CONFIGS。
    2. 执行阶段(execute=True,默认):按 action 真实执行一次:
       - schedule → 调用 _tool_schedule_task 真实调度
       - dispatch_subagent → 调用 _tool_dispatch_subagent 派发子智能体
       - webhook → httpx POST 到 arguments.webhook_url
    """
    import uuid

    import httpx

    task_id = arguments.get("task_id", "wechat_daily")
    execute = bool(arguments.get("execute", True))
    action = arguments.get("action", "")

    # ===== 配置阶段(保留原有 koubo_daily/wechat_daily config 路径)=====
    config_ok = False
    config_resp: dict[str, Any] = {}
    if task_id in ("koubo_daily", "wechat_daily"):
        hour = int(arguments.get("hour", 9))
        minute = int(arguments.get("minute", 0))
        dry_run = bool(arguments.get("dry_run", True))
        enabled = bool(arguments.get("enabled", True))
        title_template = arguments.get("title_template")
        config_body: dict[str, Any] = {
            "hour": hour, "minute": minute,
            "dry_run": dry_run, "enabled": enabled,
        }
        if title_template:
            config_body["title_template"] = str(title_template)
        url = f"{_get_automation_api_base()}/{task_id}/config"
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                resp = await client.post(url, json=config_body)
                if resp.status_code < 400:
                    data = resp.json()
                    config_resp = data.get("data", data) if isinstance(data, dict) else data
                    config_ok = True
                else:
                    config_resp = {"error": f"api 返回 {resp.status_code}: {resp.text[:200]}"}
        except Exception as e:
            config_resp = {"error": f"配置失败: {type(e).__name__}: {str(e)[:200]}"}
    # 非 koubo_daily/wechat_daily:跳过 api config(仅作为缓存,供 schedule/dispatch/webhook 执行)

    config_id = uuid.uuid4().hex
    _AUTOMATION_CONFIGS[config_id] = {
        "task_id": task_id, "action": action, "execute": execute,
        "arguments": arguments, "config_response": config_resp,
    }

    # ===== 执行阶段 =====
    executed = False
    execution_result: dict[str, Any] = {}
    if execute and action:
        try:
            if action == "schedule":
                execution_result = await _tool_schedule_task(arguments)
                executed = bool(execution_result.get("ok"))
            elif action in ("dispatch_subagent", "orchestrate_agents"):
                execution_result = await _tool_dispatch_subagent(arguments)
                executed = bool(execution_result.get("ok"))
            elif action == "webhook":
                webhook_url = arguments.get("webhook_url", "")
                if not webhook_url:
                    execution_result = {
                        "ok": False, "errorCode": "MISSING_PARAMS",
                        "error": "action=webhook 时 webhook_url 必填",
                    }
                else:
                    # 批 52b:webhook 出站走网络审批门(fail-closed;SSRF 硬防线
                    # 由内网地址不可达兜底,此处补审批语义层)
                    # 批58(十六):拒绝分支带 codex 原因码 + 可读文案。
                    _net_ok = True
                    _net_denial: str | None = None
                    try:
                        from .network_approval import evaluate_network_access_detailed

                        _net_verdict, _net_denial = evaluate_network_access_detailed(
                            webhook_url, reason="tool:webhook"
                        )
                        _net_ok = _net_verdict != "deny"
                    except Exception:  # noqa: BLE001 - 门故障不改变现有行为
                        _net_ok = True
                    if not _net_ok:
                        execution_result = {
                            "ok": False, "errorCode": "NETWORK_APPROVAL_DENIED",
                            "error": "webhook 目标未获网络审批授权",
                            "detail": _network_denial_message(_net_denial, webhook_url),
                            "denialReason": _net_denial,
                        }
                    else:
                        # 2026-10-31 安全强化第 32 批:webhook_url 是外部可控输入,
                        # 而本服务能访问内网 —— "内网地址不可达兜底"不成立。出站前
                        # 过同一把 SSRF 尺并钉定公网 IP(POST 不跟随重定向,只需首跳)。
                        from .screenshot_service import (
                            _validate_url_ssrf,
                            resolve_pinned_target,
                        )

                        _webhook_ok, _webhook_reason = _validate_url_ssrf(webhook_url)
                        _webhook_pinned = (
                            resolve_pinned_target(webhook_url) if _webhook_ok else None
                        )
                        if not _webhook_ok or _webhook_pinned is None:
                            execution_result = {
                                "ok": False, "errorCode": "SSRF_BLOCKED",
                                "error": "webhook 目标不允许访问: "
                                + (_webhook_reason or "无法钉定公网 IP"),
                            }
                            executed = False
                        else:
                            _pinned_url, _orig_host = _webhook_pinned
                            webhook_payload = arguments.get("webhook_payload", arguments)
                            async with httpx.AsyncClient(timeout=15.0) as client:
                                wresp = await client.post(
                                    _pinned_url,
                                    json=webhook_payload,
                                    headers={"Host": _orig_host},
                                    extensions={"sni_hostname": _orig_host},
                                )
                                execution_result = {
                                    "ok": wresp.status_code < 400,
                                    "status_code": wresp.status_code,
                                    "response": wresp.text[:500],
                                }
                                executed = wresp.status_code < 400
            else:
                execution_result = {
                    "ok": False, "errorCode": "INVALID_PARAMS",
                    "error": f"不支持的 action: {action}(schedule/dispatch_subagent/orchestrate_agents/webhook)",
                }
        except Exception as e:
            execution_result = {
                "ok": False, "errorCode": "EXECUTION_EXCEPTION",
                "error": f"执行失败: {type(e).__name__}: {str(e)[:200]}",
            }

    # ok:执行模式下看 executed;纯配置模式看 config_ok(非 koubo/wechat 视为配置通过)
    if execute and action:
        overall_ok = executed
    else:
        overall_ok = config_ok or (task_id not in ("koubo_daily", "wechat_daily"))

    return {
        "ok": overall_ok,
        "configured": config_ok or (task_id not in ("koubo_daily", "wechat_daily")),
        "executed": executed,
        "execution_result": execution_result,
        "config_id": config_id,
        "task_id": task_id,
        "action": action,
    }


async def _tool_vision_analyze(arguments: dict[str, Any]) -> dict[str, Any]:
    """vision_analyze: 图像分析(支持本地文件路径、URL 和 base64)。

    参数优先级: image_path > image_base64 > image_url > image(legacy 兼容)。
    参数:
    - image_path: 本地图片绝对路径(可选,自动转 base64,需在工作区白名单内)
    - image_base64: base64 编码图片(可选)
    - image_url: 图片 URL(可选)
    - image: 图片 URL 或 base64(legacy 兼容,可选)
    - task: 分析任务描述(必填)
    - model: 期望模型(可选,缺省用支持视觉的模型)
    """
    import base64 as _b64
    from pathlib import Path

    from ..core.llm_gateway import llm_gateway

    task = arguments.get("task", "")
    model = arguments.get("model")
    image_path = arguments.get("image_path", "")
    image_base64 = arguments.get("image_base64", "")
    image_url = arguments.get("image_url", "")
    legacy_image = arguments.get("image", "")

    # 解析图片来源,构造 OpenAI vision image_url url
    source = ""
    file_path = ""

    if image_path:
        # 本地文件路径:校验工作区白名单(防 symlink 穿越)
        ok, info = _validate_path_in_workspace(str(image_path))
        if not ok:
            return {
                "tool": "vision_analyze", "ok": False,
                "error": info, "errorCode": "PATH_NOT_IN_WORKSPACE",
            }
        p = Path(info)
        if not p.exists():
            return {
                "tool": "vision_analyze", "ok": False,
                "error": f"文件不存在: {image_path}", "errorCode": "FILE_NOT_FOUND",
            }
        # 文件大小校验(>10MB 拒绝)
        try:
            file_size = p.stat().st_size
        except OSError as e:
            return {
                "tool": "vision_analyze", "ok": False,
                "error": f"读取文件大小失败: {e}", "errorCode": "FILE_NOT_FOUND",
            }
        if file_size > 10 * 1024 * 1024:
            return {
                "tool": "vision_analyze", "ok": False,
                "error": f"图片过大({file_size} bytes > 10MB)", "errorCode": "IMAGE_TOO_LARGE",
            }
        # MIME 推断
        ext = p.suffix.lower()
        mime_map = {
            ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
            ".webp": "image/webp", ".gif": "image/gif",
        }
        mime = mime_map.get(ext)
        if not mime:
            return {
                "tool": "vision_analyze", "ok": False,
                "error": f"不支持的图片格式: {ext}(仅支持 png/jpg/jpeg/webp/gif)",
                "errorCode": "UNSUPPORTED_IMAGE_FORMAT",
            }
        try:
            raw_bytes = p.read_bytes()
        except OSError as e:
            return {
                "tool": "vision_analyze", "ok": False,
                "error": f"读取文件失败: {e}", "errorCode": "FILE_NOT_FOUND",
            }
        b64 = _b64.b64encode(raw_bytes).decode("ascii")
        image_url_value = f"data:{mime};base64,{b64}"
        source = "local_file"
        file_path = str(image_path)
    elif image_base64:
        image_url_value = (
            image_base64 if image_base64.startswith("data:")
            else f"data:image/png;base64,{image_base64}"
        )
        source = "base64"
    elif image_url:
        image_url_value = image_url
        source = "url"
    elif legacy_image:
        image_url_value = legacy_image
        source = "legacy"
    else:
        return {
            "tool": "vision_analyze", "ok": False,
            "error": "image_path / image_base64 / image_url / image 至少需要一个",
        }

    if not task:
        return {"tool": "vision_analyze", "ok": False, "error": "task is required"}

    # 构造 OpenAI vision 格式消息(text + image_url content block)
    # 批 42 接线:data URL 先经 image_preparation 按提示图像预算降采样
    # (遵循统一工程规范;此前原图原样上传,超大图打爆
    # vision 请求或被服务端拒绝;远程 URL 保持原样交由上游拉取)。降采样
    # 失败安全:回退原图,行为与历史一致,不阻塞分析。
    vision_note = ""
    if image_url_value.startswith("data:"):
        try:
            from ..core.image_preparation import (
                detail_limits as _vl,
            )
            from ..core.image_preparation import (
                load_data_url_for_prompt as _vload,
            )

            _detail, _limits = _vl("high")
            _prepared = _vload(image_url_value, _limits)
            if (_prepared.width, _prepared.height) != (
                _prepared.source_width,
                _prepared.source_height,
            ):
                image_url_value = _prepared.into_data_url()
                vision_note = (
                    f"image resized from {_prepared.source_width}x"
                    f"{_prepared.source_height} to {_prepared.width}x"
                    f"{_prepared.height} pixels to fit the prompt image budget"
                )
        except Exception:  # noqa: BLE001 - 降采样失败回退原图
            vision_note = ""
    messages = [
        {
            "role": "user",
            "content": [
                {"type": "text", "text": task},
                {"type": "image_url", "image_url": {"url": image_url_value}},
            ],
        }
    ]
    try:
        result = await llm_gateway.complete(messages, model=model)
        ret: dict[str, Any] = {
            "tool": "vision_analyze",
            "ok": not result.get("error"),
            "analysis": result.get("content", ""),
            "model": result.get("model", model or ""),
            "stub": result.get("stub", False),
            "error": result.get("error_message"),
            "source": source,
        }
        if vision_note:
            ret["resized"] = vision_note
        if file_path:
            ret["file_path"] = file_path
        return ret
    except Exception as e:
        return {
            "tool": "vision_analyze",
            "ok": False,
            "error": str(e)[:200],
            "message": f"vision analysis failed: {type(e).__name__}",
        }


async def _tool_read_image(arguments: dict[str, Any]) -> dict[str, Any]:
    """read_image: 读取工作区内图片并交给**主模型**直接看(多模态工具结果)。

    与 vision_analyze 的分工:后者把图片转交给另一个视觉模型并只回文字结论;
    本工具把图片本体送回当前主模型。返回值刻意只带元数据 + content_id ——
    图片本体经 tool_image_delivery 的有界暂存交付,避免被 call_tool 的 token
    截断护栏截坏、也避免 SSE tool-result 事件承载 10MB data URL。
    """
    from pathlib import Path

    from .tool_image_delivery import prepare_image_file, stash_image

    raw_path = arguments.get("file_path") or ""
    ok, info = _validate_path_in_workspace(str(raw_path))
    if not ok:
        return {
            "tool": "read_image", "ok": False,
            "error": info, "errorCode": "PATH_NOT_ALLOWED",
        }
    path = Path(info)
    denied = _cursorignore_denial(str(path))
    if denied is not None:
        return {"tool": "read_image", "ok": False, **denied}
    if not path.exists() or not path.is_file():
        return {
            "tool": "read_image", "ok": False,
            "error": f"文件不存在: {info}", "errorCode": "FILE_NOT_FOUND",
        }
    prepared, error = prepare_image_file(path)
    if prepared is None or error is not None:
        return {"tool": "read_image", "ok": False, **(error or {})}
    content_id = stash_image(prepared)
    return {
        "tool": "read_image",
        "ok": True,
        "path": str(path),
        "image": {
            "content_id": content_id,
            "media_type": prepared["media_type"],
            "bytes": prepared["bytes"],
            "width": prepared["width"],
            "height": prepared["height"],
            "source_width": prepared["source_width"],
            "source_height": prepared["source_height"],
            "name": prepared["name"],
        },
        "note": "图片本体随本轮 tool 结果之后的一条 user 多模态消息送达;不要安装图像库或生成缩略图来查看",
    }


# ---------------------------------------------------------------------------
# 子智能体派发工具(2026-07-24 新增)
# 让 LLM 在 tool loop 中能自主派发子智能体执行任务
# ---------------------------------------------------------------------------

# 模块级单例 + lazy init(避免循环依赖:agent_orchestrator.py 在模块加载时
# `from .mcp_server import mcp_server`,若本模块顶部反向 import 会触发循环导入)
_orchestrator: "AgentOrchestrator | None" = None


def _get_orchestrator() -> "AgentOrchestrator":
    """Lazy 获取 AgentOrchestrator 单例(避免模块加载时循环导入)。

    agent_orchestrator.py 模块加载时执行 `from .mcp_server import mcp_server`,
    若本模块在顶部反向 import agent_orchestrator 会触发循环导入 → 用 lazy init。
    复用 agent_orchestrator.py 模块级单例(已注册 5 个默认 agent)。
    """
    global _orchestrator
    if _orchestrator is None:
        from .agent_orchestrator import agent_orchestrator as _inst
        _orchestrator = _inst
    return _orchestrator


# ===== D145①(2026-09-29)dispatch_subagent 广告面的唯一派生出口 =====
# 病(取证 docs/AI_CHAT_BENCHMARK_ANALYSIS_V4.md §十一.3 D145 行 + §十 D145 第 2 栏):
# 旧工具描述硬编码 5 个注册表里**根本不存在**的名(code-reviewer/bug-fixer/feature-planner/
# test-writer/refactorer),模型照说明书调用必回 "Agent 不存在"(agent_orchestrator.invoke
# 的 registry.get 落空分支)。三分离口径:**执行名 = 注册表键**,是模型可见的唯一名单;
# 展示名(昵称池 / i18n 角色词)不在这条面上;wire 值一字不动(未知名回包只是**新增**
# availableAgents/errorCode 两个键,既有键名与状态值逐字未变)。
# 判据两条:
#   · 静态面 scripts/check-agent-status-vocabulary-parity.mjs SV4 —— 描述文本里出现的
#     agent 名必须逐个能在注册表解析(把拼接改回硬编码幽灵名 ⇒ 该门必红);
#   · 运行时面 apps/ai-service/tests/test_dispatch_subagent_advertised_names.py ——
#     广告名单必须与注册表现读集合**相等**,注册表增删一档 ⇒ 广告面必须跟随
#     (改回 import 期硬编码清单,该用例必红 —— 反向对照)。
# 不得再抄第二份名字清单(§"两处算同一件事必漂移",本仓记过多次)。
_DISPATCH_SUBAGENT_DESC_CORE = (
    "派发子智能体执行独立任务(子任务分解 / 多视角审查 / 并行执行)。"
    "调用后子智能体独立执行并返回结果,不污染主对话上下文。"
    "唯一入口支持 9 种模式:single(单 agent)/parallel(tasks 并行)/"
    "pipeline(串行流水线)/debate(多轮辩论)/vote(方案投票)/"
    "critique(提案-批判-改进)/decompose(任务自动分解调度)/team(团队并行 + 结构化聚合)/"
    "recursive(材料递归归纳:分片并行 → 聚合 → 超预算再切一层)。"
    "复杂任务按性质自主选择 mode;简单任务直接回答,不要派发。"
)


def _dispatch_subagent_advertised_names() -> list[str]:
    """注册表现读的执行名清单(排序去重)。读不到 ⇒ 空列表,**绝不广告猜出来的名**。"""
    try:
        return sorted(set(_get_orchestrator().registry.names()))
    except Exception as e:  # noqa: BLE001 - 广告面降级为空并点名原因,不静默冒充名单
        logger.warning("dispatch_subagent 广告名注册表现读失败(广告面留空): %s", e)
        return []


def _dispatch_subagent_description() -> str:
    """dispatch_subagent 面向模型的完整描述 = 静态骨架 + 注册表现读名单(每次调用现拼)。"""
    names = _dispatch_subagent_advertised_names()
    if not names:
        return (
            _DISPATCH_SUBAGENT_DESC_CORE
            + "当前注册表读不到可用名单,未知名回包会带 availableAgents 供自纠。"
        )
    return (
        _DISPATCH_SUBAGENT_DESC_CORE
        + "可用 agent 名称(注册表现读):"
        + "、".join(names)
        + "。未知名回包带 availableAgents 供自纠。"
    )


# ===== D145 评审修复轮 1①(2026-09-29)两条广告面必须同源 =====
# 评审判定的第二广告面漏修:`_populate_deferred_schemas()` 在 **import 期**把 `_TOOLS`
# 灌进 `_DEFERRED_TOOL_SCHEMAS`,那里只有静态骨架 ⇒ TOOL_DEFERRAL=on(默认,见
# routers/agents.py:141 `_TOOL_DEFERRAL_SUFFIX` —— 描述被截成"…〔完整参数用 get_tool_schema
# 查询〕")时,模型拿到 80 字符骨架后**只能**经 `get_full_tool_schema()` 反查完整描述,
# 而那条面交回的是 import 期快照 ⇒ 名单退化成 0 个名。实测取证见交付报告"评审修复轮 1"
# 一节(同一次调用里 list_tools 的描述有 10 档、get_full_tool_schema 的有 0 档)。
# 判据必须覆盖门自己产出的形态(§4 圆角那一课),所以两张面**都**走下面这一张 provider 表:
#   · 清单面 MCPServer.list_tools() —— 重建条目时现读;
#   · 反查面 get_full_tool_schema() —— 返回浅拷贝并现读,**绝不**回写注册表
#     (注册表存的是 import 期那一份完整 schema,改写它会让两条面各自漂移,且 deferral
#      的 input_schema 仍是那一份真相)。
# 名单不在这里抄第二份:唯一来源仍是 `_dispatch_subagent_description` → 注册表现读。
_ADVERTISED_DESCRIPTION_PROVIDERS: dict[str, Callable[[], str]] = {
    "orchestrate_agents": _dispatch_subagent_description,
    # 旧名兼容:get_full_tool_schema("dispatch_subagent") 仍返回同一份现读描述。
    "dispatch_subagent": _dispatch_subagent_description,
}


class _ToolSurfaceKwargs(TypedDict, total=False):
    """dispatch_subagent 传给 orchestrator 的工具面收窄参数(键集封闭)。

    为什么必须是 TypedDict 而不是 `dict[str, list[str]]`:两处调用都用星号展开
    (`**surface_extra`)传进 `invoke` / `invoke_parallel`,裸 dict 在 mypy strict 下
    无法证明不含 `session_id` / `progress_callback` 之类的**同一调用里的其它参数**,
    于是把 `list[str]` 硬套到 `str | None`、`Callable[...] | None` 上报 arg-type 红。
    收紧键集后星号展开与签名逐一对得上,不需要忽略注释去放宽判据(§0.2 反过来读:
    修类型缺口,不是关掉门)。
    """

    tool_allow: list[str]
    tool_deny: list[str]


def _dispatch_tool_surface_kwargs(
    arguments: Mapping[str, object],
) -> tuple[_ToolSurfaceKwargs, str | None]:
    """聊天 SSE 把模型入参原样交给 dispatch_subagent。

    allowedTools / disallowedTools 两键都缺时返回空 dict,派发参数与从前相同。
    名单不是字符串数组时返回字段名,调用方回 INVALID_PARAMS,不派发。
    合法时只把真正收窄的键放进 dict。父线程白名单不在这条入参里,
    按 resolve_subagent_tool_surface 的「父级没有白名单」处理。
    """
    if "allowedTools" not in arguments and "disallowedTools" not in arguments:
        return {}, None
    from .subagent_spawn_policy import (
        SubagentToolListError,
        parse_optional_tool_list,
        resolve_subagent_tool_surface,
    )

    try:
        call_allow = (
            parse_optional_tool_list(arguments.get("allowedTools"), "allowedTools")
            if "allowedTools" in arguments
            else None
        )
        call_deny = (
            parse_optional_tool_list(arguments.get("disallowedTools"), "disallowedTools")
            if "disallowedTools" in arguments
            else None
        )
    except SubagentToolListError as err:
        return {}, err.field
    allow, deny = resolve_subagent_tool_surface(None, [], call_allow, call_deny)
    extra: _ToolSurfaceKwargs = {}
    if allow is not None:
        extra["tool_allow"] = allow
    if deny:
        extra["tool_deny"] = deny
    return extra, None


def _orchestration_error(
    mode: str, error: str, error_code: str, **extra: Any
) -> dict[str, Any]:
    """编排失败的结构化回包(不抛异常,与单/并行派发的错误形态一致)。"""
    payload: dict[str, Any] = {
        "tool": "orchestrate_agents",
        "mode": mode,
        "ok": False,
        "status": "failed",
        "error": error,
        "errorCode": error_code,
    }
    payload.update(extra)
    return payload


def _orchestration_agents(
    arguments: Mapping[str, Any],
    *,
    mode: str,
    registry_names: set[str],
    minimum: int = 2,
) -> tuple[list[str], dict[str, Any] | None]:
    """解析并校验 agents 名单(白名单 + 数量上限 + 去重)。"""
    raw = arguments.get("agents")
    if not isinstance(raw, list) or not raw:
        return [], _orchestration_error(
            mode, "agents 必须为非空字符串数组", "INVALID_PARAMS"
        )
    if len(raw) > _ORCHESTRATION_MAX_AGENTS:
        return [], _orchestration_error(
            mode,
            f"agents 最多 {_ORCHESTRATION_MAX_AGENTS} 个(本次 {len(raw)} 个)",
            "INVALID_PARAMS",
        )
    names: list[str] = []
    for i, item in enumerate(raw):
        if not isinstance(item, str) or not item.strip():
            return [], _orchestration_error(
                mode, f"agents[{i}] 须为非空字符串", "INVALID_PARAMS"
            )
        names.append(item.strip())
    if len(set(names)) != len(names):
        return [], _orchestration_error(mode, "agents 不得重复", "INVALID_PARAMS")
    if len(names) < minimum:
        return [], _orchestration_error(
            mode, f"{mode} 至少需要 {minimum} 个 agent", "INVALID_PARAMS"
        )
    unknown = sorted({name for name in names if name not in registry_names})
    if unknown:
        return [], _orchestration_error(
            mode,
            f"Agent 不存在: {', '.join(unknown)}",
            "UNKNOWN_AGENT",
            availableAgents=sorted(registry_names),
        )
    return names, None


async def _run_orchestration_mode(
    *,
    mode: str,
    arguments: Mapping[str, Any],
    emit: Callable[[dict[str, Any]], None],
) -> dict[str, Any]:
    """执行统一多智能体编排(dispatch_subagent 的编排 mode 分支)。

    六种模式全部走既有 AgentOrchestrator 实现,不复制第二套编排逻辑:
    pipeline→run_pipeline / debate→run_debate / vote→run_vote /
    critique→run_critique / decompose→run_decomposed / team→run_with_communication。

    治理与单/并行派发同源:agents 白名单、数量上限、并发信号量、嵌套深度 +1、
    超时、结构化回包。验证失败一律回 ok=False,不抛异常。
    """
    try:
        orchestrator = _get_orchestrator()
        registry_names = set(orchestrator.registry.names())
    except Exception as e:  # noqa: BLE001 - 编排面不可用时结构化降级
        logger.warning("dispatch_subagent 编排注册表不可用(mode=%s): %s", mode, e)
        return _orchestration_error(
            mode, f"编排注册表不可用: {e}", "ORCHESTRATION_UNAVAILABLE"
        )
    task = str(arguments.get("task") or "").strip()
    if not task:
        return _orchestration_error(
            mode, "task 不能为空(描述要解决的问题 / 主题 / 目标)", "MISSING_PARAMS"
        )
    # tasks 只属于并行派发;编排模式误传时明确拒绝,避免静默忽略模型的输入。
    if arguments.get("tasks") is not None:
        return _orchestration_error(
            mode,
            f"mode={mode} 不接受 tasks;并行派发请用 mode=parallel",
            "INVALID_PARAMS",
        )
    # background / 工具面收窄只属于单/并行派发;编排模式的子 agent 工具面由各自定义决定。
    if arguments.get("background"):
        return _orchestration_error(
            mode, "编排模式不支持 background,请直接同步执行", "INVALID_PARAMS"
        )
    if arguments.get("allowedTools") or arguments.get("disallowedTools"):
        return _orchestration_error(
            mode,
            "编排模式不支持 allowedTools/disallowedTools(子 agent 工具面由各自定义决定)",
            "INVALID_PARAMS",
        )
    # 模式专属字段不得串用:静默忽略等于给模型错误暗示。
    if mode == "pipeline" and arguments.get("agents") is not None:
        return _orchestration_error(
            mode, "mode=pipeline 不接受 agents;参与者写在 steps[].agent", "INVALID_PARAMS"
        )
    if mode in ("debate", "vote", "critique", "team") and arguments.get("steps") is not None:
        return _orchestration_error(
            mode, f"mode={mode} 不接受 steps;串行流水线请用 mode=pipeline", "INVALID_PARAMS"
        )
    if mode == "decompose" and (
        arguments.get("agents") is not None or arguments.get("steps") is not None
    ):
        return _orchestration_error(
            mode, "mode=decompose 不接受 agents/steps;参与者由分解器自动分配", "INVALID_PARAMS"
        )
    # recursive 的参与者由材料切片决定,同样不接受手写参与者/步骤。
    if mode == "recursive" and (
        arguments.get("agents") is not None or arguments.get("steps") is not None
    ):
        return _orchestration_error(
            mode,
            "mode=recursive 不接受 agents/steps;参与者由 chunks 切片自动生成",
            "INVALID_PARAMS",
        )
    # chunks 只属于 recursive;其它模式误传时显式拒绝,不静默忽略。
    if arguments.get("chunks") is not None and mode != "recursive":
        return _orchestration_error(
            mode, f"mode={mode} 不接受 chunks(仅 recursive)", "INVALID_PARAMS"
        )
    if arguments.get("max_rounds") is not None and mode not in ("debate", "critique"):
        return _orchestration_error(
            mode, f"mode={mode} 不接受 max_rounds(仅 debate/critique)", "INVALID_PARAMS"
        )
    if arguments.get("strategy") is not None and mode != "decompose":
        return _orchestration_error(
            mode, f"mode={mode} 不接受 strategy(仅 decompose)", "INVALID_PARAMS"
        )
    if arguments.get("aggregation") is not None and mode not in ("team", "recursive"):
        return _orchestration_error(
            mode, f"mode={mode} 不接受 aggregation(仅 team/recursive)", "INVALID_PARAMS"
        )

    agents: list[str] = []
    steps: list[dict[str, Any]] = []
    strategy = "dag"
    if mode in ("debate", "vote", "critique", "team"):
        agents, err = _orchestration_agents(
            arguments,
            mode=mode,
            registry_names=registry_names,
            minimum=1 if mode == "team" else 2,
        )
        if err is not None:
            return err
    elif mode == "pipeline":
        raw_steps = arguments.get("steps")
        if not isinstance(raw_steps, list) or not raw_steps:
            return _orchestration_error(
                mode, "pipeline 需要非空 steps 数组", "INVALID_PARAMS"
            )
        if len(raw_steps) > _ORCHESTRATION_MAX_STEPS:
            return _orchestration_error(
                mode,
                f"steps 最多 {_ORCHESTRATION_MAX_STEPS} 步(本次 {len(raw_steps)} 步)",
                "INVALID_PARAMS",
            )
        for i, item in enumerate(raw_steps):
            if not isinstance(item, dict):
                return _orchestration_error(
                    mode, f"steps[{i}] 须为对象", "INVALID_PARAMS"
                )
            agent_name = str(item.get("agent") or "").strip()
            if not agent_name:
                return _orchestration_error(
                    mode, f"steps[{i}].agent 不能为空", "INVALID_PARAMS"
                )
            if agent_name not in registry_names:
                return _orchestration_error(
                    mode,
                    f"Agent 不存在: {agent_name}",
                    "UNKNOWN_AGENT",
                    availableAgents=sorted(registry_names),
                )
            raw_template = item.get("input_template")
            if raw_template is not None and not isinstance(raw_template, str):
                return _orchestration_error(
                    mode, f"steps[{i}].input_template 须为字符串", "INVALID_PARAMS"
                )
            steps.append({
                "agent": agent_name,
                "input_template": str(raw_template or "{input}"),
            })
    elif mode == "decompose":
        strategy = str(arguments.get("strategy") or "dag").strip().lower()
        if strategy not in _DECOMPOSE_STRATEGIES:
            return _orchestration_error(
                mode,
                f"strategy 非法: {strategy!r},须为 {list(_DECOMPOSE_STRATEGIES)} 之一",
                "INVALID_PARAMS",
            )

    # team 的聚合策略与 decompose 的分解策略是两个语义,各用独立参数,不共用一个枚举。
    # recursive 复用 team 的聚合封闭集(它就是"每层一次 team 聚合")。
    aggregation = "merge"
    if mode in ("team", "recursive"):
        aggregation = str(arguments.get("aggregation") or "merge").strip().lower()
        if aggregation not in _TEAM_AGGREGATIONS:
            return _orchestration_error(
                mode,
                f"aggregation 非法: {aggregation!r},须为 {list(_TEAM_AGGREGATIONS)} 之一",
                "INVALID_PARAMS",
            )

    chunks: list[str] = []
    depth = 1
    max_chars_per_node = 0
    if mode == "recursive":
        # 边界与切分实现都在 agent_teams;本层不复制第二份上限(§0.6)。
        from .agent_teams import RECURSIVE_MAX_DEPTH, RECURSIVE_MIN_CHARS

        raw_chunks = arguments.get("chunks")
        if not isinstance(raw_chunks, list) or not raw_chunks:
            return _orchestration_error(
                mode,
                "mode=recursive 需要 chunks(非空字符串数组:待归纳的材料切片)",
                "MISSING_PARAMS",
            )
        for i, item in enumerate(raw_chunks):
            if not isinstance(item, str) or not item.strip():
                return _orchestration_error(
                    mode, f"chunks[{i}] 须为非空字符串", "INVALID_PARAMS"
                )
        chunks = [str(item) for item in raw_chunks]
        raw_depth = arguments.get("depth")
        if isinstance(raw_depth, bool):
            return _orchestration_error(
                mode, "depth 须为整数,不能是布尔值", "INVALID_PARAMS"
            )
        try:
            depth = int(raw_depth) if raw_depth is not None else 1
        except (TypeError, ValueError):
            return _orchestration_error(mode, "depth 须为整数", "INVALID_PARAMS")
        depth = max(1, min(depth, RECURSIVE_MAX_DEPTH))
        raw_chars = arguments.get("max_chars_per_node")
        if isinstance(raw_chars, bool):
            return _orchestration_error(
                mode, "max_chars_per_node 须为整数,不能是布尔值", "INVALID_PARAMS"
            )
        if raw_chars is not None:
            try:
                max_chars_per_node = int(raw_chars)
            except (TypeError, ValueError):
                return _orchestration_error(
                    mode, "max_chars_per_node 须为整数", "INVALID_PARAMS"
                )
            max_chars_per_node = max(RECURSIVE_MIN_CHARS, min(max_chars_per_node, 64000))

    raw_rounds = arguments.get("max_rounds")
    if isinstance(raw_rounds, bool):
        return _orchestration_error(mode, "max_rounds 须为整数,不能是布尔值", "INVALID_PARAMS")
    try:
        max_rounds = (
            int(raw_rounds)
            if raw_rounds is not None
            else (3 if mode == "debate" else 2)
        )
    except (TypeError, ValueError):
        return _orchestration_error(mode, "max_rounds 须为整数", "INVALID_PARAMS")
    max_rounds = max(1, min(max_rounds, _ORCHESTRATION_MAX_ROUNDS))

    raw_session = arguments.get("session_id")
    session_id = raw_session if isinstance(raw_session, str) and raw_session.strip() else None

    emit({
        "phase": "orchestration_started",
        "mode": mode,
        "agents": agents or [step["agent"] for step in steps],
        "task_preview": task[:200],
    })

    if _SUBAGENT_SEMAPHORE.locked():
        return _orchestration_error(
            mode,
            f"子代理并发数已达上限({_SUBAGENT_MAX_CONCURRENT}),拒绝编排",
            "CONCURRENCY_LIMIT_EXCEEDED",
        )

    # 编排总预算按模式/规模放大:debate 5×3、pipeline 6 步等长任务不再被 300s 误杀。
    # 与 tool_timeout_policy.resolve_tool_timeout_budget 共用同一函数,内外层预算不会打架。
    from app.core.tool_timeout_policy import orchestration_budget_s

    timeout_s = orchestration_budget_s(arguments)
    team_round: Any = None
    recursive_result: dict[str, Any] | None = None
    result: Any = None
    async with _SUBAGENT_SEMAPHORE:
        # 与单/并行派发同一深度语义:编排期间子代理再派发会被深度闸拦住。
        _dtok = _subagent_depth.set(_subagent_depth.get() + 1)
        try:
            if mode == "pipeline":
                result = await asyncio.wait_for(
                    orchestrator.run_pipeline(
                        steps=steps, initial_input=task, session_id=session_id
                    ),
                    timeout=timeout_s,
                )
            elif mode == "debate":
                result = await asyncio.wait_for(
                    orchestrator.run_debate(
                        agents=agents,
                        topic=task,
                        max_rounds=max_rounds,
                        session_id=session_id,
                    ),
                    timeout=timeout_s,
                )
            elif mode == "vote":
                result = await asyncio.wait_for(
                    orchestrator.run_vote(
                        agents=agents, topic=task, session_id=session_id
                    ),
                    timeout=timeout_s,
                )
            elif mode == "critique":
                result = await asyncio.wait_for(
                    orchestrator.run_critique(
                        agents=agents,
                        topic=task,
                        max_rounds=max_rounds,
                        session_id=session_id,
                    ),
                    timeout=timeout_s,
                )
            elif mode == "decompose":
                result = await asyncio.wait_for(
                    orchestrator.run_decomposed(
                        task=task, strategy=strategy, session_id=session_id
                    ),
                    timeout=timeout_s,
                )
            elif mode == "recursive":
                # 与 team 同源:同一条 TeamOrchestrator,只是把"每层一次 run_round"
                # 串成递归;节点预算仍由 subagent_jobs 那一个数兜住。
                from .agent_teams import RECURSIVE_NODE_MAX_CHARS, TeamOrchestrator

                recursive_result = await asyncio.wait_for(
                    TeamOrchestrator(orchestrator).run_recursive(
                        objective=task,
                        chunks=chunks,
                        merge_strategy=cast(Any, aggregation),
                        max_concurrency=_SUBAGENT_MAX_CONCURRENT,
                        depth=depth,
                        max_chars_per_node=max_chars_per_node or RECURSIVE_NODE_MAX_CHARS,
                    ),
                    timeout=timeout_s,
                )
                if recursive_result.get("ok") is False:
                    return _orchestration_error(
                        mode,
                        str(recursive_result.get("error") or "递归分解被拒绝"),
                        str(recursive_result.get("errorCode") or "RECURSIVE_FAILED"),
                        limit=recursive_result.get("limit"),
                    )
                result = None
            else:  # team:fan-out + 结构化聚合(merge/best_of/consensus)
                from .agent_teams import TeamOrchestrator

                team_round = await asyncio.wait_for(
                    TeamOrchestrator(orchestrator).run_round(
                        objective=task,
                        tasks=[
                            {"name": name, "task": f"{task}{_TEAM_OUTPUT_CONTRACT}"}
                            for name in agents
                        ],
                        strategy=cast(Any, aggregation),
                        max_concurrency=min(len(agents), _SUBAGENT_MAX_CONCURRENT),
                    ),
                    timeout=timeout_s,
                )
                result = None
        except TimeoutError:
            return _orchestration_error(
                mode, f"编排超时({timeout_s}s)", "ORCHESTRATION_TIMEOUT"
            )
        except asyncio.CancelledError:
            raise
        except Exception as e:  # noqa: BLE001 - 结构化回包,不把异常抛给工具循环
            logger.warning(
                "dispatch_subagent 编排失败(mode=%s): %s", mode, e, exc_info=True
            )
            return _orchestration_error(mode, str(e), "ORCHESTRATION_FAILED")
        finally:
            _subagent_depth.reset(_dtok)

    if recursive_result is not None:
        # 与 team 同一回包形状:final_output 承载最后一层聚合正文,
        # 中间层只留可判读数(层号 / 成败计数 / 该层正文长度),避免整棵中间树进上下文。
        levels = recursive_result.get("levels") or []
        payload = {
            "tool": "orchestrate_agents",
            "mode": "recursive",
            "ok": True,
            "status": "completed",
            "nodes": recursive_result.get("nodes", 0),
            "depth": recursive_result.get("depth", 1),
            "levels": [
                {
                    "round_index": lv.get("round_index"),
                    "succeeded": lv.get("succeeded"),
                    "failed": lv.get("failed"),
                    "partial": lv.get("partial"),
                    "merged_chars": len(
                        str((lv.get("aggregate") or {}).get("merged_text") or "")
                    ),
                }
                for lv in levels
                if isinstance(lv, dict)
            ],
            "final_output": recursive_result.get("merged_text", ""),
            "summary": (recursive_result.get("final_summary_context") or "")[:500],
            "trace": [{
                "mode": "recursive",
                "depth": recursive_result.get("depth", 1),
                "nodes": recursive_result.get("nodes", 0),
            }],
        }
        emit({
            "phase": "orchestration_done",
            "mode": "recursive",
            "ok": payload["ok"],
            "status": payload["status"],
            "nodes": payload["nodes"],
        })
        return payload

    if team_round is not None:
        # TeamRoundResult 与 OrchestrationResult 统一成同一个回包形状:
        # steps 承载每个贡献者,final_output 承载聚合后的 summary_context。
        team_status = (
            "completed"
            if team_round.succeeded > 0 and team_round.failed == 0
            else "failed"
        )
        payload = {
            "tool": "orchestrate_agents",
            "mode": "team",
            "ok": team_status == "completed",
            "status": team_status,
            "orchestrationId": team_round.round_id,
            "total_duration_ms": round(
                sum(c.duration_ms for c in team_round.contributors), 2
            ),
            "agents": [c.name for c in team_round.contributors],
            "steps": [
                {
                    "agent": c.name,
                    "status": c.status,
                    "duration_ms": c.duration_ms,
                    "output_preview": (c.output or "")[:600],
                    "error": c.error,
                }
                for c in team_round.contributors
            ],
            "final_output": team_round.summary_context,
            "summary": (team_round.summary_context or "")[:500],
            "aggregate": team_round.aggregate,
            "trace": [{
                "strategy": team_round.strategy,
                "succeeded": team_round.succeeded,
                "failed": team_round.failed,
                "partial": team_round.partial,
            }],
        }
        emit({
            "phase": "orchestration_done",
            "mode": "team",
            "ok": payload["ok"],
            "status": payload["status"],
            "total_duration_ms": payload["total_duration_ms"],
        })
        return payload

    if result is None:  # 防御:正常路径必已赋值,不放行"空结果当成功"
        return _orchestration_error(mode, "编排未产出结果", "ORCHESTRATION_FAILED")

    payload = {
        "tool": "orchestrate_agents",
        "mode": mode,
        "ok": result.status == "completed",
        "status": result.status,
        "orchestrationId": result.orchestration_id,
        "total_duration_ms": result.total_duration_ms,
        "agents": [step.agent_name for step in result.steps],
        "steps": [
            {
                "agent": step.agent_name,
                "status": step.status,
                "duration_ms": step.duration_ms,
                # 单步正文只留预览:完整结果由 final_output 承载,避免多份长文膨胀上下文
                "output_preview": (step.output or "")[:600],
                "error": step.error,
            }
            for step in result.steps
        ],
        "final_output": result.final_output,
        "summary": (result.final_output or "")[:500],
        "trace": result.trace,
    }
    emit({
        "phase": "orchestration_done",
        "mode": mode,
        "ok": payload["ok"],
        "status": payload["status"],
        "total_duration_ms": payload["total_duration_ms"],
    })
    return payload


def _settle_dispatch_ticket(ticket_id: str | None, payload: dict[str, Any]) -> None:
    """派工结束写回既有工单账。模拟结果不算成功,不把步骤收成 ready。"""
    if not ticket_id:
        return
    from .work_admission import note_worker_finished

    stub = payload.get("status") == "stub" or payload.get("stub") is True
    note_worker_finished(
        ticket_id,
        ok=bool(payload.get("ok")) and not stub,
        simulation=stub,
    )
    payload["ticketId"] = ticket_id


def _drop_dispatch_ticket(ticket_id: str | None) -> None:
    """用户停止或连接断开:在途工单记 dropped,不留 ready。"""
    if not ticket_id:
        return
    from .work_admission import report_assignment

    report_assignment(ticket_id, "dropped", by="worker")


def _mark_stub_payload(payload: dict[str, Any]) -> dict[str, Any]:
    """任一 worker 是模拟结果时,整包不得再报成功。"""
    results = payload.get("results")
    child_stub = any(
        isinstance(item, dict) and item.get("status") == "stub" for item in results
    ) if isinstance(results, list) else False
    # 统一编排回包用 steps 承载单步结果,与 results 同一判定(不新开一套 stub 语义)。
    steps = payload.get("steps")
    if not child_stub and isinstance(steps, list):
        child_stub = any(
            isinstance(item, dict) and item.get("status") == "stub" for item in steps
        )
    if payload.get("status") == "stub" or payload.get("stub") is True or child_stub:
        payload["ok"] = False
        payload["stub"] = True
        payload["status"] = "stub"
        payload["errorCode"] = "STUB_RESPONSE"
    return payload


def _get_subagent_hook_runtime() -> Any:
    """子代理钩子运行时(惰性单例;构造失败降级为 None,不挡派发)。"""
    global _SUBAGENT_HOOK_RUNTIME
    if _SUBAGENT_HOOK_RUNTIME is None:
        try:
            from ..core.hook_runtime import build_registered_hook_runtime

            _SUBAGENT_HOOK_RUNTIME = build_registered_hook_runtime()
        except Exception as e:  # noqa: BLE001 - 钩子装不上就不装,派发优先
            logger.warning("子代理钩子运行时构造失败(降级,不阻断派发): %s", e)
            _SUBAGENT_HOOK_RUNTIME = False
    return _SUBAGENT_HOOK_RUNTIME or None


async def _run_subagent_hooks(kind_name: str, payload: dict[str, Any]) -> str:
    """跑 subagent_start / subagent_stop(2026-11-21 第 36 项)。

    返回可注入子任务提示词的 additionalContext 拼接串(stop 点恒为空串)。
    语义边界:
    - start 点是**上下文注入面**:钩子给的 additionalContext 只加在子任务正文前,
      不动 resident 前缀缓存段(前缀缓存按字节命中,动了就整段失效);
    - stop 点是**观察面**:结果已定型,不解读 decision/stop,不改写 status/output;
    - 异常/超时一律降级(5s 硬上限),不阻断派发。
    """
    rt = _get_subagent_hook_runtime()
    if rt is None:
        return ""
    try:
        from ..core.hook_runtime import HookKind

        kind = getattr(HookKind, kind_name)
        outcome = await asyncio.wait_for(
            rt.run(kind, payload), timeout=_SUBAGENT_HOOK_TIMEOUT_SECONDS
        )
    except (TimeoutError, asyncio.CancelledError):
        logger.warning("%s 子代理钩子超时/被取消(派发照常继续)", kind_name)
        return ""
    except Exception as e:  # noqa: BLE001 - 钩子异常不阻断派发
        logger.warning("%s 子代理钩子异常(降级): %s", kind_name, e)
        return ""
    contexts = getattr(outcome, "additional_contexts", None) or []
    # 第 37 项:子代理钩子结果也下发 hook.run —— 此前只有 agent_loop 的 12 个挂载点
    # 可见,子代理派发面的钩子失败/超时在面板上完全空白。走同一观察通道
    # (publish_observation,不进 HOOK_EVENTS,防自激);空表不发。
    events_fn = getattr(outcome, "events_as_dicts", None)
    if events_fn is not None:
        try:
            from .hook_engine import hook_engine as _he

            _evts = events_fn()
            if _evts:
                _he.publish_observation(
                    "hook.run",
                    {
                        "session_id": str(payload.get("session_id") or ""),
                        "run_id": str(payload.get("session_id") or payload.get("agent_name") or ""),
                        "tool_name": "orchestrate_agents",
                        "hooks": _evts,
                    },
                )
        except Exception as e:  # noqa: BLE001 - 下行失败不影响派发
            logger.warning("子代理 hook.run 下行失败(降级): %s", e)
    return "\n".join(str(c) for c in contexts if c)


async def _invoke_subagent_for_job(
    agent_name: str, user_input: str, session_id: str | None
) -> dict[str, Any]:
    """后台作业/续跑共用的单子代理调用(并发闸 + 嵌套深度 + 超时同同步路径)。"""
    orchestrator = _get_orchestrator()
    if _SUBAGENT_SEMAPHORE.locked():
        raise RuntimeError(
            f"子代理并发数已达上限({_SUBAGENT_MAX_CONCURRENT}),后台作业未执行"
        )
    async with _SUBAGENT_SEMAPHORE:
        _dtok = _subagent_depth.set(_subagent_depth.get() + 1)
        try:
            _bg_ctx = await _run_subagent_hooks(
                "SUBAGENT_START",
                {
                    "agent_name": agent_name,
                    "mode": "background",
                    "session_id": session_id or "",
                    "depth": _subagent_depth.get(),
                    "task_preview": user_input[:800],
                },
            )
            step_result = await asyncio.wait_for(
                orchestrator.invoke(
                    agent_name=agent_name,
                    user_input=(f"{_bg_ctx}\n\n{user_input}" if _bg_ctx else user_input),
                    session_id=session_id,
                ),
                timeout=_get_subagent_timeout(),
            )
        finally:
            _subagent_depth.reset(_dtok)
        await _run_subagent_hooks(
            "SUBAGENT_STOP",
            {
                "agent_name": agent_name,
                "mode": "background",
                "ok": step_result.status == "completed",
                "needs_help": bool(getattr(step_result, "needs_help", False)),
                "iterations": step_result.iterations,
                "duration_ms": float(getattr(step_result, "duration_ms", 0.0) or 0.0),
                "output_preview": str(step_result.output or "")[:400],
            },
        )
    return {
        "status": step_result.status,
        "output": step_result.output,
        "iterations": step_result.iterations,
        "error": step_result.error,
        "ok": step_result.status == "completed",
    }


async def _tool_subagent_job(arguments: dict[str, Any]) -> dict[str, Any]:
    """subagent_job:后台子代理作业的 list/wait/send 最小闭环(2026-11-14 立)。

    对齐 外部实现 continuable subagent:spawn(dispatch_subagent background=true)立即
    返回 job_id;list/wait 查询;终态后 send 以同一 lineage 续跑(上一轮任务与
    输出作为上下文)。所有权只认宿主注入身份,越权与不存在同形。
    """
    from . import subagent_jobs as jobs_store

    action = str(arguments.get("action") or "list")
    user_id = str(arguments.get("__user_id") or "").strip() or None
    session_id = str(arguments.get("__session_id") or "").strip() or None

    if action == "list":
        try:
            limit = int(arguments.get("limit", 20))
        except (TypeError, ValueError):
            limit = 20
        result = jobs_store.list_jobs(
            user_id=user_id, session_id=session_id, limit=max(1, min(limit, 100))
        )
        return {"tool": "subagent_job", "action": "list", **result}

    job_id = str(arguments.get("job_id") or "").strip()
    if not job_id:
        return {
            "tool": "subagent_job", "ok": False, "errorCode": "MISSING_PARAMS",
            "error": f"{action} 需要 job_id",
        }

    if action == "wait":
        try:
            wait_s = float(arguments.get("wait_s", 30))
        except (TypeError, ValueError):
            wait_s = 30.0
        result = await jobs_store.wait_job(
            job_id,
            user_id=user_id,
            session_id=session_id,
            wait_s=max(1.0, min(wait_s, 300.0)),
        )
        return {"tool": "subagent_job", "action": "wait", **result}

    if action == "send":
        job = jobs_store.get_job(job_id)
        if job is None:
            return {
                "tool": "subagent_job", "ok": False,
                "errorCode": "SUBAGENT_NOT_FOUND", "error": "作业不存在或无权访问",
            }

        def _builder(task_text: str) -> Callable[[], Awaitable[dict[str, Any]]]:
            async def _invoke() -> dict[str, Any]:
                return await _invoke_subagent_for_job(job.name, task_text, job.session_id)

            return _invoke

        result = await jobs_store.send_job(
            job_id,
            str(arguments.get("message") or ""),
            user_id=user_id,
            session_id=session_id,
            invoker_builder=_builder,
            timeout_s=float(_get_subagent_timeout()),
        )
        return {"tool": "subagent_job", "action": "send", **result}

    if action == "cancel":
        result = await jobs_store.cancel_job(
            job_id, user_id=user_id, session_id=session_id
        )
        return {"tool": "subagent_job", "action": "cancel", **result}

    return {
        "tool": "subagent_job", "ok": False, "errorCode": "INVALID_PARAMS",
        "error": f"不支持的 action: {action}(list/wait/send/cancel)",
    }


async def _tool_dispatch_subagent(
    arguments: dict[str, Any],
    progress_callback: Callable[[dict[str, Any]], None] | None = None,
    *,
    host_view: Mapping[str, object] | None = None,
) -> dict[str, Any]:
    """dispatch_subagent: 派发子智能体执行独立任务(单 agent 或并行多 agent)。

    双模式(自研 subagent orchestration):
    - 单 agent 模式(兼容):{name, task, session_id?} → orchestrator.invoke
    - 并行模式:{tasks: [{name, task, context?}, ...], max_concurrency?} →
      orchestrator.invoke_parallel,真实并行派发,互不污染上下文。

    互斥:同时传 name/task 与 tasks → 报错 DUAL_MODE。

    2026-07-30 加固:新增 progress_callback 参数(可选),让调用方(llm.py router)
    能在子任务执行过程中实时推送 subagent_progress SSE 事件,而不是等任务全部完成
    才返回。callback 收到 {phase, agentName, iteration, tool, ok, output_preview}。
    """
    name = arguments.get("name", "")
    task = arguments.get("task", "")
    tasks = arguments.get("tasks")
    max_concurrency = arguments.get("max_concurrency", 5)
    ticket_id: str | None = None

    def _emit(evt: dict[str, Any]) -> None:
        """统一进度事件出口(无 callback 时静默 no-op)"""
        if progress_callback is not None:
            try:
                progress_callback(evt)
            except Exception:  # noqa: BLE001
                # 回调失败不影响主任务执行
                pass

    # 0-6 嵌套深度护栏:顶层 depth=0 → 1(允许),子代理内 → 2(允许),
    # 再嵌套 → 3 拒绝(阻断无限递归派发链)。contextvar 保证跨协程上下文传递。
    current_depth = _subagent_depth.get()
    next_depth = current_depth + 1
    if next_depth > _SUBAGENT_MAX_DEPTH:
        return {
            "tool": "orchestrate_agents", "ok": False,
            "error": (
                f"子代理嵌套深度超过上限({_SUBAGENT_MAX_DEPTH}),"
                f"当前深度 {current_depth},拒绝派发以阻断无限递归"
            ),
            "errorCode": "NESTING_DEPTH_EXCEEDED",
        }
    has_single = bool(name) or bool(task)
    has_tasks = tasks is not None

    # 双模式互斥校验
    if has_single and has_tasks:
        return {
            "tool": "orchestrate_agents", "ok": False,
            "error": "不可同时传 name/task 与 tasks(单 agent 模式与并行模式互斥)",
            "errorCode": "DUAL_MODE",
        }

    surface_extra, surface_field = _dispatch_tool_surface_kwargs(arguments)
    if surface_field is not None:
        return {
            "tool": "orchestrate_agents",
            "ok": False,
            "error": f"{surface_field} 须为非空字符串组成的数组",
            "errorCode": "INVALID_PARAMS",
        }
    if arguments.get("resident_file") is not None and tasks is not None:
        return {
            "tool": "orchestrate_agents", "ok": False,
            "error": "resident_file 只支持单 agent 模式（并行 tasks 不支持）",
            "errorCode": "RESIDENT_UNSUPPORTED_MODE",
        }

    # 主聊天传入宿主视图才准入。不传时保持原执行契约(CLI/调度/既有单测)。
    # 视图由路由按认证会话组装,不从模型 arguments 里取范围。
    if host_view is not None:
        from .work_admission import evaluate_host_view

        admission = evaluate_host_view(host_view)
        if admission.get("runs_worker") is not True:
            reason = str(admission.get("reason") or "not_admitted")
            return {
                "tool": "orchestrate_agents",
                "ok": False,
                "status": "skipped",
                "error": reason,
                "errorCode": reason,
                "admissionKind": admission.get("kind"),
                "wouldAccept": admission.get("would_accept") is True,
            }
        raw_ticket = admission.get("ticket_id")
        ticket_id = raw_ticket if isinstance(raw_ticket, str) else None

    # ===== 统一多智能体编排(2026-11-16):唯一入口的 mode 分支 =====
    # mode 省略 → 保持历史行为(单 agent / tasks 并行);显式编排 mode 才进本分支。
    # 六种编排模式与单/并行共用同一套治理,不再新增平级工具。
    raw_mode = arguments.get("mode")
    if raw_mode is not None and not isinstance(raw_mode, str):
        return {
            "tool": "orchestrate_agents", "ok": False,
            "error": f"mode 须为字符串,收到 {type(raw_mode).__name__}",
            "errorCode": "INVALID_PARAMS",
        }
    mode = raw_mode.strip().lower() if isinstance(raw_mode, str) else ""
    # 省略 mode 时按入参推断,与 tasks/name 的既有推断保持一致:
    # 有 steps → pipeline;有 tasks → parallel;有 name/task → single。
    if not mode and isinstance(arguments.get("steps"), list) and arguments.get("steps"):
        mode = "pipeline"
    if not mode:
        _missing_mode_fields = [
            key
            for key in ("agents", "strategy", "aggregation", "max_rounds")
            if arguments.get(key) is not None
        ]
        if _missing_mode_fields:
            return {
                "tool": "orchestrate_agents", "ok": False,
                "error": (
                    f"传了 {_missing_mode_fields} 但未指定 mode;"
                    "请显式选择 debate/vote/critique/decompose/team/pipeline"
                ),
                "errorCode": "INVALID_PARAMS",
            }
    if mode and mode not in _DISPATCH_MODES:
        return {
            "tool": "orchestrate_agents", "ok": False,
            "error": f"mode 非法: {raw_mode!r},须为 {list(_DISPATCH_MODES)} 之一",
            "errorCode": "INVALID_PARAMS",
        }
    if mode == "single" and has_tasks:
        return {
            "tool": "orchestrate_agents", "ok": False, "mode": "single",
            "error": "mode=single 不接受 tasks;多个独立子任务请用 mode=parallel",
            "errorCode": "INVALID_PARAMS",
        }
    if mode == "parallel" and not has_tasks:
        return {
            "tool": "orchestrate_agents", "ok": False, "mode": "parallel",
            "error": "mode=parallel 需要 tasks 数组",
            "errorCode": "INVALID_PARAMS",
        }
    if mode in ("single", "parallel"):
        # 单/并行只认 name/task/tasks;编排专属字段静默忽略会让模型误以为生效。
        for key in ("agents", "steps", "strategy", "aggregation", "max_rounds"):
            if arguments.get(key) is not None:
                return {
                    "tool": "orchestrate_agents", "ok": False, "mode": mode,
                    "error": f"mode={mode} 不接受 {key};编排模式请显式选 mode",
                    "errorCode": "INVALID_PARAMS",
                }
        if mode == "parallel" and arguments.get("background"):
            return {
                "tool": "orchestrate_agents", "ok": False, "mode": "parallel",
                "error": "mode=parallel 不支持 background;后台执行请用 mode=single",
                "errorCode": "INVALID_PARAMS",
            }
    if mode in _ORCHESTRATION_MODES:
        # 常驻文件只对单 agent 有意义（前缀缓存按单一子代理的会话走）：
        # 编排模式下显式拒绝，绝不静默忽略入参。
        if arguments.get("resident_file") is not None:
            return {
                "tool": "orchestrate_agents", "ok": False, "mode": mode,
                "error": "resident_file 只支持单 agent 模式（编排模式不支持）",
                "errorCode": "RESIDENT_UNSUPPORTED_MODE",
            }
        try:
            orchestrated = await _run_orchestration_mode(
                mode=mode, arguments=arguments, emit=_emit
            )
        except asyncio.CancelledError:
            _drop_dispatch_ticket(ticket_id)
            raise
        except Exception as e:  # noqa: BLE001 - 兜底:任何意外都要结清工单
            logger.warning("orchestrate_agents 执行异常(mode=%s): %s", mode, e, exc_info=True)
            _drop_dispatch_ticket(ticket_id)
            return {
                "tool": "orchestrate_agents", "ok": False, "mode": mode,
                "error": f"编排执行失败: {e}",
                "errorCode": "ORCHESTRATION_FAILED",
            }
        _mark_stub_payload(orchestrated)
        _settle_dispatch_ticket(ticket_id, orchestrated)
        return _truncate_tool_output(
            orchestrated,
            tool_name="orchestrate_agents",
            session_id=arguments.get("session_id"),
        )

    # 并行模式:tasks 数组 → invoke_parallel
    if has_tasks:
        if not isinstance(tasks, list):
            return {
                "tool": "orchestrate_agents", "ok": False,
                "error": "tasks 必须为数组", "errorCode": "INVALID_PARAMS",
            }
        if not tasks:
            return {
                "tool": "orchestrate_agents", "ok": False,
                "error": "tasks 列表为空", "errorCode": "EMPTY_TASKS",
            }
        for i, t in enumerate(tasks):
            if not isinstance(t, dict) or not t.get("name") or not t.get("task"):
                return {
                    "tool": "orchestrate_agents", "ok": False,
                    "error": f"tasks[{i}] 缺少 name 或 task 字段",
                    "errorCode": "INVALID_PARAMS",
                }
        _emit({"phase": "parallel_started", "total": len(tasks), "max_concurrency": max_concurrency})
        try:
            orchestrator = _get_orchestrator()
            if _SUBAGENT_SEMAPHORE.locked():
                _limited = {
                    "tool": "orchestrate_agents", "ok": False, "mode": "parallel",
                    "error": f"子代理并发数已达上限({_SUBAGENT_MAX_CONCURRENT}),拒绝派发",
                    "errorCode": "CONCURRENCY_LIMIT_EXCEEDED",
                }
                _settle_dispatch_ticket(ticket_id, _limited)
                return _limited
            async with _SUBAGENT_SEMAPHORE:
                # 0-6 进入嵌套层级:当前深度 +1,供子代理内再派发时检测
                _dtok = _subagent_depth.set(_subagent_depth.get() + 1)
                try:
                    # 第 36 项:每个子任务的 start 钩子各点一次(只改正文,不动结构字段)。
                    _par_tasks: list[dict[str, Any]] = []
                    for _t in tasks:
                        _pctx = await _run_subagent_hooks(
                            "SUBAGENT_START",
                            {
                                "agent_name": str(_t.get("name") or ""),
                                "mode": "parallel",
                                "session_id": str(arguments.get("session_id") or ""),
                                "depth": _subagent_depth.get(),
                                "task_preview": str(_t.get("task") or "")[:800],
                            },
                        )
                        _par_tasks.append(
                            {**_t, "task": (f"{_pctx}\n\n{_t['task']}" if _pctx else _t["task"])}
                        )
                    result = await asyncio.wait_for(
                        orchestrator.invoke_parallel(
                            tasks=_par_tasks,
                            max_concurrency=max_concurrency,
                            **surface_extra,
                        ),
                        timeout=_get_subagent_timeout(),
                    )
                finally:
                    _subagent_depth.reset(_dtok)
            _par_total = result.get("total", 0)
            _par_succeeded = result.get("succeeded", 0)
            _par_failed = result.get("failed", 0)
            _par_results = result.get("results")
            _par_needs_help = any(
                bool(r.get("needs_help") or r.get("needsHelp"))
                for r in (_par_results if isinstance(_par_results, list) else [])
                if isinstance(r, dict)
            )
            # 第 36 项:stop 钩子逐个子代理收尾(只观察,不改写合计与单条结果)。
            for _r in _par_results if isinstance(_par_results, list) else []:
                if not isinstance(_r, dict):
                    continue
                await _run_subagent_hooks(
                    "SUBAGENT_STOP",
                    {
                        "agent_name": str(_r.get("name") or ""),
                        "mode": "parallel",
                        "ok": str(_r.get("status") or "") == "completed",
                        "needs_help": bool(_r.get("needs_help") or _r.get("needsHelp")),
                        "iterations": int(_r.get("iterations") or 0),
                        "duration_ms": float(_r.get("duration_ms") or 0.0),
                        "output_preview": str(
                            _r.get("output") or _r.get("error") or ""
                        )[:400],
                    },
                )
            # D08②:完成/受阻/求助换手消息 —— 复用既有 subagent_progress 帧的载荷,不新造帧。
            _emit({
                "phase": "parallel_done",
                "total": _par_total,
                "succeeded": _par_succeeded,
                "failed": _par_failed,
                **_subagent_handoff_event(
                    _subagent_handoff_kind(
                        ok=bool(result.get("ok", False)) and not _par_failed,
                        needs_help=_par_needs_help,
                    ),
                    "",
                    result.get("message", "") or f"{_par_succeeded}/{_par_total} 成功",
                ),
            })
            _payload = {
                "tool": "orchestrate_agents", "mode": "parallel",
                "ok": result.get("ok", False),
                "total": result.get("total", 0),
                "succeeded": result.get("succeeded", 0),
                "failed": result.get("failed", 0),
                "results": result.get("results", []),
                "message": result.get("message", ""),
            }
            # D08②:任一份子任务显式求助 ⇒ 结束帧 kind 判为 help(与单模式同口)。
            if _par_needs_help:
                _payload["needs_help"] = True
            _mark_stub_payload(_payload)
            _settle_dispatch_ticket(ticket_id, _payload)
            # 0-6 单子代理输出限额:复用 0-2 截断助手
            return _truncate_tool_output(
                _payload,
                tool_name="orchestrate_agents",
                session_id=arguments.get("session_id"),
            )
        except asyncio.CancelledError:
            _drop_dispatch_ticket(ticket_id)
            raise
        except Exception as e:
            _failed = {
                "tool": "orchestrate_agents", "ok": False, "mode": "parallel",
                "error": str(e), "errorCode": "SUBAGENT_FAILED",
            }
            _settle_dispatch_ticket(ticket_id, _failed)
            return _failed

    # 单 agent 模式(兼容)
    session_id = arguments.get("session_id")
    if not name or not task:
        _missing = {
            "tool": "orchestrate_agents", "ok": False,
            "error": "name and task are required(或传 tasks 数组启用并行模式)",
            "errorCode": "MISSING_PARAMS",
        }
        _settle_dispatch_ticket(ticket_id, _missing)
        return _missing
    # 常驻文件（resident_file）：读一次、租一把、每轮重放同一前缀。
    # 语义对齐 deepseek-tui：同一文件同时只允许一个子代理持有租约。
    resident_prefix = ""
    resident_key: str | None = None
    resident_owner: str | None = None
    raw_resident = arguments.get("resident_file")
    if raw_resident is not None:
        if not isinstance(raw_resident, str) or not raw_resident.strip():
            return {
                "tool": "orchestrate_agents", "ok": False,
                "error": "resident_file 须为非空字符串",
                "errorCode": "INVALID_PARAMS",
            }
        _res_ok, _res_path = _validate_path_in_workspace(raw_resident.strip())
        if not _res_ok:
            return {
                "tool": "orchestrate_agents", "ok": False,
                "error": _res_path,
                "errorCode": "RESIDENT_PATH_NOT_ALLOWED",
            }
        _res_read = read_resident_text(_res_path)
        if not _res_read.get("ok"):
            return {
                "tool": "orchestrate_agents", "ok": False,
                "error": _res_read.get("error") or "常驻文件读取失败",
                "errorCode": _res_read.get("errorCode") or "RESIDENT_READ_FAILED",
                "bytes": _res_read.get("bytes"),
                "limit": _res_read.get("limit"),
            }
        resident_key = normalize_path_key(_res_path)
        resident_owner = f"resident-{os.urandom(6).hex()}"
        _res_lease = resident_lease_registry.acquire(resident_key, resident_owner)
        if not _res_lease.get("ok"):
            return {
                "tool": "orchestrate_agents", "ok": False,
                "error": (
                    f"常驻文件已被 {_res_lease.get('holder')} 独占；"
                    "同一文件同时只允许一个子代理持有租约"
                ),
                "errorCode": _res_lease.get("errorCode") or "RESIDENT_LEASE_HELD",
                "holder": _res_lease.get("holder"),
            }
        resident_prefix = build_resident_prefix(
            display_path=raw_resident.strip(),
            text=str(_res_read.get("text") or ""),
            session_id=session_id,
        )

    # 后台可续跑模式(2026-11-14 立,遵循统一工程规范):
    # 只支持单 agent;立即返回 job_id,父级用 subagent_job(list/wait/send)闭环。
    if bool(arguments.get("background")):
        if has_tasks:
            return {
                "tool": "orchestrate_agents", "ok": False, "mode": "background",
                "error": "background 模式只支持单 agent(name/task),不支持 tasks 并行数组",
                "errorCode": "BACKGROUND_PARALLEL_UNSUPPORTED",
            }
        from . import subagent_jobs as jobs_store

        _bg_session = (
            str(arguments.get("__session_id") or session_id or "").strip() or None
        )
        _bg_user = str(arguments.get("__user_id") or "").strip() or None
        _context_mode = str(arguments.get("context_mode") or "spawn").strip().lower()
        _parent_job_id = str(arguments.get("parent_job_id") or "").strip() or None
        _seed = jobs_store.prepare_context_seed(
            context_mode=_context_mode,
            parent_job_id=_parent_job_id,
            user_id=_bg_user,
            session_id=_bg_session,
        )
        if not _seed.get("ok"):
            return {
                "tool": "orchestrate_agents",
                "ok": False,
                "mode": "background",
                **{k: v for k, v in _seed.items() if k != "ok"},
            }
        _effective_task = str(_seed.get("prefix") or "") + resident_prefix + task

        async def _invoke() -> dict[str, Any]:
            try:
                return await _invoke_subagent_for_job(
                    name, _effective_task, session_id
                )
            finally:
                if resident_key is not None and resident_owner is not None:
                    resident_lease_registry.release(resident_key, resident_owner)

        started = await jobs_store.start_job(
            name=name,
            task=_effective_task,
            user_id=_bg_user,
            session_id=_bg_session,
            invoker=_invoke,
            timeout_s=float(_get_subagent_timeout()),
            parent_job_id=_parent_job_id,
            context_mode=_context_mode,
        )
        if not started.get("ok"):
            return {"tool": "orchestrate_agents", "mode": "background", **started}
        _job = started["job"]
        # 工单不在此结算:后台作业仍在跑,结算权在整个作业结束(与同步路径同义)。
        return _truncate_tool_output(
            {
                "tool": "orchestrate_agents",
                "ok": True,
                "mode": "background",
                "agent": name,
                "job_id": _job["job_id"],
                "lineage_id": _job["lineage_id"],
                "status": _job["status"],
                "context_mode": _job.get("context_mode", "spawn"),
                "fork_depth": _job.get("fork_depth", 0),
                "message": (
                    "后台子智能体已启动。用 subagent_job(action='wait', job_id=...) "
                    "等待终态,或 action='list' 查看;终态后 action='send' 可续跑同一任务线。"
                ),
            },
            tool_name="orchestrate_agents",
            session_id=session_id,
        )

    _emit({"phase": "single_started", "agentName": name})
    try:
        orchestrator = _get_orchestrator()
        if _SUBAGENT_SEMAPHORE.locked():
            _limited = {
                "tool": "orchestrate_agents", "ok": False, "mode": "single",
                "error": f"子代理并发数已达上限({_SUBAGENT_MAX_CONCURRENT}),拒绝派发",
                "errorCode": "CONCURRENCY_LIMIT_EXCEEDED",
            }
            _settle_dispatch_ticket(ticket_id, _limited)
            return _limited
        async with _SUBAGENT_SEMAPHORE:
            # 0-6 进入嵌套层级:当前深度 +1,供子代理内再派发时检测
            _dtok = _subagent_depth.set(_subagent_depth.get() + 1)
            try:
                # 第 36 项:start 钩子的上下文只加在正文前,resident 前缀逐字留给前缀缓存。
                _sg_ctx = await _run_subagent_hooks(
                    "SUBAGENT_START",
                    {
                        "agent_name": name,
                        "mode": "single",
                        "session_id": session_id or "",
                        "depth": _subagent_depth.get(),
                        "task_preview": task[:800],
                    },
                )
                step_result = await asyncio.wait_for(
                    orchestrator.invoke(
                        agent_name=name,
                        user_input=(
                            resident_prefix
                            + (f"{_sg_ctx}\n\n" if _sg_ctx else "")
                            + task
                        ),
                        session_id=session_id,
                        **surface_extra,
                    ),
                    timeout=_get_subagent_timeout(),
                )
            finally:
                _subagent_depth.reset(_dtok)
                if resident_key is not None and resident_owner is not None:
                    resident_lease_registry.release(resident_key, resident_owner)
        _single_ok = step_result.status == "completed"
        _single_needs_help = bool(getattr(step_result, "needs_help", False))
        # 第 36 项:stop 钩子只观察(结果已定型,不改写 status/output)。
        await _run_subagent_hooks(
            "SUBAGENT_STOP",
            {
                "agent_name": name,
                "mode": "single",
                "ok": _single_ok,
                "needs_help": _single_needs_help,
                "iterations": step_result.iterations,
                "duration_ms": float(getattr(step_result, "duration_ms", 0.0) or 0.0),
                "output_preview": str(
                    step_result.output if _single_ok else (step_result.error or step_result.output)
                    or ""
                )[:400],
            },
        )
        # D08②:完成/受阻/求助换手消息 —— 复用既有 subagent_progress 帧的载荷,不新造帧。
        _emit({
            "phase": "single_done",
            "agentName": name,
            "iterations": step_result.iterations,
            "ok": _single_ok,
            **_subagent_handoff_event(
                _subagent_handoff_kind(ok=_single_ok, needs_help=_single_needs_help),
                name,
                step_result.output if _single_ok else (step_result.error or step_result.output),
                token_usage=getattr(step_result, "token_usage", None),
            ),
        })
        _payload = {
            "tool": "orchestrate_agents", "mode": "single",
            "agent": name,
            "task": task,
            "status": step_result.status,
            "output": step_result.output,
            "duration_ms": step_result.duration_ms,
            "iterations": step_result.iterations,
            "error": step_result.error,
            "ok": step_result.status == "completed",
        }
        # D08②:子代理显式求助位 —— 仅在置位时加键,供 subagent_end 帧的 kind 判为 help。
        if _single_needs_help:
            _payload["needs_help"] = True
        _mark_stub_payload(_payload)
        _settle_dispatch_ticket(ticket_id, _payload)
        # D145①:未知名回包补 availableAgents —— 撞"Agent 不存在"后调用方(模型)能
        # 自我纠正,而不是照猜再撞第二次。判据与 invoke 的落空同源(registry.get 为空);
        # 对拿不到 registry 的替身(既有测试的 _FakeOrchestrator)不判也不加键 ——
        # **纯加键**:status/error 等 wire 值一字未动(动值域属另一票)。
        _reg = getattr(orchestrator, "registry", None)
        if _reg is not None:
            try:
                _known = _reg.get(name)
            except Exception:  # noqa: BLE001 - registry 形态读不到 ⇒ 不猜,不加假名单
                _known = True
            if _known is None:
                _payload["errorCode"] = "AGENT_NOT_FOUND"
                _payload["availableAgents"] = sorted(set(_reg.names()))
        # 0-6 单子代理输出限额:复用 0-2 截断助手
        return _truncate_tool_output(
            _payload,
            tool_name="orchestrate_agents",
            session_id=arguments.get("session_id"),
        )
    except asyncio.CancelledError:
        _drop_dispatch_ticket(ticket_id)
        raise
    except Exception as e:
        _failed = {
            "tool": "orchestrate_agents", "ok": False, "mode": "single",
            "error": str(e), "errorCode": "SUBAGENT_FAILED",
        }
        _settle_dispatch_ticket(ticket_id, _failed)
        return _failed


# ===== D08①(2026-10-25):团队共享任务列表(子 agent 可认领/更新条目)=====
# 派发面原本是"派发-回收"一次性往返,子 agent 之间没有共同的事实源:谁领了哪条、
# 做到哪一步,只能靠各自的回包倒推。这里补一张**每队一份**的条目表作为共享事实源,
# 子 agent 认领/更新都写同一张表,回包即当前条目状态。
#
# 边界(照实写,不夸大):表在**进程内**共享 —— 与 dispatch_subagent 同进程的子 agent
# 派发面天然可见;跨进程/跨节点要照 `artifacts_store` 那份 Redis 化另立一票,
# 本条不拿进程内实现冒充分布式共享。
# SSE 口径:票面硬约束「复用既有 subagent_* 帧族、禁新帧族」⇒ 本条**不新造帧**,
# 看板状态一律走工具回包,不抢 subagent_progress / subagent_end 两个既有帧。
_TEAM_TASK_STATUS: Final = ("pending", "claimed", "done", "blocked")
_TEAM_TASK_BOARD_LIMIT: Final = 500
_TEAM_TASK_BOARD: dict[str, dict[str, dict[str, Any]]] = {}
# 2026-11-01 安全强化:每队那张表有 500 条上限,但**队数本身**此前没有 ——
# team_id 由工具入参决定,一个账号可以不断开新队,每队最多 500 枚任务字典
# ⇒ 外层无界 × 内层封顶 = 可放大的内存面。封顶后按"最没用的先逐出":
# 空表 → 闲置超 24h 的表 → 插入序最旧,且**只在越限时动手**(越限前行为一字不变)。
_TEAM_BOARD_MAX_TEAMS: Final = 128
_TEAM_BOARD_IDLE_SECONDS: Final = 24 * 3600.0
_TEAM_TASK_LOCK = asyncio.Lock()
team_board_evictions = 0


def _team_board_freshness(board: dict[str, dict[str, Any]]) -> float:
    """表里最新一条的时间戳(epoch 秒);解析不出/空表 ⇒ 0(视作最可逐出)。"""
    from datetime import datetime

    newest = 0.0
    for task in board.values():
        for field in ("updatedAt", "claimedAt", "createdAt"):
            raw = task.get(field) if isinstance(task, dict) else None
            if not isinstance(raw, str) or not raw:
                continue
            try:
                parsed = datetime.fromisoformat(raw.replace("Z", "+00:00"))
            except ValueError:
                continue
            stamp = parsed.timestamp()
            if stamp > newest:
                newest = stamp
    if not board:
        return 0.0
    return newest


def _prune_team_boards() -> None:
    """越过队数上限时才逐出;逐出顺序:空表 → 闲置 → 插入序最旧。"""
    global team_board_evictions
    if len(_TEAM_TASK_BOARD) < _TEAM_BOARD_MAX_TEAMS:
        return
    import time as _time

    now = _time.time()
    stale = [
        team_id
        for team_id, board in _TEAM_TASK_BOARD.items()
        if (now - _team_board_freshness(board)) >= _TEAM_BOARD_IDLE_SECONDS
    ]
    for team_id in stale:
        _TEAM_TASK_BOARD.pop(team_id, None)
        team_board_evictions += 1
    while len(_TEAM_TASK_BOARD) >= _TEAM_BOARD_MAX_TEAMS:
        oldest = next(iter(_TEAM_TASK_BOARD))
        _TEAM_TASK_BOARD.pop(oldest, None)
        team_board_evictions += 1


def _team_task_board(team_id: str, owner: str = "") -> dict[str, dict[str, Any]]:
    """AIS-109:看板按**宿主主体**分命名空间 —— 旧码只用模型自报的 team_id 分键,
    缺省 `default` 就是一张全平台共用的表,role=0 可枚举/篡改所有人的任务。宿主
    注入的 `__user_id` 非空时拼进键;**展示与报错仍用 team_id**,不把主体 id 泄给
    模型。无宿主身份(进程内/开发态)保持旧键,不改变既有调用方。
    """
    _prune_team_boards()
    key = f"{owner}::{team_id}" if owner else team_id
    return _TEAM_TASK_BOARD.setdefault(key, {})


def _team_task_now() -> str:
    """条目时间戳(与 D08② 换手事件同一口径:UTC ISO8601)。"""
    from datetime import UTC, datetime

    return datetime.now(UTC).isoformat()


_TEAM_TASK_MAX_DEPS: Final = 20
_TEAM_TASK_MAX_SCOPES: Final = 20


def _team_task_str_list(
    raw: object, field: str, limit: int
) -> tuple[list[str] | None, dict[str, Any] | None]:
    """把模型给的字符串数组归一(去空白、去重保序、限量);非法值结构化拒绝。"""
    if raw is None:
        return None, None
    if not isinstance(raw, list):
        return None, {
            "ok": False, "errorCode": "INVALID_PARAMS",
            "error": f"{field} 必须是字符串数组",
        }
    if len(raw) > limit:
        return None, {
            "ok": False, "errorCode": "INVALID_PARAMS",
            "error": f"{field} 最多 {limit} 项",
        }
    out: list[str] = []
    for item in raw:
        if not isinstance(item, str) or not item.strip():
            return None, {
                "ok": False, "errorCode": "INVALID_PARAMS",
                "error": f"{field} 每项必须是非空字符串",
            }
        out.append(item.strip())
    return list(dict.fromkeys(out)), None


def _team_task_would_cycle(
    board: dict[str, dict[str, Any]], task_id: str, depends_on: list[str]
) -> bool:
    """依赖环判定:从新依赖集合出发沿 depends_on 上溯,能回到 task_id 即成环。"""
    stack = list(depends_on)
    seen: set[str] = set()
    while stack:
        current = stack.pop()
        if current == task_id:
            return True
        if current in seen:
            continue
        seen.add(current)
        entry = board.get(current)
        if entry is not None:
            stack.extend(entry.get("depends_on") or [])
    return False


def _team_task_validate_dependencies(
    board: dict[str, dict[str, Any]], task_id: str, depends_on: list[str]
) -> dict[str, Any] | None:
    """依赖合法性:自依赖/不存在/成环一律整条拒绝(不静默丢弃)。"""
    for dep in depends_on:
        if dep == task_id:
            return {
                "ok": False, "errorCode": "TASK_DEPENDENCY_SELF",
                "error": "条目不能依赖自身",
            }
        if dep not in board:
            return {
                "ok": False, "errorCode": "TASK_NOT_FOUND",
                "error": f"依赖条目 {dep} 不存在",
                "missing_dependency": dep,
            }
    if task_id and _team_task_would_cycle(board, task_id, depends_on):
        return {
            "ok": False, "errorCode": "TASK_DEPENDENCY_CYCLE",
            "error": "依赖关系会形成环",
        }
    return None


def _team_task_blockers(
    board: dict[str, dict[str, Any]], entry: dict[str, Any]
) -> list[str]:
    """未完成的直接前置(缺失的依赖也按未完成处理,宁可挡住不放过)。"""
    return [
        dep
        for dep in entry.get("depends_on") or []
        if (board.get(dep) or {}).get("status") != "done"
    ]


def _team_task_scopes_overlap(left: str, right: str) -> bool:
    """规范化路径前缀是否相交(同 外部实现 scopesOverlap:相等或互为目录前缀)。"""
    left = left.rstrip("/")
    right = right.rstrip("/")
    return (
        left == right
        or left.startswith(f"{right}/")
        or right.startswith(f"{left}/")
    )


def _team_task_view(
    board: dict[str, dict[str, Any]], entry: dict[str, Any]
) -> dict[str, Any]:
    """条目视图:原字段 + 派生态(ready/blocked_by/文件触碰提示)。

    派生态只读、不回写条目;写范围重叠提示只和 `claimed`(进行中)的兄弟条目比,
    与 外部实现 `projectTaskView` 只比 in_progress 同义。
    """
    view = dict(entry)
    blockers = _team_task_blockers(board, entry)
    view["blocked_by"] = blockers
    view["ready"] = entry.get("status") == "pending" and not blockers
    warnings: list[str] = []
    scopes = entry.get("write_scopes") or []
    if scopes:
        for other in board.values():
            if other.get("id") == entry.get("id"):
                continue
            if other.get("status") != "claimed":
                continue
            other_scopes = other.get("write_scopes") or []
            if any(
                _team_task_scopes_overlap(left, right)
                for left in scopes
                for right in other_scopes
            ):
                warnings.append(f"write scopes overlap with {other.get('id')}")
    view["write_scope_warnings"] = warnings
    return view


def _team_task_stale(entry: dict[str, Any], expected_revision: object) -> dict[str, Any] | None:
    """CAS:调用方带了 expected_revision 且与当前 revision 不符 → 整条拒绝。"""
    if expected_revision is None:
        return None
    if not isinstance(expected_revision, (str, int, float)):
        return {
            "ok": False, "errorCode": "INVALID_PARAMS",
            "error": "expected_revision 必须是整数",
        }
    try:
        expected = int(expected_revision)
    except (TypeError, ValueError):
        return {
            "ok": False, "errorCode": "INVALID_PARAMS",
            "error": "expected_revision 必须是整数",
        }
    current = int(entry.get("revision", 1))
    if expected != current:
        return {
            "ok": False, "errorCode": "TASK_STALE_REVISION",
            "error": f"条目 {entry.get('id')} 已被并发修改(revision {current},期望 {expected})",
            "revision": current,
            "task": dict(entry),
        }
    return None


def _team_task_add(
    team_id: str,
    title: str,
    *,
    detail: str = "",
    created_by: str = "",
    owner: str = "",
    depends_on: list[str] | None = None,
    write_scopes: list[str] | None = None,
) -> dict[str, Any]:
    """新增一条待办(进入 pending,谁都可领);依赖/写范围可选。"""
    board = _team_task_board(team_id, owner)
    if len(board) >= _TEAM_TASK_BOARD_LIMIT:
        return {
            "ok": False, "errorCode": "BOARD_FULL",
            "error": f"团队 {team_id} 任务表已达上限({_TEAM_TASK_BOARD_LIMIT})",
        }
    import uuid

    deps = list(depends_on or [])
    dependency_error = _team_task_validate_dependencies(board, "", deps)
    if dependency_error is not None:
        return {**dependency_error, "tool": "team_task", "team_id": team_id}

    now = _team_task_now()
    entry: dict[str, Any] = {
        "id": uuid.uuid4().hex[:12],
        "title": str(title),
        "detail": str(detail or ""),
        "status": "pending",
        "claimed_by": "",
        "created_by": str(created_by or ""),
        "created_ts": now,
        "updated_ts": now,
        "note": "",
        # 依赖/CAS/写范围(2026-11-14 立,遵循统一工程规范):
        # revision 从 1 起,每次成功 mutation +1;depends_on 未 done 时不可 claim;
        # write_scopes 只做重叠提示,不阻断。
        "revision": 1,
        "depends_on": deps,
        "write_scopes": list(write_scopes or []),
    }
    board[entry["id"]] = entry
    return {
        "ok": True, "tool": "team_task", "team_id": team_id,
        "task": _team_task_view(board, entry),
    }


def _team_task_claim(
    team_id: str,
    task_id: str,
    agent_id: str,
    *,
    owner: str = "",
    expected_revision: object = None,
) -> dict[str, Any]:
    """独占认领:依赖未完成/已被他人领走/已结束都会拒绝并回带现状。"""
    if not agent_id:
        return {
            "ok": False, "errorCode": "MISSING_PARAMS",
            "error": "claim 需要 agent_id(认领者身份)",
        }
    board = _team_task_board(team_id, owner)
    entry = board.get(task_id)
    if entry is None:
        return {
            "ok": False, "errorCode": "TASK_NOT_FOUND",
            "error": f"团队 {team_id} 内没有条目 {task_id}",
        }
    stale_error = _team_task_stale(entry, expected_revision)
    if stale_error is not None:
        return {**stale_error, "tool": "team_task", "team_id": team_id}

    # 依赖闸:任何直接前置未 done 都不可认领(和 外部实现 taskReady 同义)。
    blockers = _team_task_blockers(board, entry)
    if blockers:
        return {
            "ok": False, "errorCode": "TASK_BLOCKED",
            "error": f"条目 {task_id} 的前置未完成: {', '.join(blockers)}",
            "blocked_by": blockers,
            "task": _team_task_view(board, entry),
        }

    holder = entry.get("claimed_by") or ""
    # 生命周期优先于持有者判定:已完结/已受阻的条目谁都不可再领(领了也没人更新,只会污染看板)。
    # 先判 closed 再判 holder —— 否则"他人已做完的条目"会被报成"被他人领着",把"已完结"
    # 这条更要紧的信息盖掉。
    if entry.get("status") in ("done", "blocked"):
        return {
            "ok": False, "errorCode": "TASK_CLOSED",
            "error": f"条目 {task_id} 已处于 {entry.get('status')},不可再认领",
            "claimed_by": holder,
            "task": dict(entry),
        }
    if holder and holder != agent_id:
        return {
            "ok": False, "errorCode": "ALREADY_CLAIMED",
            "error": f"条目 {task_id} 已被 {holder} 认领",
            "claimed_by": holder,
            "task": dict(entry),
        }
    entry["claimed_by"] = agent_id
    entry["status"] = "claimed"
    entry["revision"] = int(entry.get("revision", 1)) + 1
    entry["updated_ts"] = _team_task_now()
    return {
        "ok": True, "tool": "team_task", "team_id": team_id,
        "task": _team_task_view(board, entry),
    }


def _team_task_update(
    team_id: str, task_id: str, agent_id: str, *, status: str | None = None,
    note: str | None = None, owner: str = "", depends_on: list[str] | None = None,
    write_scopes: list[str] | None = None, expected_revision: object = None,
) -> dict[str, Any]:
    """更新条目:只有持有者可改;status 非法值整条拒绝(不静默吞掉)。"""
    if not agent_id:
        return {
            "ok": False, "errorCode": "MISSING_PARAMS",
            "error": "update 需要 agent_id(认领者身份)",
        }
    if status is not None and status not in _TEAM_TASK_STATUS:
        return {
            "ok": False, "errorCode": "INVALID_STATUS",
            "error": f"status 必须是 {list(_TEAM_TASK_STATUS)} 之一,实得 {status!r}",
        }
    board = _team_task_board(team_id, owner)
    entry = board.get(task_id)
    if entry is None:
        return {
            "ok": False, "errorCode": "TASK_NOT_FOUND",
            "error": f"团队 {team_id} 内没有条目 {task_id}",
        }
    stale_error = _team_task_stale(entry, expected_revision)
    if stale_error is not None:
        return {**stale_error, "tool": "team_task", "team_id": team_id}
    if depends_on is not None:
        dependency_error = _team_task_validate_dependencies(board, task_id, depends_on)
        if dependency_error is not None:
            return {**dependency_error, "tool": "team_task", "team_id": team_id}
    holder = entry.get("claimed_by") or ""
    if holder != agent_id:
        return {
            "ok": False, "errorCode": "FORBIDDEN",
            "error": f"条目 {task_id} 的持有者是 {holder or '(无人认领)'},非本人不得更新",
            "claimed_by": holder,
            "task": dict(entry),
        }
    if status is not None:
        entry["status"] = status
    if note is not None:
        entry["note"] = str(note)[:500]
    if depends_on is not None:
        entry["depends_on"] = list(depends_on)
    if write_scopes is not None:
        entry["write_scopes"] = list(write_scopes)
    entry["revision"] = int(entry.get("revision", 1)) + 1
    entry["updated_ts"] = _team_task_now()
    return {
        "ok": True, "tool": "team_task", "team_id": team_id,
        "task": _team_task_view(board, entry),
    }


def _team_task_list(team_id: str, *, owner: str = "") -> dict[str, Any]:
    """整表快照(按创建序;只读,不改任何条目)。"""
    board = _team_task_board(team_id, owner)
    return {
        "ok": True, "tool": "team_task", "team_id": team_id,
        "total": len(board),
        "tasks": [_team_task_view(board, t) for t in board.values()],
    }


async def _tool_team_task(arguments: dict[str, Any]) -> dict[str, Any]:
    """team_task:团队共享任务列表(add/claim/update/list)。

    与 dispatch_subagent 的关系:派发是一次性"派发-回收",本表给同一次协作里的多个
    子 agent 一个共同事实源 —— 领了哪条、做到哪一步写同一张表,谁都能 list 读到。
    认领是 check-and-set(持锁),并发抢同一条必有一个拿到 ALREADY_CLAIMED。
    """
    action = arguments.get("action", "")
    team_id = str(arguments.get("team_id") or "default")
    agent_id = str(arguments.get("agent_id") or "")
    task_id = str(arguments.get("task_id") or "")
    # 依赖/CAS/写范围(2026-11-14):字段级校验先做,不持锁;依赖存在性与成环
    # 判定在锁内(要读整表)。
    depends_on, depends_error = _team_task_str_list(
        arguments.get("depends_on"), "depends_on", _TEAM_TASK_MAX_DEPS
    )
    if depends_error is not None:
        return {**depends_error, "tool": "team_task", "team_id": team_id}
    write_scopes, scopes_error = _team_task_str_list(
        arguments.get("write_scopes"), "write_scopes", _TEAM_TASK_MAX_SCOPES
    )
    if scopes_error is not None:
        return {**scopes_error, "tool": "team_task", "team_id": team_id}
    expected_revision = arguments.get("expected_revision")
    # AIS-109:看板归属取宿主注入的主体(LLM 不可控),模型自报的 team_id 只做展示分栏。
    owner = str(arguments.get("__user_id") or "").strip()
    # 全表操作串行化:claim 的"读-判-写"必须原子,否则并发下两人都能领到同一条。
    async with _TEAM_TASK_LOCK:
        if action == "add":
            title = str(arguments.get("title") or "")
            if not title:
                return {
                    "tool": "team_task", "ok": False, "errorCode": "MISSING_PARAMS",
                    "error": "add 需要 title",
                }
            return _team_task_add(
                team_id, title,
                detail=str(arguments.get("detail") or ""),
                created_by=agent_id,
                owner=owner,
                depends_on=depends_on,
                write_scopes=write_scopes,
            )
        if action == "claim":
            if not task_id:
                return {
                    "tool": "team_task", "ok": False, "errorCode": "MISSING_PARAMS",
                    "error": "claim 需要 task_id",
                }
            return _team_task_claim(
                team_id, task_id, agent_id, owner=owner,
                expected_revision=expected_revision,
            )
        if action == "update":
            if not task_id:
                return {
                    "tool": "team_task", "ok": False, "errorCode": "MISSING_PARAMS",
                    "error": "update 需要 task_id",
                }
            _status = arguments.get("status")
            return _team_task_update(
                team_id, task_id, agent_id,
                status=str(_status) if _status is not None else None,
                note=arguments.get("note"),
                owner=owner,
                depends_on=depends_on,
                write_scopes=write_scopes,
                expected_revision=expected_revision,
            )
        if action == "list":
            return _team_task_list(team_id, owner=owner)
    return {
        "tool": "team_task", "ok": False, "errorCode": "INVALID_PARAMS",
        "error": f"不支持的 action: {action}(add/claim/update/list)",
    }


async def _tool_terminal(arguments: dict[str, Any]) -> dict[str, Any]:
    """terminal:长驻交互式终端(open/send/keys/paste/mouse/snapshot/search/read/wait_for/signal/resize/eof/close/list)。

    2026-11-14 立,遵循统一工程规范。与 run_command 的差别是**同一进程
    跨多次调用**:open 后可用 send 分步输入、keys 发控制键(Tab/Esc/方向键/Ctrl 组合;
    程序点过 `DECSET 1`(DECCKM)后方向键/Home/End 自动改发 SS3 应用形态,回执 `app_cursor`
    如实说明这次用的是哪套编码)、
    read 增量取输出、wait_for 等到提示符/关键字出现(命中/超时/已退出三态)、signal 中断、
    resize 改窗口尺寸、eof 送输入结束让程序按 EOF 自行收尾(之后 send/keys 显式拒
    TERMINAL_STDIN_CLOSED)、close 收尾。`paste` 是**整段多行粘贴**(不追加回车、不逐行
    执行);程序开了 bracketed paste(DECSET 2004)时自动用 `ESC[200~…ESC[201~` 包裹,回执
    里的 `bracketed` 如实说明这次包没包。`mouse` 把一次鼠标事件当输入字节上报给真 tty 程序
    (vim/htop 的鼠标交互):程序必须先用 `DECSET 1000/1002/1003` 请求鼠标,编码按它点的
    1006/1005/1015 选(回执里的 `mouse_mode`/`encoding` 就是实际用的那一种);坐标是 1 基单元格。
    `snapshot` 回**屏幕快照**(剥掉转义序列的纯文本,
    只要末尾 max_lines 行,truncated 说明还有更早的行),按**当前屏面**取:主屏与 alt 屏
    (vim/htop 切屏)互不混入,回执的 `alt_screen` 说明现在在哪一块屏;`search` 在同一份归一文本里按行
    检索(scrollback search,支持 regex/ignore_case,命中回 line_no/text/match)。open 还可带
    `cols`/`rows` 直接**开在**目标尺寸(真终端本就该在启动时定尺寸;先按 120×30 起再 resize
    会让 TUI 首屏白排一遍)。
    权限:admin-only + 高危审批(与 run_command 同档);cwd 必须落在工作区白名单内;
    子进程环境走 sandbox 严档白名单,不整份继承宿主环境(PTY 后端在此之上补 TERM/COLORTERM
    默认值 —— 真 tty 缺 TERM 会退化成 dumb 终端)。
    """
    from . import interactive_terminal as term

    action = str(arguments.get("action") or "").strip()
    user_id = str(arguments.get("__user_id") or "").strip() or None
    session_id = str(arguments.get("__session_id") or "").strip() or None
    if not user_id and not session_id:
        return {
            "tool": "terminal", "ok": False,
            "errorCode": "TERMINAL_NO_IDENTITY",
            "error": "无宿主会话身份,拒绝打开或访问终端",
        }

    if action == "open":
        command = str(arguments.get("command") or "").strip() or term.default_shell()
        cwd_raw = str(arguments.get("cwd") or "").strip()
        if not cwd_raw:
            roots = _get_workspace_roots()
            cwd_raw = roots[0] if roots else os.getcwd()
        ok, resolved = _validate_path_in_workspace(cwd_raw)
        if not ok:
            return {
                "tool": "terminal", "ok": False,
                "errorCode": "PATH_NOT_ALLOWED", "error": resolved,
            }
        env_raw = arguments.get("env")
        env_extra = (
            {str(k): str(v) for k, v in env_raw.items()}
            if isinstance(env_raw, dict)
            else None
        )
        result = await asyncio.to_thread(
            term.open_terminal,
            command=command,
            cwd=resolved,
            user_id=user_id,
            session_id=session_id,
            env_extra=env_extra,
            # 尺寸原样交给模块判(非整数/越界由 _normalize_size 单一出口拒)——
            # 工具层再抄一份 int() 判断只会造出第二个真相源。
            cols=arguments.get("cols"),
            rows=arguments.get("rows"),
        )
        return {"tool": "terminal", "action": "open", **result}

    if action == "list":
        result = await asyncio.to_thread(
            term.list_terminals, user_id=user_id, session_id=session_id
        )
        return {"tool": "terminal", "action": "list", **result}

    terminal_id = str(arguments.get("terminal_id") or "").strip()
    if not terminal_id:
        return {
            "tool": "terminal", "ok": False, "errorCode": "MISSING_PARAMS",
            "error": f"{action or '该操作'} 需要 terminal_id",
        }

    if action == "send":
        text = arguments.get("input")
        if not isinstance(text, str):
            return {
                "tool": "terminal", "ok": False, "errorCode": "INVALID_PARAMS",
                "error": "send 需要字符串 input",
            }
        result = await asyncio.to_thread(
            term.send_terminal,
            terminal_id,
            text,
            user_id=user_id,
            session_id=session_id,
            enter=bool(arguments.get("enter", True)),
        )
        return {"tool": "terminal", "action": "send", **result}

    if action == "keys":
        keys_raw = arguments.get("keys")
        if isinstance(keys_raw, str):
            keys = [k for k in keys_raw.replace(",", " ").split() if k]
        elif isinstance(keys_raw, list):
            keys = [str(k) for k in keys_raw]
        else:
            keys = []
        if not keys:
            return {
                "tool": "terminal", "ok": False, "errorCode": "INVALID_PARAMS",
                "error": "keys 需要键名(字符串或数组),如 [\"up\",\"tab\",\"escape\"]",
            }
        result = await asyncio.to_thread(
            term.send_terminal_keys,
            terminal_id,
            keys,
            user_id=user_id,
            session_id=session_id,
        )
        return {"tool": "terminal", "action": "keys", **result}

    if action == "paste":
        content = arguments.get("text")
        if content is None:
            content = arguments.get("input")
        if not isinstance(content, str) or not content:
            return {
                "tool": "terminal", "ok": False, "errorCode": "INVALID_PARAMS",
                "error": "paste 需要非空字符串 text(多行内容整段粘贴,不逐行执行)",
            }
        result = await asyncio.to_thread(
            term.paste_terminal,
            terminal_id,
            content,
            user_id=user_id,
            session_id=session_id,
        )
        return {"tool": "terminal", "action": "paste", **result}

    if action == "mouse":
        mods_raw = arguments.get("modifiers")
        if isinstance(mods_raw, str):
            mods = [m for m in mods_raw.replace(",", " ").split() if m]
        elif isinstance(mods_raw, list):
            mods = [str(m) for m in mods_raw]
        else:
            mods = []
        result = await asyncio.to_thread(
            term.mouse_terminal,
            terminal_id,
            event=str(arguments.get("event") or "press"),
            button=arguments.get("button"),
            x=arguments.get("x", 1),
            y=arguments.get("y", 1),
            modifiers=mods,
            user_id=user_id,
            session_id=session_id,
        )
        return {"tool": "terminal", "action": "mouse", **result}

    if action == "snapshot":
        try:
            max_lines = int(arguments.get("max_lines", 200))
        except (TypeError, ValueError):
            max_lines = 200
        result = await asyncio.to_thread(
            term.snapshot_terminal,
            terminal_id,
            user_id=user_id,
            session_id=session_id,
            max_lines=max_lines,
        )
        return {"tool": "terminal", "action": "snapshot", **result}

    if action == "search":
        pattern = arguments.get("pattern")
        if not isinstance(pattern, str) or not pattern:
            return {
                "tool": "terminal", "ok": False, "errorCode": "INVALID_PARAMS",
                "error": "search 需要非空字符串 pattern",
            }
        try:
            max_matches = int(arguments.get("max_matches", 20))
        except (TypeError, ValueError):
            max_matches = 20
        result = await asyncio.to_thread(
            term.search_terminal,
            terminal_id,
            pattern=pattern,
            user_id=user_id,
            session_id=session_id,
            regex=bool(arguments.get("regex", False)),
            ignore_case=bool(arguments.get("ignore_case", False)),
            max_matches=max_matches,
        )
        return {"tool": "terminal", "action": "search", **result}

    if action == "read":
        try:
            since_seq = int(arguments.get("since_seq", 0))
        except (TypeError, ValueError):
            since_seq = 0
        try:
            wait_s = float(arguments.get("wait_s", 1.0))
        except (TypeError, ValueError):
            wait_s = 1.0
        try:
            max_chars = int(arguments.get("max_chars", 8000))
        except (TypeError, ValueError):
            max_chars = 8000
        result = await asyncio.to_thread(
            term.read_terminal,
            terminal_id,
            user_id=user_id,
            session_id=session_id,
            since_seq=max(0, since_seq),
            wait_s=max(0.0, min(wait_s, 10.0)),
            max_chars=max(1, min(max_chars, term.MAX_READ_CHARS)),
        )
        return {"tool": "terminal", "action": "read", **result}

    if action == "wait_for":
        pattern = arguments.get("pattern")
        if not isinstance(pattern, str) or not pattern:
            return {
                "tool": "terminal", "ok": False, "errorCode": "INVALID_PARAMS",
                "error": "wait_for 需要非空字符串 pattern",
            }
        try:
            since_seq = int(arguments.get("since_seq", 0))
        except (TypeError, ValueError):
            since_seq = 0
        try:
            timeout_s = float(arguments.get("timeout_s", 10.0))
        except (TypeError, ValueError):
            timeout_s = 10.0
        try:
            max_chars = int(arguments.get("max_chars", 8000))
        except (TypeError, ValueError):
            max_chars = 8000
        result = await asyncio.to_thread(
            term.wait_terminal,
            terminal_id,
            pattern=pattern,
            user_id=user_id,
            session_id=session_id,
            since_seq=max(0, since_seq),
            timeout_s=max(0.0, min(timeout_s, term.MAX_WAIT_S)),
            max_chars=max(1, min(max_chars, term.MAX_READ_CHARS)),
            regex=bool(arguments.get("regex", False)),
            # plain=按**归一文本**判断(TUI 把提示符拆在几条颜色序列之间时,原文匹配不到)。
            plain=bool(arguments.get("plain", False)),
        )
        return {"tool": "terminal", "action": "wait_for", **result}

    if action == "signal":
        result = await asyncio.to_thread(
            term.signal_terminal,
            terminal_id,
            signal_name=str(arguments.get("signal") or "interrupt"),
            user_id=user_id,
            session_id=session_id,
        )
        return {"tool": "terminal", "action": "signal", **result}

    if action == "resize":
        try:
            # 经 str() 收敛:工具入参可能是 JSON 数字也可能是字符串;None → "None" 走 ValueError,
            # 非数值同档显式拒(不把脏值喂给内核)。
            cols = int(str(arguments.get("cols")).strip())
            rows = int(str(arguments.get("rows")).strip())
        except (TypeError, ValueError):
            return {
                "tool": "terminal", "ok": False, "errorCode": "INVALID_PARAMS",
                "error": "resize 需要整数 cols 与 rows",
            }
        result = await asyncio.to_thread(
            term.resize_terminal,
            terminal_id,
            cols=cols,
            rows=rows,
            user_id=user_id,
            session_id=session_id,
        )
        return {"tool": "terminal", "action": "resize", **result}

    if action == "eof":
        result = await asyncio.to_thread(
            term.eof_terminal,
            terminal_id,
            user_id=user_id,
            session_id=session_id,
        )
        return {"tool": "terminal", "action": "eof", **result}

    if action == "close":
        result = await asyncio.to_thread(
            term.close_terminal,
            terminal_id,
            user_id=user_id,
            session_id=session_id,
        )
        return {"tool": "terminal", "action": "close", **result}

    return {
        "tool": "terminal", "ok": False, "errorCode": "INVALID_PARAMS",
        "error": (
            f"不支持的 action: {action}"
            "(open/send/keys/paste/mouse/snapshot/search/eof/read/wait_for/signal/resize/close/list)"
        ),
    }


async def _tool_session_search(arguments: dict[str, Any]) -> dict[str, Any]:
    """session_search:跨会话全文检索(只读)。

    遵循统一工程规范):
    - 授权只认宿主注入的 `__user_id`(模型自报无效);命中过滤写在 SQL 里;
    - **始终省略调用方会话**(`__session_id`),与 外部实现 一致;
    - 可显式 `thread_id` 限定单个会话,但属主不符与"不存在"同形(不做存在性预言机);
    - 无身份(未绑用户的 dev 通道)直接拒绝,不退回全量检索。
    """
    query = str(arguments.get("query") or "").strip()
    if not query:
        return {
            "tool": "session_search", "ok": False, "errorCode": "MISSING_PARAMS",
            "error": "session_search 需要 query(非空检索词)",
        }
    try:
        limit = int(arguments.get("limit", 10))
    except (TypeError, ValueError):
        limit = 10
    limit = max(1, min(limit, 50))
    thread_id = str(arguments.get("thread_id") or "").strip() or None
    caller_user = str(arguments.get("__user_id") or "").strip()
    caller_thread = str(arguments.get("__session_id") or "").strip() or None

    if not caller_user:
        return {
            "tool": "session_search", "ok": False,
            "errorCode": "SESSION_SEARCH_UNAUTHORIZED",
            "error": "无宿主身份,拒绝跨会话检索",
        }

    # 懒导入:routers.sessions 依赖 app 装配,模块顶层导入会引入启动环。
    from app.routers.sessions import get_session_store

    store = get_session_store()
    if thread_id is not None:
        thread = store.get_thread(thread_id)
        owner = (thread.metadata or {}).get("userId") if thread is not None else None
        if thread is None or owner != caller_user:
            return {
                "tool": "session_search", "ok": False,
                "errorCode": "SESSION_SEARCH_UNAUTHORIZED",
                "error": "无权检索该会话",
                "thread_id": thread_id,
            }

    hits = store.full_text_search(
        query,
        thread_id=thread_id,
        limit=limit,
        owner_user_id=caller_user,
        # 限定单会话时无需排除;全库检索时始终省略调用方会话。
        exclude_thread_id=None if thread_id else caller_thread,
    )
    results: list[dict[str, Any]] = []
    for hit in hits:
        thread = store.get_thread(hit.thread_id)
        results.append({
            "thread_id": hit.thread_id,
            "title": thread.title if thread is not None else "",
            "item_type": hit.item_type,
            "seq": hit.seq,
            "snippet": hit.snippet,
            "score": hit.score,
        })
    return {
        "tool": "session_search",
        "ok": True,
        "query": query,
        "fts_enabled": bool(store.fts_enabled),
        "total": len(results),
        "hits": results,
    }


# ---------------------------------------------------------------------------
# 扩展工具(2026-07-24 新增,自研核心能力)
# 6 个工具:fetch_url / image_generation / review_pr /
#          summarize_artifacts / schedule_task / proactive_suggestion
# ---------------------------------------------------------------------------

# 会话 artifacts 持久化(Redis hash TTL 7d,进程重启不丢;Redis 不可用降级进程内)。
# _ARTIFACTS_CACHE 保留为 artifacts_store._fallback_cache 的别名引用,向后兼容现有测试
# (test_mcp_server.py 直接读写 _ARTIFACTS_CACHE);_tool_summarize_artifacts 改用 _load_artifacts。
from .artifacts_store import _fallback_cache as _ARTIFACTS_CACHE

# 2026-09-10:F401 会把「仅被测试/外部引用」的再导出判为未使用并**直接删除**
# (本次债务收敛时就误删过本别名,导致 tests/test_artifacts_store.py 收集失败)。
# `__all__` 是 ruff 认可的「这是有意的再导出」信号,在此显式声明以锁定该兼容契约。
__all__ = ["_ARTIFACTS_CACHE"]

# 财务部板块插件(RP-46,2026-11-12 立):AI 一键代账/一键报税。
# 描述文案单源在 finance_tools(与 D09 专家包共用,§0.6 不写第二份);
# 纯计算 + tmp/artifacts 产物 ⇒ 与 generate_report 同档,不入 _ADMIN_ONLY_TOOLS。
# (isort 落点:同模块语句按首名 ai_* 排在 create_* 之前;finance_tools 语句在段尾)
from ..tools import (  # noqa: E402
    ai_bookkeeping as _ai_bookkeeping,
)

# 人事部→财务部 AI 交割(2026-11-13 立):生成某月薪资的财务交割凭证(payroll_handoff_tools,
# 经 internal 凭证腿调 apps/api POST /api/hr-payroll/handoff;create_automation 同路线)
from ..tools import (  # noqa: E402
    ai_payroll_handoff as _ai_payroll_handoff,
)

# 财务部五腿扩展(2026-11-13 立):一键报销 / 社保医保精算 / 个税专项附加。
# 实现分文件(单一职责),描述文案单源在各工具文件(与 D09 专家包共用,§0.6 不写第二份);
# 纯计算 + tmp/artifacts 产物 ⇒ 与 ai_bookkeeping 同档,不入 _ADMIN_ONLY_TOOLS。
from ..tools import (  # noqa: E402
    ai_reimbursement as _ai_reimbursement,
)
from ..tools import (  # noqa: E402
    ai_tax_filing as _ai_tax_filing,
)

# G3 Beyond-Coding 泛化(2026-10-30 立):统一交付物工具(artifact_tools,
# payload 落 tmp/artifacts 白名单目录 + 元数据经 artifacts_store 挂会话附件)
from ..tools import (  # noqa: E402
    create_artifact as _create_artifact,
)

# G2 Automations 产品闭环(2026-10-30 立):对话式创建定时自动化(automation_tools,
# 经 internal 凭证腿调 apps/api POST /api/automations;edu 工具同路线)
from ..tools import (  # noqa: E402
    create_automation as _create_automation,
)
from ..tools import (
    document_tables as _document_tables,
)
from ..tools import (
    extract_document_assets as _extract_document_assets,
)

# P0 新增工具(chart_tools / document_tools,零新依赖,2026-09-01 竞品对齐补齐)
# 延迟导入避免启动期探测;工具内部异常已自兜底返回结构化错误,不抛给 MCP 层
from ..tools import (  # noqa: E402
    generate_chart as _generate_chart,
)

# PROJECT_PLAN #81 最小一环:报表模板生成器(report_tools,同 chart 的零依赖路线)
from ..tools import (  # noqa: E402
    generate_report as _generate_report,
)

# D07 残余②:「/init 式 AGENTS.md」能力接入(实现已入库,此前未注册 ⇒ 外部不可调用)
from ..tools import (
    init_agents_md as _init_agents_md,
)
from ..tools import (
    parse_document as _parse_document,
)

# G1(2026-11-14,遵循统一工程规范):xlsx 公式重算/校验。
# 零新增依赖(zipfile+ElementTree),逐格 provenance + 依赖图 + 结构化错误。
from ..tools import (
    sheet_formula_eval as _sheet_formula_eval,
)
from ..tools import (
    sheet_formula_validate as _sheet_formula_validate,
)
from ..tools import (  # noqa: E402
    social_insurance_calc as _social_insurance_calc,
)
from ..tools import (  # noqa: E402
    special_deduction_calc as _special_deduction_calc,
)

# 人事部 AI 工具(2026-11-21 实装):员工自助 4 枚 + 月度算薪 1 枚。
# 自助四枚只走本人作用域端点(/mine*、/my-*),身份票主体 = 宿主注入的 __user_id;
# hr_payroll_calc 是管理侧算薪,权限 hr:payroll:manage 由 apps/api RBAC 逐请求现问
# (与 ai_payroll_handoff 同口径,不入 _ADMIN_ONLY_TOOLS:对话链 user_role 默认 0,
# 入档等于把管理员也挡在门外,见 image_generation 的历史结论)。
from ..tools import (  # noqa: E402
    hr_my_attendance as _hr_my_attendance,
)
from ..tools import (  # noqa: E402
    hr_my_leaves as _hr_my_leaves,
)
from ..tools import (  # noqa: E402
    hr_my_payroll as _hr_my_payroll,
)
from ..tools import (  # noqa: E402
    hr_my_payroll_periods as _hr_my_payroll_periods,
)
from ..tools import (  # noqa: E402
    hr_payroll_calc as _hr_payroll_calc,
)
from ..tools import (  # noqa: E402
    hr_insurance_readiness as _hr_insurance_readiness,
)
# 动作型财务/人事工具(2026-11-23 立):一枚工具 + action 路由表,见 api_ops_common
from ..tools import (  # noqa: E402
    finance_ledger_ops as _finance_ledger_ops,
)
from ..tools import (  # noqa: E402
    finance_tax_ops as _finance_tax_ops,
)
from ..tools import (  # noqa: E402
    hr_lifecycle_ops as _hr_lifecycle_ops,
)
from ..tools import (  # noqa: E402
    hr_payout_ops as _hr_payout_ops,
)
from ..tools.finance_ops_tools import (  # noqa: E402
    FINANCE_LEDGER_DESCRIPTION,
    FINANCE_TAX_DESCRIPTION,
)
from ..tools.hr_ops_tools import (  # noqa: E402
    HR_LIFECYCLE_DESCRIPTION,
    HR_PAYOUT_DESCRIPTION,
)

# 财务部插件描述常量(RP-46):与上方 ai_* import 同源,文案单源在 finance_tools
from ..tools.finance_tools import (  # noqa: E402
    AI_BOOKKEEPING_DESCRIPTION,
    AI_TAX_FILING_DESCRIPTION,
)

# 人事部→财务部交割描述常量(2026-11-13 立):文案单源在 payroll_handoff_tools
from ..tools.payroll_handoff_tools import (  # noqa: E402
    PAYROLL_HANDOFF_DESCRIPTION,
)

# 人事部自助/算薪描述常量(2026-11-21 实装):文案单源在 hr_tools
from ..tools.hr_tools import (  # noqa: E402
    HR_INSURANCE_READINESS_DESCRIPTION,
    HR_MY_ATTENDANCE_DESCRIPTION,
    HR_MY_LEAVES_DESCRIPTION,
    HR_MY_PAYROLL_DESCRIPTION,
    HR_MY_PAYROLL_PERIODS_DESCRIPTION,
    HR_PAYROLL_CALC_DESCRIPTION,
)

# 财务部五腿扩展描述常量(2026-11-13):文案单源在各工具文件
from ..tools.reimbursement_tools import (  # noqa: E402
    AI_REIMBURSEMENT_DESCRIPTION,
)
from ..tools.social_insurance_tools import (  # noqa: E402
    SOCIAL_INSURANCE_DESCRIPTION,
)
from ..tools.special_deduction_tools import (  # noqa: E402
    SPECIAL_DEDUCTION_DESCRIPTION,
)


async def _init_agents_md_guarded(arguments: dict[str, Any]) -> dict[str, Any]:
    """MCP 面入口:workspace_root 必须先过写路径白名单(D07 残余②)。

    工具本体只保证 output_path 落在调用方给的 workspace_root 内;workspace_root
    本身若不受限,普通用户即可指定任意目录写 AGENTS.md。这里复用写路径单一权威源
    (``_validate_write_path_in_workspace``:白名单根 + symlink 解析 + 敏感目录黑名单),
    把根收进进程白名单/会话附加根之后才下传。
    """
    raw_root = arguments.get("workspace_root")
    root = str(raw_root).strip() if raw_root is not None else ""
    if not root:
        return await _init_agents_md(arguments)
    ok, info = _validate_write_path_in_workspace(root)
    if not ok:
        return {
            "tool": "init_agents_md",
            "ok": False,
            "errorCode": "PERMISSION_DENIED",
            "message": info,
        }
    return await _init_agents_md({**arguments, "workspace_root": info})


from ..tools.web_crawl_tools import (
    crawl_site as _crawl_site,
)
from ..tools.web_crawl_tools import (
    extract_web as _extract_web,
)

# Web 网络抓取(Firecrawl Scrape/Map/Crawl/Extract 极致融合, 2026-09)
from ..tools.web_crawl_tools import (  # noqa: E402
    fetch_readable as _fetch_readable,
)
from ..tools.web_crawl_tools import (
    map_site as _map_site,
)
from .artifacts_store import (  # noqa: E402
    load_artifacts as _load_artifacts,
)

# 进程内调度任务列表(schedule_task 用,内存镜像;Redis 为持久化真相源)
# 2026-11-01 安全强化(补镜像封顶):原先每条任务(含 `prompt` / `agent_tools` /
# `webhook_url` 等用户原文)append 后**永不出队**,而现读**生产代码零读取点**
# (只有 tests/test_mcp_server.py 清它并断言自己刚写的那一条)—— 真相源是
# Redis + task_scheduler,本表既不被生产读也不被淘汰 ⇒ 纯积累面。
# 逐出只发生在**越限**时(越限前行为一字不变,测试的"写一条读到一条"仍在 512 内),
# 且丢条数必须可观测:静默丢是另一种失效形。
_SCHEDULED_TASKS: list[dict[str, Any]] = []
_SCHEDULED_TASKS_MAX_MIRROR: Final = 512
#: 被逐出镜像的累计条数(只报数,不参与任何判定;读不到即 0 是真的 0)
scheduled_tasks_mirror_drops: int = 0


def _remember_scheduled_task(task: dict[str, Any]) -> None:
    """把任务记进内存镜像,并在越限时从**最旧**一端逐出。"""
    global scheduled_tasks_mirror_drops
    _SCHEDULED_TASKS.append(task)
    overflow = len(_SCHEDULED_TASKS) - _SCHEDULED_TASKS_MAX_MIRROR
    if overflow > 0:
        del _SCHEDULED_TASKS[:overflow]
        scheduled_tasks_mirror_drops += overflow

# 调度任务 Redis 持久化层(2026-07-24 立,遵循统一工程规范)
# key 规范:mcp:schedule:<task_id> hash,字段见 _SCHEDULE_REDIS_FIELDS
import logging as _schedule_logging
from datetime import UTC

logger = _schedule_logging.getLogger(__name__)
_SCHEDULE_REDIS_PREFIX = "mcp:schedule:"
_SCHEDULE_REDIS_FIELDS = (
    "task_id", "name", "prompt", "schedule", "run_at", "cron",
    "interval_seconds", "agent_tools", "next_run_at", "status",
    "created_at", "last_run_at", "last_result", "webhook_url",
)
# 进程内 Redis 客户端单例(同步,线程安全;None 表示 Redis 不可用,降级内存)
_SCHEDULE_REDIS: Any = None
_SCHEDULE_REDIS_CHECKED = False


def _get_schedule_redis() -> Any:
    """返回调度任务 Redis 同步客户端,不可用返回 None(降级内存模式)。"""
    global _SCHEDULE_REDIS, _SCHEDULE_REDIS_CHECKED
    if _SCHEDULE_REDIS_CHECKED:
        return _SCHEDULE_REDIS
    _SCHEDULE_REDIS_CHECKED = True
    from app.core.config import settings

    url = settings.schedule_redis_url or settings.redis_url
    try:
        import redis

        # protocol=2 强制 RESP2:redis-py 8.x 默认 RESP3(HELLO 3 协商),
        # 老 Redis/Memurai 4.x 不支持会 unknown command HELLO(同 im_bridge)
        client = redis.Redis.from_url(url, decode_responses=True, protocol=2, socket_connect_timeout=2)
        client.ping()
        _SCHEDULE_REDIS = client
        logger.info("[schedule_task] Redis 连接成功: %s", url)
    except Exception as e:
        _SCHEDULE_REDIS = None
        logger.warning("[schedule_task] Redis 不可用,降级内存模式: %s", e)
    return _SCHEDULE_REDIS


def _serialize_task_field(key: str, value: Any) -> str:
    """序列化任务字段为 Redis hash 字符串(list/dict/数字 → JSON,字符串原样)。"""
    if key in ("agent_tools", "interval_seconds"):
        import json as _json

        return _json.dumps(value)
    return str(value) if value is not None else ""


def _deserialize_task(data: dict[str, str]) -> dict[str, Any]:
    """反序列化 Redis hash → task dict(agent_tools/interval_seconds 还原为原类型)。"""
    import json as _json

    task: dict[str, Any] = {}
    for key, raw in data.items():
        if key in ("agent_tools", "interval_seconds"):
            try:
                task[key] = _json.loads(raw)
            except (TypeError, ValueError):
                task[key] = raw
        else:
            task[key] = raw
    return task


def _persist_task_to_redis(task: dict[str, Any]) -> bool:
    """持久化任务到 Redis hash,成功返回 True;Redis 不可用返回 False(调用方降级内存)。"""
    client = _get_schedule_redis()
    tid = task.get("task_id", "")
    if not tid or client is None:
        return False
    mapping = {
        k: _serialize_task_field(k, task.get(k, "" if k != "agent_tools" else []))
        for k in _SCHEDULE_REDIS_FIELDS
        if k in task or k in ("agent_tools",)
    }
    try:
        client.hset(_SCHEDULE_REDIS_PREFIX + tid, mapping=mapping)
        return True
    except Exception as e:
        logger.warning("[schedule_task] Redis 持久化失败: %s", e)
        return False


def _load_task_from_redis(task_id: str) -> dict[str, Any] | None:
    """从 Redis 加载单个任务,不存在或 Redis 不可用返回 None。"""
    client = _get_schedule_redis()
    if client is None:
        return None
    try:
        data = client.hgetall(_SCHEDULE_REDIS_PREFIX + task_id)
    except Exception as e:
        logger.warning("[schedule_task] Redis 读取失败: %s", e)
        return None
    return _deserialize_task(data) if data else None


def _load_pending_tasks_from_redis() -> list[dict[str, Any]]:
    """扫描所有 mcp:schedule:* 任务记录(供 ai-service 启动时重新注册)。"""
    client = _get_schedule_redis()
    if client is None:
        return []
    tasks: list[dict[str, Any]] = []
    try:
        for key in client.scan_iter(_SCHEDULE_REDIS_PREFIX + "*"):
            data = client.hgetall(key)
            if data:
                tasks.append(_deserialize_task(data))
    except Exception as e:
        logger.warning("[schedule_task] Redis 扫描失败: %s", e)
    return tasks


def _update_schedule_task_status(
    task_id: str, status: str, **fields: Any
) -> bool:
    """局部更新任务状态字段,成功返回 True;Redis 不可用返回 False(调用方降级内存)。"""
    client = _get_schedule_redis()
    if client is None:
        return False
    mapping = {"status": status}
    for k, v in fields.items():
        mapping[k] = _serialize_task_field(k, v) if k in ("agent_tools", "interval_seconds") else (str(v) if v is not None else "")
    try:
        client.hset(_SCHEDULE_REDIS_PREFIX + task_id, mapping=mapping)
        return True
    except Exception as e:
        logger.warning("[schedule_task] Redis 状态更新失败: %s", e)
        return False


async def _tool_fetch_url(arguments: dict[str, Any]) -> dict[str, Any]:
    """fetch_url: 抓取 URL 内容,返回 markdown/text/html/metadata(对齐 #Web + Codex in-app browser)。

    SSRF 防护:复用 screenshot_service._validate_url_ssrf,禁止内网/保留/回环地址。
    """
    import html as _html
    import json as _json
    from datetime import datetime

    url = arguments.get("url", "")
    mode = arguments.get("mode", "text")
    max_chars = int(arguments.get("max_chars", 8000))

    if not url or not isinstance(url, str):
        return {
            "tool": "fetch_url", "ok": False,
            "error": "缺少 url 参数", "errorCode": "MISSING_PARAMS",
        }
    if mode not in ("text", "html", "metadata"):
        return {
            "tool": "fetch_url", "ok": False, "url": url,
            "error": f"无效 mode: {mode}(允许 text/html/metadata)",
            "errorCode": "INVALID_PARAMS",
        }

    # SSRF 校验(复用 screenshot_service 实现,防 127.0.0.1/10.*/169.254.* 云元数据等)
    from .screenshot_service import _validate_url_ssrf
    ok_ssrf, reason = _validate_url_ssrf(url)
    if not ok_ssrf:
        return {
            "tool": "fetch_url", "ok": False, "url": url,
            "error": reason, "errorCode": "SSRF_BLOCKED",
            "message": f"SSRF 校验失败: {reason}",
        }

    # 批 52b:网络审批门(遵循统一工程规范)。
    # SSRF 硬防线在前(不可被审批放行);审批门在后,持久授权命中免弹窗,
    # 未授权默认拒绝(fail-closed),requester 未注入时不改变现有行为。
    # 批58(十六):拒绝分支附加 codex 原因码 + 可读消息(network_policy_decision)。
    try:
        from .network_approval import evaluate_network_access_detailed

        verdict, _denial_reason = evaluate_network_access_detailed(
            url, reason="tool:fetch_url"
        )
        if verdict == "deny":
            return {
                "tool": "fetch_url", "ok": False, "url": url,
                "error": "网络访问未授权(审批拒绝/无审批通道)",
                "errorCode": "NETWORK_APPROVAL_DENIED",
                "message": _network_denial_message(_denial_reason, url),
                "denialReason": _denial_reason,
            }
    except Exception:  # noqa: BLE001 - 审批门自身故障不改变现有放行行为(向后兼容)
        pass

    try:
        import httpx
    except ImportError:
        return {
            "tool": "fetch_url", "ok": False, "url": url,
            "error": "httpx 未安装", "errorCode": "DEP_MISSING",
        }

    try:
        # 2026-10-31 安全强化第 32 批:逐跳 SSRF(此前 follow_redirects=True 可被
        # 公网 302 → 内网/云元数据绕过;正文会原样回给模型)。
        fetched = await _fetch_url_ssrf_safe(
            url,
            httpx,
            timeout=15.0,
            headers={
                "User-Agent": (
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/120.0.0.0 Safari/537.36"
                ),
            },
        )
        if fetched is None:
            return {
                "tool": "fetch_url", "ok": False, "url": url,
                "error": "URL 抓取失败或被 SSRF 尺拒绝(重定向逐跳校验)",
                "errorCode": "FETCH_FAILED",
            }
        _status, body, content_type, final_url = fetched
        title = ""
        truncated = False

        # title(所有模式都尝试提取)
        _TITLE_RE = re.compile(r"<title[^>]*>(.*?)</title>", re.IGNORECASE | re.DOTALL)
        m_title = _TITLE_RE.search(body)
        if m_title:
            title = _html.unescape(m_title.group(1).strip())

        if mode == "html":
            content = body
        elif mode == "metadata":
            _DESC_RE = re.compile(
                r"""<meta\s+name=["']description["']\s+content=["']([^"']*)["']""",
                re.IGNORECASE,
            )
            _OG_RE = re.compile(
                r"""<meta\s+property=["']og:([^"']+)["']\s+content=["']([^"']*)["']""",
                re.IGNORECASE,
            )
            desc = ""
            dm = _DESC_RE.search(body)
            if dm:
                desc = _html.unescape(dm.group(1))
            og = {prop: _html.unescape(val) for prop, val in _OG_RE.findall(body)}
            content = _json.dumps(
                {"title": title, "description": desc, "og": og},
                ensure_ascii=False,
            )
        else:  # text 模式:简单 HTML→text
            text = re.sub(
                r"<script[^>]*>.*?</script>", "", body, flags=re.IGNORECASE | re.DOTALL
            )
            text = re.sub(
                r"<style[^>]*>.*?</style>", "", text, flags=re.IGNORECASE | re.DOTALL
            )
            text = re.sub(r"<br\s*/?>", "\n", text, flags=re.IGNORECASE)
            text = re.sub(r"</p\s*>", "\n\n", text, flags=re.IGNORECASE)
            text = re.sub(r"<[^>]+>", "", text)
            content = _html.unescape(text)
            content = re.sub(r"[ \t]+\n", "\n", content)
            content = re.sub(r"\n{3,}", "\n\n", content)
            content = content.strip()

        if len(content) > max_chars:
            content = content[:max_chars]
            truncated = True

        return {
            "tool": "fetch_url",
            "ok": True,
            "url": final_url,
            "title": title,
            "content": content,
            "content_type": content_type,
            "status_code": _status,
            "fetched_at": datetime.now(UTC).isoformat(),
            "truncated": truncated,
            "message": f"抓取成功(mode={mode}, {len(content)} 字符)",
        }
    except Exception as e:
        return {
            "tool": "fetch_url", "ok": False, "url": url,
            "error": str(e)[:200], "errorCode": "FETCH_FAILED",
            "message": f"抓取失败: {type(e).__name__}",
        }


# 图片落地约束(2026-07-24 save_path 升级)
_MAX_IMAGE_BYTES = 5 * 1024 * 1024  # 5MB
_IMAGE_EXTENSIONS = (".png", ".jpg", ".jpeg", ".webp")
# 2026-09-05 video_generation(可灵/即梦真实视频任务)落地支持
_VIDEO_EXTENSIONS = (".mp4",)
_MAX_VIDEO_BYTES = 200 * 1024 * 1024  # 200MB
# 音乐生成 save_path(2026-09-08 token6688 music 工具用)
_AUDIO_EXTENSIONS = (".mp3", ".wav", ".ogg", ".flac")
_MAX_AUDIO_BYTES = 50 * 1024 * 1024  # 50MB(Suno 风格成曲一般 3~8MB)


def _validate_video_save_path(save_path: str) -> tuple[bool, str, str | None]:
    """校验视频 save_path:工作区白名单 + 后缀(.mp4)。"""
    if not save_path or not isinstance(save_path, str):
        return False, "", "MISSING_PARAMS"
    ext = os.path.splitext(save_path)[1].lower()
    if ext not in _VIDEO_EXTENSIONS:
        return False, "", "INVALID_EXTENSION"
    ok, info = _validate_path_in_workspace(save_path)
    if not ok:
        return False, info, "PATH_NOT_ALLOWED"
    return True, info, None


async def _persist_video_to_disk(
    video_bytes: bytes, save_path: str
) -> tuple[bool, str, int, str | None]:
    """将视频字节写入磁盘 save_path(200MB 上限,父目录自动 mkdir)。"""
    if len(video_bytes) > _MAX_VIDEO_BYTES:
        return False, "", 0, "VIDEO_TOO_LARGE"
    try:
        from pathlib import Path

        path_obj = Path(save_path)
        path_obj.parent.mkdir(parents=True, exist_ok=True)
        with open(path_obj, "wb") as f:
            f.write(video_bytes)
        return True, str(path_obj), len(video_bytes), None
    except OSError:
        return False, "", 0, "WRITE_FAILED"


async def _persist_video_for_save_path(
    save_path: Any, video_url: str, provider: str, prompt: Any
) -> tuple[str | None, int, dict[str, Any] | None]:
    """AIS-117:视频三条分支(token6688 / agnes / 通用链)共用的 save_path 落盘。

    旧码只有通用链做了校验+下载+落盘;token6688 与 agnes 两个专用分支在落盘块
    之前就 return,agnes 载荷还硬编码 `saved_path: None` —— 调用方要求 save_path、
    回执 ok=true,但盘上没有文件,也没做过白名单校验。

    返回 (saved_path, file_size_bytes, error_payload);error_payload 非 None 时
    调用方直接把它当失败回执返回(零上游副作用之外,失败语义与通用链一致)。
    """
    if not save_path:
        return None, 0, None
    import httpx

    ok_path, resolved, err_code = _validate_video_save_path(str(save_path))
    if not ok_path:
        logger.warning("[mcp][video] save_path 校验失败(AIS-117): provider=%s code=%s", provider, err_code)
        return None, 0, {
            "tool": "video_generation", "ok": False, "prompt": prompt,
            "provider": provider, "video_url": None, "errorCode": err_code,
            "message": f"save_path 校验失败: {err_code}",
        }
    vid_bytes = await _download_media_bytes(video_url, httpx)
    if vid_bytes is None:
        logger.warning("[mcp][video] 落盘下载失败(AIS-117): provider=%s", provider)
        return None, 0, {
            "tool": "video_generation", "ok": False, "prompt": prompt,
            "provider": provider, "video_url": None,
            "errorCode": "VIDEO_FETCH_FAILED", "message": "视频下载失败",
        }
    ok_w, sp, sz, werr = await _persist_video_to_disk(vid_bytes, resolved)
    if not ok_w:
        logger.warning("[mcp][video] 落盘写失败(AIS-117): provider=%s code=%s", provider, werr)
        return None, 0, {
            "tool": "video_generation", "ok": False, "prompt": prompt,
            "provider": provider, "video_url": None, "errorCode": werr,
            "message": f"视频写入磁盘失败: {werr}",
        }
    return sp, sz, None


def _validate_audio_save_path(save_path: str) -> tuple[bool, str, str | None]:
    """校验音频 save_path:工作区白名单 + 后缀(.mp3/.wav/.ogg/.flac)。"""
    if not save_path or not isinstance(save_path, str):
        return False, "", "MISSING_PARAMS"
    ext = os.path.splitext(save_path)[1].lower()
    if ext not in _AUDIO_EXTENSIONS:
        return False, "", "INVALID_EXTENSION"
    ok, info = _validate_path_in_workspace(save_path)
    if not ok:
        return False, info, "PATH_NOT_ALLOWED"
    return True, info, None


async def _persist_audio_to_disk(
    audio_bytes: bytes, save_path: str
) -> tuple[bool, str, int, str | None]:
    """将音频字节写入磁盘 save_path(50MB 上限,父目录自动 mkdir)。"""
    if len(audio_bytes) > _MAX_AUDIO_BYTES:
        return False, "", 0, "AUDIO_TOO_LARGE"
    try:
        from pathlib import Path

        path_obj = Path(save_path)
        path_obj.parent.mkdir(parents=True, exist_ok=True)
        with open(path_obj, "wb") as f:
            f.write(audio_bytes)
        return True, str(path_obj), len(audio_bytes), None
    except OSError:
        return False, "", 0, "WRITE_FAILED"


def _validate_image_save_path(save_path: str) -> tuple[bool, str, str | None]:
    """校验 save_path:工作区白名单 + 后缀(.png/.jpg/.jpeg/.webp)。

    Returns:
        (ok, resolved_path, error_code)
    """
    if not save_path or not isinstance(save_path, str):
        return False, "", "MISSING_PARAMS"
    ext = os.path.splitext(save_path)[1].lower()
    if ext not in _IMAGE_EXTENSIONS:
        return False, "", "INVALID_EXTENSION"
    ok, info = _validate_path_in_workspace(save_path)
    if not ok:
        return False, info, "PATH_NOT_ALLOWED"
    return True, info, None


async def _persist_image_to_disk(
    image_bytes: bytes, save_path: str
) -> tuple[bool, str, int, str | None]:
    """将图片字节写入磁盘 save_path(覆盖已存在文件,父目录自动 mkdir)。

    Returns:
        (ok, saved_path, file_size_bytes, error_code)
    """
    if len(image_bytes) > _MAX_IMAGE_BYTES:
        return False, "", 0, "IMAGE_TOO_LARGE"
    try:
        from pathlib import Path

        path_obj = Path(save_path)
        path_obj.parent.mkdir(parents=True, exist_ok=True)
        with open(path_obj, "wb") as f:
            f.write(image_bytes)
        return True, str(path_obj), len(image_bytes), None
    except OSError:
        return False, "", 0, "WRITE_FAILED"


def _image_provider_chain(explicit: str | None) -> list[str]:
    """图片 provider 自动切换链(2026-09-08 全模态自动切换,对齐 video 编排)。

    顺序:env `IMAGE_PROVIDER`(逗号分隔,顺序即优先级)缺省
    token6688 → agnes → kling → jimeng,仅保留凭据已配置的。
    (2026-09-21 移除 stepfun:官方 /v1/models 无文生图模型,原硬编码 step-1v-8k 不在售,生图必失败)
    显式指定 provider 时:已配置 → 提到链首(用户意图优先);未配置 → 保持自动链
    (与 video_generation 显式 provider 未配置时降级全链的行为一致)。
    """
    from ..core.config import settings

    def _has_creds(name: str) -> bool:
        try:
            if name == "token6688":
                cfg = settings.get_provider_config("token6688")
                return bool(cfg.api_key or os.environ.get("TOKEN6688_API_KEY", ""))
            if name == "agnes":
                return bool(settings.get_provider_config(name).api_key)
            if name == "kling":
                from ..providers import KlingProvider

                return bool(KlingProvider(None).configured)
            if name == "jimeng":
                from ..providers import JimengProvider

                return bool(JimengProvider(None).configured)
        except Exception:  # noqa: BLE001
            return False
        return False

    raw = os.environ.get("IMAGE_PROVIDER", "").strip()
    order = [p.strip() for p in raw.split(",") if p.strip()] or [
        "token6688", "agnes", "kling", "jimeng",
    ]
    chain = [n for n in order if n in ("token6688", "agnes", "kling", "jimeng") and _has_creds(n)]
    if explicit:
        if explicit in chain:
            chain = [explicit] + [n for n in chain if n != explicit]
        elif _has_creds(explicit):
            chain.insert(0, explicit)
    return chain


async def _image_generate_once(
    provider: str, prompt: str, size: str, save_path: str | None,
    arguments: dict[str, Any],
) -> dict[str, Any]:
    """单家图片 provider 生成一次(OpenAI images 协议;失败返回 ok=False 不抛)。"""
    from datetime import datetime

    from ..core.config import settings

    if provider == "token6688":
        cfg = settings.get_provider_config("token6688")
        api_base = (cfg.api_base or os.environ.get(
            "TOKEN6688_BASE_URL", "https://k.token6688.com"
        )).rstrip("/")
        if not api_base.endswith("/v1"):
            api_base += "/v1"
        api_key = cfg.api_key or os.environ.get("TOKEN6688_API_KEY", "")
        model = os.environ.get("TOKEN6688_IMAGE_MODEL", "gpt-image-2")
        # 2026-09-21:官方 gpt-image-2.5 系列参数表无 size(官方用 aspect_ratio/resolution),
        # 旧版固定注入 size 会被提交前校验拦截,不再发送
        payload: dict[str, Any] = {"prompt": prompt, "model": model, "n": 1}
    elif provider == "agnes":
        cfg = settings.get_provider_config("agnes")
        api_key = cfg.api_key
        api_base = cfg.api_base or "https://api.agnes-ai.cn/v1"
        # 2026-09-20 修复:原硬编码 "agnes-image-v1" 是无效模型 ID,agnes 生图必失败。
        # Agnes 实际生图模型(/v1/models 实测): agnes-image-2.5-flash(最新,默认,
        # 已实测出图)/ agnes-image-2.1-flash(2026-10-10:2.0-flash 已下架);
        # 支持 arguments.model 覆盖 + AGNES_IMAGE_MODEL env 配置
        model = (
            str(arguments.get("model") or "").strip()
            or os.environ.get("AGNES_IMAGE_MODEL", "agnes-image-2.5-flash")
        )
        payload = {"prompt": prompt, "model": model, "size": size, "n": 1}
    else:
        # kling/jimeng 走 providers 包原生真实适配器(可灵 JWT / 即梦 Ark Bearer)
        return await _tool_image_generation_native(prompt, provider, size, save_path, arguments)

    if not api_key:
        return {
            "tool": "image_generation", "ok": False, "prompt": prompt,
            "provider": provider, "saved_path": None,
            "errorCode": "PROVIDER_NOT_CONFIGURED",
            "error": f"{provider} 未配置 api_key",
        }

    # token6688 提交前 fail-fast 校验(2026-09-08 目录加深):prompt 长度/size 枚举,
    # 非法直接拒(不调用上游不产生费用);元数据未同步时跳过不阻塞
    if provider == "token6688":
        from . import token6688_catalog as _t6688_catalog

        _meta = await _t6688_catalog.get_model_metadata(str(model))
        if _meta and isinstance(_meta.get("param_schema"), dict) and _meta["param_schema"]:
            _ps = dict(_meta["param_schema"])
            if _meta.get("max_prompt_chars"):
                _ps["_max_prompt_chars"] = _meta["max_prompt_chars"]
            _chk: dict[str, Any] = {}
            _issues = _t6688_catalog.validate_generation_params(
                _ps, _chk, prompt=str(prompt), linkages=_meta.get("linkages"),
            )
            if _issues:
                return {
                    "tool": "image_generation", "ok": False, "prompt": prompt,
                    "provider": provider, "model": model, "saved_path": None,
                    "error": "参数未通过提交前校验(未调用上游,不产生费用): "
                             + "; ".join(_issues),
                    "errorCode": "INVALID_PARAMS",
                    "hint": "可用 token6688_model_info(action=params, model=...) "
                            "查询该模型的参数合法值。",
                }

    try:
        import httpx
    except ImportError:
        return {
            "tool": "image_generation", "ok": False, "prompt": prompt,
            "provider": provider, "saved_path": None,
            "error": "httpx 未安装", "errorCode": "DEP_MISSING",
        }

    endpoint = f"{api_base}/images/generations"
    try:
        # timeout 90s:官方同步出图 40-50s 且 40s 后发保活字节,60s 会误断
        async with httpx.AsyncClient(timeout=90.0) as client:
            resp = await client.post(
                endpoint,
                json=payload,
                headers={"Authorization": f"Bearer {api_key}"},
            )
        if resp.status_code >= 400:
            return {
                "tool": "image_generation", "ok": False, "prompt": prompt,
                "provider": provider, "saved_path": None,
                "error": f"provider 返回 {resp.status_code}: {resp.text[:200]}",
                "errorCode": "PROVIDER_ERROR",
            }
        data = resp.json()
        # ⚠ 官方指南:同步端点 40s 后发保活字节,HTTP 状态码已固定 200,
        # 生成失败也改不回 4xx → 必须检查 body.error(token6688)
        body_err = data.get("error")
        if body_err:
            return {
                "tool": "image_generation", "ok": False, "prompt": prompt,
                "provider": provider, "saved_path": None,
                "error": str(body_err.get("message") or body_err)[:300],
                "errorCode": "PROVIDER_ERROR",
            }
        items = data.get("data") or []
        if not items:
            return {
                "tool": "image_generation", "ok": False, "prompt": prompt,
                "provider": provider, "saved_path": None,
                "error": "provider 返回空 data", "errorCode": "EMPTY_RESULT",
            }
        item = items[0]
        if item.get("b64_json"):
            image_url = f"data:image/png;base64,{item['b64_json']}"
        else:
            image_url = item.get("url", "")
        if not image_url:
            return {
                "tool": "image_generation", "ok": False, "prompt": prompt,
                "provider": provider, "saved_path": None,
                "error": "provider 响应缺少 url/b64_json", "errorCode": "EMPTY_RESULT",
            }

        # save_path 落地:校验 → 取字节 → 写入磁盘
        saved_path: str | None = None
        file_size_bytes: int = 0
        if save_path:
            img_bytes = await _fetch_image_bytes(item, image_url, httpx)
            if img_bytes is None:
                return {
                    "tool": "image_generation", "ok": False, "prompt": prompt,
                    "provider": provider, "saved_path": None,
                    "errorCode": "IMAGE_FETCH_FAILED",
                    "message": "无法获取图片字节(b64 解码 / URL 下载均失败)",
                }
            ok_w, sp, sz, werr = await _persist_image_to_disk(img_bytes, save_path)
            if not ok_w:
                return {
                    "tool": "image_generation", "ok": False, "prompt": prompt,
                    "provider": provider, "saved_path": None,
                    "errorCode": werr,
                    "message": f"图片写入磁盘失败: {werr}",
                }
            saved_path = sp
            file_size_bytes = sz

        return {
            "tool": "image_generation", "ok": True, "prompt": prompt,
            "image_url": image_url, "size": payload.get("size"),
            "provider": provider, "model": model,
            "saved_path": saved_path, "file_size_bytes": file_size_bytes,
            "created_at": datetime.now(UTC).isoformat(),
            "message": f"图片已生成(provider={provider}, model={model}"
                       + (f", saved={saved_path}" if saved_path else "") + ")",
        }
    except Exception as e:
        return {
            "tool": "image_generation", "ok": False, "prompt": prompt,
            "provider": provider, "saved_path": None,
            "error": str(e)[:200], "errorCode": "GENERATION_FAILED",
            "message": f"图片生成失败: {type(e).__name__}",
        }


async def _tool_image_generation(arguments: dict[str, Any]) -> dict[str, Any]:
    """image_generation: 生成图片(多 provider 统一编排 + 运行时自动故障转移)。

    2026-09-08 全模态自动切换升级:
    - provider 链:IMAGE_PROVIDER env(缺省 token6688 → agnes → kling → jimeng),
      仅保留凭据已配置的;首选失败自动换下一家(含 401/402/429/5xx/超时),全失败才报错
    - 显式 provider 已配置 → 提到链首;未配置 → 自动链兜底(兼容旧降级语义)
    - 返回带 failover_attempts(每次尝试的 provider/errorCode 摘要),对话侧可如实转述
    - save_path 落地:校验前置(链路外 fail-fast,不浪费付费 API 调用)
    """
    prompt = arguments.get("prompt", "")
    size = arguments.get("size", "1024x1024")
    provider = arguments.get("provider")  # None=自动:按链逐家尝试
    save_path = arguments.get("save_path")

    if not prompt or not isinstance(prompt, str):
        return {
            "tool": "image_generation", "ok": False,
            "error": "缺少 prompt 参数", "errorCode": "MISSING_PARAMS",
            "saved_path": None,
        }
    _ALLOWED = ("token6688", "agnes", "kling", "jimeng")
    if provider is not None and provider not in _ALLOWED:
        return {
            "tool": "image_generation", "ok": False,
            "error": f"未知 provider: {provider}(允许 {'/'.join(_ALLOWED)})",
            "errorCode": "INVALID_PROVIDER", "saved_path": None,
        }
    # save_path 校验前置:格式/白名单错误与 provider 无关,fail-fast 不浪费付费调用
    resolved_save: str | None = None
    if save_path:
        ok_path, resolved_save, err_code = _validate_image_save_path(save_path)
        if not ok_path:
            return {
                "tool": "image_generation", "ok": False, "prompt": prompt,
                "provider": provider or "auto", "saved_path": None,
                "errorCode": err_code,
                "message": f"save_path 校验失败: {err_code}",
            }

    # 高消耗审批:宿主盖过的余额/批准才算数。拒绝发生在选 provider 之前,
    # 所以上游调用次数在拒绝时是 0。没给余额则不计量,旧调用保持原样。
    from ..core.mcp_tool_approval import gate_image_spend

    credit_block = gate_image_spend(arguments)
    if credit_block is not None:
        credit_block["prompt"] = prompt
        return credit_block

    chain = _image_provider_chain(provider)
    if not chain:
        return {
            "tool": "image_generation", "ok": False, "prompt": prompt,
            "provider": provider or "auto", "saved_path": None,
            "errorCode": "PROVIDER_NOT_CONFIGURED",
            "message": "未配置任何图片生成 provider,请在 .env 的 LLM_PROVIDERS JSON 配置 "
                       "agnes 的 api_key，或 KLING_*/ARK_* 凭据",
        }

    attempts: list[dict[str, str]] = []
    for name in chain:
        result = await _image_generate_once(name, prompt, size, resolved_save, arguments)
        if result.get("ok"):
            if attempts:
                result["failover_attempts"] = attempts
            return result
        attempts.append({
            "provider": name,
            "errorCode": str(result.get("errorCode", "UNKNOWN")),
            "error": str(result.get("error") or result.get("message") or "")[:200],
        })
    # 全链失败:errorCode 保留末次错误码(单 provider 场景与旧语义一致),附尝试明细
    last = attempts[-1]
    return {
        "tool": "image_generation", "ok": False, "prompt": prompt,
        "provider": chain[0], "saved_path": None,
        "errorCode": last["errorCode"],
        "error": last["error"],
        "failover_attempts": attempts,
        "message": f"全部 {len(attempts)} 家图片 provider 均失败",
    }


async def _fetch_url_ssrf_safe(
    url: str,
    httpx_mod: Any,
    *,
    timeout: float = 15.0,
    headers: dict[str, str] | None = None,
    max_hops: int = 5,
    max_bytes: int = 5 * 1024 * 1024,
) -> tuple[int, str, str, str] | None:
    """SSRF 安全的逐跳 GET(返回 状态码/正文/content-type/最终 URL),2026-10-31 安全强化第 32 批。

    缺陷:`_tool_fetch_url` 此前只有首跳 `_validate_url_ssrf` + `follow_redirects=True` ——
    公网页 302 → `http://169.254.169.254/` 即绕过校验,正文原样回给模型。
    现逐跳自管:每跳过同一把尺(screenshot_service 那份,不另立判据)并钉定公网 IP
    (校验期与请求期两次 DNS 解析可不一致),任一跳被拒/钉不出 IP/异常/正文超限 ⇒ None。
    """
    from .screenshot_service import _validate_url_ssrf, resolve_pinned_target

    if not url or url.startswith("data:"):
        return None
    current = url
    try:
        async with httpx_mod.AsyncClient(timeout=timeout, follow_redirects=False) as client:
            for _hop in range(max_hops + 1):
                ok, _reason = _validate_url_ssrf(current)
                if not ok:
                    logger.warning("mcp_server fetch_url 被 SSRF 尺拒绝: %s", current[:200])
                    return None
                pinned = resolve_pinned_target(current)
                if pinned is None:
                    logger.warning("mcp_server fetch_url 无法钉定公网 IP: %s", current[:200])
                    return None
                pinned_url, orig_host = pinned
                resp = await client.get(
                    pinned_url,
                    headers={**(headers or {}), "Host": orig_host},
                    extensions={"sni_hostname": orig_host},
                )
                location = resp.headers.get("location")
                # 用状态码判重定向(而不是 httpx 的 is_redirect 属性):测试桩只需
                # 实现最小契约(status_code/headers/text/url),判据不依赖具体实现细节。
                if 300 <= resp.status_code < 400 and location:
                    current = str(resp.url.join(location))
                    continue
                body = resp.text
                if len(body) > max_bytes:
                    logger.warning("mcp_server fetch_url 正文超限: %s", current[:200])
                    return None
                return (
                    resp.status_code,
                    body,
                    resp.headers.get("content-type", ""),
                    str(resp.url),
                )
        return None
    except Exception as e:
        logger.warning("mcp_server fetch_url 失败: %s", e)
        return None


def _download_url_ssrf_safe_sync(
    url: str,
    httpx_mod: Any,
    *,
    timeout: float = 60.0,
    max_hops: int = 5,
) -> bytes | None:
    """SSRF 安全的逐跳下载(同步版,供同步函数使用;2026-10-31 安全强化第 32 批)。

    与 async 版 `_download_url_ssrf_safe` 同判据、同钉 IP 纪律;存在的理由只有一个:
    `_audio_source_from_args` 是同步函数,不能 await async 版。
    """
    from .screenshot_service import _validate_url_ssrf, resolve_pinned_target

    if not url or url.startswith("data:"):
        return None
    current = url
    try:
        with httpx_mod.Client(timeout=timeout, follow_redirects=False) as client:
            for _hop in range(max_hops + 1):
                ok, _reason = _validate_url_ssrf(current)
                if not ok:
                    logger.warning("mcp_server 同步下载被 SSRF 尺拒绝: %s", current[:200])
                    return None
                pinned = resolve_pinned_target(current)
                if pinned is None:
                    logger.warning("mcp_server 同步下载无法钉定公网 IP: %s", current[:200])
                    return None
                pinned_url, orig_host = pinned
                resp = client.get(
                    pinned_url,
                    headers={"Host": orig_host},
                    extensions={"sni_hostname": orig_host},
                )
                location = resp.headers.get("location")
                if 300 <= resp.status_code < 400 and location:
                    current = str(resp.url.join(location))
                    continue
                if resp.status_code >= 400:
                    return None
                return cast(bytes, resp.content)
        return None
    except Exception as e:
        logger.warning("mcp_server 同步下载失败: %s", e)
        return None


async def _download_url_ssrf_safe(
    url: str,
    httpx_mod: Any,
    *,
    timeout: float = 60.0,
) -> bytes | None:
    """SSRF 安全的 URL 字节下载单源(2026-10-31 安全强化第 10 批)。

    此前三处 URL 下载(_fetch_image_bytes / _resolve_image_source_bytes /
    _download_media_bytes)直接 GET 用户/模型可控 URL:前两处连首跳
    _validate_url_ssrf 都没有,且全部 follow_redirects=True 不复检落点 ——
    公网 302 → http://169.254.169.254/ 即整条 SSRF。现统一:每跳(含重定向
    逐跳)都过 _validate_url_ssrf,任一跳被禁整条失败(返回 None,由调用方
    按既有错误码降级)。
    """
    from .screenshot_service import _validate_url_ssrf, resolve_pinned_target

    if not url or url.startswith("data:"):
        return None
    current = url
    try:
        async with httpx_mod.AsyncClient(timeout=timeout, follow_redirects=False) as dl:
            for _hop in range(6):
                ok, _reason = _validate_url_ssrf(current)
                if not ok:
                    logger.warning("mcp_server URL 下载被 SSRF 尺拒绝: %s", current[:200])
                    return None
                # 2026-10-31 安全强化第 10 批 R6:钉 IP —— 校验期与请求期两次
                # DNS 解析可不一致(短 TTL rebinding),连接只用于校验过的那个 IP,
                # Host 头与 TLS SNI 保持原域名。钉不出公网 IP 即拒绝。
                pinned = resolve_pinned_target(current)
                if pinned is None:
                    logger.warning("mcp_server URL 下载无法钉定公网 IP: %s", current[:200])
                    return None
                pinned_url, orig_host = pinned
                resp = await dl.get(
                    pinned_url,
                    headers={"Host": orig_host},
                    extensions={"sni_hostname": orig_host},
                )
                location = resp.headers.get("location")
                if resp.is_redirect and location:
                    current = str(resp.url.join(location))
                    continue
                if resp.status_code < 400:
                    return cast(bytes, resp.content)
                return None
        return None
    except Exception as e:
        logger.warning("mcp_server URL 下载失败: %s", e, exc_info=True)
        return None


async def _fetch_image_bytes(
    item: dict[str, Any], image_url: str, httpx_mod: Any
) -> bytes | None:
    """从 provider 响应提取图片字节:优先 b64_json,降级 URL 下载。"""
    b64 = item.get("b64_json")
    if b64:
        try:
            import base64

            return base64.b64decode(b64)
        except Exception as e:
            logger.warning("mcp_server b64_json 解码失败: %s", e, exc_info=True)
            return None
    if image_url and not image_url.startswith("data:"):
        # 2026-10-31 安全强化第 10 批:URL 下载统一走 SSRF 安全单源
        return await _download_url_ssrf_safe(image_url, httpx_mod)
    return None


async def _download_media_bytes(url: str, httpx_mod: Any) -> bytes | None:
    """下载媒体字节(图片/视频统一),失败返回 None。

    2026-10-31 安全强化第 10 批:改走 _download_url_ssrf_safe 单源
    (此前 follow_redirects=True 不复检落点,重定向可绕过 SSRF)。"""
    return await _download_url_ssrf_safe(url, httpx_mod, timeout=300.0)


def _resolve_native_provider(provider: str) -> tuple[Any, str]:
    """实例化 kling/jimeng 原生真实适配器,返回 (impl, 默认 model)。"""
    from ..providers import JimengProvider, KlingProvider

    if provider == "kling":
        return KlingProvider(None), "kling-v1"
    return JimengProvider(None), "jimeng-video_generation"


async def _tool_image_generation_native(
    prompt: str, provider: str, size: str, save_path: str | None,
    arguments: dict[str, Any],
) -> dict[str, Any]:
    """image_generation 的 kling/jimeng 原生分支(2026-09-05 真实化)。

    复用 providers 包真实适配器(可灵 JWT HS256 / 即梦 Ark Bearer +
    视觉服务 V4 HMAC 签名),save_path 落地流程与主分支一致。
    """
    from datetime import datetime

    from ..providers.base_provider import ProviderError

    impl, default_model = _resolve_native_provider(provider)
    model = arguments.get("model") or default_model
    kwargs: dict[str, Any] = {
        k: arguments[k]
        for k in ("negative_prompt", "aspect_ratio", "image", "seed", "watermark")
        if k in arguments
    }
    try:
        result = await impl.generate_image(prompt, model, size=size, **kwargs)
    except ProviderError as e:
        return {
            "tool": "image_generation", "ok": False, "prompt": prompt,
            "provider": provider, "saved_path": None,
            "error": str(e)[:300], "errorCode": "PROVIDER_ERROR",
        }
    items = result.get("data") or []
    image_url = items[0].get("url", "") if items else ""
    if not image_url:
        return {
            "tool": "image_generation", "ok": False, "prompt": prompt,
            "provider": provider, "saved_path": None,
            "error": "provider 返回空 data", "errorCode": "EMPTY_RESULT",
        }

    # save_path 落地(与主分支一致:校验 → 下载 → 写盘)
    saved_path: str | None = None
    file_size_bytes: int = 0
    if save_path:
        import httpx

        ok_path, resolved, err_code = _validate_image_save_path(save_path)
        if not ok_path:
            return {
                "tool": "image_generation", "ok": False, "prompt": prompt,
                "provider": provider, "saved_path": None,
                "errorCode": err_code,
                "message": f"save_path 校验失败: {err_code}",
            }
        img_bytes = await _fetch_image_bytes({"url": image_url}, image_url, httpx)
        if img_bytes is None:
            return {
                "tool": "image_generation", "ok": False, "prompt": prompt,
                "provider": provider, "saved_path": None,
                "errorCode": "IMAGE_FETCH_FAILED",
                "message": "无法获取图片字节(b64 解码 / URL 下载均失败)",
            }
        ok_w, sp, sz, werr = await _persist_image_to_disk(img_bytes, resolved)
        if not ok_w:
            return {
                "tool": "image_generation", "ok": False, "prompt": prompt,
                "provider": provider, "saved_path": None,
                "errorCode": werr,
                "message": f"图片写入磁盘失败: {werr}",
            }
        saved_path = sp
        file_size_bytes = sz

    used_model = result.get("model", model)
    return {
        "tool": "image_generation", "ok": True, "prompt": prompt,
        "image_url": image_url, "size": size,
        "provider": provider, "model": used_model,
        "saved_path": saved_path, "file_size_bytes": file_size_bytes,
        "created_at": datetime.now(UTC).isoformat(),
        "message": f"图片已生成(provider={provider}, model={used_model}"
                   + (f", saved={saved_path}" if saved_path else "") + ")",
    }


async def _resolve_image_source_bytes(source: str) -> tuple[bytes | None, str | None]:
    """把图片输入(source)解析为原始字节,返回 (bytes, 错误码)。

    支持:
    - http(s) URL → 下载(60s 超时)
    - data URI(data:image/*;base64,...) → base64 解码
    - 裸 base64 字符串 → 直接解码
    - 本地绝对路径 → 读文件(工作区白名单校验)
    """
    import base64 as _b64
    from pathlib import Path

    import httpx as _httpx

    if not source or not isinstance(source, str):
        return None, "MISSING_PARAMS"
    s = source.strip()
    if s.startswith("data:"):
        try:
            _, _, b64part = s.partition(";base64,")
            raw = _b64.b64decode(b64part)
        except Exception:  # noqa: BLE001
            return None, "INVALID_BASE64"
        return raw or None, None if raw else "INVALID_BASE64"
    if s.startswith("http://") or s.startswith("https://"):
        # 2026-10-31 安全强化第 10 批:URL 下载统一走 SSRF 安全单源
        # (此前连首跳 _validate_url_ssrf 都没有,follow_redirects=True 不复检落点)
        fetched = await _download_url_ssrf_safe(s, _httpx)
        return (fetched, None) if fetched else (None, "DOWNLOAD_FAILED")
    if len(s) > 40 and (s.startswith("data:") is False):
        # 可能是纯 base64(非 data URI)或本地路径
        try:
            raw = _b64.b64decode(s, validate=True)
            if raw:
                return raw, None
        except Exception:  # noqa: BLE001
            pass
        ok, info = _validate_path_in_workspace(s)
        if ok:
            p = Path(info)
            if p.exists() and p.is_file():
                try:
                    raw = p.read_bytes()
                except OSError:
                    return None, "FILE_READ_FAILED"
                if raw:
                    return raw, None
    return None, "INVALID_SOURCE"


async def _tool_image_edit(arguments: dict[str, Any]) -> dict[str, Any]:
    """image_edit: 图片编辑(token6688 官方 /v1/images/edits,OpenAI Images edits 同构)。

    2026-09-09 全模态深度适配新增:图片生成之外补齐"改图"能力(局部重绘/扩图/改元素),
    与 REST POST /api/image/edits 同源,供 AI 对话内直接调用。
    - image 必填:待编辑图(URL / data URI / 裸 base64 / 本地工作区路径)
    - prompt 必填:编辑指令(改什么)
    - mask 可选:遮罩(透明区域=重绘区,URL/data URI)
    - 同步 40-50s 出图;200 响应仍检查 body.error(官方陷阱);超 25MiB 拒绝
    - save_path 落地(.png/.jpg/.jpeg/.webp,工作区白名单,5MB 上限)
    token6688 平台已永久下线。外部 API+计费。
    """
    image = arguments.get("image")
    prompt = arguments.get("prompt", "")
    if not image or not prompt:
        return {
            "tool": "image_edit", "ok": False,
            "error": "缺少 image(待编辑图)或 prompt(编辑指令)",
            "errorCode": "MISSING_PARAMS", "saved_path": None,
        }
    if not isinstance(image, str) or len(image) > 30 * 1024 * 1024:
        return {
            "tool": "image_edit", "ok": False,
            "error": "image 参数非法(须为 URL/data URI/base64,且 ≤30MiB)",
            "errorCode": "INVALID_PARAMS", "saved_path": None,
        }
    # save_path 校验前置(与 image_generation 一致,fail-fast 不浪费付费调用)
    resolved_save: str | None = None
    save_path = arguments.get("save_path")
    if save_path:
        ok_path, resolved_save, err_code = _validate_image_save_path(save_path)
        if not ok_path:
            return {
                "tool": "image_edit", "ok": False, "prompt": prompt,
                "saved_path": None, "errorCode": err_code,
                "message": f"save_path 校验失败: {err_code}",
            }

    # AIS-116:改图与生图同属付费上游调用,必须共用同一计费闸 —— 旧实现只有
    # image_generation 过 gate_image_spend,edits 漏了,宿主盖章余额为 0 也照扣费。
    # 位置在 save_path 校验之后、任何上游/配置读取之前(拒绝零副作用)。
    from ..core.mcp_tool_approval import gate_image_spend

    credit_block = gate_image_spend(arguments)
    if credit_block is not None:
        _spend = credit_block.get("creditSpend") or {}
        logger.warning(
            "[mcp] image_edit 计费闸拒绝(AIS-116): disposition=%s reason=%s "
            "quoted=%s balance=%s code=CREDIT_APPROVAL_REQUIRED",
            _spend.get("disposition"), _spend.get("reason"),
            _spend.get("quotedCredits"), _spend.get("balanceCredits"),
        )
        return {
            **credit_block, "tool": "image_edit", "prompt": prompt,
            "errorCode": "CREDIT_APPROVAL_REQUIRED",
            "error": "这次改图消耗需要人批准后才会调用上游,当前没有放行",
        }

    from ..core.config import settings
    from ..providers.base_provider import ProviderError
    from ..providers.token6688_provider import Token6688Provider

    cfg = settings.get_provider_config("token6688")
    api_key = cfg.api_key or os.environ.get("TOKEN6688_API_KEY", "")
    if not api_key:
        return {
            "tool": "image_edit", "ok": False, "prompt": prompt,
            "saved_path": None,
            "error": "token6688 平台已永久下线",
            "errorCode": "PROVIDER_NOT_CONFIGURED",
        }
    api_base = (cfg.api_base or os.environ.get("TOKEN6688_BASE_URL", "https://k.token6688.com")).rstrip("/")
    provider = Token6688Provider(api_key=api_key, api_base=api_base)

    image_bytes, err_code = await _resolve_image_source_bytes(image)
    if image_bytes is None:
        return {
            "tool": "image_edit", "ok": False, "prompt": prompt,
            "saved_path": None, "errorCode": err_code,
            "error": f"无法解析待编辑图({err_code})",
        }
    mask_bytes = None
    mask = arguments.get("mask")
    if mask:
        mask_bytes, mask_err = await _resolve_image_source_bytes(mask)
        if mask_bytes is None:
            return {
                "tool": "image_edit", "ok": False, "prompt": prompt,
                "saved_path": None, "errorCode": mask_err,
                "error": f"无法解析 mask({mask_err})",
            }

    model = arguments.get("model")
    n = int(arguments.get("n") or 1)
    size = arguments.get("size")
    extra: dict[str, Any] = {}
    for k in ("aspect_ratio", "quality", "output_format"):
        if arguments.get(k):
            extra[k] = arguments[k]
    try:
        result = await provider.images_edits(
            prompt, image_bytes, filename="image.png",
            model=model, mask_bytes=mask_bytes, n=n, size=size, **extra,
        )
    except ProviderError as e:
        return {
            "tool": "image_edit", "ok": False, "prompt": prompt,
            "saved_path": None,
            "error": str(e)[:300], "errorCode": "PROVIDER_ERROR",
        }
    except Exception as e:  # noqa: BLE001
        return {
            "tool": "image_edit", "ok": False, "prompt": prompt,
            "saved_path": None, "error": str(e)[:300], "errorCode": "GENERATION_FAILED",
        }

    items = result.get("images") or []
    item = items[0] if items else {}
    if item.get("b64_json"):
        image_url = f"data:image/png;base64,{item['b64_json']}"
    else:
        image_url = item.get("url", "")
    if not image_url:
        return {
            "tool": "image_edit", "ok": False, "prompt": prompt,
            "saved_path": None,
            "error": "provider 响应缺少 url/b64_json", "errorCode": "EMPTY_RESULT",
        }

    saved_path: str | None = None
    file_size_bytes = 0
    if resolved_save:
        import httpx as _httpx

        img_bytes = await _fetch_image_bytes(item, image_url, _httpx)
        if img_bytes is None:
            return {
                "tool": "image_edit", "ok": False, "prompt": prompt,
                "saved_path": None, "errorCode": "IMAGE_FETCH_FAILED",
                "message": "无法获取编辑结果字节(b64 解码 / URL 下载均失败)",
            }
        ok_w, sp, sz, werr = await _persist_image_to_disk(img_bytes, resolved_save)
        if not ok_w:
            return {
                "tool": "image_edit", "ok": False, "prompt": prompt,
                "saved_path": None, "errorCode": werr,
                "message": f"图片写入磁盘失败: {werr}",
            }
        saved_path = sp
        file_size_bytes = sz

    return {
        "tool": "image_edit", "ok": True, "prompt": prompt,
        "image_url": image_url,
        "model": result.get("model"), "saved_path": saved_path,
        "file_size_bytes": file_size_bytes,
        "message": "图片编辑完成" + (f", saved={saved_path}" if saved_path else ""),
    }


async def _agnes_submit_with_retry(
    inst: Any,
    prompt: str,
    model: str,
    *,
    duration: int,
    image: Any = None,
    size: str | None = None,
) -> tuple[dict[str, Any] | None, str, bool]:
    """提交 agnes 视频任务,只在**排队类可重试错误**上退避重放。

    返回 ``(提交结果, 失败原文, 是否排队满)``:成功 ⇒ ``(res, "", False)``。

    为什么要单独成格:免费档(`agnes-video-2.5-flash`)提交被
    `503 video queue is full` 顶回来的概率比成功还高(2026-10-29 实测同一分钟连撞 6 次)。
    一次 503 就判「视频功能不可用」是把可恢复的拥堵说成硬故障;反过来同步等到底又会把
    对话卡住。故只对 503 做有限次退避重放,其余错误(参数错/鉴权错)立刻返回,不浪费窗口。
    次数与步长可配(`VIDEO_BUSY_RETRIES` / `VIDEO_BUSY_BACKOFF_S`),默认 3 次 × 4/8s ≈ 12s。
    """
    try:
        tries = max(1, int(os.environ.get("VIDEO_BUSY_RETRIES", "3") or 3))
        base = max(0.0, float(os.environ.get("VIDEO_BUSY_BACKOFF_S", "4") or 4))
    except ValueError:
        tries, base = 3, 4.0
    from ..providers.base_provider import ProviderError
    last = ""
    busy = False
    for attempt in range(tries):
        try:
            res = await inst.generate_video(
                prompt, model, duration=duration, wait=False, image=image, size=size
            )
            return res, "", False
        except ProviderError as e:
            last = str(e)[:300]
            busy = int(getattr(e, "status_code", 0) or 0) == 503
            if not busy or attempt >= tries - 1:
                return None, last, busy
            await asyncio.sleep(base * (attempt + 1))
        except Exception as e:  # noqa: BLE001
            return None, f"{type(e).__name__}: {e}"[:300], False
    return None, last, busy


async def _tool_video_generation(arguments: dict[str, Any]) -> dict[str, Any]:
    """video_generation: 生成视频(统一编排,5 家厂商自动故障转移)。

    复用 app.services.video_generation.generate_video 统一编排:
    - token6688(名创AI 聚合网关,单 key,默认首选;提交+限时轮询+task_id 取件)
    - kling(快手可灵, JWT text2video/image2video)
    - jimeng(字节即梦, Ark Seedance)
    - wan(阿里通义万相, DashScope 文生视频)
    - hunyuan(腾讯混元, 文生视频需开通)

    按 VIDEO_PROVIDER / 已配置凭据顺序自动挑厂商,首选失败自动降级下一家。
    返回统一 {provider, model, task_id, video_url, duration}。
    token6688 长任务(p90 55~75 分钟):90s 窗口内完成直接返回成片;否则返回
    submitted+task_id,后续传 arguments.task_id 查询取件(防工具调用卡死对话)。
    未配置任何厂商凭据时返回清晰错误(PROVIDER_NOT_CONFIGURED),
    不误标"已生成"——对话侧据 ok=false 如实告知用户。
    """
    from datetime import datetime

    from ..providers.base_provider import ProviderError

    prompt = arguments.get("prompt", "")
    provider = arguments.get("provider")  # None=自动;显式=指定厂商
    duration = arguments.get("duration", 5)
    save_path = arguments.get("save_path")
    # 查询模式:只传 task_id 不传 prompt(对话里"视频好了吗"直接取件)
    _query_task_id = str(arguments.get("task_id") or "").strip()

    if _query_task_id:
        prompt = prompt if isinstance(prompt, str) else ""
    elif not prompt or not isinstance(prompt, str):
        return {
            "tool": "video_generation", "ok": False,
            "error": "缺少 prompt 参数(或传 task_id 查询已有任务)", "errorCode": "MISSING_PARAMS",
            "video_url": None,
        }
    if provider is not None and provider not in (
        "agnes", "kling", "jimeng", "wan", "hunyuan", "token6688",
    ):
        return {
            "tool": "video_generation", "ok": False,
            "error": f"未知 provider: {provider}(允许 agnes/kling/jimeng/wan/hunyuan/token6688)",
            "errorCode": "INVALID_PROVIDER", "video_url": None,
        }
    if not isinstance(duration, int) or duration <= 0:
        duration = 5

    # ---- 查询模式:传 task_id 时查在途任务(对话里"视频好了吗")----
    # 厂商按"显式指定 > 已配置凭据的优先级顺序"择一:agnes 与 token6688 的
    # 查询返回形状不同(前者是上游 record,后者是 {ok,video_url,status,failed}),
    # 这里只归一化到 status/video_url 两键判读,不各自再写一套分支。
    if _query_task_id:
        from .video_generation import _instantiate as _video_instantiate
        _q_inst = None
        _q_provider = ""
        for _cand in ([provider] if provider else ["agnes"]):
            _cand_inst = _video_instantiate(_cand)
            if _cand_inst is not None:
                _q_inst, _q_provider = _cand_inst, _cand
                break
        if _q_inst is None:
            return {
                "tool": "video_generation", "ok": False,
                "error": "未配置可查询的视频厂商(agnes 无凭据),无法查询任务",
                "errorCode": "PROVIDER_NOT_CONFIGURED", "video_url": None,
            }
        st = await _q_inst.get_task_status(_query_task_id)
        _q_status = str(st.get("status") or "").lower()
        _q_url = str(st.get("video_url") or "")
        _q_done = _q_status in ("completed", "succeeded", "success") or bool(st.get("ok"))
        _q_failed = bool(st.get("failed")) or _q_status in ("failed", "cancelled", "canceled")
        if _q_url and _q_done:
            return {
                "tool": "video_generation", "ok": True, "completed": True,
                "task_id": _query_task_id, "provider": _q_provider,
                "video_url": _q_url, "status": st.get("status"),
                "message": "视频已生成完成",
            }
        if _q_failed:
            return {
                "tool": "video_generation", "ok": False, "task_id": _query_task_id,
                "provider": _q_provider, "video_url": None, "status": st.get("status"),
                "error": st.get("error") or "视频任务失败", "errorCode": "TASK_FAILED",
            }
        return {
            "tool": "video_generation", "ok": True, "completed": False,
            "task_id": _query_task_id, "provider": _q_provider, "video_url": None,
            "status": st.get("status"), "progress": st.get("progress"),
            "message": f"视频仍在生成中(status={st.get('status')}),请稍后再问一次(带同一 task_id)",
        }

    # ---- token6688 专用路径:提交 + 限时轮询,避免长任务(p90 55~75 分钟)卡死对话 ----
    # 完成窗口内(默认 90s,VIDEO_TOOL_WAIT_S 可调)拿到视频直接返回;超时返回
    # submitted+task_id,用户稍后带 task_id 再问一次即可取件。其他厂商保持原同步编排。
    from .video_generation import _instantiate as _video_instantiate
    _t6688 = _video_instantiate("token6688") if provider in (None, "token6688") else None
    if _t6688 is not None:
        # ---- 提交前 fail-fast 参数校验(2026-09-08 目录加深)----
        # 用同步入库的 param_schema/linkages 校验,非法参数直接拒:
        # 枚举错值上游会静默落默认档(白花钱),mode=first-frame 漏传图上游必报错。
        # 元数据缺失(未同步/未指定 model)时跳过,不阻塞主路径。
        _model_in = str(arguments.get("model") or "").strip()
        if _model_in:
            from . import token6688_catalog as _t6688_catalog

            _meta = await _t6688_catalog.get_model_metadata(_model_in)
            if _meta and isinstance(_meta.get("param_schema"), dict) and _meta["param_schema"]:
                # 复刻 provider 的 mode 自动推断(显式 > 传图 first-frame > 纯文生)
                _eff_mode = str(arguments.get("mode") or "").strip()
                if not _eff_mode:
                    _eff_mode = "first-frame" if arguments.get("image") else "text-to-video"
                _chk: dict[str, Any] = {"mode": _eff_mode}
                for _k in ("resolution", "aspect_ratio"):
                    if arguments.get(_k) is not None:
                        _chk[_k] = arguments[_k]
                if arguments.get("duration") is not None:
                    _chk["duration"] = arguments["duration"]
                if arguments.get("image"):
                    _chk["images"] = arguments["image"]  # linkages 用官方参数名
                _ps = dict(_meta["param_schema"])
                if _meta.get("max_prompt_chars"):
                    _ps["_max_prompt_chars"] = _meta["max_prompt_chars"]
                _issues = _t6688_catalog.validate_generation_params(
                    _ps, _chk, prompt=str(prompt), linkages=_meta.get("linkages"),
                )
                if _issues:
                    return {
                        "tool": "video_generation", "ok": False, "prompt": prompt,
                        "provider": "token6688", "model": _model_in, "video_url": None,
                        "error": "参数未通过提交前校验(未调用上游,不产生费用): "
                                 + "; ".join(_issues),
                        "errorCode": "INVALID_PARAMS",
                        "hint": "可用 token6688_model_info(action=params, model=...) "
                                "查询该模型的参数合法值与素材上限。",
                    }
        try:
            submitted = await _t6688.generate_video(
                prompt, str(arguments.get("model") or ""),
                duration=duration, wait=False,
                image=arguments.get("image"),
                mode=arguments.get("mode") or None,
                resolution=arguments.get("resolution") or None,
                aspect_ratio=arguments.get("aspect_ratio") or None,
            )
        except Exception as e:  # noqa: BLE001
            # token6688 提交失败 → 落回原编排(自动降级其他厂商)
            logger.warning("[mcp][video] token6688 提交失败,降级原编排: %s", e)
            submitted = None
        if submitted is not None and submitted.get("task_id"):
            wait_s = max(15, int(os.environ.get("VIDEO_TOOL_WAIT_S", "90")))
            import asyncio as _asyncio

            deadline = time.monotonic() + wait_s
            while time.monotonic() < deadline:
                await _asyncio.sleep(3)
                st = await _t6688.get_task_status(str(submitted["task_id"]))
                if st.get("ok") and st.get("video_url"):
                    result = {
                        "provider": "token6688", "model": submitted.get("model", ""),
                        "task_id": submitted["task_id"], "video_url": st["video_url"],
                        "duration": duration,
                    }
                    break
                if st.get("failed"):
                    return {
                        "tool": "video_generation", "ok": False, "prompt": prompt,
                        "provider": "token6688", "task_id": submitted["task_id"],
                        "video_url": None, "error": st.get("error") or "视频任务失败",
                        "errorCode": "TASK_FAILED",
                    }
            else:
                return {
                    "tool": "video_generation", "ok": True, "submitted": True,
                    "prompt": prompt, "provider": "token6688",
                    "model": submitted.get("model", ""),
                    "task_id": submitted["task_id"], "video_url": None,
                    "message": (
                        "视频生成任务已提交(token6688 网关),官方耗时中位 4~40 分钟、"
                        f"p90 55~75 分钟。已等待 {wait_s}s 未完成——请稍后让我查询进度"
                        f"(我会用 task_id={submitted['task_id']} 拿成片链接)。"
                        "任务已计费,请勿重复提交同一 prompt。"
                    ),
                }
            # while 内 break(拿到成片)→ 落到下方统一返回
            video_url = result.get("video_url", "")
            _sp, _sz, _perr = await _persist_video_for_save_path(
                save_path, video_url, "token6688", prompt
            )
            if _perr is not None:
                return _perr
            return {
                "tool": "video_generation", "ok": True, "prompt": prompt,
                "provider": result.get("provider", "token6688"),
                "model": result.get("model", ""), "task_id": result.get("task_id", ""),
                "video_url": video_url, "duration": result.get("duration", duration),
                "saved_path": _sp, "file_size_bytes": _sz,
                "created_at": datetime.now(UTC).isoformat(),
                "message": "视频生成完成" + (f", saved={_sp}" if _sp else ""),
            }

    # ---- agnes 专用路径:提交 + 限时窗口轮询 ----
    # 免费档(agnes-video-2.5-flash)实测从提交到出片约 6~7 分钟(排队占大头),
    # 同步等完会把工具调用挂死。与 token6688 同款处置:窗口内完成直接给成片,
    # 超时把 task_id 交回去,用户稍后追问时只传 task_id 取件。
    _agnes = _video_instantiate("agnes") if provider in (None, "agnes") else None
    _submitted: dict[str, Any] | None = None
    if _agnes is not None:
        _res_in = str(arguments.get("resolution") or "").strip().upper()
        _submitted, _agnes_err, _agnes_busy = await _agnes_submit_with_retry(
            _agnes,
            prompt,
            str(arguments.get("model") or ""),
            duration=duration,
            image=arguments.get("image"),
            size=_res_in or None,
        )
        if _submitted is None:
            # 提交侧彻底失败。显式点名 agnes ⇒ 如实回错(排队满要标 retryable,
            # 让模型转述成"稍后再试"而不是"视频功能坏了");未点名 ⇒ 让位给
            # 通用链的其他厂商,不把一家拥堵升级成整条链路不可用。
            if provider == "agnes":
                return {
                    "tool": "video_generation", "ok": False, "prompt": prompt,
                    "provider": "agnes", "video_url": None,
                    "error": (
                        f"agnes 免费档排队已满,稍后重试即可({_agnes_err})"
                        if _agnes_busy
                        else f"agnes 视频提交失败:{_agnes_err}"
                    ),
                    "errorCode": "PROVIDER_BUSY" if _agnes_busy else "PROVIDER_CALL_FAILED",
                    "retryable": _agnes_busy,
                }
            _agnes = None
    if _agnes is not None and _submitted is not None:
        _ref = str(_submitted.get("task_id") or "")
        _url = str(_submitted.get("video_url") or "")
        _ok_payload = {
            "tool": "video_generation", "ok": True, "prompt": prompt,
            "provider": "agnes", "model": _submitted.get("model", ""),
            "task_id": _ref, "duration": _submitted.get("duration") or duration,
            "saved_path": None, "file_size_bytes": 0,
            "created_at": datetime.now(UTC).isoformat(),
        }
        if _url:
            _sp, _sz, _perr = await _persist_video_for_save_path(
                save_path, _url, "agnes", prompt
            )
            if _perr is not None:
                return _perr
            return {
                **_ok_payload, "video_url": _url,
                "saved_path": _sp, "file_size_bytes": _sz,
                "message": "视频已生成(agnes)" + (f", saved={_sp}" if _sp else ""),
            }
        _wait_s = int(os.environ.get("VIDEO_TOOL_WAIT_S", "90") or 90)
        _deadline = time.monotonic() + max(0, _wait_s)
        while time.monotonic() < _deadline:
            await asyncio.sleep(5)
            try:
                _rec = await _agnes.get_task_status(_ref)
            except ProviderError:
                continue  # 单次查询抖动不代表任务失败,继续等窗口
            _st = str(_rec.get("status") or "").lower()
            if _st in ("completed", "succeeded", "success") and _rec.get("video_url"):
                _sp, _sz, _perr = await _persist_video_for_save_path(
                    save_path, _rec["video_url"], "agnes", prompt
                )
                if _perr is not None:
                    return _perr
                return {
                    **_ok_payload, "video_url": _rec["video_url"],
                    "saved_path": _sp, "file_size_bytes": _sz,
                    "message": "视频已生成(agnes)" + (f", saved={_sp}" if _sp else ""),
                }
            if _st in ("failed", "cancelled", "canceled"):
                return {
                    "tool": "video_generation", "ok": False, "prompt": prompt,
                    "provider": "agnes", "task_id": _ref, "video_url": None,
                    "error": str(_rec.get("error") or f"任务失败(status={_st})")[:300],
                    "errorCode": "TASK_FAILED",
                }
        return {
            **_ok_payload, "video_url": None, "submitted": True,
            "message": (
                f"视频任务已提交(agnes 免费档),实测排队可达数分钟。已等待 {_wait_s}s 未完成——"
                f"请稍后让我查询进度(我会用 task_id={_ref} 取成片链接)。任务已计费,请勿重复提交。"
            ),
        }

    from .video_generation import generate_video

    try:
        result = await generate_video(
            prompt,
            duration=duration,
            image=arguments.get("image"),
            provider=provider,
        )
    except ProviderError as e:
        return {
            "tool": "video_generation", "ok": False, "prompt": prompt,
            "provider": provider or "auto", "video_url": None,
            "error": str(e)[:300], "errorCode": "PROVIDER_NOT_CONFIGURED",
        }
    video_url = result.get("video_url", "")
    if not video_url:
        return {
            "tool": "video_generation", "ok": False, "prompt": prompt,
            "provider": result.get("provider") or "auto", "video_url": None,
            "error": "provider 返回缺少 video_url", "errorCode": "EMPTY_RESULT",
        }

    used_provider = result.get("provider") or provider or "auto"
    used_model = result.get("model", "")
    saved_path: str | None = None
    file_size_bytes: int = 0
    if save_path:
        saved_path, file_size_bytes, _perr = await _persist_video_for_save_path(
            save_path, video_url, used_provider, prompt
        )
        if _perr is not None:
            return _perr

    return {
        "tool": "video_generation", "ok": True, "prompt": prompt,
        "video_url": video_url, "task_id": result.get("task_id"),
        "provider": used_provider, "model": used_model, "duration": duration,
        "saved_path": saved_path, "file_size_bytes": file_size_bytes,
        "created_at": datetime.now(UTC).isoformat(),
        "message": f"视频已生成(provider={used_provider}, model={used_model}"
                   + (f", saved={saved_path}" if saved_path else "") + ")",
    }


async def _tool_music_generation(arguments: dict[str, Any]) -> dict[str, Any]:
    """music_generation: 生成音乐(token6688 Suno 风格,2026-09-08 落地)。

    复用 Token6688Provider.generate_music(POST /v1/audio/generations 扁平形状
    → 轮询 GET /v1/tasks/{task_id} 读 output_url)。防卡死同视频模式:
    - 提交后限时轮询(MUSIC_TOOL_WAIT_S 默认 150s,音乐官方耗时约 1~5 分钟)
    - 窗口内完成直接返回成片;超时返回 submitted+task_id,
      用户稍后带 task_id 再问一次即可取件(查询模式无需 prompt)
    - 支持 mode=song/instrumental(纯音乐)、lyrics/style/title/vocal_gender
    - 支持 save_path 下载落地(.mp3/.wav/.ogg/.flac,工作区白名单,50MB 上限)
    未配置 token6688 key 时返回 PROVIDER_NOT_CONFIGURED,如实告知用户。
    """
    from datetime import datetime

    prompt = arguments.get("prompt", "")
    mode = arguments.get("mode", "song")
    save_path = arguments.get("save_path")
    # 查询模式:只传 task_id 不传 prompt(对话里"歌好了吗"直接取件)
    _query_task_id = str(arguments.get("task_id") or "").strip()

    if _query_task_id:
        prompt = prompt if isinstance(prompt, str) else ""
    elif not prompt or not isinstance(prompt, str):
        return {
            "tool": "music_generation", "ok": False,
            "error": "缺少 prompt 参数(或传 task_id 查询已有任务)", "errorCode": "MISSING_PARAMS",
            "audio_url": None,
        }
    if mode not in ("song", "instrumental"):
        mode = "song"

    from .video_generation import _instantiate as _video_instantiate
    inst = _video_instantiate("token6688")
    if inst is None:
        return {
            "tool": "music_generation", "ok": False,
            "error": "token6688 平台已永久下线，音乐生成不可用",
            "errorCode": "PROVIDER_NOT_CONFIGURED", "audio_url": None,
        }

    # ---- 查询模式 ----
    if _query_task_id:
        st = await inst.get_task_status(_query_task_id)
        if st.get("ok") and st.get("video_url"):
            return {
                "tool": "music_generation", "ok": True, "completed": True,
                "task_id": _query_task_id, "provider": "token6688",
                "audio_url": st["video_url"], "status": st["status"],
                "message": "音乐已生成完成",
            }
        if st.get("failed"):
            return {
                "tool": "music_generation", "ok": False, "task_id": _query_task_id,
                "provider": "token6688", "audio_url": None, "status": st["status"],
                "error": st.get("error") or "音乐任务失败", "errorCode": "TASK_FAILED",
            }
        return {
            "tool": "music_generation", "ok": True, "completed": False,
            "task_id": _query_task_id, "provider": "token6688", "audio_url": None,
            "status": st["status"], "progress": st.get("progress"),
            "message": f"音乐仍在生成中(status={st['status']}),请稍后再问一次(带同一 task_id)",
        }

    # ---- 提交 + 限时轮询 ----
    try:
        submitted = await inst.generate_music(
            prompt,
            mode=mode,
            lyrics=arguments.get("lyrics"),
            style=arguments.get("style"),
            title=arguments.get("title"),
            vocal_gender=arguments.get("vocal_gender"),
            version=arguments.get("version"),
            operation=str(arguments.get("operation") or "generate"),
            negative_tags=arguments.get("negative_tags"),
            model=str(arguments.get("model") or "")
            or os.environ.get("TOKEN6688_MUSIC_MODEL", "music"),
            wait=False,
        )
    except Exception as e:  # noqa: BLE001
        return {
            "tool": "music_generation", "ok": False, "prompt": prompt,
            "provider": "token6688", "audio_url": None,
            "error": str(e)[:300], "errorCode": "PROVIDER_ERROR",
        }
    remote_id = str(submitted.get("task_id") or "")
    if not remote_id:
        return {
            "tool": "music_generation", "ok": False, "prompt": prompt,
            "provider": "token6688", "audio_url": None,
            "error": "网关响应缺少 task_id", "errorCode": "PROVIDER_ERROR",
        }

    wait_s = max(30, int(os.environ.get("MUSIC_TOOL_WAIT_S", "150")))
    import asyncio as _asyncio

    deadline = time.monotonic() + wait_s
    while time.monotonic() < deadline:
        await _asyncio.sleep(5)
        st = await inst.get_task_status(remote_id)
        if st.get("ok") and st.get("video_url"):
            audio_url = st["video_url"]
            # ---- save_path 落地(可选)----
            saved_path: str | None = None
            file_size_bytes = 0
            if save_path:
                import httpx

                ok_path, resolved, err_code = _validate_audio_save_path(save_path)
                if not ok_path:
                    return {
                        "tool": "music_generation", "ok": True, "prompt": prompt,
                        "provider": "token6688", "task_id": remote_id,
                        "audio_url": audio_url, "saved_path": None,
                        "errorCode": err_code,
                        "message": f"音乐已生成,但 save_path 校验失败: {err_code}",
                    }
                audio_bytes = await _download_media_bytes(audio_url, httpx)
                if audio_bytes is not None:
                    ok_w, sp, sz, werr = await _persist_audio_to_disk(audio_bytes, resolved)
                    if ok_w:
                        saved_path, file_size_bytes = sp, sz
            return {
                "tool": "music_generation", "ok": True, "prompt": prompt,
                "provider": "token6688", "model": submitted.get("model", ""),
                "task_id": remote_id, "audio_url": audio_url,
                "saved_path": saved_path, "file_size_bytes": file_size_bytes,
                "created_at": datetime.now(UTC).isoformat(),
                "message": "音乐生成完成"
                           + (f",saved={saved_path}" if saved_path else ""),
            }
        if st.get("failed"):
            return {
                "tool": "music_generation", "ok": False, "prompt": prompt,
                "provider": "token6688", "task_id": remote_id,
                "audio_url": None, "error": st.get("error") or "音乐任务失败",
                "errorCode": "TASK_FAILED",
            }
    # 超时窗口:返回 submitted+task_id,用户稍后取件(防对话卡死)
    return {
        "tool": "music_generation", "ok": True, "submitted": True,
        "prompt": prompt, "provider": "token6688",
        "model": submitted.get("model", ""), "task_id": remote_id,
        "audio_url": None,
        "message": (
            f"音乐生成任务已提交(token6688 网关),官方耗时约 1~5 分钟。"
            f"已等待 {wait_s}s 未完成——请稍后让我查询进度"
            f"(我会用 task_id={remote_id} 拿成曲链接)。"
            "任务已计费,请勿重复提交同一 prompt。"
        ),
    }


async def _tool_token6688_model_info(arguments: dict[str, Any]) -> dict[str, Any]:
    """token6688_model_info: 模型信息查询(目录/参数/估价/跨渠道价)。

    - action=models:目录清单(可选 modality 过滤;读 DB 同步目录,免上游请求;
      含 modality/display_name/capabilities/健康分/官方价描述/输入提示)
    - action=params:单模型参数详情。优先读 DB 同步的 param_schema(linked-models
      dict 形态,含 available_when/max_items/max_bytes/linkages 联动),比上游单模型
      接口更丰富;DB 未同步时回退 GET /v1/skills/models/{model}(免鉴权)。
      枚举合法值在 allowed_values —— 发 value 不发界面显示名,否则参数不生效
    - action=estimate:提交前估价(POST /v1/pricing-estimate;参数与提交完全一致才准,
      带参考视频必须给 video_total_duration_sec,否则估价不含参考视频费)
    - action=pricing:跨渠道价格(GET /v1/skills/models/{model}/pricing,免鉴权)
    """
    action = str(arguments.get("action") or "estimate").lower()
    model = str(arguments.get("model") or "").strip()

    # ---- action=models:目录清单(读 DB 同步目录,不需要 model)----
    if action == "models":
        from . import token6688_catalog

        modality = str(arguments.get("modality") or "").strip().lower() or None
        if modality and modality not in ("chat", "video", "image", "audio"):
            return {
                "tool": "token6688_model_info", "ok": False,
                "error": f"modality 仅支持 chat/video/image/audio,收到 {modality!r}",
                "errorCode": "BAD_PARAMS",
            }
        items = await token6688_catalog.list_models(modality)
        return {
            "tool": "token6688_model_info", "ok": True, "action": "models",
            "modality": modality or "all", "count": len(items),
            "models": items,
            "note": "目录来自 model_sync 同步(上游 available 模型);视频/图片/音频模型走"
                    " video_generation / image_generation / tts 等工具调用,不进对话列表。",
        }

    if not model:
        return {
            "tool": "token6688_model_info", "ok": False,
            "error": "缺少 model 参数(如 seedance-2-5 / music / gpt-image-2)",
            "errorCode": "MISSING_PARAMS",
        }
    from .video_generation import _instantiate as _video_instantiate

    inst = _video_instantiate("token6688")
    if inst is None:
        return {
            "tool": "token6688_model_info", "ok": False,
            "error": "token6688 平台已永久下线",
            "errorCode": "PROVIDER_NOT_CONFIGURED",
        }
    try:
        if action == "params":
            # DB 优先:同步入库的 param_schema 含 available_when/linkages/max_items
            # 等 agent 构造素材参数需要的机读信息,且免一次上游请求
            from . import token6688_catalog

            meta = await token6688_catalog.get_model_metadata(model)
            if meta and meta.get("param_schema"):
                summary = token6688_catalog.summarize_params_for_agent(meta)
                return {
                    "tool": "token6688_model_info", "ok": True, "action": "params",
                    "model": model, "source": "db_sync",
                    "display_name": meta.get("display_name"),
                    **summary,
                }
            data = await inst.get_model_params(model)
            params_summary = []
            for p in data.get("params") or []:
                if not isinstance(p, dict):
                    continue
                opts = p.get("options") or []
                params_summary.append({
                    "name": p.get("name"),
                    "label": p.get("label"),
                    "default": next((o.get("value") for o in opts if o.get("is_default")), None),
                    "allowed_values": [o.get("value") for o in opts],
                })
            return {
                "tool": "token6688_model_info", "ok": True, "action": "params",
                "model": model, "source": "upstream",
                "display_name": data.get("display_name"),
                "capabilities": data.get("capabilities"),
                "params": params_summary, "raw": data,
            }
        if action == "pricing":
            data = await inst.get_model_pricing(model)
            return {
                "tool": "token6688_model_info", "ok": True, "action": "pricing",
                "model": model, "channel_groups": data.get("channel_groups"), "raw": data,
            }
        if action == "estimate":
            prompt = str(arguments.get("prompt") or "")
            params_in = arguments.get("params") if isinstance(arguments.get("params"), dict) else {}
            data = await inst.estimate_pricing(model, prompt, params=params_in or None)
            return {
                "tool": "token6688_model_info", "ok": True, "action": "estimate",
                "model": model,
                "effective_total_rmb": data.get("effective_total_rmb"),
                "max_effective_total_rmb": data.get("max_effective_total_rmb"),
                "price_basis": data.get("price_basis"),
                "raw": data,
            }
        return {
            "tool": "token6688_model_info", "ok": False,
            "error": f"未知 action: {action}(允许 estimate/params/pricing)", "errorCode": "BAD_PARAMS",
        }
    except Exception as e:  # noqa: BLE001
        return {
            "tool": "token6688_model_info", "ok": False, "model": model,
            "error": str(e)[:300], "errorCode": "PROVIDER_ERROR",
        }


async def _tool_token6688_cancel_task(arguments: dict[str, Any]) -> dict[str, Any]:
    """token6688_cancel_task: 取消在途异步任务(2026-09-08 新增)。

    DELETE /v1/tasks/{id} 优先、POST .../cancel 兜底;官方未收录该端点,
    ok=false 时如实带原因(unsupported/not_found),绝不阻塞对话。
    """
    task_id = str(arguments.get("task_id") or "").strip()
    if not task_id:
        return {
            "tool": "token6688_cancel_task", "ok": False,
            "error": "缺少 task_id(提交任务时返回的异步任务 ID)",
            "errorCode": "MISSING_PARAMS",
        }
    from .video_generation import _instantiate as _video_instantiate

    inst = _video_instantiate("token6688")
    if inst is None:
        return {
            "tool": "token6688_cancel_task", "ok": False,
            "error": "token6688 平台已永久下线",
            "errorCode": "PROVIDER_NOT_CONFIGURED",
        }
    try:
        result = await inst.cancel_task(task_id)
        return {"tool": "token6688_cancel_task", "task_id": task_id, **result}
    except Exception as e:  # noqa: BLE001
        return {
            "tool": "token6688_cancel_task", "ok": False, "task_id": task_id,
            "error": str(e)[:300], "errorCode": "PROVIDER_ERROR",
        }


async def _tool_token6688_upload_file(arguments: dict[str, Any]) -> dict[str, Any]:
    """token6688_upload_file: 上传文件换 24h 有效公网 URL(POST /v1/files,≤50MB)。

    多模态输入(视频参考素材 audios/videos、图编辑、声纹克隆参考音频)官方只收
    URL,本地文件先走此接口拿 URL。入参二选一:
    - path: 服务器本地文件路径(读取后上传)
    - url:  远程 http(s) URL(先 SSRF 校验,再拉取转发)
    purpose 可选(官方语义:assistants/voice 等)。
    """
    from .video_generation import _instantiate as _video_instantiate

    path = str(arguments.get("path") or "").strip()
    url = str(arguments.get("url") or "").strip()
    purpose = str(arguments.get("purpose") or "").strip() or None
    if not path and not url:
        return {
            "tool": "token6688_upload_file", "ok": False,
            "error": "缺少入参:传 path(服务器本地路径)或 url(远程 http URL)",
            "errorCode": "MISSING_PARAMS", "file_url": None,
        }
    import os

    try:
        if path:
            ok_path, path_info, path_err = _validate_media_local_path(path)
            if not ok_path:
                return {
                    "tool": "token6688_upload_file", "ok": False,
                    "error": path_info, "errorCode": path_err,
                    "file_url": None,
                }
            path = path_info
            if not os.path.isfile(path):
                return {
                    "tool": "token6688_upload_file", "ok": False,
                    "error": f"文件不存在: {path}", "errorCode": "FILE_NOT_FOUND",
                    "file_url": None,
                }
            size = os.path.getsize(path)
            if size > 50 * 1024 * 1024:
                return {
                    "tool": "token6688_upload_file", "ok": False,
                    "error": f"文件超过 50MB 上限({size} 字节)", "errorCode": "FILE_TOO_LARGE",
                    "file_url": None,
                }
            with open(path, "rb") as _f:
                data = _f.read()
            filename = os.path.basename(path) or "file.bin"
        else:
            from .screenshot_service import _validate_url_ssrf

            ok_ssrf, reason = _validate_url_ssrf(url)
            if not ok_ssrf:
                return {
                    "tool": "token6688_upload_file", "ok": False,
                    "error": f"URL 不允许访问: {reason}", "errorCode": "SSRF_BLOCKED",
                    "file_url": None,
                }
            import httpx as _httpx

            # 2026-10-31 安全强化第 32 批:走 SSRF 安全下载单源(逐跳 + 钉 IP)。
            # 此前 follow_redirects=True ⇒ 公网 302 → 内网即可把内网文件上传到外部存储。
            fetched_data = await _download_url_ssrf_safe(url, _httpx, timeout=60.0)
            if fetched_data is None:
                return {
                    "tool": "token6688_upload_file", "ok": False,
                    "error": "拉取远程文件失败或被 SSRF 尺拒绝(重定向逐跳校验)",
                    "errorCode": "FETCH_FAILED",
                    "file_url": None,
                }
            data = fetched_data
            if len(data) > 50 * 1024 * 1024:
                return {
                    "tool": "token6688_upload_file", "ok": False,
                    "error": "远程文件超过 50MB 上限", "errorCode": "FILE_TOO_LARGE",
                    "file_url": None,
                }
            filename = url.rsplit("/", 1)[-1][:200] or "file.bin"
        inst = _video_instantiate("token6688")
        if inst is None:
            return {
                "tool": "token6688_upload_file", "ok": False,
                "error": "token6688 平台已永久下线",
                "errorCode": "PROVIDER_NOT_CONFIGURED", "file_url": None,
            }
        file_url = await inst.upload_file(data, filename, purpose=purpose)
        return {
            "tool": "token6688_upload_file", "ok": True,
            "file_url": file_url, "filename": filename, "size": len(data),
            "hint": "该 URL 24 小时内有效,可作为视频参考素材(videos/audios)/图编辑输入/声纹参考",
        }
    except Exception as e:  # noqa: BLE001
        return {
            "tool": "token6688_upload_file", "ok": False,
            "error": str(e)[:300], "errorCode": "PROVIDER_ERROR", "file_url": None,
        }


_TTS_OPENAI_VOICES = frozenset({"alloy", "echo", "fable", "onyx", "nova", "shimmer"})


def _tts_engine_chain(engine: str, voice: str) -> list[str]:
    """TTS 引擎自动切换链(2026-09-08 全模态自动切换)。

    - engine=auto(缺省):voice 是 OpenAI 官方音色或声纹库 voice_id → token6688 优先
      (edge 发不出这些音色);否则 edge 优先(零 key 零成本)。失败互备换下一家。
    - engine 显式指定 edge/token6688 → 单引擎(尊重用户明确选择,失败如实报错)。
    """
    if engine in ("edge", "token6688"):
        return [engine]
    if voice:
        v = voice.strip()
        if v.lower() in _TTS_OPENAI_VOICES or v.lower().startswith("voice_"):
            return ["token6688", "edge"]
    return ["edge", "token6688"]


async def _tts_once(
    engine: str, text: str, arguments: dict[str, Any]
) -> tuple[bytes, str, str, str, dict[str, Any] | None]:
    """单引擎合成一次。返回 (audio, content_type, voice, provider_name, err)。

    err 非 None 时 audio 为空字节,err 为归一化失败 dict(ok=False)。
    """
    if engine == "token6688":
        from .video_generation import _instantiate as _video_instantiate

        inst = _video_instantiate("token6688")
        if inst is None:
            return b"", "", "", "token6688", {
                "ok": False, "provider": "token6688",
                "error": "token6688 平台已永久下线;"
                         "可改用 engine=edge(零成本)或 engine=auto(自动切换)",
                "errorCode": "PROVIDER_NOT_CONFIGURED", "audio_url": None,
            }
        used_voice = str(arguments.get("voice") or "alloy")
        try:
            audio, content_type = await inst.tts(
                text, voice=used_voice,
                speed=float(arguments.get("speed") or 1.0),
                response_format=str(arguments.get("response_format") or "mp3"),
            )
            return audio, content_type, used_voice, "token6688", None
        except Exception as e:  # noqa: BLE001
            return b"", "", used_voice, "token6688", {
                "ok": False, "provider": "token6688",
                "error": str(e)[:300], "errorCode": "PROVIDER_ERROR", "audio_url": None,
            }
    # engine == "edge":微软 edge-tts,零 key 零成本
    used_voice = str(arguments.get("voice") or "zh-CN-XiaoxiaoNeural")
    try:
        import edge_tts

        communicate = edge_tts.Communicate(text, voice=used_voice)
        chunks: list[bytes] = []
        async for chunk in communicate.stream():
            if chunk.get("type") == "audio":
                chunks.append(chunk["data"])
        if not chunks:
            raise RuntimeError("edge-tts 未返回音频数据")
        return b"".join(chunks), "audio/mpeg", used_voice, "edge-tts", None
    except Exception as e:  # noqa: BLE001
        return b"", "", used_voice, "edge-tts", {
            "ok": False, "provider": "edge-tts",
            "error": f"edge-tts 不可达或失败: {e}"[:300], "errorCode": "ENGINE_ERROR",
            "audio_url": None,
        }


async def _tool_voice_tts(arguments: dict[str, Any]) -> dict[str, Any]:
    """voice_tts: 文本转语音(对话内朗读/配音/播报,2026-09-08 落地)。

    2026-09-08 全模态自动切换升级:engine=auto(新默认)按音色智能排序引擎链,
    失败自动互备(edge↔token6688),全失败才报错;显式 engine 仍单引擎。
    2026-09-09 深度增强:
    - 超长文本(2000<text≤5000)自动切 token6688 异步 TTS(/v1/audio/speech/async,
      免长连接;返回 task_id + submitted=true,与视频/音乐长任务同构,可用 task_id 取件)
    - task_id 查询模式:只传 task_id 时查询异步 TTS 任务状态,completed 返回公网 audio_url
    - voice 支持声纹库 voice_id(克隆音色;engine=token6688 时直通)
    - edge:微软 edge-tts,零 key 零成本,中文质量高(白名单音色)
    - token6688:聚合网关 /v1/audio/speech(OpenAI 同构,单 key;
      voice 可传官方音色 alloy/echo/fable/onyx/nova/shimmer 或声纹库 voice_id 克隆音色)
    - 同步接口直接出音频,无任务轮询;audio_url 为 data URI(前端 <audio> 直接播放)
    - 支持 save_path 落地(.mp3/.wav/.ogg/.flac,工作区白名单,50MB 上限)
    """
    import base64 as _base64
    from datetime import datetime

    # ---- task_id 查询模式(2026-09-09):异步 TTS 取件 ----
    query_task_id = str(arguments.get("task_id") or "").strip()
    if query_task_id:
        from .video_generation import _instantiate as _video_instantiate

        inst = _video_instantiate("token6688")
        if inst is None:
            return {
                "tool": "voice_tts", "ok": False, "task_id": query_task_id,
                "error": "token6688 平台已永久下线,"
                         "无法查询异步 TTS 任务",
                "errorCode": "PROVIDER_NOT_CONFIGURED", "audio_url": None,
            }
        try:
            st = await inst.get_task_status(query_task_id)
        except Exception as e:  # noqa: BLE001
            return {
                "tool": "voice_tts", "ok": False, "task_id": query_task_id,
                "error": f"查询异步 TTS 任务失败: {e}"[:300],
                "errorCode": "PROVIDER_ERROR", "audio_url": None,
            }
        if st.get("failed"):
            return {
                "tool": "voice_tts", "ok": False, "task_id": query_task_id,
                "status": st.get("status"), "error": st.get("error") or "异步 TTS 任务失败",
                "errorCode": "TASK_FAILED", "audio_url": None,
            }
        audio_url = st.get("audio_url") or st.get("video_url") or ""
        if st.get("ok") and audio_url:
            return {
                "tool": "voice_tts", "ok": True, "task_id": query_task_id,
                "status": "completed", "audio_url": audio_url,
                "provider": "token6688", "message": "异步 TTS 任务已完成",
            }
        return {
            "tool": "voice_tts", "ok": True, "task_id": query_task_id,
            "status": st.get("status") or "processing", "submitted": True,
            "audio_url": None, "provider": "token6688",
            "message": f"异步 TTS 任务处理中(status={st.get('status') or 'processing'}),"
                       "请稍后带同一 task_id 查询取件",
        }

    text = arguments.get("text", "")
    if not isinstance(text, str) or not text.strip():
        return {
            "tool": "voice_tts", "ok": False,
            "error": "缺少 text 参数", "errorCode": "MISSING_PARAMS", "audio_url": None,
        }
    text = text.strip()
    if len(text) > 5000:
        return {
            "tool": "voice_tts", "ok": False,
            "error": f"text 超长({len(text)}>5000 字符),请分段合成或缩短文本",
            "errorCode": "TEXT_TOO_LONG", "audio_url": None,
        }
    engine = str(arguments.get("engine") or "auto").lower()
    if engine not in ("auto", "edge", "token6688"):
        return {
            "tool": "voice_tts", "ok": False,
            "error": f"未知 engine: {engine}(允许 auto/edge/token6688)",
            "errorCode": "BAD_PARAMS", "audio_url": None,
        }
    save_path = arguments.get("save_path")
    # AIS-118:save_path 提前 fail-fast —— 旧码只在下游 `if ok_path:` 里落盘,校验
    # 失败被丢弃,末尾照旧回 ok=true/saved_path=None,调用方分不清"没要求落盘"与
    # "落盘被拒"。这里在合成前就判,非法路径一个上游都不调(与 image/video 一致)。
    resolved_save: str | None = None
    if save_path:
        ok_path, resolved_save, err_code = _validate_audio_save_path(str(save_path))
        if not ok_path:
            logger.warning(
                "[mcp][tts] save_path 校验失败(AIS-118): code=%s path=%s", err_code, save_path
            )
            return {
                "tool": "voice_tts", "ok": False, "errorCode": err_code,
                "error": f"save_path 校验失败: {err_code}", "audio_url": None,
                "saved_path": None, "save_path": str(save_path),
            }

    # ---- 超长文本(>2000):自动切 token6688 异步 TTS(免长连接;产物为公网 URL)----
    if len(text) > 2000:
        from .video_generation import _instantiate as _video_instantiate

        if engine == "edge":
            return {
                "tool": "voice_tts", "ok": False,
                "error": f"text 超长({len(text)}>2000 字符),edge 引擎不支持超长合成;"
                         "长文本 TTS 已随 token6688 平台永久下线，请把文本拆到 2000 字符以内",
                "errorCode": "TEXT_TOO_LONG", "audio_url": None,
            }
        inst = _video_instantiate("token6688")
        if inst is None:
            return {
                "tool": "voice_tts", "ok": False,
                "error": "token6688 平台已永久下线，长文本 TTS 不可用"
                         "请把文本分段(每段 ≤2000 字符)走 edge",
                "errorCode": "PROVIDER_NOT_CONFIGURED", "audio_url": None,
            }
        used_voice = str(arguments.get("voice") or "alloy")
        try:
            sub = await inst.tts_async(
                text, voice=used_voice,
                speed=float(arguments.get("speed") or 1.0),
                response_format=str(arguments.get("response_format") or "mp3"),
                wait=False,
            )
        except Exception as e:  # noqa: BLE001
            return {
                "tool": "voice_tts", "ok": False,
                "error": f"token6688 异步 TTS 提交失败: {e}"[:300],
                "errorCode": "PROVIDER_ERROR", "audio_url": None,
            }
        return {
            "tool": "voice_tts", "ok": True, "provider": "token6688",
            "engine": "token6688", "voice": used_voice,
            "task_id": sub.get("task_id"), "submitted": True,
            "status": "submitted", "text_chars": len(text),
            "audio_url": None,
            "message": f"超长文本已提交 token6688 异步 TTS(task_id={sub.get('task_id')}),"
                       "完成后会返回公网语音链接;稍后问我'语音好了吗'带该 task_id 即可取件",
        }

    chain = _tts_engine_chain(engine, str(arguments.get("voice") or ""))
    attempts: list[dict[str, str]] = []
    audio = b""
    content_type = "audio/mpeg"
    used_voice = ""
    provider_name = ""
    used_engine = chain[0] if chain else "edge"
    for eng in chain:
        audio, content_type, used_voice, provider_name, err = await _tts_once(eng, text, arguments)
        if err is None:
            used_engine = eng
            break
        attempts.append({
            "engine": eng, "provider": provider_name,
            "errorCode": str(err.get("errorCode", "UNKNOWN")),
            "error": str(err.get("error", ""))[:200],
        })
    else:
        # 全引擎失败:errorCode 保留末次错误码,附尝试明细(对话侧如实转述)
        last = attempts[-1]
        return {
            "tool": "voice_tts", "ok": False, "provider": last["provider"],
            "error": last["error"], "errorCode": last["errorCode"],
            "audio_url": None, "failover_attempts": attempts,
            "message": f"全部 {len(attempts)} 个 TTS 引擎均失败",
        }

    # ---- save_path 落地(可选)----
    saved_path: str | None = None
    file_size_bytes = len(audio)
    if resolved_save:
        ok_w, sp, sz, werr = await _persist_audio_to_disk(audio, resolved_save)
        if not ok_w:
            logger.warning("[mcp][tts] 音频落盘失败(AIS-118): code=%s", werr)
            return {
                "tool": "voice_tts", "ok": False, "errorCode": werr,
                "error": f"音频写入磁盘失败: {werr}", "audio_url": None,
                "saved_path": None, "save_path": str(save_path),
            }
        saved_path, file_size_bytes = sp, sz

    # data URI 直播给前端 <audio>(文本≤2000 字符,mp3 通常 <2MB)
    audio_url = f"data:{content_type or 'audio/mpeg'};base64,{_base64.b64encode(audio).decode()}"
    out = {
        "tool": "voice_tts", "ok": True,
        "provider": provider_name, "engine": used_engine, "voice": used_voice,
        "text_chars": len(text), "file_size_bytes": file_size_bytes,
        "audio_url": audio_url, "saved_path": saved_path,
        "created_at": datetime.now(UTC).isoformat(),
        "message": "语音合成完成" + (f",saved={saved_path}" if saved_path else ""),
    }
    if attempts:
        out["failover_attempts"] = attempts
    return out


# ---------------------------------------------------------------------------
# token6688_voice_clone(2026-09-09 全模态深度适配):对话内声纹克隆管理。
# 官方声纹库端点(/v1/audio/voices):
# - action=list    列我的声纹(voice_id/名称/时长等)
# - action=upload  上传参考音频(本地路径 / http URL / base64 data URI)克隆音色
#                  (官方硬限制:MP3/M4A/WAV,10~300s,<20MiB;异步任务轮询至终态)
# - action=get     查单一声纹详情(克隆状态)
# 克隆成功后把 voice_id 传给 voice_tts(engine=token6688)即可用克隆音色合成。
# ---------------------------------------------------------------------------


# AIS-050(2026-11-08 裁定):声纹克隆是贵资源,不能只靠路径校验 ——
# 归属闸(谁克隆的只能谁 list/get/delete)+ 计费闸(克隆属计费动作)。
# 归属存储沿用仓内 sidecar 思路(artifacts `<file>.owner` 同一授权契约):
# 平台声纹库是共享账号、上游无属主概念,故本地维护 voice_id → user_id 账本。
# 账本缺失(机制上线前的存量声纹)一律 fail-closed —— 无法证明归属就不许读删,
# 与 AIS-096「新产物缺 sidecar 即 403」同一口径。账本读写失败同样 fail-closed,
# 且必须留显式告警,不许静默当成"没有属主"。
_VOICE_OWNER_STORE_ENV: Final[str] = "VOICE_OWNER_STORE"
# 一次克隆(上游训练 + 挂载)按 100 积分报价:高于生图默认 floor(8),属"需要余额/批准"
# 的贵资源档;宿主未盖章余额时维持旧路径不计量(与 gate_image_spend 同判据)。
VOICE_CLONE_QUOTED_CREDITS: Final[int] = 100


def _voice_owner_store_path() -> Path:
    raw = os.getenv(_VOICE_OWNER_STORE_ENV, "").strip()
    return Path(raw) if raw else Path(".uploads") / "voice_owners.json"


def _load_voice_owners() -> dict[str, Any]:
    path = _voice_owner_store_path()
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return {}
    except (OSError, ValueError) as exc:
        logger.warning(
            "[mcp] 声纹归属账本读取失败(AIS-050 fail-closed): path=%s err=%s", path, exc
        )
        return {}
    return data if isinstance(data, dict) else {}


def _voice_owner_of(voice_id: str, owners: dict[str, Any] | None = None) -> str:
    entry = (owners if owners is not None else _load_voice_owners()).get(voice_id)
    if isinstance(entry, dict):
        return str(entry.get("user_id") or "").strip()
    if isinstance(entry, str):
        return entry.strip()
    return ""


def _remember_voice_owner(voice_id: str, user_id: str) -> None:
    """登记的失败不阻断克隆(上游已完成),但必须告警;后续 get/delete 会 fail-closed。"""
    if not voice_id or not user_id:
        return
    path = _voice_owner_store_path()
    owners = _load_voice_owners()
    owners[voice_id] = {"user_id": user_id, "createdAt": time.strftime("%Y-%m-%dT%H:%M:%S%z")}
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_name(path.name + ".tmp")
        tmp.write_text(json.dumps(owners, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(tmp, path)
    except OSError as exc:
        logger.warning(
            "[mcp] 声纹归属登记失败(AIS-050,后续 get/delete 将 fail-closed): voice=%s err=%s",
            voice_id,
            exc,
        )


def _voice_identity_denial(action: str) -> dict[str, Any]:
    """列表/读/删/克隆都必须有宿主注入的身份;缺失按 fail-closed 拒。"""
    logger.warning(
        "[mcp] voice_clone 缺少宿主注入身份(AIS-050 归属闸): action=%s code=IDENTITY_REQUIRED",
        action,
    )
    return {
        "tool": "token6688_voice_clone", "ok": False, "action": action,
        "errorCode": "IDENTITY_REQUIRED",
        "error": "声纹属于个人资产,必须携带宿主注入的用户身份后才能操作",
    }


def _voice_id_of(item: Any) -> str:
    if not isinstance(item, dict):
        return ""
    return str(item.get("voice_id") or item.get("id") or "").strip()


def _voice_owner_denial(
    arguments: dict[str, Any], voice_id: str, action: str
) -> dict[str, Any] | None:
    user_id = str(arguments.get("__user_id") or "").strip()
    if not user_id:
        return _voice_identity_denial(action)
    owner = _voice_owner_of(voice_id)
    if owner == user_id:
        return None
    logger.warning(
        "[mcp] voice_clone 归属校验失败(AIS-050): action=%s voice=%s caller=%s owner=%s code=VOICE_NOT_OWNED",
        action, voice_id or "-", user_id, owner or "(无归属记录)",
    )
    return {
        "tool": "token6688_voice_clone", "ok": False, "action": action,
        "voice_id": voice_id or None,
        "errorCode": "VOICE_NOT_OWNED",
        "error": "该声纹不属于当前用户(机制上线前的存量声纹无归属记录,同样拒绝)",
    }


def _voice_clone_credit_denial(arguments: dict[str, Any]) -> dict[str, Any] | None:
    """克隆计费闸:复用生图的 decide_credit_spend 判据,拒绝发生在上游之前。"""
    from app.core.mcp_tool_approval import (
        HOST_APPROVAL_KEY,
        HOST_BALANCE_KEY,
        decide_credit_spend,
    )

    if HOST_BALANCE_KEY not in arguments or arguments.get(HOST_BALANCE_KEY) is None:
        return None  # 宿主没盖章余额 ⇒ 不计量,维持旧路径
    balance = arguments.get(HOST_BALANCE_KEY)
    approval = arguments.get(HOST_APPROVAL_KEY)
    if approval not in ("granted", "denied"):
        approval = None if approval is None else "unrecognized"
    if isinstance(balance, bool) or not isinstance(balance, int) or balance < 0:
        quoted, disposition, reason = None, "unjudged", "balance-invalid"
    else:
        quoted = VOICE_CLONE_QUOTED_CREDITS
        disposition, reason = decide_credit_spend(
            quoted_credits=quoted, balance_credits=balance, approval=approval
        )
        if approval == "unrecognized":
            disposition, reason = "unjudged", "approval-unrecognized"
    if disposition == "allow":
        return None
    logger.warning(
        "[mcp] 声纹克隆计费闸拒绝(AIS-050): disposition=%s reason=%s quoted=%s balance=%s code=CREDIT_APPROVAL_REQUIRED",
        disposition, reason, quoted, balance,
    )
    return {
        "tool": "token6688_voice_clone", "ok": False, "action": "upload",
        "errorCode": "CREDIT_APPROVAL_REQUIRED",
        "error": "声纹克隆属于计费资源,当前余额/批准不足,已在调用上游前拦截",
        "creditSpend": {
            "disposition": disposition, "quotedCredits": quoted,
            "balanceCredits": balance if isinstance(balance, int) else None,
            "reason": reason,
        },
    }


def _audio_source_from_args(
    arguments: dict[str, Any],
) -> tuple[bytes, str, str | None, str | None]:
    """从工具入参解析音频字节:path / url / data URI 三选一。

    Returns (audio_bytes, filename, error, error_code)。error 非 None 时前两者为空;
    error_code 是结构化错误码(path 分支被工作区/敏感文件判据拒绝时为
    PATH_NOT_ALLOWED / SENSITIVE_FILE_BLOCKED)。
    """
    import base64 as _b64
    import os as _os

    path = str(arguments.get("path") or "").strip()
    url = str(arguments.get("url") or "").strip()
    data_uri = str(arguments.get("data_uri") or "").strip()
    sources = sum(bool(v) for v in (path, url, data_uri))
    if sources == 0:
        return b"", "", "缺少入参:path / url / data_uri 至少传一个", None
    if sources > 1:
        return b"", "", "path / url / data_uri 只能传一个", None
    if path:
        ok_path, path_info, path_err = _validate_media_local_path(path)
        if not ok_path:
            return b"", "", path_info, path_err
        path = path_info
        if not _os.path.isfile(path):
            return b"", "", f"文件不存在: {path}", None
        size = _os.path.getsize(path)
        if size >= 20 * 1024 * 1024:
            return b"", "", f"声纹参考音频 {size} 字节超过官方 <20MiB 硬限制", None
        try:
            with open(path, "rb") as _f:
                return _f.read(), _os.path.basename(path) or "ref.wav", None, None
        except OSError as e:
            return b"", "", f"读取文件失败: {e}", None
    if url:
        from .screenshot_service import _validate_url_ssrf

        ok_ssrf, reason = _validate_url_ssrf(url)
        if not ok_ssrf:
            return b"", "", f"URL 不允许访问: {reason}", None
        import httpx as _httpx

        # 2026-10-31 安全强化第 32 批:走同步版 SSRF 安全下载单源(逐跳 + 钉 IP)。
        # 此前 follow_redirects=True ⇒ 公网 302 → 内网音频可被拉取。
        data = _download_url_ssrf_safe_sync(url, _httpx, timeout=60.0)
        if data is None:
            return b"", "", "拉取远程音频失败或被 SSRF 尺拒绝(重定向逐跳校验)", None
        if len(data) >= 20 * 1024 * 1024:
            return b"", "", "远程音频超过官方 <20MiB 硬限制", None
        return data, url.rsplit("/", 1)[-1][:200] or "ref.wav", None, None
    # data URI:data:audio/mpeg;base64,....
    # 2026-09-09 修复:partition 结果变量原命名为 _b64,遮蔽了 import base64 as _b64
    # 的模块引用,导致 b64decode 抛 AttributeError → 永远"解码失败"。改名 _b64payload。
    _head, _sep, _b64payload = data_uri.partition(",")
    if not _sep or not _b64payload:
        return b"", "", "data_uri 格式非法(应为 data:audio/xxx;base64,...)", None
    try:
        data = _b64.b64decode(_b64payload)
    except Exception:  # noqa: BLE001
        data = b""
    if not data:
        return b"", "", "data_uri base64 解码失败或内容为空", None
    if len(data) >= 20 * 1024 * 1024:
        return b"", "", "data_uri 音频超过官方 <20MiB 硬限制", None
    ext = "mp3"
    if _head and "/" in _head:
        _mime = _head.split(";", 1)[0].split("/", 1)[-1]
        if _mime in ("wav", "wave", "m4a", "mp3"):
            ext = "wav" if _mime == "wave" else _mime
    return data, f"ref.{ext}", None, None


async def _tool_token6688_voice_clone(arguments: dict[str, Any]) -> dict[str, Any]:
    """token6688_voice_clone: 声纹克隆管理(2026-09-09 全模态深度适配)。

    - action=list: 列我的声纹库(voice_id 列表,克隆 TTS 直接传 voice_id)
    - action=upload: 上传参考音频克隆音色(path / url / data_uri 三选一;
      MP3/M4A/WAV,10~300s,<20MiB;异步任务轮询至终态,返回 voice_id)
    - action=get: 查单一声纹(voice_id 必填)
    - action=delete: 删除克隆声纹(voice_id 必填;DELETE /v1/audio/voices/{id} 优先,
      POST /delete 兜底,失败如实返回不抛)
    用户说"克隆我的声音/用我的声音朗读/上传参考音频"时使用;"删除音色/清理声纹"用 delete。
    """
    action = str(arguments.get("action") or "list").lower()
    if action not in ("list", "upload", "get", "delete"):
        return {
            "tool": "token6688_voice_clone", "ok": False,
            "error": f"未知 action: {action}(允许 list/upload/get/delete)", "errorCode": "BAD_PARAMS",
        }
    from .video_generation import _instantiate as _video_instantiate

    inst = _video_instantiate("token6688")
    if inst is None:
        return {
            "tool": "token6688_voice_clone", "ok": False,
            "error": "token6688 平台已永久下线",
            "errorCode": "PROVIDER_NOT_CONFIGURED",
        }
    try:
        if action == "list":
            user_id = str(arguments.get("__user_id") or "").strip()
            if not user_id:
                return _voice_identity_denial("list")
            voices = await inst.list_voices()
            owners = _load_voice_owners()
            mine = [v for v in voices if _voice_owner_of(_voice_id_of(v), owners) == user_id]
            return {
                "tool": "token6688_voice_clone", "ok": True, "action": "list",
                "count": len(mine), "voices": mine,
                "omitted": max(0, len(voices) - len(mine)),
                "hint": "把某个 voice_id 传给 voice_tts(engine=token6688,voice=voice_id)即可克隆合成",
            }
        if action == "get":
            voice_id = str(arguments.get("voice_id") or "").strip()
            if not voice_id:
                return {
                    "tool": "token6688_voice_clone", "ok": False,
                    "error": "缺少 voice_id(action=get 需要)", "errorCode": "MISSING_PARAMS",
                }
            denial = _voice_owner_denial(arguments, voice_id, "get")
            if denial is not None:
                return denial
            data = await inst.get_voice(voice_id)
            return {
                "tool": "token6688_voice_clone", "ok": True, "action": "get",
                "voice_id": voice_id, "voice": data, "raw": data,
            }
        if action == "delete":
            voice_id = str(arguments.get("voice_id") or "").strip()
            if not voice_id:
                return {
                    "tool": "token6688_voice_clone", "ok": False,
                    "error": "缺少 voice_id(action=delete 需要)", "errorCode": "MISSING_PARAMS",
                }
            denial = _voice_owner_denial(arguments, voice_id, "delete")
            if denial is not None:
                return denial
            result = await inst.delete_voice(voice_id)
            return {
                "tool": "token6688_voice_clone", "ok": bool(result.get("ok")), "action": "delete",
                "voice_id": voice_id, "status": result.get("status", ""),
                "error": result.get("error"), "raw": result.get("raw"),
                "hint": "声纹已删除" if result.get("ok") else f"删除失败(status={result.get('status')})",
            }
        # action == "upload":贵资源 —— 身份 + 计费闸都必须在读音频/调上游之前。
        user_id = str(arguments.get("__user_id") or "").strip()
        if not user_id:
            return _voice_identity_denial("upload")
        credit_denial = _voice_clone_credit_denial(arguments)
        if credit_denial is not None:
            return credit_denial
        audio, filename, err, err_code = _audio_source_from_args(arguments)
        if err:
            return {
                "tool": "token6688_voice_clone", "ok": False,
                "error": err, "errorCode": err_code or "BAD_PARAMS",
            }
        result = await inst.upload_voice(audio, filename)
        voice_id = ""
        v = result.get("voice")
        if isinstance(v, dict):
            voice_id = str(v.get("id") or v.get("voice_id") or "").strip()
        if not voice_id:
            voice_id = str(result.get("id") or result.get("voice_id") or "").strip()
        _remember_voice_owner(voice_id, user_id)
        return {
            "tool": "token6688_voice_clone", "ok": True, "action": "upload",
            "voice_id": voice_id or None, "voice": v if isinstance(v, dict) else None,
            "filename": filename, "size": len(audio), "raw": result,
            "hint": f"声纹克隆完成:voice_id={voice_id or '(见 voice 字段)'}。"
                    "用 voice_tts(engine=token6688,voice=voice_id)即可用该音色合成",
        }
    except Exception as e:  # noqa: BLE001
        return {
            "tool": "token6688_voice_clone", "ok": False,
            "error": str(e)[:300], "errorCode": "PROVIDER_ERROR",
        }


# ---------------------------------------------------------------------------
# audio_transcription(2026-09-09 全模态深度适配):对话内语音转文字(ASR)。
# 引擎链:local(faster-whisper 本地推理,零 key 零成本,与 /api/voice/stt 同源)
# → token6688(/v1/audio/transcriptions,OpenAI 同构;平台暂未开通时 404 自动换)。
# 输入支持:URL(http/https,过 SSRF 校验)/ base64 data URI / 本地路径。
# ---------------------------------------------------------------------------
_AUDIO_STT_MAX_BYTES = 25 * 1024 * 1024  # 25MB,与主流转写接口上限对齐


def _stt_engine_chain() -> list[str]:
    """STT 引擎链:本地 faster-whisper 优先(零成本),token6688 兜底。"""
    return ["local", "token6688"]


async def _stt_once(
    engine: str, audio_bytes: bytes, filename: str, language: str | None
) -> tuple[str, str, str, dict[str, Any] | None]:
    """单引擎转写一次。返回 (text, model_name, provider_name, err)。

    err 非 None 时 text 为空串,err 为归一化失败 dict(ok=False)。
    """
    if engine == "token6688":
        from .video_generation import _instantiate as _video_instantiate

        inst = _video_instantiate("token6688")
        if inst is None:
            return "", "", "token6688", {
                "ok": False, "provider": "token6688",
                "error": "token6688 平台已永久下线",
                "errorCode": "PROVIDER_NOT_CONFIGURED",
            }
        try:
            st = await inst.stt(audio_bytes, filename, language=language or None)
            return str(st.get("text", "")), str(st.get("model", "")), "token6688", None
        except Exception as e:  # noqa: BLE001
            return "", "", "token6688", {
                "ok": False, "provider": "token6688",
                "error": str(e)[:300], "errorCode": "PROVIDER_ERROR",
            }
    # engine == "local":faster-whisper 本地推理(与 /api/voice/stt 同源,零成本)
    try:
        import asyncio as _asyncio
        import os as _os
        import tempfile as _tempfile

        from ..routers.voice_stt import _DEFAULT_STT_MODEL, _get_whisper_model, _transcribe_sync

        suffix = ".wav"
        dot = filename.rfind(".")
        if dot >= 0:
            ext = filename[dot + 1:].lower()
            if ext.isalnum() and len(ext) <= 6:
                suffix = f".{ext}"
        model = await _asyncio.to_thread(_get_whisper_model)
        tmp_fd, tmp_path = _tempfile.mkstemp(suffix=suffix)
        try:
            with _os.fdopen(tmp_fd, "wb") as f:
                f.write(audio_bytes)
            text = await _asyncio.to_thread(_transcribe_sync, model, tmp_path, language or None)
        finally:
            with contextlib.suppress(OSError):
                _os.unlink(tmp_path)
        return text, _DEFAULT_STT_MODEL, "faster-whisper", None
    except ImportError:
        return "", "", "faster-whisper", {
            "ok": False, "provider": "faster-whisper",
            "error": "faster-whisper 未安装(请运行 pip install faster-whisper)",
            "errorCode": "ENGINE_UNAVAILABLE",
        }
    except Exception as e:  # noqa: BLE001
        return "", "", "faster-whisper", {
            "ok": False, "provider": "faster-whisper",
            "error": f"本地转写失败: {e}"[:300], "errorCode": "ENGINE_ERROR",
        }


async def _tool_audio_transcription(arguments: dict[str, Any]) -> dict[str, Any]:
    """audio_transcription: 语音转文字(对话内 ASR,2026-09-09 落地)。

    引擎链自动切换:local(faster-whisper,零 key 零成本)→ token6688(备用),
    首选失败自动换下一家,全失败聚合报错(对话侧如实转述)。
    用户说"把这段录音转文字/听听这个音频说了什么"时使用。
    """
    import base64 as _base64

    audio_in = arguments.get("audio") or arguments.get("file") or ""
    if not isinstance(audio_in, str) or not audio_in.strip():
        return {
            "tool": "audio_transcription", "ok": False,
            "error": "缺少 audio 参数(URL / base64 data URI / 本地路径)",
            "errorCode": "MISSING_PARAMS", "text": None,
        }
    audio_in = audio_in.strip()
    language = str(arguments.get("language") or "").strip() or None
    filename = str(arguments.get("filename") or "audio.wav")

    audio_bytes = b""
    source = ""
    if audio_in.startswith("data:"):
        # base64 data URI:data:audio/mpeg;base64,....
        _head, _sep, _b64 = audio_in.partition(",")
        if not _sep or not _b64:
            return {
                "tool": "audio_transcription", "ok": False,
                "error": "data URI 格式非法(应为 data:audio/xxx;base64,...)",
                "errorCode": "BAD_PARAMS", "text": None,
            }
        try:
            audio_bytes = _base64.b64decode(_b64)
        except Exception:  # noqa: BLE001
            audio_bytes = b""
        if not audio_bytes:
            # 解码异常或空载荷(如 b64decode 忽略非法字符后得空)统一按格式非法处理
            return {
                "tool": "audio_transcription", "ok": False,
                "error": "base64 解码失败或内容为空", "errorCode": "BAD_PARAMS",
                "text": None,
            }
        source = "data_uri"
    elif audio_in.lower().startswith(("http://", "https://")):
        # 2026-10-31 R12:统一走逐跳 + 钉 IP 的下载单源。
        # 此前只有首跳 _validate_url_ssrf,校验期与连接期两次 DNS 可被 rebinding 换掉。
        import httpx as _httpx

        downloaded = await _download_url_ssrf_safe(audio_in, _httpx, timeout=60.0)
        if downloaded is None:
            return {
                "tool": "audio_transcription", "ok": False,
                "error": "URL 不允许访问或下载失败", "errorCode": "SSRF_BLOCKED",
                "text": None,
            }
        audio_bytes = downloaded
        source = "url"
        _path_lower = urlparse(audio_in).path.lower()
        _url_ext = _path_lower.rsplit(".", 1)[-1] if "." in _path_lower else ""
        filename = (
            f"audio.{_url_ext}"
            if _url_ext in ("mp3", "wav", "ogg", "flac", "m4a", "webm", "aac")
            else "audio.mp3"
        )
    else:
        # 本地路径(如 voice_tts save_path 落地的音频)
        from pathlib import Path as _Path

        ok_path, path_info, path_err = _validate_media_local_path(audio_in)
        if not ok_path:
            return {
                "tool": "audio_transcription", "ok": False,
                "error": path_info, "errorCode": path_err,
                "text": None,
            }
        audio_in = path_info
        p = _Path(audio_in)
        if not p.is_file():
            return {
                "tool": "audio_transcription", "ok": False,
                "error": f"本地文件不存在: {audio_in}", "errorCode": "FILE_NOT_FOUND",
                "text": None,
            }
        if p.stat().st_size > _AUDIO_STT_MAX_BYTES:
            return {
                "tool": "audio_transcription", "ok": False,
                "error": f"音频超限({p.stat().st_size} > {_AUDIO_STT_MAX_BYTES} 字节)",
                "errorCode": "TOO_LARGE", "text": None,
            }
        audio_bytes = p.read_bytes()
        source = "local_path"
        filename = p.name

    if not audio_bytes:
        return {
            "tool": "audio_transcription", "ok": False,
            "error": "音频内容为空", "errorCode": "EMPTY_AUDIO", "text": None,
        }
    if len(audio_bytes) > _AUDIO_STT_MAX_BYTES:
        return {
            "tool": "audio_transcription", "ok": False,
            "error": f"音频超限({len(audio_bytes)} > {_AUDIO_STT_MAX_BYTES} 字节)",
            "errorCode": "TOO_LARGE", "text": None,
        }

    attempts: list[dict[str, str]] = []
    text = ""
    used_model = ""
    provider_name = ""
    for eng in _stt_engine_chain():
        text, used_model, provider_name, err = await _stt_once(
            eng, audio_bytes, filename, language,
        )
        if err is None:
            break
        attempts.append({
            "engine": eng, "provider": err.get("provider", eng),
            "errorCode": str(err.get("errorCode", "UNKNOWN")),
            "error": str(err.get("error", ""))[:200],
        })
    else:
        last = attempts[-1]
        return {
            "tool": "audio_transcription", "ok": False,
            "provider": last["provider"], "error": last["error"],
            "errorCode": last["errorCode"], "text": None,
            "failover_attempts": attempts,
            "message": f"全部 {len(attempts)} 个转写引擎均失败",
        }

    out = {
        "tool": "audio_transcription", "ok": True,
        "provider": provider_name, "model": used_model,
        "text": text, "text_chars": len(text),
        "audio_bytes": len(audio_bytes), "source": source,
        "language": language,
        "message": "转写完成",
    }
    if attempts:
        out["failover_attempts"] = attempts
    return out


async def _tool_token6688_balance(arguments: dict[str, Any]) -> dict[str, Any]:
    """token6688_balance: 查询 token6688(名创AI 网关)账户余额(只读)。

    用户问"还剩多少额度/余额多少钱"时使用;未配置 key 时返回清晰错误。
    """
    from .video_generation import _instantiate as _video_instantiate

    inst = _video_instantiate("token6688")
    if inst is None:
        return {
            "tool": "token6688_balance", "ok": False,
            "error": "token6688 平台已永久下线",
            "errorCode": "PROVIDER_NOT_CONFIGURED",
        }
    try:
        st = await inst.get_balance()
    except Exception as e:  # noqa: BLE001
        return {
            "tool": "token6688_balance", "ok": False,
            "error": f"余额查询失败: {e}"[:300], "errorCode": "PROVIDER_ERROR",
        }
    return {
        "tool": "token6688_balance", "ok": True,
        "balance": st.get("balance"), "available_balance": st.get("available_balance"),
        "frozen": st.get("frozen"), "currency": "USD",
        "message": "余额查询成功",
    }


def _scan_pr_files_for_findings(
    files: list[dict[str, Any]], focus: str
) -> list[dict[str, Any]]:
    """扫描 PR 文件 diff,用正则模式匹配潜在问题(零 LLM)。"""
    findings: list[dict[str, Any]] = []
    # (regex, category, severity, comment)
    _PATTERNS = [
        (r"\beval\s*\(", "security", "high", "使用 eval() 有代码注入风险"),
        (r"\bexec\s*\(", "security", "high", "使用 exec() 有代码注入风险"),
        (r"new\s+Function\s*\(", "security", "high", "new Function() 有代码注入风险"),
        (r"os\.system\s*\(", "security", "high", "os.system() 有命令注入风险"),
        (
            r"subprocess\.(?:run|call|Popen)\s*\([^)]*shell\s*=\s*True",
            "security", "high", "subprocess shell=True 有命令注入风险",
        ),
        (
            r"""(?:api[_-]?key|secret|token|password)\s*=\s*["'][^"']{8,}["']""",
            "security", "high", "疑似硬编码凭证",
        ),
        (
            r"for\s+[^:]+:\s*\n[+\-\s]*for\s+[^:]+:",
            "performance", "medium", "嵌套循环可能 O(n²)",
        ),
        (
            r"for\s+\w+\s+in\s+.*:\s*\n[+\-\s]*.*\.execute\s*\(",
            "performance", "medium", "疑似 N+1 查询模式",
        ),
    ]
    for f in files:
        filename = f.get("filename", "")
        patch = f.get("patch", "")
        if not patch:
            continue
        for rgx, cat, sev, comment in _PATTERNS:
            if focus not in ("all", cat):
                continue
            m = re.search(rgx, patch, re.IGNORECASE)
            if m:
                line_no = patch[: m.start()].count("\n") + 1
                findings.append({
                    "severity": sev, "file": filename,
                    "line": line_no, "category": cat, "comment": comment,
                })
        # readability: 大函数检测(新增行 > 500)
        added_count = sum(
            1 for ln in patch.splitlines()
            if ln.startswith("+") and not ln.startswith("+++")
        )
        if focus in ("readability", "all") and added_count > 500:
            findings.append({
                "severity": "low", "file": filename, "line": 1,
                "category": "readability",
                "comment": f"新增 {added_count} 行,可能函数过长",
            })
    return findings


# PR diff 缓存(进程内,TTL 1h,2026-07-24 review_pr 升级)
# 2026-11-01 安全强化:原实现"TTL 只在**重读同一键**时检查",于是从未被再读的条目永久驻留,
# 且键数无上限 —— 而这里存的是**整份 PR diff(源码正文)**,由 `review_pr` 的参数决定键。
# 换成有界原语:`slide_on_read=False`,因为这份 TTL 的语义是"内容还能用多久"的硬期限,
# 读它不该把过期内容续成永生(会话/授权类才用滑动)。
_PR_DIFF_CACHE_TTL = 3600.0  # 1 hour
_PR_DIFF_CACHE_MAX_KEYS = 256
_PR_DIFF_CACHE: BoundedTtlDict = BoundedTtlDict(
    max_keys=_PR_DIFF_CACHE_MAX_KEYS,
    ttl_seconds=_PR_DIFF_CACHE_TTL,
    slide_on_read=False,
)


def _get_cached_pr_diff(key: str) -> str | None:
    """读 PR diff 缓存:命中且未过期返回 diff 文本,否则 None(过期即就地失效)。"""
    cached = _PR_DIFF_CACHE.get(key)
    return cast("str | None", cached)


def _set_cached_pr_diff(key: str, diff_text: str) -> None:
    """写 PR diff 缓存(满则逐出最旧键,逐出计数可观测)。"""
    _PR_DIFF_CACHE.set(key, diff_text)


def _parse_unified_diff(diff_text: str) -> list[dict[str, Any]]:
    """解析 unified diff 文本为文件列表。

    每项: {filename, patch(原始 diff 行), additions, deletions}
    以 '+++ b/<path>' 行作为文件边界。

    口径归属(G-415 A9):下面这对 `+`/`-` 前缀判据与 `routers.llm.calculate_added_lines` /
    `calculate_deleted_lines` 是**同一个量纲**(改动行数,`+++`/`---` 头都不计入),但输入不同
    (这里吃 patch 文本、那里吃 tool_call.args),因此它是那份口径的**第二处实现**,不是巧合相似。
    `scripts/check-line-split-parity.mjs` 目前只把 llm.py 那两个函数当对照本体 —— 这一处尚未进
    语料(要进就得先给门一份"patch 文本 → 期望数"的语料,那是另一票)。**改这里的判据必须同批
    改 llm.py 那两处**,否则同一个 PR 在两个界面上会报出两个行数。
    """
    files: list[dict[str, Any]] = []
    current: dict[str, Any] | None = None
    for line in diff_text.splitlines():
        m = re.match(r"^\+\+\+ b/(.+?)(?:\s|$)", line)
        if m:
            if current:
                files.append(current)
            current = {
                "filename": m.group(1).strip(),
                "patch": "",
                "additions": 0,
                "deletions": 0,
            }
            current["patch"] += line + "\n"
            continue
        if current is None:
            continue
        current["patch"] += line + "\n"
        if line.startswith("+") and not line.startswith("+++"):
            current["additions"] += 1
        elif line.startswith("-") and not line.startswith("---"):
            current["deletions"] += 1
    if current:
        files.append(current)
    return files


def _compute_diff_stats(files: list[dict[str, Any]]) -> dict[str, Any]:
    """从解析后的文件列表计算 files_changed/added_lines/removed_lines/complexity/risk。"""
    files_changed = len(files)
    added = sum(f.get("additions", 0) for f in files)
    removed = sum(f.get("deletions", 0) for f in files)
    complexity = added + 2 * removed + 10 * files_changed
    if complexity < 50:
        risk = "low"
    elif complexity < 300:
        risk = "medium"
    else:
        risk = "high"
    return {
        "files_changed": files_changed,
        "added_lines": added,
        "removed_lines": removed,
        "complexity_score": complexity,
        "risk_assessment": risk,
    }


def _gh_error_for_status(status: int) -> str:
    """GitHub API 状态码 → errorCode 映射(2026-07-24 spec)。"""
    if status in (401, 403):
        return "GITHUB_AUTH_FAILED"
    if status in (404, 422):
        return "PR_NOT_FOUND"
    return "GITHUB_API_ERROR"


async def _tool_review_pr(arguments: dict[str, Any]) -> dict[str, Any]:
    """review_pr: GitHub PR 审查(正则模式匹配,零 LLM,遵循统一工程规范)。

    2026-07-24 升级:
    - 新增 diff 参数(字符串),与 repo+pr_number 互斥(优先 repo+pr_number)
    - repo+pr_number 时调 GitHub API 获取真实 diff(Accept: application/vnd.github.v3.diff)
    - Authorization: Bearer(GITHUB_TOKEN 可空,空则匿名限速 60/h)
    - 新增 source / pr_url / files_changed / added_lines / removed_lines / complexity_score / risk_assessment
    - 进程内 cache 1h(key=github:pr:{repo}:{pr_number}:diff)
    """
    repo = arguments.get("repo", "")
    pr_number = arguments.get("pr_number")
    diff_arg = arguments.get("diff", "")
    focus = arguments.get("focus", "all")
    max_files = int(arguments.get("max_files", 20))

    if focus not in ("security", "performance", "readability", "all"):
        return {
            "tool": "review_pr", "ok": False,
            "error": f"无效 focus: {focus}", "errorCode": "INVALID_PARAMS",
        }

    use_github = bool(repo and "/" in repo and pr_number is not None)
    if not use_github and not diff_arg:
        return {
            "tool": "review_pr", "ok": False,
            "error": "缺少 repo+pr_number 或 diff 参数", "errorCode": "MISSING_PARAMS",
        }

    # 分支 1:diff 字符串(无 GitHub API 调用)
    if not use_github:
        files = _parse_unified_diff(diff_arg)[:max_files]
        findings = _scan_pr_files_for_findings(files, focus)
        stats = _compute_diff_stats(files)
        return _build_review_result(
            repo="", pr_number=None, source="diff_string", pr_url=None,
            title="", author="", additions=0, deletions=0,
            files_reviewed=len(files), findings=findings, stats=stats, focus=focus,
        )

    # 分支 2:GitHub API(repo + pr_number)
    # use_github=True 隐含 pr_number is not None(已在 line 2744 校验)
    if pr_number is None:
        return {
            "tool": "review_pr", "ok": False,
            "error": "pr_number 必须是正整数", "errorCode": "INVALID_PARAMS",
        }
    try:
        pr_number = int(pr_number)
    except (TypeError, ValueError):
        return {
            "tool": "review_pr", "ok": False,
            "error": "pr_number 必须是正整数", "errorCode": "INVALID_PARAMS",
        }
    if pr_number <= 0:
        return {
            "tool": "review_pr", "ok": False,
            "error": "pr_number 必须是正整数", "errorCode": "INVALID_PARAMS",
        }

    try:
        import httpx
    except ImportError:
        return {
            "tool": "review_pr", "ok": False,
            "error": "httpx 未安装", "errorCode": "DEP_MISSING",
        }

    gh_token = os.environ.get("GITHUB_TOKEN", "")
    auth_hdr = f"Bearer {gh_token}" if gh_token else None
    headers_json = {"Accept": "application/vnd.github+json"}
    headers_diff = {"Accept": "application/vnd.github.v3.diff"}
    if auth_hdr:
        headers_json["Authorization"] = auth_hdr
        headers_diff["Authorization"] = auth_hdr

    cache_key = f"github:pr:{repo}:{pr_number}:diff"
    cached_diff = _get_cached_pr_diff(cache_key)
    base = f"https://api.github.com/repos/{repo}/pulls/{pr_number}"

    try:
        async with httpx.AsyncClient(timeout=20.0, follow_redirects=True) as client:
            # 1) JSON metadata(title/author/additions/deletions,向后兼容)
            pr_resp = await client.get(base, headers=headers_json)
            if pr_resp.status_code >= 400:
                return {
                    "tool": "review_pr", "ok": False, "repo": repo,
                    "pr_number": pr_number,
                    "error": f"GitHub API 返回 {pr_resp.status_code}",
                    "errorCode": _gh_error_for_status(pr_resp.status_code),
                }
            pr_data = pr_resp.json()

            # 2) Raw diff via Accept: application/vnd.github.v3.diff(新)
            if cached_diff is None:
                diff_resp = await client.get(base, headers=headers_diff)
                if diff_resp.status_code >= 400:
                    return {
                        "tool": "review_pr", "ok": False, "repo": repo,
                        "pr_number": pr_number,
                        "error": f"GitHub API (diff) 返回 {diff_resp.status_code}",
                        "errorCode": _gh_error_for_status(diff_resp.status_code),
                    }
                cached_diff = diff_resp.text
                _set_cached_pr_diff(cache_key, cached_diff)

            # 3) /files endpoint(向后兼容:findings 走 file list + patch)
            files_resp = await client.get(f"{base}/files", headers=headers_json)
            files_data = files_resp.json() if files_resp.status_code < 400 else []
    except Exception as e:
        return {
            "tool": "review_pr", "ok": False, "repo": repo,
            "pr_number": pr_number,
            "error": str(e)[:200], "errorCode": "GITHUB_API_ERROR",
            "message": f"PR 审查失败: {type(e).__name__}",
        }

    files_to_scan = files_data[:max_files] if isinstance(files_data, list) else []
    findings = _scan_pr_files_for_findings(files_to_scan, focus)
    parsed_files = _parse_unified_diff(cached_diff)
    stats = _compute_diff_stats(parsed_files)

    return _build_review_result(
        repo=repo, pr_number=pr_number, source="github_api",
        pr_url=f"https://github.com/{repo}/pull/{pr_number}",
        title=pr_data.get("title", ""),
        author=(pr_data.get("user") or {}).get("login", ""),
        additions=pr_data.get("additions", 0),
        deletions=pr_data.get("deletions", 0),
        files_reviewed=len(files_to_scan),
        findings=findings, stats=stats, focus=focus,
    )


def _build_review_result(
    repo: str, pr_number: int | None, source: str, pr_url: str | None,
    title: str, author: str, additions: int, deletions: int,
    files_reviewed: int, findings: list[dict[str, Any]], stats: dict[str, Any], focus: str,
) -> dict[str, Any]:
    """组装 review_pr 返回结构(避免主函数超 80 行)。"""
    high = sum(1 for f in findings if f["severity"] == "high")
    med = sum(1 for f in findings if f["severity"] == "medium")
    low = sum(1 for f in findings if f["severity"] == "low")
    result: dict[str, Any] = {
        "tool": "review_pr", "ok": True, "repo": repo,
        "pr_number": pr_number,
        "source": source,
        "pr_url": pr_url,
        "title": title,
        "author": author,
        "files_reviewed": files_reviewed,
        "additions": additions,
        "deletions": deletions,
        "files_changed": stats["files_changed"],
        "added_lines": stats["added_lines"],
        "removed_lines": stats["removed_lines"],
        "complexity_score": stats["complexity_score"],
        "risk_assessment": stats["risk_assessment"],
        "findings": findings,
        "summary": (
            f"审查 {files_reviewed} 个文件,发现 {high} 个 high / "
            f"{med} 个 medium / {low} 个 low 问题"
        ),
        "message": f"PR 审查完成(focus={focus}, {len(findings)} 个 finding, source={source})",
    }
    return result


async def _tool_summarize_artifacts(arguments: dict[str, Any]) -> dict[str, Any]:
    """summarize_artifacts: 聚合当前会话的 plans/sources/artifacts(遵循统一工程规范)。

    通过 artifacts_store 读取(Redis hash 持久化,进程重启不丢;Redis 不可用降级进程内)。
    纯本地读取,不调外部 API(零算力)。
    """
    # AIS-108:旧码直接信任模型自报的 `conversation_id` —— 任意会话都能读别人的
    # plans/sources/artifacts/tool_calls(提示注入还能指定受害者 id)。宿主注入的
    # `__session_id` 才是唯一可信会话键:有宿主会话时一律以它为准,自报值与之不符
    # 直接拒且零读取;无宿主会话(进程内/开发态)才回落自报值。
    host_session = str(arguments.get("__session_id") or "").strip()
    requested_cid = str(arguments.get("conversation_id") or "").strip()
    if host_session:
        if requested_cid and requested_cid != host_session:
            logger.warning(
                "[mcp] summarize_artifacts 跨会话读取被拒(AIS-108): requested=%s host=%s",
                requested_cid, host_session,
            )
            return {
                "tool": "summarize_artifacts", "ok": False,
                "errorCode": "CONVERSATION_MISMATCH",
                "error": "conversation_id 与当前会话不一致",
                "conversation_id": requested_cid, "plans": [], "sources": [],
                "artifacts": [], "tool_calls_summary": {"total": 0, "by_tool": {}},
                "message": "",
            }
        conversation_id = host_session
    else:
        conversation_id = requested_cid
    include = arguments.get("include") or ["plans", "sources", "artifacts", "tool_calls"]
    max_items = int(arguments.get("max_items", 20))

    result: dict[str, Any] = {
        "tool": "summarize_artifacts", "ok": True,
        "conversation_id": conversation_id,
        "plans": [], "sources": [], "artifacts": [],
        "tool_calls_summary": {"total": 0, "by_tool": {}},
        "message": "",
    }

    if not conversation_id:
        result["message"] = "未提供 conversation_id,返回空 artifacts"
        return result

    cached = _load_artifacts(conversation_id)
    if not cached:
        result["message"] = "无会话 artifacts 记录(可能为新会话或 Redis 未命中)"
        return result

    def _clip(items: Any) -> Any:
        return items[:max_items] if isinstance(items, list) else items

    if "plans" in include:
        result["plans"] = _clip(cached.get("plans", []))
    if "sources" in include:
        result["sources"] = _clip(cached.get("sources", []))
    if "artifacts" in include:
        result["artifacts"] = _clip(cached.get("artifacts", []))
    if "tool_calls" in include:
        tc = cached.get("tool_calls", [])
        by_tool: dict[str, int] = {}
        for call in tc:
            name = call.get("tool", "unknown") if isinstance(call, dict) else "unknown"
            by_tool[name] = by_tool.get(name, 0) + 1
        result["tool_calls_summary"] = {"total": len(tc), "by_tool": by_tool}
    result["message"] = f"聚合 {conversation_id} 的 artifacts 完成"
    return result


# present_files 声明面上限:每次最多 8 个文件(超出直接拒绝,不静默截断 ——
# 静默截断会让"我以为都交付了"和"实际只交付了一半"在账面同形);
# 路径/说明的长度上限只防无界输入,不参与任何文件系统判定。
# 2026-11-21:093e778d7e「提交工作树全部未提交改动」把本工具连同注册整块覆盖掉,
# 而 agent_loop_v2 的 _record_deliverable_step 仍在消费 present_files ⇒ 无人生产的死口,
# 按 904e129c14 原样恢复(handler + _TOOLS 条目 + _TOOL_HANDLERS 条目三块同批)。
_PRESENT_FILES_MAX = 8
_PRESENT_FILE_PATH_MAX = 500
_PRESENT_FILE_DESC_MAX = 200


def _normalize_present_path(raw: Any) -> str:
    """归一化交付路径:去空白、统一分隔符、拒绝控制字符;不做文件系统访问。

    为什么这里**不**调 `_validate_path_in_workspace`:本工具只登记交付物,
    不读取也不改写。本地工作区模式(workspace_context 委托读写)下服务端本来
    就看不到用户磁盘,按服务端根判存会把合法的本地产物全判死;而路径最终由
    前端工作区文件预览解析,那一层才有真实的文件句柄。安全边界因此不在本工具,
    但空路径 / 控制字符 / 超长仍一律拒绝。
    """
    if not isinstance(raw, str):
        return ""
    text = raw.strip().replace("\\", "/")
    if not text or len(text) > _PRESENT_FILE_PATH_MAX:
        return ""
    if any(ord(ch) < 0x20 or ord(ch) == 0x7F for ch in text):
        return ""
    return text


async def _tool_present_files(arguments: dict[str, Any]) -> dict[str, Any]:
    """present_files: 把已存在的文件显式声明为交付物(对标 DSH dsh-tool-present)。

    病灶:自动交付清单只收得到「经由文件工具写入」的变更证据;由 run_command
    构建出来的产物、office_document 转换出的 docx/pdf、脚本导出的图表都不会
    出现在 filesChanged 里 —— 模型没有任何办法告诉界面"这些才是最终交付物"。

    判据:
      - 只登记,不读、不写、不判存在(见 `_normalize_present_path` 的理由);
      - 空路径 / 非字符串 / 控制字符 / 超过 500 字 → 整次拒绝(失败闭合,不半登记);
      - 一次最多 8 个,超出整次拒绝(不静默截断);
      - 同路径(忽略大小写)保首现,重复项不重复展示。
    """
    raw_files = arguments.get("files")
    if not isinstance(raw_files, list) or not raw_files:
        return {
            "tool": "present_files", "ok": False,
            "errorCode": "INVALID_ARGUMENTS",
            "error": "files 必须是非空数组,每项形如 {\"path\": \"...\", \"description\": \"...\"}",
            "presented": [],
        }
    if len(raw_files) > _PRESENT_FILES_MAX:
        return {
            "tool": "present_files", "ok": False,
            "errorCode": "TOO_MANY_FILES",
            "error": f"一次最多登记 {_PRESENT_FILES_MAX} 个交付文件(收到 {len(raw_files)} 个),请挑选最终交付物",
            "presented": [],
        }

    presented: list[dict[str, Any]] = []
    seen: set[str] = set()
    for index, item in enumerate(raw_files):
        if not isinstance(item, dict):
            return {
                "tool": "present_files", "ok": False,
                "errorCode": "INVALID_ARGUMENTS",
                "error": f"files[{index}] 必须是对象",
                "presented": [],
            }
        path = _normalize_present_path(item.get("path"))
        if not path:
            return {
                "tool": "present_files", "ok": False,
                "errorCode": "INVALID_PATH",
                "error": f"files[{index}].path 为空、含控制字符或超过 {_PRESENT_FILE_PATH_MAX} 字",
                "presented": [],
            }
        key = path.casefold()
        if key in seen:
            continue
        seen.add(key)
        entry: dict[str, Any] = {"path": path}
        desc_raw = item.get("description")
        if isinstance(desc_raw, str):
            desc = " ".join(desc_raw.split())[:_PRESENT_FILE_DESC_MAX]
            if desc:
                entry["description"] = desc
        presented.append(entry)

    return {
        "tool": "present_files", "ok": True,
        "presented": presented,
        "count": len(presented),
        "message": f"已登记 {len(presented)} 个交付文件",
    }


def _parse_simple_cron(cron: str) -> str | None:
    """降级解析简单 cron 表达式(croniter 未安装时,仅支持 'M H * * *' 形式)。"""
    parts = cron.split()
    if len(parts) != 5:
        return None
    minute, hour, *_rest = parts
    try:
        m = int(minute)
        h = int(hour)
    except ValueError:
        return None
    return f"{h:02d}:{m:02d} daily (cron: {cron})"


def _build_scheduler_params(
    task: dict[str, Any],
) -> tuple[str, dict[str, Any], dict[str, Any]]:
    """将 schedule_task 任务字典映射为 task_scheduler 的 (trigger_type, trigger_config, callback)。

    - once → date trigger(run_date=run_at)
    - recurring + cron → cron trigger(解析 crontab 5 字段 → APScheduler kwargs)
    - recurring + interval_seconds → interval trigger
    callback:webhook_url 存在 → http_webhook,否则 mcp_tool(dispatch_subagent)。
    """
    schedule = task.get("schedule", "once")
    webhook_url = task.get("webhook_url", "")
    prompt = task.get("prompt", "")
    task_id = task.get("task_id", "")

    if schedule == "once":
        trigger_type = "date"
        trigger_config = {"run_date": task.get("run_at", "")}
    elif task.get("cron"):
        trigger_type = "cron"
        parts = str(task.get("cron", "")).split()
        if len(parts) != 5:
            raise ValueError(f"cron 表达式必须是 5 字段: {task.get('cron')}")
        trigger_config = {
            "minute": parts[0], "hour": parts[1], "day": parts[2],
            "month": parts[3], "day_of_week": parts[4],
        }
    else:
        trigger_type = "interval"
        trigger_config = {"seconds": int(task.get("interval_seconds") or 0)}

    if webhook_url:
        callback = {
            "type": "http_webhook", "url": webhook_url,
            "payload": {"prompt": prompt, "task_id": task_id},
        }
    else:
        callback = {
            "type": "mcp_tool", "tool_name": "orchestrate_agents",
            "args": {"name": "feature-planner", "task": prompt},
        }
    return trigger_type, trigger_config, callback


async def _tool_schedule_task(arguments: dict[str, Any]) -> dict[str, Any]:
    """schedule_task: 调度定时任务(遵循统一工程规范)。

    支持 cron / date / interval 三种 trigger,任务记录持久化到 Redis
    (key: mcp:schedule:<task_id> 详细记录 + task_scheduler 内部 mcp:scheduled_task: 调度态),
    由 task_scheduler(AsyncIOScheduler)后台执行 worker(派发 dispatch_subagent 或 POST webhook_url)。
    """
    import uuid
    from datetime import datetime, timedelta

    name = arguments.get("name", "")
    prompt = arguments.get("prompt", "")
    schedule = arguments.get("schedule", "once")
    run_at = arguments.get("run_at", "")
    cron = arguments.get("cron", "")
    interval_seconds = arguments.get("interval_seconds")
    webhook_url = arguments.get("webhook_url", "")
    agent_tools = (
        arguments.get("agent_tools")
        or ["search_codebase", "read_file", "web_search"]
    )

    if not name:
        return {
            "tool": "schedule_task", "ok": False,
            "error": "缺少 name 参数", "errorCode": "MISSING_PARAMS",
        }
    if not prompt:
        return {
            "tool": "schedule_task", "ok": False,
            "error": "缺少 prompt 参数", "errorCode": "MISSING_PARAMS",
        }
    if schedule not in ("once", "recurring"):
        return {
            "tool": "schedule_task", "ok": False,
            "error": f"无效 schedule: {schedule}", "errorCode": "INVALID_PARAMS",
        }
    if schedule == "once" and not run_at:
        return {
            "tool": "schedule_task", "ok": False,
            "error": "schedule=once 时 run_at 必填", "errorCode": "MISSING_PARAMS",
        }
    if schedule == "recurring" and not cron and not interval_seconds:
        return {
            "tool": "schedule_task", "ok": False,
            "error": "schedule=recurring 时 cron 或 interval_seconds 至少一个必填",
            "errorCode": "MISSING_PARAMS",
        }

    next_run_at = ""
    if schedule == "once":
        next_run_at = run_at
    elif cron:
        # recurring + cron:优先用 croniter 计算 next_run
        try:
            from croniter import croniter

            cron_iter = croniter(cron, datetime.now(UTC))
            next_run_at = cron_iter.get_next(datetime).isoformat()
        except ImportError:
            parsed = _parse_simple_cron(cron)
            if parsed is None:
                return {
                    "tool": "schedule_task", "ok": False,
                    "errorCode": "CRON_NOT_SUPPORTED",
                    "message": "croniter 未安装,无法解析复杂 cron 表达式",
                }
            next_run_at = parsed
    else:
        # recurring + interval_seconds
        if interval_seconds is None:
            return {
                "tool": "schedule_task", "ok": False,
                "error": "interval_seconds 必须为正整数",
                "errorCode": "INVALID_PARAMS",
            }
        try:
            int(interval_seconds)
        except (TypeError, ValueError):
            return {
                "tool": "schedule_task", "ok": False,
                "error": "interval_seconds 必须为正整数",
                "errorCode": "INVALID_PARAMS",
            }
        next_run_at = (
            datetime.now(UTC) + timedelta(seconds=int(interval_seconds))
        ).isoformat()

    task_id = uuid.uuid4().hex
    task = {
        "task_id": task_id, "name": name, "prompt": prompt,
        "schedule": schedule, "run_at": run_at, "cron": cron,
        "interval_seconds": interval_seconds, "agent_tools": agent_tools,
        "next_run_at": next_run_at, "status": "scheduled",
        "created_at": datetime.now(UTC).isoformat(),
        "webhook_url": webhook_url,
    }
    _remember_scheduled_task(task)
    # 持久化到 Redis(失败降级内存,不阻塞调度)
    _persist_task_to_redis(task)
    # 注册到后台调度器(task_scheduler 单例:AsyncIOScheduler + cron/date/interval + worker 回调)
    # scheduler 未启动或 stub 模式时 add_task 内部降级,不抛异常
    try:
        from app.services.scheduler_service import task_scheduler

        trigger_type, trigger_config, callback = _build_scheduler_params(task)
        # 2026-10-31:此前这里写的是任务名(conversation_id=name),按会话过滤永远查不到
        # 自己建的任务。__session_id 由 call_tool 在派发前覆盖注入(模型伪造会被覆盖),
        # 无会话上下文(内部直调)才退回 name 以保持旧行为。
        sched_result = await task_scheduler.add_task(
            task_id, trigger_type, trigger_config, callback,
            conversation_id=str(arguments.get("__session_id") or name),
        )
        if sched_result.get("next_run_at"):
            task["next_run_at"] = sched_result["next_run_at"]
            _persist_task_to_redis(task)
    except Exception as e:
        logger.warning("[schedule_task] 注册到 task_scheduler 失败(仅持久化): %s", e)
    return {
        "tool": "schedule_task", "ok": True, "task_id": task_id,
        "name": name, "schedule": schedule, "next_run_at": next_run_at,
        "status": "scheduled",
        "message": "任务已调度,后台 worker 将按计划自动执行",
    }


async def _tool_list_scheduled_tasks(arguments: dict[str, Any]) -> dict[str, Any]:
    """list_scheduled_tasks: 列出定时任务(补 schedule_task 的"看得见"动词)。

    判据全住 scheduler_service.list_tasks(Redis 扫描 / 内存降级 / stub 三态),
    本层只把 conversation_id 原样透传,不自己过滤 —— 第二份过滤必然与持久化面漂移。
    """
    from app.services.scheduler_service import task_scheduler

    raw = arguments.get("conversation_id")
    conversation_id = raw.strip() if isinstance(raw, str) and raw.strip() else None
    try:
        result = await task_scheduler.list_tasks(conversation_id)
    except Exception as e:
        logger.warning("[list_scheduled_tasks] list_tasks 失败: %s", e)
        return {
            "tool": "list_scheduled_tasks", "ok": False,
            "errorCode": "SCHEDULER_ERROR", "message": f"读取定时任务失败: {e}",
        }
    tasks = result.get("tasks") or []
    return {
        "tool": "list_scheduled_tasks", "ok": bool(result.get("ok", True)),
        "conversation_id": conversation_id,
        "tasks": tasks,
        "count": result.get("count", len(tasks)),
        "stub": bool(result.get("stub", False)),
    }


async def _tool_cancel_scheduled_task(arguments: dict[str, Any]) -> dict[str, Any]:
    """cancel_scheduled_task: 取消定时任务(补 schedule_task 的"撤得掉"动词)。

    get_task 只为取回执摘要 + 让"取消不存在的任务"不静默成功;删除动作本身只有
    task_scheduler.remove_task 一处实现(APScheduler job + Redis/memory 双删)。
    归属口径沿用服务层现态:remove_task 不做 owner 校验,本层不另造一套鉴权。
    """
    from app.services.scheduler_service import task_scheduler

    task_id = str(arguments.get("task_id") or "").strip()
    if not task_id:
        return {
            "tool": "cancel_scheduled_task", "ok": False,
            "errorCode": "MISSING_PARAMS", "error": "缺少 task_id 参数",
        }
    try:
        found = await task_scheduler.get_task(task_id)
        if not found.get("ok") or not found.get("task"):
            return {
                "tool": "cancel_scheduled_task", "ok": False,
                "errorCode": "NOT_FOUND", "task_id": task_id,
                "message": f"任务不存在: {task_id}",
            }
        removed = await task_scheduler.remove_task(task_id)
    except Exception as e:
        logger.warning("[cancel_scheduled_task] 取消任务失败(task_id=%s): %s", task_id, e)
        return {
            "tool": "cancel_scheduled_task", "ok": False,
            "errorCode": "SCHEDULER_ERROR", "task_id": task_id,
            "message": f"取消定时任务失败: {e}",
        }
    task = found["task"]
    return {
        "tool": "cancel_scheduled_task", "ok": bool(removed.get("ok", True)),
        "task_id": task_id,
        "cancelled": {
            "task_id": task_id,
            "name": task.get("name", ""),
            "schedule": task.get("trigger_type", ""),
            "next_run_at": task.get("next_run_at", ""),
        },
        "stub": bool(removed.get("stub", False)),
        "message": f"任务已取消: {task_id}",
    }


async def _tool_schedule_wakeup(arguments: dict[str, Any]) -> dict[str, Any]:
    """schedule_wakeup: 延迟唤醒(遵循统一工程规范)。

    定时工具面此前只有建/查/撤三动词,模型没有"过 N 秒再跑一次"的最小表达;
    本工具就是 schedule_task(once) 的一格特化:入参只有 delay_seconds + prompt。

    调度参数与派发回调一律经 `_build_scheduler_params` 构造(schedule="once" → date 触发 +
    与 schedule_task 同一 callback),本层不另写一份判据 —— 第二份必然与 schedule_task 漂移。
    """
    import uuid
    from datetime import UTC, datetime, timedelta

    prompt = str(arguments.get("prompt") or "").strip()
    if not prompt:
        return {
            "tool": "schedule_wakeup", "ok": False,
            "error": "缺少 prompt 参数", "errorCode": "MISSING_PARAMS",
        }

    raw_delay = arguments.get("delay_seconds")
    delay_seconds: int | None = None
    # bool 是 int 子类:int(True) == 1 会把"任意真值"静默读成 1 秒后,先排除;
    # 非整数(float/数字串带小数)落地成整数等于静默改参,同样按非法处理。
    if raw_delay is not None and not isinstance(raw_delay, bool):
        try:
            delay_seconds = int(raw_delay)
        except (TypeError, ValueError):
            delay_seconds = None
        if delay_seconds is not None:
            try:
                if float(raw_delay) != delay_seconds:
                    delay_seconds = None
            except (TypeError, ValueError, OverflowError):
                delay_seconds = None
    if delay_seconds is None or delay_seconds <= 0:
        return {
            "tool": "schedule_wakeup", "ok": False,
            "error": "delay_seconds 必须为正整数(秒)", "errorCode": "INVALID_PARAMS",
        }

    task_id = uuid.uuid4().hex
    name = str(arguments.get("name") or f"wakeup-{task_id}")
    wake_at = (datetime.now(UTC) + timedelta(seconds=delay_seconds)).isoformat()
    # 只填 _build_scheduler_params 认的字段(schedule/run_at/prompt/task_id/webhook_url 留空
    # ⇒ 走 mcp_tool 回调),调度判据全在它那里。
    task: dict[str, Any] = {
        "task_id": task_id, "name": name, "prompt": prompt,
        "schedule": "once", "run_at": wake_at, "webhook_url": "",
    }
    try:
        trigger_type, trigger_config, callback = _build_scheduler_params(task)
        from app.services.scheduler_service import task_scheduler

        # conversation_id 与 schedule_task 同口径(2026-10-31):承载层注入的 __session_id
        # 优先,无会话上下文(内部直调)才退回任务名。
        sched_result = await task_scheduler.add_task(
            task_id, trigger_type, trigger_config, callback,
            conversation_id=str(arguments.get("__session_id") or name),
        )
    except Exception as e:
        logger.warning("[schedule_wakeup] 注册到 task_scheduler 失败(task_id=%s): %s", task_id, e)
        return {
            "tool": "schedule_wakeup", "ok": False, "errorCode": "SCHEDULER_ERROR",
            "task_id": task_id, "wake_at": wake_at,
            "message": f"延迟唤醒注册失败: {e}",
        }
    if not sched_result.get("ok", True):
        return {
            "tool": "schedule_wakeup", "ok": False,
            "errorCode": str(sched_result.get("errorCode") or "SCHEDULER_ERROR"),
            "task_id": task_id, "wake_at": wake_at,
            "message": str(sched_result.get("message") or "延迟唤醒注册被调度器拒绝"),
        }

    result: dict[str, Any] = {
        "tool": "schedule_wakeup", "ok": True, "task_id": task_id,
        "name": name, "delay_seconds": delay_seconds, "wake_at": wake_at,
        "message": f"已安排在 {wake_at} 唤醒(delay_seconds={delay_seconds})",
    }
    # 调度器回填的真实 next_run_at 优先;stub 模式(未配 redis_url)没有真实 job,如实透出
    if sched_result.get("next_run_at"):
        result["next_run_at"] = sched_result["next_run_at"]
    if sched_result.get("stub"):
        result["stub"] = True
    return result


async def _tool_proactive_suggestion(arguments: dict[str, Any]) -> dict[str, Any]:
    """proactive_suggestion: 基于当前会话上下文主动建议后续工作(遵循统一工程规范)。

    纯本地规则匹配(零算力,不调 LLM)。
    """
    ctx = arguments.get("conversation_context", "") or ""
    recent_files = arguments.get("recent_files") or []
    # G-814399:先过 _TOOL_ALIASES 归一再做字面比较 —— 注册名是 file_edit/search_codebase,
    # 调用方传别名(code_search/search_symbol 等)时负向判据才不被绕过。
    recent_tool_calls = [
        _normalize_tool_name(str(name))
        for name in (arguments.get("recent_tool_calls") or [])
    ]

    suggestions: list[dict[str, Any]] = []
    ctx_lower = ctx.lower()

    if "write_file" in recent_tool_calls:
        suggestions.append({
            "type": "follow_up", "title": "为新代码添加单元测试",
            "description": "检测到 write_file 调用,建议为新代码补充对应单元测试",
            "priority": "high", "estimated_steps": 2,
            "related_files": recent_files,
        })
    if "file_edit" in recent_tool_calls and "search_codebase" not in recent_tool_calls:
        suggestions.append({
            "type": "explore", "title": "先搜索是否有类似实现可复用",
            "description": "检测到 file_edit 但未先 search_codebase,建议先搜索可复用代码",
            "priority": "medium", "estimated_steps": 1,
            "related_files": [],
        })
    _TEST_SUFFIXES = (".test.ts", ".test.tsx", ".spec.ts", ".spec.tsx")
    if any(
        isinstance(f, str) and f.endswith(_TEST_SUFFIXES) for f in recent_files
    ):
        suggestions.append({
            "type": "test", "title": "运行测试验证改动",
            "description": "检测到测试文件改动,建议运行测试确保通过",
            "priority": "high", "estimated_steps": 1,
            "related_files": [
                f for f in recent_files
                if isinstance(f, str) and (".test." in f or ".spec." in f)
            ],
        })
    if "fix" in ctx_lower or "bug" in ctx_lower:
        suggestions.append({
            "type": "test", "title": "添加回归测试覆盖 bug 场景",
            "description": "检测到 bug 修复上下文,建议添加回归测试防止复发",
            "priority": "high", "estimated_steps": 2,
            "related_files": recent_files,
        })
    if "refactor" in ctx_lower:
        suggestions.append({
            "type": "improve", "title": "审查重构影响范围",
            "description": "检测到重构上下文,建议审查影响范围与兼容性",
            "priority": "medium", "estimated_steps": 2,
            "related_files": recent_files,
        })
    if "new feature" in ctx_lower or "新增" in ctx:
        suggestions.append({
            "type": "follow_up", "title": "同步更新 README + 守门脚本",
            "description": "检测到新功能上下文,建议同步更新 README 与守门脚本",
            "priority": "medium", "estimated_steps": 2,
            "related_files": [],
        })

    if not suggestions:
        return {
            "tool": "proactive_suggestion", "ok": True,
            "suggestions": [],
            "message": "上下文不足,无法生成建议",
        }
    return {
        "tool": "proactive_suggestion", "ok": True,
        "suggestions": suggestions,
        "message": f"生成 {len(suggestions)} 条建议",
    }


def _mcp_model_tools_enabled_from_env() -> bool:
    """批58 接线(遵循统一工程规范):特殊工具结果/校验归一。

    默认 off:后台 sleep 时长不校验、完成通知不带 async 投影(逐字节等价);
    设为 on/1/true/yes 时经 validate_sleep_duration 校验时长、经
    build_async_user_notification 产出 host 侧投递载荷。
    """
    return os.environ.get("MCP_MODEL_TOOLS_ENABLED", "false").strip().lower() in (
        "on", "1", "true", "yes",
    )


# ---------------------------------------------------------------------------
# 后台任务工具(Phase 1 第 6 项 · 2026-09-02 立)
# ---------------------------------------------------------------------------
# run_in_background:立即返回 task_id,后台执行,完成后经 message_bus 推送 IM 通知;
# bg_task_status:查询单个任务状态或列出某用户任务。两工具只读/低危,不进 _ADMIN_ONLY_TOOLS。
#
# 扩展点(V3 #51 接线改档,2026-09-27):**不要**在本文件再维护一张任务白名单表。
# 旧形态是一张 `_BG_TASK_IMPLS`(只有 sleep/echo)在这里自建分派,那既是第二个真相源
# (注册表新增一类,本文件不改就永远广告不出去),也让幂等键与断点续跑结构上接不到工具面。
# 现在唯一的分派出口是 `background_tasks.run_in_background` → `task_executors.get_spec`。
#
# 下面两个 `_bg_impl_*` 是**批58 的行为面宿主**(tests/test_mcp_wiring_58b.py 逐条断言其
# off/on/越界/异常隔离四态),生产链路已不再经它们;注册表里的 `_exec_sleep` / `_exec_echo`
# 是同一行为的唯一生产实现。两者的等价性由 tests/test_background_task_type_wiring_51.py
# 的对照断言钉死 —— 改任一侧而不改另一侧即红,不得让这份重复变成静默漂移。
async def _bg_impl_sleep(args: dict[str, Any]) -> Any:
    """演示实现:休眠指定秒数(测试 / 占位用)。

    批58:MCP_MODEL_TOOLS_ENABLED on 时先经 model_tools_57.validate_sleep_duration
    校验时长(秒→毫秒),越界直接返回 error 不休眠;off 时行为与接线前一致。
    """
    seconds = float(args.get("seconds", 0))
    if _mcp_model_tools_enabled_from_env():
        try:
            from app.core.model_tools_57 import validate_sleep_duration

            err = validate_sleep_duration(seconds * 1000.0)
            if err is not None:
                return {"error": err, "slept_seconds": 0}
        except Exception as e:  # noqa: BLE001 - 校验失败降级照常休眠
            logger.warning("model_tools 时长校验失败(降级照常休眠): %s", e)
    await asyncio.sleep(seconds)
    return {"slept_seconds": seconds}


async def _bg_impl_echo(args: dict[str, Any]) -> Any:
    """演示实现:回显消息(测试 / 占位用)。"""
    return {"echo": args.get("message", "")}


def _bg_task_types_prose() -> str:
    """`run_in_background` schema 里那份**广告面白名单文字**的唯一派生出口(V3 #51 判据 6 / P6)。

    为什么必须有它:模型在 `tools/list` 里读到的"支持哪些任务类型"来自这段描述文字,
    而不是 Python 分派表。旧写法把 "sleep/echo" 写死在 description 里 ——
    于是注册表落地了 6 类真实 executor、工具层也委托过去了,模型**仍然看不见它们**,
    "接了线也调不到"。现在这一段逐字派生自 `background_tasks.RUN_IN_BACKGROUND_TASK_TYPES`
    (它就是 `task_executors.IMPLEMENTED_TASK_TYPES`),新增一类无需改本文件即自动进入广告面。
    """
    from .background_tasks import RUN_IN_BACKGROUND_TASK_TYPES

    return "/".join(RUN_IN_BACKGROUND_TASK_TYPES)


# AIS-031(2026-11-08):任务类型**分派闸**。
# `run_in_background` 与 `run_workflow` 都允许模型自填 task/agent,而 `task_executors`
# 注册表里 `long_running_command`(任意 argv)与 `test_suite`(起 pytest)是"以服务账号
# 执行代码"的同一档能力 —— 与 admin-only 的 `run_command` 同能力却低一档门槛:
# 旧注释把 `run_in_background` 整只工具当"只读/低危"排除在 `_ADMIN_ONLY_TOOLS` 之外,
# 于是 role=0 用 `{"task":"long_running_command","command":["python","-c","..."]}`
# 即可起任意进程(`dangerous_command_match` 只判 rm 一类破坏性命令,`python -c` 判"安全")。
#
# 收口位置刻意在**分派之前**:拒绝时零副作用 —— 不 submit、不起进程、不落 checkpoint。
# 角色只认宿主注入的 `__user_role`(`call_tool` 注入,LLM 不可控);缺失/畸形容一律按 0
# (fail-closed)。特权类型之外(sleep/echo/patrol...)role=0 保持原样,对话链不断。
_ADMIN_ONLY_DISPATCH_TASK_TYPES: frozenset[str] = frozenset(
    {"long_running_command", "test_suite"}
)


def _dispatch_permission_denial(
    tool: str, task_type: str, arguments: dict[str, Any]
) -> dict[str, Any] | None:
    """非 admin 把特权 task_type 交给 executor ⇒ PERMISSION_DENIED(留结构化告警)。

    同一判据被 `run_in_background`(task)与 `run_workflow`(节点 agent)两扇门共用 ——
    两张工具面都是 `task_executors.execute_task` 的分派入口,只堵一扇等于没堵。
    """
    if task_type not in _ADMIN_ONLY_DISPATCH_TASK_TYPES:
        return None
    try:
        role = int(arguments.get("__user_role") or 0)
    except (TypeError, ValueError):
        role = 0
    if role >= 1:
        return None
    logger.warning(
        "[mcp] 越权任务分派被拒(AIS-031): tool=%s task=%s user_role=%s code=PERMISSION_DENIED",
        tool,
        task_type,
        role,
    )
    return {
        "ok": False,
        "tool": tool,
        "errorCode": "PERMISSION_DENIED",
        "error": f"任务类型 '{task_type}' 需要 admin 权限(role >= 1),当前 role={role}",
        "task_type": task_type,
        "executed": False,
    }


async def _tool_run_in_background(arguments: dict[str, Any]) -> dict[str, Any]:
    """run_in_background:提交后台任务并立即返回 task_id(不阻塞当前循环)。

    V3 #51 接线(2026-09-27):整份 `arguments` 直接交给
    `background_tasks.run_in_background`,由它经 `task_executors.get_spec` 分派到
    6 类真实 executor + 2 类自证 stub;本文件不再自带白名单,也不再自己拼协程。
    于是幂等键去重与断点续跑(`submit_typed`)第一次真正接到工具面 ——
    旧形态走 `manager.submit(coro_factory)`,结构上拿不到这两件事。

    未知类型由那一层返回 `ok:False` + `supported_task_types` + `executed:False`,
    绝不伪装成执行成功。完成后若 notify_on_done,经 message_bus 的 IM 通道推送通知。
    """
    denial = _dispatch_permission_denial(
        "run_in_background", str(arguments.get("task", "")).strip(), arguments
    )
    if denial is not None:
        return denial

    from .background_tasks import run_in_background

    return await run_in_background(arguments)


async def _tool_bg_task_status(arguments: dict[str, Any]) -> dict[str, Any]:
    """bg_task_status:查询单个后台任务状态,或不传 task_id 时列出某用户的任务。"""
    from .background_tasks import background_task_manager

    host_user_id = arguments.get("__user_id")
    if not isinstance(host_user_id, str) or not host_user_id:
        return {
            "ok": False,
            "error": "缺少宿主注入的调用者身份",
            "errorCode": "PRINCIPAL_REQUIRED",
        }

    task_id = arguments.get("task_id")
    raw_cancel = arguments.get("cancel")
    want_cancel = raw_cancel is True or str(raw_cancel).strip().lower() in {"1", "true", "yes", "on"}
    try:
        wait_s = float(arguments.get("wait_s") or 0)
    except (TypeError, ValueError):
        return {"ok": False, "errorCode": "INVALID_ARGUMENT", "error": "wait_s 必须是数字"}
    wait_s = min(max(wait_s, 0.0), 300.0)
    if not task_id and (want_cancel or wait_s > 0):
        return {
            "ok": False,
            "errorCode": "INVALID_ARGUMENT",
            "error": "cancel/wait_s 只在指定 task_id 时可用;列表模式不接受这两个参数",
        }
    if task_id:
        status = await background_task_manager.get_status(str(task_id))
        # 非本人的任务与"不存在"同形返回:否则 task_id 就是他人任务的枚举面
        # (任务名、状态、result 原文一并读出)。
        if status is None or status.get("user_id") != host_user_id:
            return {"ok": False, "error": f"任务不存在: {task_id}"}
        if want_cancel:
            cancel_result = await background_task_manager.cancel(str(task_id))
            current = await background_task_manager.get_status(str(task_id))
            return {
                "ok": True,
                "task": current or status,
                "cancel": cancel_result,
                "cancelled": bool(cancel_result.get("ok")),
            }
        if wait_s > 0:
            # 等待终态:按 0.25s 轮询,最长 wait_s(上限 300s);到点未终态如实回 waitTimedOut,
            # 不把"还在跑"伪装成"已完成"。wait_s=0 时保持旧的非阻塞语义。
            terminal = {"succeeded", "failed", "timeout", "cancelled"}
            deadline = time.monotonic() + wait_s
            while status.get("state") not in terminal:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    break
                await asyncio.sleep(min(0.25, remaining))
                status = await background_task_manager.get_status(str(task_id))
                if status is None or status.get("user_id") != host_user_id:
                    return {"ok": False, "error": f"任务不存在: {task_id}"}
            return {
                "ok": True,
                "task": status,
                "waited": True,
                "waitTimedOut": status.get("state") not in terminal,
            }
        return {"ok": True, "task": status}

    # 列表模式的过滤主体只认宿主注入值。原写法 `arguments.get("user_id") or __user_id`
    # 把模型自填的 user_id 排在前面 ⇒ 模型报一个他人 uuid 就能列他人正在跑的任务,
    # 直接违反 packages/types/src/tool-contract.ts 的 ROUTING_IDENTITY_KEYS(含 user_id)
    # "宿主绑定、禁入模型参数"契约。
    limit = int(arguments.get("limit", 20))
    tasks = await background_task_manager.list_tasks(user_id=host_user_id, limit=limit)
    return {"ok": True, "tasks": tasks, "count": len(tasks)}


# 工具注册表
async def _tool_context_recall(arguments: dict[str, Any]) -> dict[str, Any]:
    """context_recall: 语义检索回捞被压缩丢弃的旧消息(只读,不修改任何状态)。"""
    # 身份只认宿主注入的 __user_id(call_tool 从 FastAPI request 透传,LLM 不可控);
    # 模型自填的 user_id/session_id 一律不作归属依据 —— 原写法连 user 维都不接,
    # 等于任何人可捞任何人的压缩原文。
    host_user_id = arguments.get("__user_id")
    if not isinstance(host_user_id, str) or not host_user_id:
        return {
            "ok": False,
            "error": "缺少宿主注入的调用者身份",
            "errorCode": "PRINCIPAL_REQUIRED",
        }
    host_session_id = arguments.get("__session_id")
    model_session_id = arguments.get("session_id")
    session_id = host_session_id if isinstance(host_session_id, str) and host_session_id else model_session_id
    query = arguments.get("query", "")
    top_k = arguments.get("top_k", 8)
    if not isinstance(top_k, int) or top_k <= 0:
        top_k = 8
    try:
        return await context_recall.recall(
            session_id=session_id if isinstance(session_id, str) else None,
            query=query if isinstance(query, str) else "",
            top_k=top_k,
            user_id=host_user_id,
        )
    except Exception as e:
        logger.warning("context_recall 工具执行异常: %s", e)
        return {"ok": False, "error": str(e)}


# =============================================================================
# V3 #63(2026-09-27 立):对话流业务表单请求工具 request_business_form
# =============================================================================
#
# 这是什么:模型**请用户在对话流里填一张业务表单**(邮件撰写 / 日历事件)的能力。
# 它不由本模块执行 —— 真正干活的是主对话流的工具循环
# (`app/routers/llm.py` 的 form_request 拦截位):在那里发一帧 `form_request`,
# 等用户提交/拒绝,再把结果回灌成 tool 消息。本模块只负责两件事:
#   ① 把工具**告知模型**(注册进 _TOOLS ⇒ schema 与 list_tools 自动带上);
#   ② 持有这张能力唯一的**线格式真值表**(下面的字段表 + 组帧函数),
#      使 llm 侧与 i18n/渲染侧不必各抄一份字段清单。
#
# 为什么这里还要一个 handler(而不是"反正会被拦截,不注册"):
# `tests/test_mcp_server.py::test_tools_count_matches_registry` 断言
# `len(_TOOLS) == len(_TOOL_HANDLERS)`,只登记定义不登记处理函数会当场红;
# 更重要的是 —— 别的执行路径(agent 任务流、后台任务、将来接入的编排器)没有
# form 通道,它们若真调到这个名字,**必须拿到一句明确的可自愈提示**
# (errorCode=FORM_CHANNEL_UNAVAILABLE),而不是"未知工具"后原地重试到 max_iterations。
# 这与 V3 #49 对 _DELEGATE_ONLY_TOOLS 的处理是同一条纪律。

_FORM_REQUEST_TOOL_NAME: Final[str] = "request_business_form"

# 业务表单种类 → 字段档(键, 输入类型, 必填)。
# **权威表在 TS 侧** `packages/shared/src/chat/business-forms.ts` 的
# `BUSINESS_FORM_FIELDS`(渲染层按 kind 派发到那张表,不读本表);本表只承担一件事:
# 组一帧 `fields` 给解析层 —— `packages/api-client/src/client.ts` 的
# `tryParseFormRequest` 要求 `fields` 是**非空数组**且每项有非空 `key`,
# 否则整帧被静默丢弃(帧发出去而端上什么都没有,就是这一格)。
# 两侧一致性由 `tests/test_form_request_frame.py` 逐键对账钉住(它直接读那份 TS 源,
# 不在本文件里另写一份"谁对谁错"的判断)。
# `placeholderKey` 一律省略:判定层留空时渲染层用 label 兼作占位(见上引 TS 注释),
# 在这里填反而会让两侧对不上。
_BUSINESS_FORM_FIELDS: Final[dict[str, tuple[tuple[str, str, bool], ...]]] = {
    "email": (
        ("to", "email", True),
        ("cc", "email", False),
        ("bcc", "email", False),
        ("subject", "text", True),
        ("replyTo", "email", False),
        ("body", "multiline", True),
    ),
    "calendarEvent": (
        ("start", "datetime", True),
        ("end", "datetime", True),
        ("attendees", "attendees", True),
    ),
}

# 种类集合由字段表推导 ⇒ 不可能出现"有 kind 没有字段"的空洞表单
BUSINESS_FORM_KINDS: Final[frozenset[str]] = frozenset(_BUSINESS_FORM_FIELDS)


def business_form_wire_fields(kind: str) -> list[dict[str, object]]:
    """某类表单的线格式字段数组;未知 kind ⇒ 空列表(调用方据此**不发帧**)。"""
    return [
        {"key": key, "type": ftype, "required": required}
        for key, ftype, required in _BUSINESS_FORM_FIELDS.get(kind, ())
    ]


def build_form_request_frame(
    *,
    request_id: str,
    kind: str,
    session_id: str,
    message_id: str | None,
) -> dict[str, object] | None:
    """组一帧下行 `form_request`;**不具备发送条件时返回 None,不发半帧**。

    返回 None 的两种情形(都不该把畸形帧推给前端):
      · 未知 kind —— 端上 `projectFormRequestFrame` 对未知 kind 返回 null,发出去就是
        "服务端以为弹了、界面上什么都没有";不如让工具当场回一句可自愈的失败。
      · fields 为空 —— 解析层 `tryParseFormRequest` 对空 fields 整帧丢弃,同上。

    字段名是 **camelCase**(requestId / sessionId / messageId),与同通道上
    tool-approval 的 snake_case 不同族。这不是随手写的:那个解析层读的就是 camel 键,
    写成 snake_case **不报错、只是整帧被丢**。上行的 form_response 才用 snake_case
    (见 llm.py 的接收端),两条通道各自的形状权威都在
    `packages/shared/src/sse/contract.ts`。
    """
    fields = business_form_wire_fields(kind)
    if not fields:
        return None
    frame: dict[str, object] = {
        "type": "form_request",
        "requestId": request_id,
        "sessionId": session_id,
        "kind": kind,
        "fields": fields,
        # 成对判据:批准与拒绝必须在。只给 approve 等于替用户做完决定,
        # 违反端内硬约束"拒绝路径零副作用"(见 business-forms.ts 的 FORM_ACTION_PAIR)。
        "actions": ["approve", "reject"],
    }
    if message_id:
        frame["messageId"] = message_id
    return frame


async def _tool_request_business_form(args: dict[str, Any]) -> dict[str, object]:
    """非对话流通道调用本工具时的兜底答复(见上:这条路径没有承载表单的会话通道)。"""
    return {
        "tool": _FORM_REQUEST_TOOL_NAME,
        "ok": False,
        "error": (
            f"工具 '{_FORM_REQUEST_TOOL_NAME}' 只能在主对话流的工具循环里使用:"
            "它需要一条前端可渲染的业务表单通道(llm.py 发 form_request 帧、"
            "form-response 端点收应答)。当前执行路径没有这条通道,表单无法呈现,"
            "用户也就无从批准或拒绝。请勿重试该工具;需要这些信息时,直接在回复里"
            "向用户提问并等待其在下一轮给出。"
        ),
        "errorCode": "FORM_CHANNEL_UNAVAILABLE",
        "message": "业务表单请求仅在对话流内可用",
    }


# =============================================================================
# 工作流动作的模型可见面(G-01 补齐腿之二,2026-10-31 立)
# =============================================================================
#
# 病理:引擎 `app/services/workflow_engine.py` 在产(889 行,HTTP 面 routers/workflow.py
# 与 koubo 消费方都在),而 `git grep 'workflow' mcp_server.py` 的工具注册面 0 命中
# ⇒ 模型看不见"触发 / 续跑 / 查实例状态"这三枚动词,工作流只能由人从画布点。
#
# 与对照程序的区别 = 本仓的超越轴(如实写清,不是顺手做的造型):
#   对方 run_workflow 的入参是 `script` / `scriptPath` —— 模型交一段脚本文本或一个脚本
#   路径,执行体就地跑;本族三枚工具的入参只有 workflow_id / instance_id 加一个**数据
#   对象**,而且三张 schema 都带 `additionalProperties: False` ⇒ "模型给一段代码就地执行"
#   这条 RCE 面在本仓结构上不存在(不是靠正则拦住的,是靠没有那个字段)。
#   续跑的比对单位是"步骤的调用键"(workflow_engine.step_call_key,算式单源
#   task_executors.compute_idempotency_key),比对方只证到 agent() 结果缓存更细。
#
# 身份:三枚都只认宿主注入的 `__user_id`,并先过 `resolve_caller` 把开发降级身份归一成
# None(否则 dev-anonymous 会被当成一个真主体喂给属主闸)。拿不到主体即 PRINCIPAL_REQUIRED
# 且**一次都不碰引擎** —— 引擎在 principal=None 时是不加闸的,放过去就等于让对话链上的
# 一次匿名工具调用能碰任何人把工作流。

_WORKFLOW_INSTANCE_STATUS_TASK_FIELDS: Final[tuple[str, ...]] = (
    "step",
    "name",
    "type",
    "status",
    "error",
)


async def _tool_workflow_trigger(arguments: dict[str, Any]) -> dict[str, Any]:
    """workflow_trigger:按 workflow_id 触发一个**已存在**的工作流(不接收脚本)。"""
    from .workflow_engine import resolve_caller, workflow_engine

    principal = resolve_caller(arguments.get("__user_id"))
    if not principal:
        return {
            "tool": "workflow_trigger", "ok": False,
            "errorCode": "PRINCIPAL_REQUIRED", "error": "缺少宿主注入的调用者身份",
        }
    workflow_id = str(arguments.get("workflow_id") or "").strip()
    if not workflow_id:
        return {
            "tool": "workflow_trigger", "ok": False,
            "errorCode": "MISSING_PARAMS", "error": "缺少 workflow_id 参数",
        }
    raw_input = arguments.get("input")
    if raw_input is not None and not isinstance(raw_input, dict):
        return {
            "tool": "workflow_trigger", "ok": False,
            "errorCode": "INVALID_PARAMS",
            "error": "input 必须是对象(工作流的数据入参);不接受字符串/数组/脚本文本",
        }
    inst = await workflow_engine.trigger_workflow(
        workflow_id, dict(raw_input or {}), principal=principal
    )
    if inst is None:
        # 不存在 / 非本人可见 / 已禁用 / 已有实例在跑 四种都落这一句:前两种在引擎里
        # 本就同形,这里不替它们分家(分了就是存在性 oracle)。
        return {
            "tool": "workflow_trigger", "ok": False,
            "errorCode": "WORKFLOW_NOT_TRIGGERABLE",
            "error": f"工作流不可触发(不存在、对当前身份不可见、已禁用或已有实例在跑): {workflow_id}",
        }
    return {"tool": "workflow_trigger", "ok": True, "instance": workflow_engine.instance_to_dict(inst)}


async def _tool_workflow_resume(arguments: dict[str, Any]) -> dict[str, Any]:
    """workflow_resume:按调用键续跑一个历史实例(未变步取缓存,改动/新增步才真跑)。"""
    from .workflow_engine import resolve_caller, workflow_engine

    principal = resolve_caller(arguments.get("__user_id"))
    if not principal:
        return {
            "tool": "workflow_resume", "ok": False,
            "errorCode": "PRINCIPAL_REQUIRED", "error": "缺少宿主注入的调用者身份",
        }
    instance_id = str(arguments.get("instance_id") or "").strip()
    if not instance_id:
        return {
            "tool": "workflow_resume", "ok": False,
            "errorCode": "MISSING_PARAMS", "error": "缺少 instance_id 参数",
        }
    raw_input = arguments.get("input")
    if raw_input is not None and not isinstance(raw_input, dict):
        return {
            "tool": "workflow_resume", "ok": False,
            "errorCode": "INVALID_PARAMS",
            "error": "input 必须是对象(新的工作流数据入参);不接受字符串/数组/脚本文本",
        }
    # 错误码与原因由引擎单源给出(build_replay_plan 的「未判定」族),本层不改写、
    # 更不兜成"那就整条重跑"。
    result = await workflow_engine.resume_instance(
        instance_id, dict(raw_input) if raw_input is not None else None, principal=principal
    )
    return {"tool": "workflow_resume", **result}


async def _tool_workflow_instance_status(arguments: dict[str, Any]) -> dict[str, Any]:
    """workflow_instance_status:查实例状态 + 逐步 trace(只读,不给存在性 oracle)。"""
    from .workflow_engine import resolve_caller, workflow_engine

    principal = resolve_caller(arguments.get("__user_id"))
    if not principal:
        return {
            "tool": "workflow_instance_status", "ok": False,
            "errorCode": "PRINCIPAL_REQUIRED", "error": "缺少宿主注入的调用者身份",
        }
    instance_id = str(arguments.get("instance_id") or "").strip()
    if not instance_id:
        return {
            "tool": "workflow_instance_status", "ok": False,
            "errorCode": "MISSING_PARAMS", "error": "缺少 instance_id 参数",
        }
    inst = workflow_engine.get_instance(instance_id, principal)
    if inst is None:
        return {
            "tool": "workflow_instance_status", "ok": False,
            "errorCode": "INSTANCE_NOT_VISIBLE",
            "error": f"实例不存在或对当前身份不可见: {instance_id}",
        }
    tasks: list[dict[str, Any]] = []
    for t in workflow_engine.get_instance_tasks(instance_id, principal):
        # 序列化单源 = engine.task_to_dict(§0.6):本层只从中挑状态面,
        # output 原文不回给模型(它可能整段是 LLM 长文),只回字数。
        row = workflow_engine.task_to_dict(t)
        tasks.append({key: row[key] for key in _WORKFLOW_INSTANCE_STATUS_TASK_FIELDS})
        tasks[-1]["outputChars"] = len(str(row.get("output") or ""))
    return {
        "tool": "workflow_instance_status", "ok": True,
        "instance": workflow_engine.instance_to_dict(inst),
        "tasks": tasks,
        "taskCount": len(tasks),
    }


# ---------------------------------------------------------------------------
# 代码库只读调查 + 跨会话点名发消息(G-11 / G-07 接线,2026-10-31 立)
# 身份只认承载层注入的 __user_id / __user_role / __session_id(LLM 不可控);
# 缺失即具名 PRINCIPAL_REQUIRED 且一次都不碰被调服务(§5)。
# ---------------------------------------------------------------------------
async def _tool_investigate_codebase(arguments: dict[str, Any]) -> dict[str, Any]:
    """investigate_codebase:只读代码库调查(三态 observed/inferred/unknown)。"""
    # AIS-107:只读 ≠ 可越界。root 与其它代码工具同一把尺,越界不进入遍历/读文件。
    # 顺序与 search_codebase 一致:先判存在性,再判工作区 —— 不存在的路径由下游
    # 三态如实回 unknown,不能把"不存在"改写成"不允许"(§0.3)。
    _probe_path = str(arguments.get("path", "."))
    if Path(_probe_path).exists():
        ok_path, resolved_path = _validate_path_in_workspace(_probe_path)
        if not ok_path:
            return {
                "tool": "investigate_codebase",
                "ok": False,
                "status": "unjudged",
                "errorCode": "PATH_NOT_ALLOWED",
                "path": _probe_path,
                "intent": arguments.get("intent"),
                "query": arguments.get("query", ""),
                "findings": [],
                "legs": [],
                "missing_inputs": [],
                "read_only": True,
                "message": f"路径不允许: {resolved_path}",
            }
        arguments = {**arguments, "path": resolved_path}
    from .codebase_investigator import investigate_codebase

    # AIS-107:模型给的 path 不能直接当仓根 —— 否则 role=0 可指向任意目录(文件面/
    # 大小/命名/结构一次性外泄,且被扫描内容会回灌给模型)。与 file_search 同一白名单判据,
    # 下传的是**校验后**路径而非原文。
    _ok_root, _root_info = _validate_path_in_workspace(
        str(arguments.get("path") or ".")
    )
    if not _ok_root:
        return {
            "tool": "investigate_codebase", "ok": False,
            "errorCode": "PATH_NOT_ALLOWED", "error": _root_info,
            "findings": [], "anchors": [],
        }
    result: dict[str, Any] = await investigate_codebase(
        {**arguments, "path": _root_info}
    )
    return result


async def _tool_send_team_message(arguments: dict[str, Any]) -> dict[str, Any]:
    """send_team_message:向点名同伴投递一条消息(绝不广播)。"""
    from .agent_comm import send_to_agent

    if not arguments.get("__user_id"):
        return {
            "tool": "send_team_message", "ok": False,
            "code": "missing_caller_identity",
            "missingKeys": ["__user_id", "__session_id"],
            "not_queued": True,
            "detail": "缺少宿主注入的调用者身份与归属会话",
        }
    return await send_to_agent(
        recipient=str(arguments.get("recipient") or ""),
        content=str(arguments.get("content") or ""),
        # 契约要求 str:模型可能给 null,`or None` 会把 None 透给下游(类型层已判红)
        sender=str(arguments.get("sender") or ""),
        session_id=arguments.get("__session_id"),
        user_id=arguments.get("__user_id"),
        user_role=arguments.get("__user_role"),
        message_type=str(arguments.get("message_type") or "notification"),
        require_reply=bool(arguments.get("require_reply") or False),
        sub_task_id=arguments.get("sub_task_id") or None,
        # 2026-11-08 信箱语义:四枚开关 + 链深/幂等键(落信封,由收件方决定怎么用)
        enters_context=arguments.get("enters_context", True) is not False,
        triggers_agent=bool(arguments.get("triggers_agent") or False),
        artifact_refs=arguments.get("artifact_refs") or None,
        priority=arguments.get("priority") or 0,
        hop_depth=arguments.get("hop_depth") or 0,
        source_event_id=arguments.get("source_event_id") or None,
    )


async def _tool_read_team_inbox(arguments: dict[str, Any]) -> dict[str, Any]:
    """read_team_inbox:读本席收件箱(会话 ∧ 属主双闸,拒读零消费)。"""
    from .agent_comm import read_agent_inbox

    if not arguments.get("__user_id"):
        return {
            "tool": "read_team_inbox", "ok": False,
            "code": "missing_caller_identity",
            "missingKeys": ["__user_id", "__session_id"],
            "count": 0,
            "detail": "缺少宿主注入的调用者身份与归属会话",
        }
    return await read_agent_inbox(
        agent_name=str(arguments.get("agent_name") or ""),
        session_id=arguments.get("__session_id"),
        user_id=arguments.get("__user_id"),
        user_role=arguments.get("__user_role"),
        limit=int(arguments.get("limit") or 10),
        wait_seconds=float(arguments.get("wait_seconds") or 0.0),
    )


async def _tool_send_to_session(
    arguments: dict[str, Any], bus: Any | None = None
) -> dict[str, Any]:
    """send_to_session:按会话寻址投递一条消息(绝不广播,不跨属主)。

    与 send_team_message 互补:那枚按「代理名」寻址(席间),本枚按「会话 id」寻址
    (会话间),两者复用同一条 AgentMessageBus,不新造传输层(§0.6)。
    """
    from uuid import uuid4

    from .agent_comm import AgentMessage, agent_message_bus
    from .run_ownership import owner_of

    caller_session = str(arguments.get("__session_id") or "")
    caller_user = str(arguments.get("__user_id") or "")
    if not caller_user or not caller_session:
        missing = [
            key
            for key, value in (("__user_id", caller_user), ("__session_id", caller_session))
            if not value
        ]
        return {
            "tool": "send_to_session", "ok": False,
            "code": "missing_caller_identity",
            "missingKeys": missing,
            "delivered": False,
            "sideEffects": "none",
        }

    caller_owner = owner_of(caller_session)
    if caller_owner is not None and caller_owner != caller_user:
        return {
            "tool": "send_to_session", "ok": False,
            "code": "forbidden_caller_session_mismatch",
            "delivered": False,
            "sideEffects": "none",
        }

    target = str(arguments.get("target_session_id") or "")
    content = str(arguments.get("message") or "")
    kind = str(arguments.get("kind") or "notification")
    if not target:
        return {
            "tool": "send_to_session", "ok": False,
            "code": "missing_target_session",
            "delivered": False, "sideEffects": "none",
        }
    if target == "*":
        return {
            "tool": "send_to_session", "ok": False,
            "code": "broadcast_not_allowed",
            "delivered": False, "sideEffects": "none",
        }
    if target == caller_session:
        return {
            "tool": "send_to_session", "ok": False,
            "code": "self_target",
            "delivered": False, "sideEffects": "none",
        }
    if not content.strip():
        return {
            "tool": "send_to_session", "ok": False,
            "code": "empty_message",
            "delivered": False, "sideEffects": "none",
        }
    if kind not in _NAMABLE_MESSAGE_TYPES:
        return {
            "tool": "send_to_session", "ok": False,
            "code": "unsupported_kind",
            "supported": sorted(_NAMABLE_MESSAGE_TYPES),
            "delivered": False, "sideEffects": "none",
        }

    target_owner = owner_of(target)
    if target_owner is None:
        return {
            "tool": "send_to_session", "ok": False,
            "code": "target_owner_unknown",
            "delivered": False, "sideEffects": "none",
        }
    if target_owner != caller_user:
        return {
            "tool": "send_to_session", "ok": False,
            "code": "forbidden_cross_owner",
            "delivered": False, "sideEffects": "none",
        }

    b = bus if bus is not None else agent_message_bus
    # 目标会话队列按需创建:放行路径才建,拒绝路径一条都不碰("零副作用"是可断言的)
    b.register(target)
    message_id = str(uuid4())
    before = b.queue_depth(target) or 0
    await b.send(
        AgentMessage(
            id=message_id,
            fromAgent=caller_session,
            toAgent=target,
            type=kind,  # type: ignore[arg-type]
            content=content,
            requireReply=(kind == "request"),
            ownerUserId=caller_user,
            sessionId=caller_session,
        )
    )
    after = b.queue_depth(target)
    if after is None or after <= before:
        return {
            "tool": "send_to_session", "ok": False,
            "code": "not_queued",
            "delivered": False,
            "messageId": message_id,
            "sideEffects": "none",
        }
    return {
        "tool": "send_to_session", "ok": True,
        "code": "queued",
        "delivered": True,
        "toSessionId": target,
        "queueDepth": after,
        "messageId": message_id,
    }


# ---------------------------------------------------------------------------
# Notebook 结构编辑(G-NotebookEdit 补齐,2026-11-01 立;对齐对方 NotebookEdit 的
# cell_id/cell_type/edit_mode 三键,本仓 MCP/CLI 工具面此前 0 命中)
# 写盘腿纪律:定位/改写只动目标 cell,回写一律走 _tool_write_file 的串行化腿
# (per-path 锁 + 并发漂移判定 + base 刷新),不开第二条文件写/权限腿(§0.6)。
# 身份闸与相邻写工具同档:只认宿主注入的 __user_id(call_tool 从 FastAPI request
# 透传,LLM 不可控),缺失即 PRINCIPAL_REQUIRED 且一次都不碰磁盘(§5 认证≠授权)。
# ---------------------------------------------------------------------------

_NOTEBOOK_EDIT_MODES: Final[frozenset[str]] = frozenset({"replace", "insert", "delete"})
_NOTEBOOK_CELL_TYPES: Final[frozenset[str]] = frozenset({"code", "markdown", "raw"})
_NOTEBOOK_CELL_INDEX_RE: Final[re.Pattern[str]] = re.compile(r"^cell-(\d+)$")
# 体积上限与 file_edit 同档(10MB);notebook 常内嵌 base64 输出,超限直接拒 edit。
_NOTEBOOK_EDIT_MAX_BYTES: Final[int] = 10 * 1024 * 1024


def _notebook_source_lines(text: str) -> list[str]:
    """把新源码切成 ipynb 惯用的行数组(每行保留行尾换行符)。"""
    return text.splitlines(keepends=True)


async def _tool_notebook_edit(arguments: dict[str, Any]) -> dict[str, Any]:
    """notebook_edit:按单元格结构编辑 .ipynb(replace/insert/delete)。

    cell_id 两种形态:`cell-N`(0 基序号,对方 NotebookEdit 展示形)或 notebook 原生
    cell 的 id 字段值。edit_mode=replace 改写目标 cell 的 source(可顺带改 cell_type);
    insert 在目标 cell 之后插入新 cell(cell_type 必填);delete 删除目标 cell。
    其余 cell 在同一次 JSON 序列化下逐字节保持不变(测试逐 cell dump 比对钉住)。
    """
    def _err(code: str, msg: str) -> dict[str, Any]:
        return {"tool": "notebook_edit", "ok": False, "errorCode": code, "error": msg}

    # 1. 身份闸最先判:拿不到宿主注入主体就拒绝,连路径校验都不做(零磁盘动作)。
    host_user_id = arguments.get("__user_id")
    if not isinstance(host_user_id, str) or not host_user_id:
        return _err("PRINCIPAL_REQUIRED", "缺少宿主注入的调用者身份")

    notebook_path = str(arguments.get("notebook_path") or "")
    if not notebook_path.lower().endswith(".ipynb"):
        return _err("NOT_A_NOTEBOOK", "notebook_path 必须指向 .ipynb 文件")
    ok, info = _validate_write_path_in_workspace(notebook_path)
    if not ok:
        return _err("PATH_NOT_ALLOWED", info)
    resolved_path = info

    edit_mode = str(arguments.get("edit_mode") or "replace")
    if edit_mode not in _NOTEBOOK_EDIT_MODES:
        return _err("INVALID_EDIT_MODE", f"edit_mode 只接受 replace/insert/delete,收到: {edit_mode}")

    cell_id = str(arguments.get("cell_id") or "").strip()
    if not cell_id:
        return _err("MISSING_PARAMS", "缺少 cell_id 参数")

    new_source = arguments.get("new_source")
    if edit_mode in ("replace", "insert") and (not isinstance(new_source, str) or not new_source):
        return _err("MISSING_PARAMS", f"{edit_mode} 模式必须携带非空的 new_source")

    cell_type = arguments.get("cell_type")
    if cell_type is not None and str(cell_type) not in _NOTEBOOK_CELL_TYPES:
        return _err("INVALID_CELL_TYPE", "cell_type 只接受 code/markdown/raw")

    try:
        if not os.path.isfile(resolved_path):
            return _err("FILE_NOT_FOUND", f"笔记本不存在: {resolved_path}")
        if os.path.getsize(resolved_path) > _NOTEBOOK_EDIT_MAX_BYTES:
            return _err("FILE_TOO_LARGE", "笔记本大于 10MB,拒绝编辑")
        with open(resolved_path, encoding="utf-8") as f:
            original_text = f.read()
    except OSError as e:
        return _err("IO_ERROR", str(e))

    try:
        nb: dict[str, Any] = json.loads(original_text)
    except ValueError as e:
        return _err("INVALID_NOTEBOOK", f".ipynb JSON 解析失败: {e}")
    cells = nb.get("cells")
    if not isinstance(nb, dict) or not isinstance(cells, list):
        return _err("INVALID_NOTEBOOK", "cells 数组缺失或形态非法,不是有效笔记本")

    # 2. 定位目标 cell:cell-N 优先按 0 基序号,否则按 notebook 原生 id 逐格匹配。
    target_index: int | None = None
    index_match = _NOTEBOOK_CELL_INDEX_RE.match(cell_id)
    if index_match is not None:
        ordinal = int(index_match.group(1))
        if 0 <= ordinal < len(cells):
            target_index = ordinal
    else:
        for i, cell in enumerate(cells):
            if isinstance(cell, dict) and cell.get("id") == cell_id:
                target_index = i
                break
    if target_index is None:
        return _err("CELL_NOT_FOUND", f"未找到单元格: {cell_id}")

    applied_cell_id = cell_id
    if edit_mode == "replace":
        target = cells[target_index]
        if not isinstance(target, dict):
            return _err("INVALID_NOTEBOOK", f"单元格 {cell_id} 内容不是对象,拒绝改写")
        target["source"] = _notebook_source_lines(str(new_source))
        if cell_type is not None:
            ct = str(cell_type)
            target["cell_type"] = ct
            if ct == "code":
                target.setdefault("execution_count", None)
                target.setdefault("outputs", [])
            else:
                target.pop("execution_count", None)
                target.pop("outputs", None)
    elif edit_mode == "insert":
        if cell_type is None:
            return _err("MISSING_CELL_TYPE", "insert 模式必须携带 cell_type(code/markdown/raw)")
        ct = str(cell_type)
        new_cell: dict[str, Any] = {
            "cell_type": ct,
            "metadata": {},
            "source": _notebook_source_lines(str(new_source)),
        }
        if ct == "code":
            new_cell["execution_count"] = None
            new_cell["outputs"] = []
        # 对方语义:插到 cell_id 所指单元格之后(形态对齐 NotebookEdit edit_mode=insert)
        cells.insert(target_index + 1, new_cell)
        applied_cell_id = f"cell-{target_index + 1}"
    else:  # delete
        removed = cells.pop(target_index)
        if isinstance(removed, dict) and removed.get("id"):
            applied_cell_id = str(removed["id"])

    nb["cells"] = cells
    # nbformat 生态默认 writer 形态:indent=1 + 文件末尾换行;序列化确定性 = 跑两次同结果。
    new_text = json.dumps(nb, ensure_ascii=False, indent=1) + "\n"

    # 3. 回写复用 write_file 串行化腿:先以刚读到的快照刷新 base(读-改-写自洽),
    #    写段内 classify 若读到外部改动即 drifted 拒写(失效方向=多要一次重读,不盲覆盖)。
    _record_file_base(resolved_path, original_text)
    write_result = await _tool_write_file({"path": resolved_path, "content": new_text})
    if not write_result.get("ok"):
        return {
            "tool": "notebook_edit", "ok": False,
            "errorCode": str(write_result.get("errorCode") or "WRITE_FAILED"),
            "error": write_result.get("error"),
            "write": write_result,
        }
    return {
        "tool": "notebook_edit", "ok": True,
        "editMode": edit_mode,
        "cellId": applied_cell_id,
        "notebookPath": resolved_path,
        "cellCount": len(cells),
        "bytesWritten": write_result.get("bytes_written"),
    }


# ---------------------------------------------------------------------------
# advisor_consult(G-11 协议层收尾,2026-10-31 立):指定另一个模型就子问题作答。
# 身份只认承载层注入的 __user_id / __session_id(LLM 不可控),复用 agent_comm 的
# 单源校验器判"缺一即拒",缺身份时一次都不碰 LLM;预算 / 模型 fail-closed 的判据
# 本体全在 app/services/advisor.py,本层只接线、不复算(§0.6)。
# ---------------------------------------------------------------------------
async def _tool_advisor_consult(arguments: dict[str, Any]) -> dict[str, Any]:
    """advisor_consult:向指定模型咨询一个子问题(会话级次数预算 + 模型名 fail-closed)。"""
    from .advisor import consult
    from .agent_comm import _identity_or_error

    _sid, _uid, identity_error = _identity_or_error(
        arguments.get("__session_id"), arguments.get("__user_id")
    )
    if identity_error is not None:
        return {
            "tool": "advisor_consult", "ok": False,
            "errorCode": "PRINCIPAL_REQUIRED",
            "error": "缺少宿主注入的调用者身份",
            "missingKeys": identity_error.get("missingKeys"),
        }
    raw_max_uses = arguments.get("max_uses")
    max_uses = (
        raw_max_uses
        if isinstance(raw_max_uses, int) and not isinstance(raw_max_uses, bool)
        else None
    )
    result = await consult(
        principal=_uid,
        session_id=_sid,
        prompt=str(arguments.get("prompt") or ""),
        model=str(arguments.get("model") or "").strip() or None,
        max_uses=max_uses,
    )
    return {"tool": "advisor_consult", **result}


# ---------------------------------------------------------------------------
# run_workflow(独立分析对齐补齐腿,2026-11-02 立):多节点 agent 工作流 +
# resume_from_run_id 入参级续跑缓存。判据本体全在 app/services/workflow_runner.py
# (幂等键/续跑存储/分派出口全部 import 复用 task_executors 单源,§0.6),
# 本层只接线、不复算。身份只认承载层注入 __user_id(_identity_or_error 单源),
# 主体缺失即 PRINCIPAL_REQUIRED,run 归属他人即 WORKFLOW_FORBIDDEN,均零执行。
# ---------------------------------------------------------------------------
async def _tool_run_workflow(arguments: dict[str, Any]) -> dict[str, Any]:
    """run_workflow:执行工作流脚本;带 resume_from_run_id 时入参未变节点回缓存不重跑。"""
    from .agent_comm import _identity_or_error
    from .workflow_runner import run_workflow

    _sid, _uid, identity_error = _identity_or_error(
        arguments.get("__session_id"), arguments.get("__user_id")
    )
    if identity_error is not None:
        return {
            "tool": "run_workflow", "ok": False,
            "errorCode": "PRINCIPAL_REQUIRED",
            "error": "缺少宿主注入的调用者身份",
            "missingKeys": identity_error.get("missingKeys"),
        }
    # AIS-031:节点 `agent` 就是 task_type —— 与 run_in_background 同一条分派出口的另一扇门。
    # 放在身份校验之后、run_workflow 之前:拒绝时零节点执行(不落 checkpoint、不跑上游节点)。
    nodes_raw = arguments.get("nodes")
    if isinstance(nodes_raw, list):
        for node in nodes_raw:
            if not isinstance(node, dict):
                continue
            denial = _dispatch_permission_denial(
                "run_workflow", str(node.get("agent") or "").strip(), arguments
            )
            if denial is not None:
                # 与 run_workflow 既有回执同形(workflow_runner._undetermined 口径):
                # 拒绝发生在分派之前 ⇒ executed/cached 必为空,status 为 undetermined。
                # 调用方不必按"拒绝来自哪一层"分叉解析响应形状。
                return {
                    "tool": "run_workflow",
                    "ok": False,
                    "errorCode": denial["errorCode"],
                    "error": denial["error"],
                    "run_id": None,
                    "status": "undetermined",
                    "executed": [],
                    "cached": [],
                    "skipped": {},
                    "failed": {},
                    "results": {},
                }

    resume_raw = arguments.get("resume_from_run_id")
    resume = str(resume_raw).strip() if resume_raw is not None and str(resume_raw).strip() else None
    # 后台化(对齐 外部实现 tool-workflow 的 run_in_background):提交即返回 task_id,
    # 工作流按同一 run_workflow 语义在后台执行,结果经 bg_task_status 取回。
    # 拒绝/禁用态显式回 BACKGROUND_REJECTED,绝不伪装成"已开始"。
    raw_bg = arguments.get("run_in_background")
    run_bg = raw_bg is True or str(raw_bg).strip().lower() in {"1", "true", "yes", "on"}
    if run_bg:
        from .background_tasks import background_task_manager

        try:
            timeout_s = float(arguments.get("timeout_s") or 1800)
        except (TypeError, ValueError):
            timeout_s = 1800.0
        timeout_s = min(max(timeout_s, 1.0), 3600.0)
        node_count = len(nodes_raw) if isinstance(nodes_raw, list) else 0
        raw_notify = arguments.get("notify_on_done")
        notify = raw_notify is True or str(raw_notify).strip().lower() in {"1", "true", "yes", "on"}
        submitted = await background_task_manager.submit(
            lambda: run_workflow(
                arguments.get("nodes"),
                principal=_uid,
                user_role=arguments.get("__user_role"),
                resume_from_run_id=resume,
            ),
            name=f"后台工作流({node_count} 节点)",
            user_id=_uid,
            session_id=_sid,
            notify_on_done=notify,
            timeout_s=timeout_s,
        )
        if isinstance(submitted, dict):
            return {
                "tool": "run_workflow", "ok": False,
                "errorCode": "BACKGROUND_REJECTED",
                "error": str(submitted.get("error") or "后台任务被拒绝"),
                "detail": submitted,
            }
        return {
            "tool": "run_workflow", "ok": True, "background": True,
            "task_id": submitted, "status": "pending", "run_id": None,
            "executed": [], "cached": [], "skipped": {}, "failed": {}, "results": {},
        }
    result = await run_workflow(
        arguments.get("nodes"),
        principal=_uid,
        user_role=arguments.get("__user_role"),
        resume_from_run_id=resume,
    )
    return {"tool": "run_workflow", **result}


# ---------------------------------------------------------------------------
# Qoder 行为对齐(2026-11-08):技能渐进披露 + 会话待办板
#
# 这两族工具的共同点:此前 IHUI 的服务端执行链里**没有模型可调用的实现**
# (技能只有 UI 侧模板;任务板只有 CLI 侧 todo_write/todo_read)。接线口径
# 见 skill_scope.py / session_todo.py 头注,这里只做参数校验与回执。
# ---------------------------------------------------------------------------
_SKILL_INSTRUCTIONS_MAX_CHARS = 12000


def _session_identity_or_error(
    arguments: dict[str, Any],
) -> tuple[str, str, dict[str, Any] | None]:
    """技能/任务板只需要会话;用户可缺省(缺省时键仍是 (``""``, session))。

    与 ``agent_comm._identity_or_error`` 的差别:那里是"投递/收件资格",必须双身份;
    这里是"本会话的工作记忆",会话在即成立。缺 session ⇒ fail-closed,
    避免无会话调用把一处计划写成全进程共享。
    """
    sid = str(arguments.get("__session_id") or "").strip()
    uid = str(arguments.get("__user_id") or "").strip()
    if not sid:
        return sid, uid, {
            "ok": False,
            "code": "missing_session",
            "missingKeys": ["__session_id"],
            "detail": "技能作用域/任务板按会话隔离,缺 __session_id 时拒绝写入",
        }
    return sid, uid, None


async def _tool_skill(arguments: dict[str, Any]) -> dict[str, Any]:
    """skill:按名加载一个技能(渐进披露),并激活其 allowed-tools 会话作用域。

    与"把全部技能正文塞进系统提示"相反:模型先看到技能清单(``available_skills``
    资源 / 技能名),需要时才调本工具拿到 SKILL.md 的 instructions。这样技能库
    可以继续增长而不吃掉每轮上下文。
    """
    sid, uid, identity_error = _session_identity_or_error(arguments)
    if identity_error is not None:
        return {
            "tool": "skill",
            "ok": False,
            "errorCode": "SESSION_REQUIRED",
            "error": "skill 作用域按会话隔离,当前调用缺少 __session_id",
            "missingKeys": identity_error.get("missingKeys"),
        }

    release = bool(arguments.get("release")) or str(arguments.get("action") or "").strip() == "release"
    if release:
        released = _release_skill_scope(user_id=uid, session_id=sid)
        return {"tool": "skill", "ok": True, "data": {"released": released}}

    name = str(arguments.get("name") or "").strip()
    if not name:
        return {
            "tool": "skill",
            "ok": False,
            "errorCode": "INVALID_INPUT",
            "error": (
                "name 必填:传技能名加载;传 {release: true} 结束当前技能作用域。"
                "可用技能见 resources/skills://available。"
            ),
        }

    skill = skill_registry.get(name)
    if skill is None:
        return {
            "tool": "skill",
            "ok": False,
            "errorCode": "SKILL_NOT_FOUND",
            "error": f"未知 skill: {name}",
            "available": sorted({s.name for s in skill_registry.list_skills()})[:120],
        }

    variables = arguments.get("arguments")
    body = (
        skill.render(variables)
        if isinstance(variables, dict) and variables
        else skill.prompt_template
    )
    truncated = False
    if len(body) > _SKILL_INSTRUCTIONS_MAX_CHARS:
        body = body[:_SKILL_INSTRUCTIONS_MAX_CHARS]
        truncated = True

    # allowed-tools 是**授权**(Qoder 原文:permission grant, not a restriction):
    # 名单内工具在本会话免走高危审批。空声明也记录以便回执可读,但不授权任何工具。
    allowed = skill.allowed_tools
    scope = _activate_skill_scope(
        user_id=uid,
        session_id=sid,
        skill=skill.name,
        allowed_tools=list(allowed),
        normalize=_normalize_tool_name,
    )
    return {
        "tool": "skill",
        "ok": True,
        "data": {
            "name": skill.name,
            "description": skill.description,
            "source": skill.source,
            "instructions": body,
            "truncated": truncated,
            "scope": _describe_skill_scope(scope),
            # 模型下一次调用就能看到"哪些工具已获授权",不必靠猜。
            "note": (
                "已将 allowed-tools 登记为本会话的免审批授权(只跳过审批门,"
                "角色矩阵/能力门/路径校验/沙箱仍然生效);"
                "需要收回授权时调用 skill({release: true})。"
                if allowed
                else "该 skill 未声明 allowed-tools,不产生会话级授权。"
            ),
        },
    }


async def _tool_todo_write(arguments: dict[str, Any]) -> dict[str, Any]:
    """todo_write:整表替换本会话的任务板。"""
    sid, uid, identity_error = _session_identity_or_error(arguments)
    if identity_error is not None:
        return {
            "tool": "todo_write",
            "ok": False,
            "errorCode": "SESSION_REQUIRED",
            "error": "任务板按会话隔离,当前调用缺少 __session_id",
            "missingKeys": identity_error.get("missingKeys"),
        }

    items, error = _normalize_todos(arguments.get("todos"))
    if error is not None:
        # 拒绝时**不改**任务板:模型手里的计划与板上保持一致,否则它会以为自己写成功了。
        return {
            "tool": "todo_write",
            "ok": False,
            "errorCode": "INVALID_TODOS",
            "error": error,
            "board": _format_todos(_todo_board.get(user_id=uid, session_id=sid)),
        }

    assert items is not None  # normalize_todos 的返回契约:error 为 None 时 items 必在
    _todo_board.set(user_id=uid, session_id=sid, items=items)
    counts = {
        "total": len(items),
        "pending": sum(1 for i in items if i.status == "pending"),
        "inProgress": sum(1 for i in items if i.status == "in_progress"),
        "completed": sum(1 for i in items if i.status == "completed"),
        "cancelled": sum(1 for i in items if i.status == "cancelled"),
        "blocked": sum(1 for i in items if i.status == "blocked"),
    }
    return {
        "tool": "todo_write",
        "ok": True,
        "data": {"counts": counts, "board": _format_todos(items), "note": "整表替换"},
    }


async def _tool_todo_read(arguments: dict[str, Any]) -> dict[str, Any]:
    """todo_read:读回本会话当前任务板。"""
    sid, uid, identity_error = _session_identity_or_error(arguments)
    if identity_error is not None:
        return {
            "tool": "todo_read",
            "ok": False,
            "errorCode": "SESSION_REQUIRED",
            "error": "任务板按会话隔离,当前调用缺少 __session_id",
            "missingKeys": identity_error.get("missingKeys"),
        }

    items = _todo_board.get(user_id=uid, session_id=sid)
    return {
        "tool": "todo_read",
        "ok": True,
        "data": {
            "todos": [item.as_dict() for item in items],
            "board": _format_todos(items),
        },
    }


async def _tool_ask_user_question(arguments: dict[str, Any]) -> dict[str, Any]:
    """ask_user_question 兜底 handler:无交互宿主的执行面**不等**答复。

    真正的阻塞等待只发生在带交互宿主的执行面(主聊天流 llm.py 工具循环与
    工作台 agent_loop_v2 的特例拦截位);直接 call_tool 的调用没有可送达前端的
    SSE 通道,静默等待只会把调用挂到超时,因此显式拒绝并点名原因。
    """
    return {
        "tool": "ask_user_question",
        "ok": False,
        "errorCode": "question_host_unsupported",
        "error": (
            "当前执行面没有交互宿主,无法向用户提问;"
            "请在主聊天流或工作台 agent 会话中使用本工具"
        ),
    }


_TOOLS: list[MCPTool] = [
    MCPTool(
        name="search_codebase",
        description="代码符号搜索(真实文件系统 + pgvector 语义腿并发,RRF 融合;支持 def/class/func/function/interface/type 符号 + 引用匹配,响应体 mode 点名本轮走的是融合还是单腿)",
        input_schema={
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "符号名或关键词(函数名/类名等)"},
                "path": {"type": "string", "description": "搜索路径(默认当前目录)"},
                "pattern": {"type": "string", "description": "文件名 glob 限定(逗号分隔,默认按代码扩展名过滤)"},
                "symbol_type": {"type": "string", "description": "符号类型过滤(def/class/func/function/interface/type,默认空=全部)"},
                "symbol_name": {"type": "string", "description": "符号名精确过滤(逐字相等、大小写敏感;默认空=不过滤)。这不是第 2 个查询词:命中集只保留被定义符号名逐字等于本值的片。Z37 起该位**已下推到检索腿**(随首跳进 POST /api/v1/codebase/search 的 symbolName,等值条件在 api 侧进 SQL WHERE、早于 LIMIT,取回预算脱离 topK,单源 = apps/api/src/services/codebase-index-service.ts 的 rowBudget),故按符号名取回库内切片不再受 max_results 截断;装配层仍做一次逐字过滤(关键词腿是本地扫描,不经 HTTP)。出参 stats.symbol_filter 读数三档:pushed / unjudged:<原委> / not-attempted。"},
                "max_results": {"type": "integer", "description": "最大返回数", "default": 50},
                "use_semantic": {"type": "boolean", "description": "是否启用语义腿(pgvector ANN,默认 True;False=显式只要关键词腿)。语义腿不可用不再静默回落:响应体 mode/reasons 会点名是哪条腿没答上来", "default": True},
            },
            "required": ["query"],
        },
    ),
    MCPTool(
        name="list_symbol_definitions",
        description=(
            "按符号名取跨文件定义簇(P0-8 第四批):回答「这个符号在仓库里被定义在哪几处」,"
            "输入是符号名本身,不需要先做一次检索。每条定义含虚拟路径(repo/file#symbol)+行区间+种类,"
            "拿到即可直接 read。空集按三因三分给出:path_missing(未建索引)/"
            "catalog_missing(索引早于实体表,重建可补)/upstream_unavailable(取不到,未判定)。"
            "repo_id 可省略:缺省按 path 推导(与 index_codebase 同源)。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "符号名(逐字相等、大小写敏感;必填)"},
                "repo_id": {"type": "string", "description": "仓库标识(可省略;缺省按 path 推导)"},
                "path": {"type": "string", "description": "仓库根目录(默认当前目录;仅在省略 repo_id 时用于推导)"},
                "limit": {"type": "integer", "description": "最多返回多少条定义(默认 50,夹取 1-200)", "default": 50},
            },
            "required": ["name"],
            "additionalProperties": False,
        },
    ),
    MCPTool(
        name="list_project_rules",
        description=(
            "列出项目/用户规则的选择结果(2026-11-24,Cursor 规则 picker 等价):"
            "selected(已注入正文)、agentRequested(只进目录待按需取)、excluded(逐条带原因)、"
            "budget(预算与截断)。可选 targetPaths 模拟某组文件路径下的命中;"
            "只回 locator/原因/长度,不回正文。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "工作区根目录(默认当前目录)"},
                "budgetChars": {"type": "integer", "minimum": 1, "description": "正文预算字符数(默认 8000)"},
                "targetPaths": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "按这组路径模拟 globs 命中(可选)",
                },
            },
            "additionalProperties": False,
        },
    ),
    MCPTool(
        name="read_project_rule",
        description=(
            "按 locator 取一条项目规则正文(2026-11-24,Cursor Agent Requested 等价):"
            "会话里只注入「[项目规则·可请求]」目录(description + locator),需要哪条就用本工具取哪条。"
            "locator 形如 `.cursor/rules/a.mdc` 或 `user:.cursor/rules:global.mdc`;"
            "取不到按 errorCode 返回(symlink_skipped/outside_workspace/too_large/invalid_frontmatter 等),"
            "不会用空正文冒充「规则为空」。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "locator": {"type": "string", "description": "规则定位符(取自 [项目规则·可请求] 目录;必填)"},
                "path": {"type": "string", "description": "工作区根目录(默认当前目录)"},
            },
            "required": ["locator"],
            "additionalProperties": False,
        },
    ),
    MCPTool(
        name="find_import_edges",
        description=(
            "按名字查导入关系(P0-8 第八批):direction='from' 查「这个文件导入了谁」"
            "(target=仓库相对路径),direction='to' 查「谁导入了这个名字」"
            "(target=import 名字原文)。每条边含虚拟路径(repo/file#name)+行号+名字原文。"
            "空集按三档给出:path_missing(未建索引)/ catalog_missing(索引早于边表,"
            "或该仓库的导入行不匹配既有抽取正则 —— 当前只覆盖 python 风格 import)/"
            "upstream_unavailable(取不到,未判定)。repo_id 可省略,缺省按 path 推导。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "target": {
                    "type": "string",
                    "description": "from 档填仓库相对路径;to 档填 import 名字原文(逐字相等、必填)",
                },
                "direction": {
                    "type": "string",
                    "description": "from=查该文件的导入;to=查谁导入了该名字(默认 from)",
                    "enum": ["from", "to"],
                    "default": "from",
                },
                "repo_id": {"type": "string", "description": "仓库标识(可省略;缺省按 path 推导)"},
                "path": {"type": "string", "description": "仓库根目录(默认当前目录;仅在省略 repo_id 时用于推导)"},
                "limit": {"type": "integer", "description": "最多返回多少条边(默认 50,夹取 1-200)", "default": 50},
            },
            "required": ["target"],
            "additionalProperties": False,
        },
    ),
    MCPTool(
        name="index_codebase",
        description=(
            "对本地代码库建立/刷新语义索引(Merkle 增量,未变更文件零重嵌入)。"
            "search_codebase 的语义/混合检索通道依赖本索引;首次语义搜索前建议显式调用,"
            "或依赖 search_codebase 空结果时的懒索引自动触发。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "仓库根目录绝对路径"},
                "repo_id": {"type": "string", "description": "仓库标识(为空按路径 hash 自动生成)"},
                "force_full": {"type": "boolean", "description": "强制全量重建(默认 False=Merkle 增量)", "default": False},
            },
            "required": ["path"],
            "additionalProperties": False,
        },
    ),
    MCPTool(
        name="auto_rebuild_codebase",
        description=(
            "跑一轮自动重建(受 `CODEBASE_AUTO_REBUILD` 开关与预算上限约束,缺省关闭)。"
            "取 '该重建的仓库清单'(配置指纹变了/从没索引过/超过保留期),按登记好的本地路径"
            "逐个增量索引;未登记路径的仓库会被点名跳过而不是猜路径。"
            "开关未开启时返回 skipped 与原因,不会静默跑一轮。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "max_age_days": {
                    "type": "integer",
                    "description": "超过多少天未索引算过期(默认 30,最小 0)",
                    "default": 30,
                    "minimum": 0,
                },
            },
            "additionalProperties": False,
        },
    ),
    MCPTool(
        name="knowledge_lookup",
        description="统一知识查询(多源并发:代码库语义检索 + RAG 向量检索 + 本地知识库词法多跳 + 知识图谱 + 跨会话历史摘要)。用于查找代码实现/历史对话/相关文档,减少 hallucination。返回 hits 列表,每个含 source/score/content;source 为 sag2 时 content 自带字节区间与行号引用。",
        input_schema={
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "自然语言查询,如 '用户认证逻辑实现' 或 'JWT 相关代码'"},
                "top_k_per_source": {"type": "integer", "description": "每个源返回 top-K,默认 5(范围 1-20)", "default": 5, "minimum": 1, "maximum": 20},
            },
            "required": ["query"],
            "additionalProperties": False,
        },
    ),
    MCPTool(
        name="context_recall",
        description="语义回捞被上下文压缩丢弃的旧消息(只读)",
        input_schema={
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "自然语言查询,用于语义匹配被压缩丢弃的旧消息原文"},
                "session_id": {"type": "string", "description": "会话 id(可选,限定检索范围;为空则全库检索)"},
                "top_k": {"type": "integer", "description": "返回条数上限,默认 8", "default": 8, "minimum": 1, "maximum": 50},
            },
            "required": ["query"],
            "additionalProperties": False,
        },
    ),
    MCPTool(
        # V3 #63(2026-09-27 立):请用户在对话流里填一张业务表单。
        # **入参刻意只有 kind + 可选 prefill** —— 路由身份(sessionId / user_id /
        # conversationId)一律由宿主在拦截位与 closure 里绑定,绝不交给模型填写:
        # 模型能自报身份就等于能把表单挂到别人的会话上。同一纪律见
        # packages/types/src/tool-contract.ts 的 ROUTING_IDENTITY_KEYS 与守门 113
        # (Python 面不在该门扫描射程,口径照抄)。
        #
        # ⚠️ 这里的 name 必须是**字符串字面量**,不能写成 name=_FORM_REQUEST_TOOL_NAME:
        # 守门 55(check-tool-name-display-coverage)提取注册名用的是 /name=["']([a-z0-9_]+)["']/,
        # 常量形态在它眼里等于这个工具不存在 ⇒ "新工具必须补五语言功能名"这条约束静默失效
        # (AGENTS §4 记过同型:"门让你怎么写,门就看不见怎么写")。
        # 两者的一致性由 tests/test_form_request_frame.py 的对账用例钉住。
        name="request_business_form",
        description=(
            "请用户在对话流内填写一张业务表单并等待其提交。用于**必须**由用户确认的"
            "结构化信息(邮件撰写 email / 日历事件 calendarEvent):你不知道收件人、"
            "主题、时间或出席人时调本工具,而不是编造一个值,也不是用纯文本追问"
            "(文本追问拿不到结构化字段,后续工具无法直接使用)。"
            "返回:用户提交的内容(action=approve 时含逐字段 values),"
            "或明确的失败码(rejected=用户拒绝、timeout=超时未答、"
            "form_invalid=请求的表单种类不存在)。用户拒绝时不要重试本工具,按已知的"
            "信息直接回复用户。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "kind": {
                    "type": "string",
                    "enum": sorted(BUSINESS_FORM_KINDS),
                    "description": (
                        "表单种类。只能取列出的枚举值;其他种类尚未定义,"
                        "拿不准就改用文本提问。"
                    ),
                },
                "prefill": {
                    "type": "object",
                    "description": (
                        "可选预填值,键必须取自该 kind 的字段集(如 email 的 to/subject/body)。"
                        "只填你已经确切知道的字段,**不要替用户编造**收件人、时间等事实。"
                    ),
                    "additionalProperties": {"type": "string"},
                },
            },
            "required": ["kind"],
            "additionalProperties": False,
        },
    ),
    MCPTool(
        name="read_file",
        description=(
            "读取本地文件内容。大文件用 offset/limit 按行分页:返回带行号的窗口、总行数"
            "和下一页 offset;不传 offset/limit 时返回整文件原文"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": f"文件绝对或相对路径;{_CONTEXT_URI_HINT}"},
                "offset": {
                    "type": "integer",
                    "description": "起始行号(从 1 开始);只在大文件分页时传",
                    "minimum": 1,
                },
                "limit": {
                    "type": "integer",
                    "description": f"本次最多读取行数(1-{_READ_WINDOW_MAX_LINES},默认 {_READ_WINDOW_MAX_LINES})",
                    "minimum": 1,
                    "maximum": _READ_WINDOW_MAX_LINES,
                },
            },
            "required": ["path"],
        },
    ),
    MCPTool(
        name="read_image",
        description=(
            "读取 PNG/JPEG/WebP/GIF 图片并把图片本身交给当前主模型直接查看"
            "(不是 OCR、也不转交其它视觉模型)。大图会自动降采样并给出坐标换算倍数;"
            "不要为了看图安装图像库或生成缩略图"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "file_path": {
                    "type": "string",
                    "description": "图片文件路径(必须在工作区白名单内)",
                },
            },
            "required": ["file_path"],
            "additionalProperties": False,
        },
    ),
    MCPTool(
        name="read_tool_output",
        description=(
            "读取此前因超长而落盘的工具输出工件(按字符 offset 分页续读)。"
            "工具结果正文会给出 output_artifact_id 与 output_offset;用本工具按 offset 继续读,"
            "直到返回 complete=true。只读,不产生任何副作用"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "artifact_id": {
                    "type": "string",
                    "description": "工具结果正文里给出的 output_artifact_id(32 位小写 hex)",
                },
                "offset": {
                    "type": "integer",
                    "description": "从第几个字符开始读(用上一次返回的 next);默认 0",
                    "minimum": 0,
                },
                "limit": {
                    "type": "integer",
                    "description": "本页最多返回的字符数,默认 4000,上限 20000",
                    "minimum": 1,
                    "maximum": 20000,
                },
            },
            "required": ["artifact_id"],
            "additionalProperties": False,
        },
    ),
    MCPTool(
        name="list_files",
        description="列出目录内容(返回子项名称/类型/大小;路径必须在工作区白名单内)",
        input_schema={
            "type": "object",
            "properties": {"path": {"type": "string", "description": f"目录绝对或相对路径,默认当前目录;{_CONTEXT_URI_HINT}"}},
            "required": ["path"],
        },
    ),
    MCPTool(
        name="render_repo_tree",
        description=(
            "按 token 预算渲染仓库目录骨架(不是文件清单):预算不足时先保目录树、削掉的文件与"
            "被 scope 排除的条目分别计数回报,complete/dropReason 说明这份骨架是全仓还是削过的"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "仓库根目录,默认当前目录;必须在工作区白名单内"},
                "maxTokens": {"type": "integer", "description": "骨架的 token 预算,默认 2000"},
                "scope": {"type": "string", "description": "只渲染该相对子树(如 apps/api);省略则全仓"},
            },
            "required": ["path"],
        },
    ),
    MCPTool(
        name="apply_patch_set",
        description=(
            "多文件事务写:先把拟写内容放进影子目录跑校验(py/json/toml 内置,可注入语言服务),"
            "全部通过才逐个原子回写;任一失败逆序恢复整批。返回 status(validated/applied/"
            "validation_failed/rolled_back/rejected)与逐文件诊断。改一组相关文件时优先用它,"
            "单文件仍用 write_file/file_edit。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "工作区根目录绝对路径"},
                "patches": {
                    "type": "array",
                    "minItems": 1,
                    "maxItems": 64,
                    "items": {
                        "type": "object",
                        "properties": {
                            "path": {"type": "string", "description": "工作区相对路径"},
                            "content": {"type": "string", "description": "写入后的完整 UTF-8 文本"},
                            "expectedSha256": {
                                "type": "string",
                                "description": "可选前置条件:现盘文件的 sha256(新建为空串)",
                            },
                        },
                        "required": ["path", "content"],
                    },
                },
                "dryRun": {"type": "boolean", "default": False, "description": "只校验不落盘"},
                "validate": {"type": "boolean", "default": True, "description": "false 跳过校验(只保留影子副本与事务写)"},
                "languageServer": {
                    "type": "boolean",
                    "default": True,
                    "description": "校验时叠加语言服务诊断;不可用自动回退内置语法校验",
                },
            },
            "required": ["path", "patches"],
        },
    ),
    MCPTool(
        name="write_file",
        description=(
            "写入内容到本地文件。写冲突治理:若现盘内容与本会话上次看到的版本不一致"
            "(他人已修改),写入会被拒绝(CONCURRENT_MODIFICATION);请先 read_file "
            "重新读取,或携带 force=true 表示已知情、确认覆盖"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": f"本地文件绝对或相对路径;{_CONTEXT_URI_HINT}"},
                "content": {"type": "string"},
                "force": {
                    "type": "boolean",
                    "description": "知情覆盖逃生门:检测到并发修改时,确信要覆盖他人改动才置 true",
                },
            },
            "required": ["path", "content"],
        },
    ),
    MCPTool(
        name="file_edit",
        description="精细编辑文件:精确替换 old_string 为 new_string,带 conflict 检测",
        input_schema={
            "type": "object",
            "required": ["file_path", "old_string", "new_string"],
            "properties": {
                "file_path": {"type": "string", "description": f"文件绝对路径,必须在工作区白名单内;{_CONTEXT_URI_HINT}"},
                "old_string": {"type": "string", "minLength": 1, "description": "要替换的字符串(不能为空)"},
                "new_string": {"type": "string", "description": "替换后的字符串(可为空=删除)"},
                "replace_all": {"type": "boolean", "default": False, "description": "true 替换所有匹配;false 必须唯一匹配,多个报 AMBIGUOUS_MATCH"},
            },
        },
    ),
    MCPTool(
        name="resolve_conflict",
        description="按块解决 file_edit 报告的 3-way merge 冲突(局部拒绝):choices 按冲突块顺序指定 'ours'(采用 agent 修改)/'theirs'(保留磁盘现状=拒绝该块修改),不足缺省 ours",
        input_schema={
            "type": "object",
            "required": ["file_path", "old_string", "new_string"],
            "properties": {
                "file_path": {"type": "string", "description": "文件绝对路径,必须与触发冲突的 file_edit 一致"},
                "old_string": {"type": "string", "minLength": 1, "description": "与触发冲突的 file_edit 相同的 old_string"},
                "new_string": {"type": "string", "description": "与触发冲突的 file_edit 相同的 new_string"},
                "choices": {
                    "type": "array",
                    "items": {"type": "string", "enum": ["ours", "theirs"]},
                    "description": "按冲突块顺序的决策列表:'ours'=采用 agent 修改,'theirs'=保留磁盘现状(拒绝该块)",
                },
                "replace_all": {"type": "boolean", "default": False},
            },
        },
    ),
    MCPTool(
        name="sandbox_session",
        description=(
            "长寿命沙箱会话。action："
            "create、get、pause、resume、kill、snapshot、list_snapshots、"
            "delete_snapshot、rollback、clone、write_file、read_file、exec、"
            "set_timeout、reap_idle。"
            "命令在该沙箱自己的工作区里执行；暂停后的 exec 会先恢复。"
            "调用方不能打开网络，密钥形态的环境变量不会进入子进程。"
        ),
        input_schema={
            "type": "object",
            "required": ["action"],
            "properties": {
                "action": {
                    "type": "string",
                    "enum": [
                        "create",
                        "get",
                        "pause",
                        "resume",
                        "kill",
                        "snapshot",
                        "list_snapshots",
                        "delete_snapshot",
                        "rollback",
                        "clone",
                        "write_file",
                        "read_file",
                        "exec",
                        "set_timeout",
                        "reap_idle",
                    ],
                },
                "sandbox_id": {"type": "string"},
                "snapshot_id": {"type": "string"},
                "command": {"type": "string"},
                "timeout_s": {
                    "type": "integer",
                    "description": "空闲秒数，-1 表示不自动暂停",
                },
                "timeout": {"type": "integer", "description": "exec 的超时秒数"},
                "n": {"type": "integer", "description": "克隆份数，1 到 8"},
                "path": {"type": "string"},
                "content": {"type": "string"},
                "files": {
                    "type": "object",
                    "additionalProperties": {"type": "string"},
                },
                "env": {
                    "type": "object",
                    "additionalProperties": {"type": "string"},
                },
            },
        },
    ),
    # ===== 模型侧交互式终端(2026-11-14,遵循统一工程规范)=====
    MCPTool(
        name="terminal",
        description=(
            "长驻交互式终端(同一进程跨多次调用):open 启动 → send 分步输入 → "
            "read 按 seq 增量读 → signal 中断/终止 → close 收尾;list 列出本会话终端。"
            "适合 REPL、调试器、交互式脚手架等 run_command 一次跑不完的场景。"
            "cwd 必须在工作区白名单内;子进程环境走沙箱严档白名单;"
            "admin-only 且与 run_command 同档审批。"
        ),
        input_schema={
            "type": "object",
            "required": ["action"],
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["open", "send", "read", "signal", "close", "list"],
                    "description": "open 启动 / send 输入 / read 读输出 / signal 发信号 / close 关闭 / list 列出",
                },
                "terminal_id": {
                    "type": "string",
                    "description": "open 之外的操作必填",
                },
                "command": {
                    "type": "string",
                    "description": "open:启动命令(省略则用默认 shell)",
                },
                "cwd": {
                    "type": "string",
                    "description": "open:工作目录(必须在工作区白名单内;省略用首个工作区根)",
                },
                "env": {
                    "type": "object",
                    "additionalProperties": {"type": "string"},
                    "description": "open:附加环境变量(仍受沙箱白名单约束)",
                },
                "input": {
                    "type": "string",
                    "description": "send:写入的文本",
                },
                "enter": {
                    "type": "boolean",
                    "description": "send:是否自动追加换行(默认 true)",
                    "default": True,
                },
                "since_seq": {
                    "type": "integer",
                    "description": "read:从哪个序号之后开始读(用上次返回的 next_seq 续读)",
                    "default": 0,
                },
                "wait_s": {
                    "type": "number",
                    "description": "read:等待新输出的秒数(0-10,默认 1)",
                    "default": 1,
                },
                "max_chars": {
                    "type": "integer",
                    "description": "read:本次最多返回字符数(默认 8000)",
                    "default": 8000,
                },
                "signal": {
                    "type": "string",
                    "enum": ["interrupt", "terminate", "kill"],
                    "description": "signal:信号类型(默认 interrupt)",
                    "default": "interrupt",
                },
            },
        },
    ),
    MCPTool(
        name="run_command",
        description="运行 shell 命令(asyncio.subprocess 流式读取 stdout/stderr,白名单: git/ls/cat/echo/python/node/npm/pnpm/ruff/mypy/pytest 等,禁止 rm/mv/cp/curl/重定向/管道)。支持 sandbox_backend 切换 local/docker/ssh,支持 env 透传(禁止覆盖 PATH/HOME),cwd 校验工作区,超时 kill 进程并返回 partial_output",
        input_schema={
            "type": "object",
            "properties": {
                "command": {"type": "string", "description": "命令字符串(如 git status, python --version)"},
                "cwd": {"type": "string", "description": "工作目录(默认当前目录,非 . 时需在工作区白名单内)", "default": "."},
                "timeout": {"type": "integer", "description": "超时秒数(默认 60,不超过 max_timeout)", "default": 60},
                "max_timeout": {"type": "integer", "description": "超时上限(默认 600,timeout 不超过此值)", "default": 600},
                "env": {
                    "type": "object",
                    "description": "环境变量 dict(透传到 subprocess,不允许覆盖 PATH/HOME/USERPROFILE)",
                    "additionalProperties": {"type": "string"},
                },
                "sandbox_backend": {
                    "type": "string",
                    "enum": ["local", "docker", "ssh", "modal", "daytona", "singularity"],
                    "description": "沙箱后端(默认 local,modal/daytona/singularity 预留未实现)",
                    "default": "local",
                },
                "docker_image": {
                    "type": "string",
                    "description": "Docker 镜像(backend=docker 时,默认 python:3.12-slim)",
                    "default": "python:3.12-slim",
                },
                "ssh_host": {"type": "string", "description": "SSH 主机(backend=ssh 时必填)"},
                "ssh_user": {"type": "string", "description": "SSH 用户名(backend=ssh 时,默认 root)", "default": "root"},
            },
            "required": ["command"],
        },
    ),
    MCPTool(
        name="web_search",
        description="网页搜索(复用 DuckDuckGo Lite HTML,无 API key)。支持 1-10 个 queries 并发检索并按 URL 去重合并",
        input_schema={
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "单个搜索关键词(与 queries 二选一)"},
                "queries": {
                    "type": "array",
                    "items": {"type": "string"},
                    "minItems": 1,
                    "maxItems": 10,
                    "description": "1-10 个搜索关键词;并发检索后按 URL 去重合并(query 可省略)",
                },
                "max_results": {"type": "integer", "description": "合并后的最大返回数", "default": 5},
            },
            "required": [],
        },
    ),
    MCPTool(
        name="image_search",
        description="图片搜索(DuckDuckGo Images,无 API key)。每条结果带 trust={tier: official|trusted|unknown|unsafe, score, reasons} 来源可信度分档,结果按 score 降序;unsafe 会在 summary.message 里点名。",
        input_schema={
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "搜索关键词"},
                "max_results": {"type": "integer", "description": "最大返回数", "default": 8},
            },
            "required": ["query"],
        },
    ),
    MCPTool(
        name="search_web",
        description="DuckDuckGo Lite 搜索(支持 query 单查询或 queries 多查询并发合并)",
        input_schema={
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "单个搜索关键词(与 queries 二选一)"},
                "queries": {
                    "type": "array",
                    "items": {"type": "string"},
                    "minItems": 1,
                    "maxItems": 10,
                    "description": "1-10 个搜索关键词;并发检索后按名次轮转、URL 去重合并",
                },
                "max_results": {"type": "integer", "default": 5},
            },
            "required": [],
        },
    ),
    MCPTool(
        name="analyze_code",
        description="代码静态分析(Python: AST 深度分析——未使用 import、裸 except、圈复杂度 top-N、超长函数、可变默认参数、TODO/FIXME 计数,返回结构化 findings;其他语言: 诚实降级为行级统计并标注 line-stats)",
        input_schema={
            "type": "object",
            "properties": {
                "code": {"type": "string"},
                "language": {"type": "string", "default": "text"},
            },
            "required": ["code"],
        },
    ),
    MCPTool(
        name="generate_test",
        description="LLM 生成真实测试代码并执行验证(Python: pytest 子进程真执行并返回通过/失败数;JS/TS: node 语法校验或如实标注未执行;LLM 不可用时返回 ok:False,不产出占位模板)",
        input_schema={
            "type": "object",
            "properties": {
                "code": {"type": "string"},
                "language": {"type": "string", "default": "python"},
                "framework": {"type": "string", "default": "pytest"},
            },
            "required": ["code"],
        },
    ),
    MCPTool(
        name="file_search",
        description="搜索文件内容(真实文件系统搜索,支持文件名 glob + 内容关键词)",
        input_schema={
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "搜索关键词(为空则仅按文件名匹配)"},
                "path": {"type": "string", "description": "搜索路径(默认当前目录)"},
                "pattern": {"type": "string", "description": "文件名 glob 匹配模式", "default": "*"},
                "max_results": {"type": "integer", "description": "最大返回数", "default": 50},
            },
            "required": [],
        },
    ),
    MCPTool(
        name="git_operations",
        description=(
            "Git 操作(真实 git 命令)。只读(所有用户): status/diff/log/branch/show/stash/list; "
            "写操作(需 admin): branch_create/branch_switch/branch_delete/merge/rebase/"
            "stash_push/stash_pop/tag_create/tag_list"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "description": (
                        "git 操作。只读: status/diff/log/branch/show/stash/list; "
                        "写(admin): branch_create/branch_switch/branch_delete/merge/rebase/"
                        "stash_push/stash_pop/tag_create/tag_list"
                    ),
                    "default": "status",
                },
                "repo": {"type": "string", "description": "仓库路径(默认当前目录)", "default": "."},
                "ref": {"type": "string", "description": "git 引用(仅 show 操作使用,默认 HEAD)", "default": "HEAD"},
                "name": {"type": "string", "description": "分支名/标签名(branch_create/branch_switch/branch_delete/tag_create 必填)"},
                "from": {"type": "string", "description": "起点引用(branch_create,默认 HEAD)"},
                "create": {"type": "boolean", "description": "不存在时创建(branch_switch)"},
                "force": {"type": "boolean", "description": "强制删除未合并分支(branch_delete,-D)"},
                "branch": {"type": "string", "description": "要合并的分支(merge)或变基目标分支(rebase)"},
                "upstream": {"type": "string", "description": "上游分支(rebase 必填,如 origin/main)"},
                "no_ff": {"type": "boolean", "description": "禁用 fast-forward(merge,--no-ff)"},
                "squash": {"type": "boolean", "description": "压缩合并(merge,--squash)"},
                "message": {"type": "string", "description": "提交信息(merge/tag_create/stash_push)"},
                "include_untracked": {"type": "boolean", "description": "包含未跟踪文件(stash_push,-u)"},
                "index": {"type": "integer", "description": "暂存索引(stash_pop,默认 0)", "default": 0},
                "apply": {"type": "boolean", "description": "仅应用不删除(stash_pop,--apply)"},
                "annotated": {"type": "boolean", "description": "创建附注标签(tag_create,-a)"},
                "pattern": {"type": "string", "description": "glob 匹配模式(tag_list,如 v*)"},
            },
            "required": [],
        },
    ),
    MCPTool(
        name="db_query",
        description="数据库只读查询(真实 postgres,仅允许 SELECT/WITH,参数化 + 超时 + 行数限制)",
        input_schema={
            "type": "object",
            "properties": {
                "sql": {"type": "string", "description": "SQL 查询语句(仅 SELECT/WITH)"},
                "params": {"type": "array", "description": "参数化查询参数($1,$2... 占位符)", "default": []},
                "max_rows": {"type": "integer", "description": "最大返回行数(默认 100,上限 1000)", "default": 100},
            },
            "required": ["sql"],
        },
    ),
    # ===== AI 自动控制浏览器(12 个,由 extension 端执行)=====
    MCPTool(
        name="browser_screenshot",
        description="浏览器截图(chrome.tabs.captureVisibleTab,返回 base64 PNG)",
        input_schema={
            "type": "object",
            "properties": {
                "area": {"type": "string", "enum": ["viewport", "fullpage", "element"], "default": "viewport"},
                "selector": {"type": "string", "description": "area='element' 时的 CSS 选择器"},
            },
        },
    ),
    MCPTool(
        name="browser_click_element",
        description="点击浏览器页面元素(CSS 选择器定位)",
        input_schema={
            "type": "object",
            "properties": {
                "selector": {"type": "string", "description": "CSS 选择器"},
                "button": {"type": "string", "enum": ["left", "right", "middle"], "default": "left"},
                "count": {"type": "integer", "default": 1},
            },
            "required": ["selector"],
        },
    ),
    MCPTool(
        name="browser_type_text",
        description="在浏览器输入框输入文本(CSS 选择器定位)",
        input_schema={
            "type": "object",
            "properties": {
                "selector": {"type": "string"},
                "text": {"type": "string"},
                "clear": {"type": "boolean", "default": True},
                "delay": {"type": "integer", "default": 0},
            },
            "required": ["selector", "text"],
        },
    ),
    MCPTool(
        name="browser_scroll",
        description="浏览器页面滚动(上下左右)",
        input_schema={
            "type": "object",
            "properties": {
                "direction": {"type": "string", "enum": ["up", "down", "left", "right"]},
                "amount": {"type": "integer", "default": 300},
                "selector": {"type": "string", "description": "作用于指定元素,默认 window"},
            },
            "required": ["direction"],
        },
    ),
    MCPTool(
        name="browser_extract_dom",
        description="提取浏览器页面 DOM 信息(文本/属性/节点结构)",
        input_schema={
            "type": "object",
            "properties": {
                "selector": {"type": "string", "description": "空=visible;'all'=全文档;其他=选择器"},
                "attributes": {"type": "array", "items": {"type": "string"}, "default": ["text", "href", "src", "value"]},
                "maxNodes": {"type": "integer", "default": 100},
            },
        },
    ),
    MCPTool(
        name="browser_navigate",
        description="浏览器导航到指定 URL",
        input_schema={
            "type": "object",
            "properties": {
                "url": {"type": "string"},
                "waitUntil": {"type": "string", "enum": ["load", "domcontentloaded", "networkidle0", "networkidle2"], "default": "load"},
                "timeout": {"type": "integer", "default": 30000},
            },
            "required": ["url"],
        },
    ),
    MCPTool(
        name="browser_wait_for_element",
        description="等待浏览器页面元素出现/消失",
        input_schema={
            "type": "object",
            "properties": {
                "selector": {"type": "string"},
                "state": {"type": "string", "enum": ["attached", "detached", "visible", "hidden"], "default": "visible"},
                "timeout": {"type": "integer", "default": 30000},
            },
            "required": ["selector"],
        },
    ),
    MCPTool(
        name="browser_get_attribute",
        description="获取浏览器页面元素属性值",
        input_schema={
            "type": "object",
            "properties": {
                "selector": {"type": "string"},
                "attribute": {"type": "string"},
            },
            "required": ["selector", "attribute"],
        },
    ),
    MCPTool(
        name="browser_hover",
        description="鼠标悬停在浏览器页面元素上",
        input_schema={
            "type": "object",
            "properties": {"selector": {"type": "string"}},
            "required": ["selector"],
        },
    ),
    MCPTool(
        name="browser_select_option",
        description="选择浏览器页面 select 下拉选项",
        input_schema={
            "type": "object",
            "properties": {
                "selector": {"type": "string"},
                "value": {"type": "string", "description": "选项值或文本"},
            },
            "required": ["selector", "value"],
        },
    ),
    MCPTool(
        name="browser_switch_tab",
        description="切换浏览器标签页(按索引)",
        input_schema={
            "type": "object",
            "properties": {"index": {"type": "integer", "description": "0-based 标签页索引"}},
            "required": ["index"],
        },
    ),
    MCPTool(
        name="browser_close_tab",
        description="关闭当前浏览器标签页",
        input_schema={"type": "object", "properties": {}},
    ),
    # ===== 浏览器运行时观测(2026-11-08,后端 Browser Hub + CDP)=====
    MCPTool(
        name="browser_console_messages",
        description=(
            "读取浏览器页面的 console 输出、未捕获异常与浏览器日志(最近 N 条,环形缓冲有界)。"
            "改完页面后用它确认报错/警告,不要只看截图。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "session_id": {"type": "string", "description": "浏览器会话 id(Browser Hub)"},
                "level": {
                    "type": "string",
                    "enum": ["all", "error", "warning", "info", "log", "debug"],
                    "default": "all",
                },
                "limit": {"type": "integer", "default": 50, "description": "最多返回条数(上限 200)"},
                "textContains": {"type": "string", "description": "只返回文本包含该关键字的条目"},
            },
            "required": ["session_id"],
        },
    ),
    MCPTool(
        name="browser_network_requests",
        description=(
            "读取浏览器已完成的网络请求(方法/URL/状态码/资源类型/耗时/大小/失败原因)。"
            "在途请求不落库,由 pending 计数提示还有多少没结束。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "session_id": {"type": "string", "description": "浏览器会话 id(Browser Hub)"},
                "limit": {"type": "integer", "default": 50, "description": "最多返回条数(上限 200)"},
                "urlContains": {"type": "string", "description": "只返回 URL 包含该关键字的请求"},
                "method": {"type": "string", "description": "按 HTTP 方法过滤(如 GET/POST)"},
                "statusMin": {"type": "integer", "description": "状态码下限(如 400 只看失败)"},
                "failedOnly": {"type": "boolean", "default": False, "description": "只看加载失败(loadingFailed)"},
            },
            "required": ["session_id"],
        },
    ),
    # ===== 语言服务诊断(2026-11-08,复用 api/v1/lsp)=====
    MCPTool(
        name="get_diagnostics",
        description=(
            "读取某文件的语言服务诊断(错误/警告/提示 + 行号列号)。"
            "编辑后用它在同一份判据下自检,不必先跑完整构建。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "workspacePath": {"type": "string", "description": "工作区根目录(必须在 IHUI_WORKSPACE_ROOTS 白名单内)"},
                "file": {"type": "string", "description": "文件路径(绝对路径或相对 workspacePath)"},
                "severity": {
                    "type": "string",
                    "enum": ["error", "warning", "info", "hint"],
                    "description": "只返回指定严重级别",
                },
                "limit": {"type": "integer", "default": 100, "description": "最多返回条数(上限 500)"},
            },
            "required": ["workspacePath", "file"],
        },
    ),
    # ===== AI 自动控制电脑(10 个,由 desktop 端 Tauri 执行)=====
    MCPTool(
        name="computer_screenshot_screen",
        description="电脑截屏(返回 base64 PNG,支持多显示器 + 区域截取)",
        input_schema={
            "type": "object",
            "properties": {
                "displayIndex": {"type": "integer", "default": 0, "description": "显示器索引,默认 0(主屏)"},
                "region": {"type": "array", "items": {"type": "number"}, "description": "[x, y, w, h] 截取区域,默认全屏"},
            },
        },
    ),
    MCPTool(
        name="computer_mouse_move",
        description="移动电脑鼠标(绝对坐标)",
        input_schema={
            "type": "object",
            "properties": {
                "x": {"type": "number"},
                "y": {"type": "number"},
                "absolute": {"type": "boolean", "default": True},
            },
            "required": ["x", "y"],
        },
    ),
    MCPTool(
        name="computer_mouse_click",
        description="点击电脑鼠标(支持左/右/中键 + 单/双击)",
        input_schema={
            "type": "object",
            "properties": {
                "x": {"type": "number"},
                "y": {"type": "number"},
                "button": {"type": "string", "enum": ["left", "right", "middle"], "default": "left"},
                "count": {"type": "integer", "default": 1},
            },
            "required": ["x", "y"],
        },
    ),
    MCPTool(
        name="computer_keyboard_type",
        description="电脑键盘输入文本(逐字符)",
        input_schema={
            "type": "object",
            "properties": {
                "text": {"type": "string"},
                "delay": {"type": "integer", "default": 0},
            },
            "required": ["text"],
        },
    ),
    MCPTool(
        name="computer_mouse_scroll",
        description="电脑鼠标滚轮(正数向上,负数向下)",
        input_schema={
            "type": "object",
            "properties": {
                "deltaY": {"type": "integer"},
                "x": {"type": "number"},
                "y": {"type": "number"},
            },
            "required": ["deltaY"],
        },
    ),
    MCPTool(
        name="computer_keyboard_press",
        description="电脑键盘按单个键(如 Enter/Tab/Escape)",
        input_schema={
            "type": "object",
            "properties": {"key": {"type": "string"}},
            "required": ["key"],
        },
    ),
    MCPTool(
        name="computer_keyboard_hotkey",
        description="电脑键盘组合键(如 Ctrl+Shift+A)",
        input_schema={
            "type": "object",
            "properties": {
                "keys": {"type": "array", "items": {"type": "string"}, "description": "如 ['Control','Shift','A']"},
            },
            "required": ["keys"],
        },
    ),
    MCPTool(
        name="computer_active_window",
        description="获取电脑当前活动窗口信息(标题/应用名/边界)",
        input_schema={"type": "object", "properties": {}},
    ),
    MCPTool(
        name="computer_clipboard_get",
        description="读取电脑剪贴板内容(文本/图片)",
        input_schema={
            "type": "object",
            "properties": {"format": {"type": "string", "enum": ["text", "image"], "default": "text"}},
        },
    ),
    MCPTool(
        name="computer_clipboard_set",
        description="写入电脑剪贴板内容(文本/图片)",
        input_schema={
            "type": "object",
            "properties": {
                "content": {"type": "string", "description": "文本内容或 base64 image dataURL"},
                "format": {"type": "string", "enum": ["text", "image"], "default": "text"},
            },
            "required": ["content"],
        },
    ),
    # ===== 自动化任务配置工具(2026-07-22 新增)=====
    MCPTool(
        name="configure_automation_task",
        description=(
            "配置自媒体自动化定时任务(支持 koubo_daily / wechat_daily 两个内置任务)。"
            "可修改执行时间、dry-run 模式、启用状态、标题模板。"
            "适用于用户说'帮我设置每天 9 点生成公众号文章'等场景。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "task_id": {
                    "type": "string",
                    "enum": ["koubo_daily", "wechat_daily"],
                    "description": "任务 ID:koubo_daily=每日口播稿生成,wechat_daily=每日公众号文章生成",
                },
                "hour": {
                    "type": "integer",
                    "minimum": 0,
                    "maximum": 23,
                    "description": "执行小时(0-23,24 小时制)",
                },
                "minute": {
                    "type": "integer",
                    "minimum": 0,
                    "maximum": 59,
                    "description": "执行分钟(0-59)",
                },
                "dry_run": {
                    "type": "boolean",
                    "description": "是否 dry-run 模式(默认 true,只生成不发布)",
                },
                "enabled": {
                    "type": "boolean",
                    "description": "是否启用任务(默认 true)",
                },
                "title_template": {
                    "type": "string",
                    "description": "标题模板(仅 wechat_daily 用,支持 {date} 占位符)",
                },
            },
            "required": ["task_id", "hour", "minute"],
        },
    ),
    # ===== 截图工具(2026-07-22 新增,WorkPanel iframe 降级)=====
    MCPTool(
        name="screenshot_url",
        description=(
            "对指定 URL 截图(Playwright headless Chromium),返回 base64 PNG。"
            "适用于:目标站点禁止 iframe 嵌入时,后端截图供前端展示。"
            "注意:本工具返回截图元数据(不含 base64 全文),如需获取 base64 数据请调 HTTP 端点 /api/screenshot/take。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "url": {"type": "string", "description": "目标 URL(http/https)"},
                "width": {"type": "integer", "description": "视口宽度(默认 1280)", "default": 1280},
                "height": {"type": "integer", "description": "视口高度(默认 720)", "default": 720},
                "full_page": {"type": "boolean", "description": "是否全页面截图(默认 false)", "default": False},
                "wait_until": {
                    "type": "string",
                    "enum": ["none", "dom", "load", "networkidle"],
                    "description": "等待策略(默认 load)",
                    "default": "load",
                },
                "timeout": {"type": "integer", "description": "超时 ms(默认 15000)", "default": 15000},
            },
            "required": ["url"],
        },
    ),
    # ===== 图像分析工具(P2-3,对齐 Hermes 多模态输入)=====
    MCPTool(
        name="vision_analyze",
        description=(
            "图像分析(支持本地文件、URL 和 base64)。传入图片 + 分析任务描述,"
            "调用支持视觉的 LLM 模型返回分析结果。"
            "适用于'描述这张图片的内容'/'识别图中的文字'/'分析 UI 截图'等场景。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "image_path": {
                    "type": "string",
                    "description": "本地图片路径(工作区内 png/jpg/jpeg/webp/gif,≤10MB)——分析本地截图首选",
                },
                "image": {
                    "type": "string",
                    "description": "图片 URL(http/https)或 base64 编码(如 data:image/png;base64,...)",
                },
                "image_base64": {
                    "type": "string",
                    "description": "base64 编码图片(可带 data: 前缀)",
                },
                "image_url": {"type": "string", "description": "图片 URL(http/https)"},
                "task": {
                    "type": "string",
                    "description": "分析任务描述(如'描述这张图片的内容')",
                },
                "model": {
                    "type": "string",
                    "description": "期望模型(可选,缺省用支持视觉的模型,如 gpt-4o)",
                },
            },
            "required": ["task"],
        },
    ),
    # ===== 子智能体编排工具(2026-11-16 由 dispatch_subagent 更名为模型面唯一入口)=====
    MCPTool(
        name="orchestrate_agents",
        # 旧名 dispatch_subagent 保留为 handler/alias 兼容(CLI、历史调用、定时任务仍可用),
        # 但不再出现在 _TOOLS 广告面 —— 模型只看到一个编排入口。
        # D145①:静态骨架;名单不在这里写死 —— 两条广告面(list_tools() 与
        # get_full_tool_schema())都用 `_ADVERTISED_DESCRIPTION_PROVIDERS` 现读拼接
        # (唯一出口 `_dispatch_subagent_description`,理由见其定义处注释)。
        description=_DISPATCH_SUBAGENT_DESC_CORE,
        input_schema={
            "type": "object",
            "properties": {
                "name": {
                    "type": "string",
                    "description": "单 agent 模式:要派发的子智能体名称(可用名见工具描述,注册表现读)",
                },
                "task": {
                    "type": "string",
                    "description": "单 agent 模式:交给子智能体执行的任务描述",
                },
                "session_id": {
                    "type": "string",
                    "description": "会话 ID(可选,单 agent 模式用于上下文复用)",
                },
                "tasks": {
                    "type": "array",
                    "description": (
                        "并行模式:任务数组,每项 {name, task, context?}。"
                        "传 tasks 时不可同时传 name/task(互斥,DUAL_MODE)。"
                    ),
                    "items": {
                        "type": "object",
                        "properties": {
                            "name": {"type": "string"},
                            "task": {"type": "string"},
                            "context": {"type": "object"},
                        },
                        "required": ["name", "task"],
                    },
                },
                "max_concurrency": {
                    "type": "integer",
                    "description": "并行模式最大并发数(默认 5)",
                    "default": 5,
                },
                "allowedTools": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": (
                        "可选。非空时是子代理工具硬边界。"
                        "省略或空数组表示不额外收窄。"
                    ),
                },
                "disallowedTools": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": (
                        "可选。并入子代理禁止名单;同一名字同时被允许和禁止时,禁止优先。"
                    ),
                },
                "background": {
                    "type": "boolean",
                    "description": (
                        "true=后台执行并立即返回 job_id(仅单 agent 模式);"
                        "随后用 subagent_job(list/wait/send)收结果与续跑。"
                        "长任务或需要与子代理并行推进时使用。"
                    ),
                },
                "context_mode": {
                    "type": "string",
                    "enum": ["spawn", "fork"],
                    "default": "spawn",
                    "description": (
                        "后台单 agent 的上下文后端。spawn=零父上下文(缺省);"
                        "fork=从已终态父作业播种任务与结果。"
                        "fork 必须同时给 parent_job_id,且父作业必须已成功结束。"
                    ),
                },
                "parent_job_id": {
                    "type": "string",
                    "description": (
                        "fork 的父作业 id;spawn 模式不得传。"
                        "父作业须属于同一 user_id/session_id 且已成功终态。"
                    ),
                },
                # ===== 统一多智能体编排(2026-11-16)=====
                # 同一个工具的唯一 mode 入口:模型按任务性质自主选择,不再新增平级工具。
                "mode": {
                    "type": "string",
                    "enum": list(_DISPATCH_MODES),
                    "description": (
                        "执行模式。省略=按入参推断(有 tasks → parallel,"
                        "有 steps → pipeline,有 name/task → single)。"
                        "编排模式:pipeline(串行流水线)/debate(多轮辩论)/"
                        "vote(方案投票)/critique(提案-批判-改进)/"
                        "decompose(任务自动分解调度)/team(共享黑板协作)/"
                        "recursive(材料递归归纳:chunks 分片并行 → 聚合 → 超预算再切一层)。"
                    ),
                },
                "agents": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": (
                        "debate/vote/critique 需 2-5 个 agent;team 可 1-5 个。"
                        "名字须在工具描述广告的注册表清单内。"
                    ),
                },
                "steps": {
                    "type": "array",
                    "description": "pipeline 模式的串行步骤(1-6 步),前后步骤共享 {prev_output}",
                    "items": {
                        "type": "object",
                        "properties": {
                            "agent": {"type": "string"},
                            "input_template": {
                                "type": "string",
                                "description": (
                                    "可含 {input}/{prev_output}/{step} 占位符,默认 {input}"
                                ),
                            },
                        },
                        "required": ["agent"],
                    },
                },
                "strategy": {
                    "type": "string",
                    "enum": list(_DECOMPOSE_STRATEGIES),
                    "description": "decompose 的分解策略(默认 dag)",
                },
                "aggregation": {
                    "type": "string",
                    "enum": list(_TEAM_AGGREGATIONS),
                    "description": (
                        "team/recursive 的结果聚合策略:merge 合并全文 / best_of 择优 / "
                        "consensus 共识与冲突检测(默认 merge)"
                    ),
                },
                "chunks": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": (
                        "recursive 模式待归纳的材料切片(非空字符串数组,保序)。"
                        "已分片直接用;整段材料可交给单 agent 先切再回填。"
                    ),
                },
                "depth": {
                    "type": "integer",
                    "description": "recursive 最大层数(1-3,默认 1=只做一层 Map-Reduce)",
                },
                "max_chars_per_node": {
                    "type": "integer",
                    "description": (
                        "recursive 单节点正文预算(1024-64000,默认 8192)。"
                        "某层聚合正文超过它才再切一层,否则提前收口。"
                    ),
                },
                "max_rounds": {
                    "type": "integer",
                    "description": "debate/critique 最大轮数(1-3;默认 debate=3、critique=2)",
                },
            },
        },
    ),
    # ===== 可续跑 subagent 作业台(2026-11-14,遵循统一工程规范)=====
    MCPTool(
        name="subagent_job",
        description=(
            "后台子代理作业的查询、续跑与中断:list 列出本会话作业;wait 有限等待到终态;"
            "send 向**已结束**的作业追加消息,以同一任务线(lineage)续跑,"
            "上一轮任务与输出自动作为上下文;cancel 中断运行中的作业。"
            "运行中的作业 send 返回 SUBAGENT_BUSY。"
            "spawn 入口是 orchestrate_agents(background=true)。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["list", "wait", "send", "cancel"],
                    "description": "list 列出 / wait 等待 / send 续跑 / cancel 中断",
                },
                "job_id": {
                    "type": "string",
                    "description": "wait/send/cancel 必填:orchestrate_agents(background=true) 返回的 job_id",
                },
                "wait_s": {
                    "type": "integer",
                    "description": "wait 等待秒数(1-300,默认 30;到期未完成返回 running)",
                    "default": 30,
                },
                "message": {
                    "type": "string",
                    "description": "send 必填:追加给同一任务线的新消息",
                },
                "limit": {
                    "type": "integer",
                    "description": "list 返回上限(1-100,默认 20)",
                    "default": 20,
                },
            },
            "required": ["action"],
        },
    ),
    # ===== D08①(2026-10-25):团队共享任务列表(子 agent 可认领/更新条目)=====
    MCPTool(
        name="team_task",
        description=(
            "团队共享任务列表:同一次协作里的多个子 agent 共用的待办表。"
            "add 建条目(pending,可带 depends_on/write_scopes)→ claim 认领"
            "(独占;前置未完成回 TASK_BLOCKED)→ update 更新状态/备注/依赖"
            "(仅持有者可改;带 expected_revision 做 CAS,过期回 TASK_STALE_REVISION)"
            "→ list 读整表快照(含 ready/blocked_by/write_scope_warnings)。"
            "write_scopes 只是文件触碰提示(与进行中条目路径前缀重叠时告警),不阻断。"
            "与 orchestrate_agents 搭配用:派发是一次性往返,本表补上共同事实源。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["add", "claim", "update", "list"],
                    "description": "操作:add 建条目 / claim 认领 / update 更新 / list 读整表",
                },
                "team_id": {
                    "type": "string",
                    "description": "团队标识(默认 default);不同 team_id 的条目表互相隔离",
                    "default": "default",
                },
                "agent_id": {
                    "type": "string",
                    "description": "子 agent 自身标识;claim/update 必填(认领者身份与写权限判据)",
                },
                "task_id": {
                    "type": "string",
                    "description": "条目 id;claim/update 必填",
                },
                "title": {"type": "string", "description": "add:条目标题(必填)"},
                "detail": {"type": "string", "description": "add:条目详情(可选)"},
                "status": {
                    "type": "string",
                    "enum": ["pending", "claimed", "done", "blocked"],
                    "description": "update:目标状态;非法值整条拒绝",
                },
                "note": {"type": "string", "description": "update:备注(可选,截断 500 字)"},
                "depends_on": {
                    "type": "array",
                    "items": {"type": "string"},
                    "maxItems": 20,
                    "description": (
                        "add/update:前置条目 id 列表;任一前置未 done 时不可 claim"
                        "(回 TASK_BLOCKED),成环整条拒绝(TASK_DEPENDENCY_CYCLE)"
                    ),
                },
                "write_scopes": {
                    "type": "array",
                    "items": {"type": "string"},
                    "maxItems": 20,
                    "description": (
                        "add/update:预计写入的路径前缀;与其它进行中条目的前缀重叠时"
                        "list 返回 write_scope_warnings(仅提示,不阻断)"
                    ),
                },
                "expected_revision": {
                    "type": "integer",
                    "description": "claim/update:CAS 期望版本;与当前 revision 不符回 TASK_STALE_REVISION",
                },
            },
            "required": ["action"],
        },
    ),
    # ===== 跨会话检索(2026-11-14,遵循统一工程规范)=====
    MCPTool(
        name="session_search",
        description=(
            "跨会话全文检索:在**当前用户自己的**历史会话里找相关旧工作,返回会话标题"
            "与最佳匹配摘录(只读)。始终省略调用方会话;可显式 thread_id 限定单个"
            "会话。无宿主身份时拒绝。用于开工前先查'这件事以前做过没有'。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "字面检索词(非空;FTS 可用时按全文匹配,否则 LIKE)",
                },
                "thread_id": {
                    "type": "string",
                    "description": "限定单个会话;省略则检索该用户全部历史会话",
                },
                "limit": {
                    "type": "integer",
                    "description": "命中上限(1-50,默认 10)",
                    "default": 10,
                },
            },
            "required": ["query"],
        },
    ),
    # ===== 扩展工具(2026-07-24 新增,自研)=====
    MCPTool(
        name="fetch_url",
        description=(
            "抓取 URL 内容,返回 markdown/text/html/metadata。"
            "用于获取网页正文、提取页面元数据(title/description/og 标签)。"
            "SSRF 防护:禁止内网/保留/回环地址。admin 专属工具。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "url": {"type": "string", "description": "目标 URL(http/https,必填)"},
                "mode": {
                    "type": "string",
                    "enum": ["text", "html", "metadata"],
                    "description": "返回模式:text(默认,纯文本/markdown)/html(原始 HTML)/metadata(仅 title/description/og)",
                    "default": "text",
                },
                "max_chars": {
                    "type": "integer",
                    "description": "最大返回字符数(默认 8000,避免上下文爆炸)",
                    "default": 8000,
                },
            },
            "required": ["url"],
        },
    ),
    MCPTool(
        name="image_generation",
        description=(
            "生成图片,返回图片 URL 或 base64 data URI。多 provider 统一编排 + 运行时自动故障转移:"
            "agnes → kling(可灵 Kolors)→ "
            "jimeng(即梦),按 IMAGE_PROVIDER env 或已配置凭据自动排序,首选失败(401/402/429/5xx/超时)"
            "自动换下一家,返回带 failover_attempts 明细。"
            "2026-07-24 升级:支持 save_path 落地文件系统(b64_json 解码或 URL 下载),"
            "校验后缀(.png/.jpg/.jpeg/.webp)+ 工作区白名单,5MB 上限。"
            "所有用户可用(与 video/music/tts 媒体工具一致)。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "prompt": {"type": "string", "description": "图片描述(必填)"},
                "size": {
                    "type": "string",
                    "description": "图片尺寸(默认 1024x1024;token6688 gpt-image-2.5 系列"
                                   "不支持该参数,官方用 aspect_ratio)",
                    "default": "1024x1024",
                },
                "provider": {
                    "type": "string",
                    "enum": ["token6688", "agnes", "kling", "jimeng"],
                    "default": "token6688",
                },
                "model": {
                    "type": "string",
                    "description": "可选,模型(如 kling-kolors / jimeng-high_aes_general_v21);kling/jimeng provider 用",
                },
                "negative_prompt": {
                    "type": "string",
                    "description": "可选,反向提示词(kling/jimeng provider 用)",
                },
                "save_path": {
                    "type": "string",
                    "description": "可选,绝对路径,落地图片到文件系统(需工作区白名单内,后缀 .png/.jpg/.jpeg/.webp,5MB 上限)",
                },
            },
            "required": ["prompt"],
        },
    ),
    MCPTool(
        name="image_edit",
        description=(
            "图片编辑/局部重绘/扩图(改现有图,2026-09-09 全模态深度适配新增)。"
            "图片编辑能力已随 token6688 平台永久下线:"
            "把待编辑图 image 按 prompt 指令修改(改元素/去水印/局部重绘/扩图等),"
            "可选 mask 遮罩(透明区域=重绘区)。image 支持 URL / data URI / 裸 base64 / "
            "本地工作区路径;编辑结果返回 image_url 或 base64,支持 save_path 落地"
            "(.png/.jpg/.jpeg/.webp,工作区白名单,5MB 上限)。"
            "与 image_generation 不同:这是改已有图,不是从零生成。"
            "token6688 平台已永久下线。"
            "外部 API 调用 + 计费。所有用户可用。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "image": {"type": "string", "description": "待编辑图(URL/data URI/裸 base64/本地路径,必填,≤25MiB)"},
                "prompt": {"type": "string", "description": "编辑指令(改什么,必填)"},
                "mask": {"type": "string", "description": "可选遮罩(透明区域=重绘区,URL/data URI)"},
                "model": {"type": "string", "description": "可选,图片模型(默认 gpt-image-2)"},
                "n": {"type": "integer", "description": "生成数量(官方 1~50,默认 1)", "default": 1},
                "size": {"type": "string", "description": "可选,像素串(与 aspect_ratio 二选一,兼容老 API)"},
                "aspect_ratio": {"type": "string", "description": "可选,比例(官方 12 枚举,如 16:9/1:1/9:16)"},
                "quality": {"type": "string", "enum": ["auto", "high", "medium", "low"], "description": "可选,质量"},
                "output_format": {"type": "string", "enum": ["png", "jpeg"], "description": "可选,输出格式"},
                "save_path": {
                    "type": "string",
                    "description": "可选,绝对路径,落地编辑结果(需工作区白名单内,后缀 .png/.jpg/.jpeg/.webp,5MB 上限)",
                },
            },
            "required": ["image", "prompt"],
        },
    ),
    MCPTool(
        name="video_generation",
        description=(
            "生成视频,返回视频 URL。统一编排多家厂商并自动故障转移:"
            "agnes(免费档 agnes-video-2.5-flash,默认首选,支持文生视频/图生视频)、"
            "kling(快手可灵,text2video/image2video)、jimeng(字节即梦 Seedance)、"
            "wan(阿里通义万相)、hunyuan(腾讯混元)。长任务防卡死:先提交并限时等待"
            "(agnes 在 VIDEO_TOOL_WAIT_S 窗口内完成直接返回成片);"
            "超时返回 task_id 与取件提示——用户稍后追问时只传 task_id(不传 prompt)即可查询进度/取件。"
            "支持 image 参数走图生视频、save_path 下载落地(.mp4,工作区白名单,200MB 上限)。"
            "agnes 凭据在 LLM_PROVIDERS.agnes,其余需 KLING_*/ARK_*/"
            "DASHSCOPE_API_KEY/TENCENT_* 任一厂商凭据;未配置时返回 PROVIDER_NOT_CONFIGURED,"
            "如实告知用户。外部 API 调用 + 计费。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "prompt": {"type": "string", "description": "视频描述(首次提交必填;查询模式可省)"},
                "provider": {
                    "type": "string",
                    "enum": ["agnes", "token6688", "kling", "jimeng", "wan", "hunyuan"],
                    "description": "可选,指定厂商;缺省自动按已配置凭据顺序选择"
                },
                "model": {
                    "type": "string",
                    "description": "可选,模型(如 seedance-2-5 / kling-v1 / doubao-seedance-1-0-pro / wan2.x)",
                },
                "task_id": {
                    "type": "string",
                    "description": "可选,查询模式:传入此前提交返回的 task_id 查询进度/取件成片,无需 prompt",
                },
                "duration": {
                    "type": "integer",
                    "description": "视频时长秒(token6688 支持 4~30;其他厂商上限通常 10~15s;默认 5)",
                    "default": 5,
                },
                "image": {
                    "type": "string",
                    "description": "可选,图生视频首帧图片(URL 或 base64;本地文件请先给 URL,多模态输入只收公网直链)",
                },
                "mode": {
                    "type": "string",
                    "enum": ["text-to-video", "first-frame", "reference", "first-last", "edit", "extend"],
                    "description": "可选,生成模式(token6688 枚举值,默认按有无 image 自动:text-to-video/first-frame);"
                    "reference=参考生成,first-last=首尾帧,edit=视频编辑,extend=续写。发枚举值,勿发界面显示名",
                },
                "resolution": {
                    "type": "string",
                    "enum": ["480p", "720p", "1080p"],
                    "description": "可选,清晰度(token6688,默认随模型)",
                },
                "aspect_ratio": {
                    "type": "string",
                    "enum": ["16:9", "9:16", "1:1", "4:3", "3:4", "21:9"],
                    "description": "可选,画面比例(token6688)",
                },
                "negative_prompt": {
                    "type": "string",
                    "description": "可选,反向提示词",
                },
                "save_path": {
                    "type": "string",
                    "description": "可选,绝对路径,下载视频落地(需工作区白名单内,后缀 .mp4,200MB 上限)",
                },
            },
            "required": [],
        },
    ),
    MCPTool(
        name="music_generation",
        description=(
            "生成音乐/歌曲(token6688 平台已永久下线，本工具不再提供服务)。"
            "支持 mode=song(带人声歌曲)/instrumental(纯音乐配乐),可选歌词 lyrics、"
            "曲风 style(如 EDM/民谣/古风/流行)、标题 title、人声 gender(vocal_gender)。"
            "长任务防卡死:提交后限时等待(默认 150s),窗口内完成直接返回成曲;"
            "超时返回 submitted+task_id——用户稍后追问时只传 task_id(不传 prompt)即可取件。"
            "支持 save_path 下载落地(.mp3/.wav/.ogg/.flac,工作区白名单,50MB 上限)。"
            "token6688 平台已永久下线。"
            "外部 API 调用 + 计费。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "prompt": {"type": "string", "description": "音乐/歌曲描述(首次提交必填;查询模式可省)"},
                "task_id": {
                    "type": "string",
                    "description": "可选,查询模式:传入此前提交返回的 task_id 查询进度/取件成曲,无需 prompt",
                },
                "mode": {
                    "type": "string",
                    "enum": ["song", "instrumental"],
                    "description": "song=带人声歌曲(默认);instrumental=纯音乐/配乐",
                    "default": "song",
                },
                "lyrics": {
                    "type": "string",
                    "description": "可选,自定义歌词(mode=song 时);不传则由模型根据 prompt 创作",
                },
                "style": {
                    "type": "string",
                    "description": "可选,曲风(如 EDM/民谣/古风/流行/摇滚/爵士)",
                },
                "title": {
                    "type": "string",
                    "description": "可选,歌曲标题",
                },
                "vocal_gender": {
                    "type": "string",
                    "enum": ["auto", "m", "f"],
                    "description": "可选,人声性别(mode=song 时;auto=自动/m=男声/f=女声,官方枚举值)",
                    "default": "auto",
                },
                "operation": {
                    "type": "string",
                    "enum": ["generate", "extend", "cover", "lyrics", "stems", "stems_all"],
                    "description": "可选,操作类型:generate=生成(默认)/extend=续写(需 continue_at)/"
                    "cover=翻唱/lyrics=仅写词/stems=分轨",
                    "default": "generate",
                },
                "negative_tags": {
                    "type": "string",
                    "description": "可选,排除的风格标签(不想要的元素)",
                },
                "version": {
                    "type": "string",
                    "enum": ["chirp-v5-5", "chirp-v5", "chirp-v4-5+", "chirp-v4-5", "chirp-v4", "chirp-v3-5"],
                    "description": "可选,Suno 模型版本(不传落平台默认)",
                },
                "model": {
                    "type": "string",
                    "description": "可选,模型(默认 music)",
                    "default": "music",
                },
                "save_path": {
                    "type": "string",
                    "description": "可选,绝对路径,下载成曲落地(需工作区白名单内,后缀 .mp3/.wav/.ogg/.flac,50MB 上限)",
                },
            },
            "required": [],
        },
    ),
    MCPTool(
        name="voice_tts",
        description=(
            "文本转语音/朗读/配音(对话内直接出音频,前端内嵌播放器可播)。"
            "engine=edge(默认,微软 edge-tts,零 key 零成本,中文推荐 zh-CN-XiaoxiaoNeural)。"
            "同步接口无任务轮询;text≤2000 字符走同步直出。"
            "text 上限 2000 字符;长文本异步 TTS 已随 token6688 平台永久下线。"
            "支持 save_path 落地(.mp3/.wav/.ogg/.flac,工作区白名单,50MB 上限)。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "text": {
                    "type": "string",
                    "description": "要合成的文本(≤2000 字符同步直出;2000<text≤5000 自动走 token6688 异步 TTS)",
                },
                "task_id": {
                    "type": "string",
                    "description": "可选,异步 TTS 任务 ID:只传 task_id 时查询任务状态并取件"
                    "(completed 返回公网 audio_url;处理中返回 submitted=true)",
                },
                "engine": {
                    "type": "string",
                    "enum": ["edge", "token6688"],
                    "description": "edge=零成本默认;token6688=聚合网关(单 key,支持声纹克隆与超长异步 TTS)",
                    "default": "edge",
                },
                "voice": {
                    "type": "string",
                    "description": "音色:edge 引擎用 zh-CN-XiaoxiaoNeural 等 edge 白名单;"
                    "token6688 引擎用 alloy/echo/fable/onyx/nova/shimmer 或声纹库 voice_id",
                },
                "speed": {
                    "type": "number",
                    "description": "可选,语速倍率(token6688 引擎,0.25~4.0,默认 1.0)",
                    "default": 1.0,
                },
                "response_format": {
                    "type": "string",
                    "enum": ["mp3", "opus", "aac", "flac", "wav", "pcm"],
                    "description": "可选,音频格式(token6688 引擎,默认 mp3)",
                    "default": "mp3",
                },
                "save_path": {
                    "type": "string",
                    "description": "可选,绝对路径,音频落地(需工作区白名单内,后缀 .mp3/.wav/.ogg/.flac,50MB 上限)",
                },
            },
            "required": [],
        },
    ),
    MCPTool(
        name="audio_transcription",
        description=(
            "语音转文字(对话内 ASR,2026-09-09 落地)。传入音频"
            "(URL / base64 data URI / 本地路径,≤25MB)+ 可选语言提示,"
            "引擎链自动切换:faster-whisper 本地推理(零 key 零成本,默认首选)"
            "；本地推理失败时直接返回错误。"
            "用户说'把这段录音转文字/听听这个音频说了什么/识别这段语音'时使用。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "audio": {
                    "type": "string",
                    "description": "音频来源:http(s) URL、base64 data URI(data:audio/...;base64,..)"
                    "或本地文件路径(如 voice_tts save_path 落地的 .mp3)",
                },
                "language": {
                    "type": "string",
                    "description": "可选,语言提示(ISO 639-1,如 zh/en/ja;缺省自动检测)",
                },
                "filename": {
                    "type": "string",
                    "description": "可选,文件名(用于推断格式后缀,默认 audio.wav)",
                },
            },
            "required": ["audio"],
        },
    ),
    MCPTool(
        name="review_pr",
        description=(
            "审查 GitHub PR,返回结构化审查报告。"
            "用正则模式匹配(security/performance/readability),零 LLM 调用。"
            "2026-07-24 升级:支持 diff 字符串参数(与 repo+pr_number 互斥);"
            "repo+pr_number 时调 GitHub API(Accept: application/vnd.github.v3.diff)获取真实 diff,"
            "Bearer 鉴权(GITHUB_TOKEN 可空),进程内 cache 1h。"
            "admin 专属工具(可能暴露源代码)。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "repo": {"type": "string", "description": "owner/repo 格式(与 diff 二选一,优先 repo+pr_number)"},
                "pr_number": {"type": "integer", "description": "PR 编号(正整数,与 diff 二选一)"},
                "diff": {
                    "type": "string",
                    "description": "可选,直接传入 unified diff 字符串(无 GitHub API 调用,source=diff_string)",
                },
                "focus": {
                    "type": "string",
                    "enum": ["security", "performance", "readability", "all"],
                    "default": "all",
                },
                "max_files": {
                    "type": "integer",
                    "description": "最多审查的文件数(默认 20)",
                    "default": 20,
                },
            },
            "required": [],
        },
    ),
    MCPTool(
        name="summarize_artifacts",
        description=(
            "聚合当前会话的 plans/sources/artifacts/tool_calls。"
            "纯本地缓存读取(进程内,重启即丢),不调外部 API。所有用户可用。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "conversation_id": {"type": "string", "description": "会话 ID(可选)"},
                "include": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "包含的类别(默认全部)",
                    "default": ["plans", "sources", "artifacts", "tool_calls"],
                },
                "max_items": {
                    "type": "integer",
                    "description": "每类最大返回数(默认 20)",
                    "default": 20,
                },
            },
        },
    ),
    MCPTool(
        name="present_files",
        description=(
            "把已经存在的文件显式声明为本次答复的交付物。"
            "用于补自动变更清单漏掉的产物:由 run_command 构建/导出的文件、"
            "office_document 转换出的 docx/pdf、脚本生成的图表等。"
            "只登记路径与可选说明,不读取、不改写、不校验文件是否存在;"
            "一次最多 8 个,前端交付清单按路径渲染。所有用户可用。"
            "定稿后调用:本工具在轮次结束后才会在交付清单里展示;"
            "不要只为罗列刚编辑过的源码文件调用它。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "files": {
                    "type": "array",
                    "minItems": 1,
                    "maxItems": 8,
                    "items": {
                        "type": "object",
                        "properties": {
                            "path": {
                                "type": "string",
                                "description": "文件路径(工作区相对路径或绝对路径)",
                            },
                            "description": {
                                "type": "string",
                                "description": "一句话说明这个文件是什么(可选,最多 200 字)",
                            },
                        },
                        "required": ["path"],
                    },
                    "description": "要声明为交付物的文件列表(最多 8 个)",
                },
            },
            "required": ["files"],
        },
    ),
    MCPTool(
        name="schedule_task",
        description=(
            "调度定时任务(once/recurring)。"
            "仅记录到进程内任务列表,需 ai-service 后台 worker 启动才会自动执行。"
            "admin 专属工具。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "任务名(必填)"},
                "prompt": {"type": "string", "description": "任务提示词(必填)"},
                "schedule": {
                    "type": "string",
                    "enum": ["once", "recurring"],
                    "default": "once",
                },
                "run_at": {"type": "string", "description": "ISO 时间戳(schedule=once 时必填)"},
                "cron": {"type": "string", "description": "cron 表达式(schedule=recurring 时必填)"},
                "agent_tools": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "任务可用工具列表",
                    "default": ["search_codebase", "read_file", "web_search"],
                },
            },
            "required": ["name", "prompt"],
        },
    ),
    MCPTool(
        name="list_scheduled_tasks",
        description=(
            "列出已调度的定时任务(schedule_task 创建的任务)。"
            "数据源 = task_scheduler(Redis 持久化,Redis 不可用降级内存,未配置 redis_url 时 stub 返回空)。"
            "conversation_id 可选,按任务记录里的该字段精确过滤。"
            "admin 专属工具:任务记录无归属字段,与 schedule_task 同档。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "conversation_id": {
                    "type": "string",
                    "description": "会话 ID(可选,传了才过滤)",
                },
            },
        },
    ),
    MCPTool(
        name="cancel_scheduled_task",
        description=(
            "按 task_id 取消定时任务(APScheduler job 与持久化记录一并删除),回执被取消任务的摘要。"
            "task_id 不存在时返回 NOT_FOUND,不静默成功。"
            "admin 专属工具:remove_task 无归属校验,与 schedule_task 同档。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "task_id": {"type": "string", "description": "任务 ID(必填,list_scheduled_tasks 可查)"},
            },
            "required": ["task_id"],
        },
    ),
    MCPTool(
        name="schedule_wakeup",
        description=(
            "延迟唤醒:delay_seconds 秒后把 prompt 再跑一次(对齐统一规范)。"
            "落地为 task_scheduler 的 date 触发,回调与 schedule_task 同一个派发形态。"
            "admin 专属工具:底层 add_task 无归属校验,与 schedule_task 同档。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "delay_seconds": {
                    "type": "integer",
                    "minimum": 1,
                    "description": "延迟秒数(必填,正整数)",
                },
                "prompt": {"type": "string", "description": "到点后执行的提示词(必填)"},
                "name": {"type": "string", "description": "任务名(可选,缺省 wakeup-<task_id>)"},
            },
            "required": ["delay_seconds", "prompt"],
        },
    ),
    MCPTool(
        name="proactive_suggestion",
        description=(
            "基于当前会话上下文,主动建议后续工作(follow_up/refactor/test/improve/explore)。"
            "纯本地规则匹配(零算力,不调 LLM)。所有用户可用。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "conversation_context": {"type": "string", "description": "当前对话最近消息摘要(可选)"},
                "recent_files": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "最近修改的文件列表(可选)",
                },
                "recent_tool_calls": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "最近工具调用列表(可选)",
                },
            },
        },
    ),
    MCPTool(
        name="generate_chart",
        description=(
            "生成数据图表(输出 ECharts 单文件 HTML,支持 line/bar/pie/scatter 四类,中文标题)。"
            "用于数据分析/报表/趋势可视化。data 参数为 JSON 字符串,按类型传结构。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "chart_type": {"type": "string", "description": "图表类型:line/bar/pie/scatter"},
                "title": {"type": "string", "description": "图表标题"},
                "data": {
                    "type": "string",
                    "description": "JSON 字符串。line/bar:{\"x\":[...],\"series\":[{\"name\":\"..\",\"values\":[...]}]};pie:[{\"name\":\"..\",\"value\":n}];scatter:{\"points\":[[x,y],...]} 或 {\"series\":[{\"name\":\"s1\",\"points\":[[x,y],...]}]}",
                },
                "output_dir": {"type": "string", "description": "输出目录(相对项目根,默认 tmp/charts)", "default": "tmp/charts"},
            },
            "required": ["chart_type", "title", "data"],
            "additionalProperties": False,
        },
    ),
    MCPTool(
        name="generate_report",
        description=(
            "生成报表/汇报文档(输出独立 HTML 产物文件,含标题/摘要/分节条目)。"
            "用于周报月报、数据汇报、调研结论等结构化文档产物。"
            "sections 参数为 JSON 字符串:[{\"heading\":\"节标题\",\"items\":[\"条目\",...]}]。"
            "产物落盘 tmp/artifacts 并可经既有产物签名链路在会话中预览。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "title": {"type": "string", "description": "报表标题(必填,如'2026-W39 运营周报')"},
                "sections": {
                    "type": "string",
                    "description": (
                        'JSON 字符串(必填):[{"heading":"本周进展","items":["条目1","条目2"]},'
                        '{"heading":"下周计划","items":["..."]}],1-30 节,每节 1-50 条'
                    ),
                },
                "period": {"type": "string", "description": "统计周期/日期范围(可选,如 2026-W39)"},
                "summary": {"type": "string", "description": "顶部摘要段(可选,≤4000 字)"},
                "output_dir": {"type": "string", "description": "输出目录(相对项目根,默认 tmp/artifacts)", "default": "tmp/artifacts"},
            },
            "required": ["title", "sections"],
            "additionalProperties": False,
        },
    ),
    MCPTool(
        # G3 Beyond-Coding 泛化:对话可产出五类交付物(html_report/slides/sheet/doc/video_ref)。
        # 路由身份(__user_id/__session_id)由 call_tool 宿主注入覆盖,LLM 不可控(同
        # request_business_form 的纪律);message_id 是**源转录锚点**(产物挂在哪条消息),
        # 必填但非路由身份,由调用侧/模型给出。
        name="create_artifact",
        description=(
            "创建或更新一个交付物 Artifact(带版本与源转录锚点,可导出)。kind 五选一:"
            "html_report(content=自包含 HTML 字符串)、doc(content=Markdown 正文)、"
            "slides(content=JSON 字符串 {\"slides\":[{\"title\":\"..\",\"bullets\":[\"..\"],\"notes\":\"..\"}]})、"
            "sheet(content=JSON 字符串 {\"columns\":[\"列名\"],\"rows\":[[单元格,..]]})、"
            "video_ref(content=JSON 字符串 {\"url\":\"..\",\"provider\":\"..\"})。"
            "message_id 必填(锚定到产生本产物的 assistant 消息)。传 artifact_id 即更新:"
            "version+1 且旧版 payload 保留。产物落 tmp/artifacts 并登记为会话附件,"
            "可经 /api/artifacts/:id/download?fmt=html|md|csv 导出。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "kind": {
                    "type": "string",
                    "enum": ["html_report", "slides", "sheet", "doc", "video_ref"],
                    "description": "交付物种类",
                },
                "title": {"type": "string", "description": "产物标题(非空)"},
                "content": {
                    "type": "string",
                    "description": "payload 正文:html_report/doc 为文本原样,slides/sheet/video_ref 为对应 JSON 字符串",
                },
                "message_id": {"type": "string", "description": "源转录锚点:所属消息 id(必填)"},
                "anchor_index": {"type": "integer", "minimum": 0, "description": "锚点序号(可选,同消息多产物时区分)"},
                "status": {"type": "string", "enum": ["draft", "final"], "description": "草稿/定稿,默认 draft"},
                "artifact_id": {"type": "string", "description": "更新既有产物时传入其 id(version+1,旧版保留)"},
            },
            "required": ["kind", "title", "content", "message_id"],
            "additionalProperties": False,
        },
    ),
    MCPTool(
        # G2 Automations 产品闭环(2026-10-30 立):对话式创建定时自动化。
        # 实现经 internal 凭证腿调 apps/api POST /api/automations(排期/互斥/归属判据
        # 只住 api 路由一处);rrule 白名单比 api 更严(未知段/语义错配段直接拒)。
        # 路由身份 __user_id/__session_id 由宿主注入覆盖,LLM 不可控(create_artifact 同款纪律)。
        name="create_automation",
        description=(
            "创建用户定时自动化(到点自动执行一段提示词)。schedule_type=once 必须带 "
            "scheduled_at(ISO 8601 含时区偏移,如 2026-11-01T09:00:00+08:00);recurring "
            "必须带 rrule(MVP 子集:FREQ=HOURLY|DAILY|WEEKLY,可选 BYHOUR=0-23、"
            "BYMINUTE=0-59、BYDAY=MO,TU,..;WEEKLY 必带 BYDAY,HOURLY 不接受任何 BY* 段)。"
            "timezone 为 IANA 时区名(默认 Asia/Shanghai)。可选 goal={target, max_runs}"
            "启用 Goal 自评迭代:每次执行成功后模型对照 target 自评,未达标且预算与余额"
            "允许时自动重跑(max_runs 默认 3、上限 10)。执行结果终态会推送站内通知。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "自动化名称(非空,≤200 字)"},
                "prompt": {"type": "string", "description": "每次到点执行的提示词(非空,≤8000 字)"},
                "schedule_type": {
                    "type": "string",
                    "enum": ["once", "recurring"],
                    "description": "once=一次性(配 scheduled_at);recurring=周期重复(配 rrule)",
                },
                "scheduled_at": {
                    "type": "string",
                    "description": "once 的执行时刻:ISO 8601 且必须带时区偏移(与 rrule 互斥)",
                },
                "rrule": {
                    "type": "string",
                    "description": "recurring 的重复规则(MVP 子集,与 scheduled_at 互斥),如 FREQ=DAILY;BYHOUR=9;BYMINUTE=30",
                },
                "timezone": {
                    "type": "string",
                    "description": "墙钟解释用的 IANA 时区(可选,默认 Asia/Shanghai)",
                },
                "goal": {
                    "type": "object",
                    "description": "可选 Goal 自评迭代配置(未达标自动重跑,预算/余额受限)",
                    "properties": {
                        "target": {"type": "string", "description": "目标描述(非空,≤2000 字,自评的对照基准)"},
                        "max_runs": {
                            "type": "integer",
                            "minimum": 1,
                            "maximum": 10,
                            "description": "最多执行次数(含首跑),默认 3",
                        },
                    },
                    "required": ["target"],
                    "additionalProperties": False,
                },
            },
            "required": ["name", "prompt", "schedule_type"],
            "additionalProperties": False,
        },
    ),
    MCPTool(
        # 财务部·AI 一键代账(RP-46):入参口径与纪律的描述单源 = finance_tools.AI_BOOKKEEPING_DESCRIPTION
        name="ai_bookkeeping",
        description=AI_BOOKKEEPING_DESCRIPTION,
        input_schema={
            "type": "object",
            "properties": {
                "phase": {
                    "type": "string",
                    "enum": ["classify", "voucher", "trial_balance", "close", "report", "automation", "all"],
                    "description": "执行阶段(默认 all 串联);单阶段调用逐次回传 state ⇒ 对话里逐步显示进度;automation 产内置浏览器/客户端步骤计划",
                },
                "period": {"type": "string", "description": "会计期间,如 2026-11(新任务必填)"},
                "targets": {
                    "type": "string",
                    "description": "automation 目标集 JSON 数组(etax_invoice_ledger/bank_statement/social_insurance/medical_insurance/etax_vat_declaration/etax_cit_quarterly/etax_iit_declaration;缺省用代账默认集)",
                },
                "portal": {
                    "type": "string",
                    "description": "各平台入口地址 JSON(etax_portal/bank_portal/social_portal/medical_portal/province 均可)",
                },
                "submit_mode": {
                    "type": "string",
                    "enum": ["manual_gate", "user_confirmed"],
                    "description": "提交闸档位,缺省 manual_gate=停在提交前一步由人点击;user_confirmed 须复述获明示确认后执行;不存在 auto",
                },
                "transactions": {
                    "type": "string",
                    "description": (
                        "业务流水 JSON:每笔 {date,type,amount,method,tax_rate,invoice,counterparty,summary[,social,income_tax]}. "
                        "type 常用:sales/purchase/cost/salary/rent/expense/tax_payment/receipt/payment;金额一律字符串防精度漂移"
                    ),
                },
                "state": {"type": "string", "description": "上一阶段返回的 state JSON(续跑用)"},
                "output_dir": {
                    "type": "string",
                    "description": "报表输出目录(默认 tmp/artifacts,必须位于项目根)",
                },
            },
            "additionalProperties": False,
        },
    ),
    MCPTool(
        # 财务部·AI 一键报税(RP-46):草案纪律见描述与输出双处声明,不代理对外申报
        name="ai_tax_filing",
        description=AI_TAX_FILING_DESCRIPTION,
        input_schema={
            "type": "object",
            "properties": {
                "phase": {
                    "type": "string",
                    "enum": ["compute", "validate", "draft", "automation", "all"],
                    "description": "执行阶段(默认 all 串联);automation 产电子税务局/社保医保平台步骤计划草案数字自动映射",
                },
                "period": {"type": "string", "description": "申报期间,如 2026-11(必填;新任务必带,续跑可由 state 提供)"},
                "targets": {
                    "type": "string",
                    "description": "automation 目标集 JSON 数组(etax_vat_declaration/etax_cit_quarterly/etax_iit_declaration/social_insurance/medical_insurance/etax_invoice_ledger;缺省用报税默认集)",
                },
                "portal": {
                    "type": "string",
                    "description": "各平台入口 JSON(etax_portal/bank_portal/social_portal/medical_portal;province 简写自动展开电子税务局域名)",
                },
                "submit_mode": {
                    "type": "string",
                    "enum": ["manual_gate", "user_confirmed"],
                    "description": "提交闸档位,缺省 manual_gate=停在提交前一步由人点击;user_confirmed 须明示确认;不存在 auto 静默申报",
                },
                "taxpayer_type": {
                    "type": "string",
                    "enum": ["general", "small"],
                    "description": "纳税人类型,默认 general",
                },
                "taxpayer_state_note": {"type": "string", "description": "纳税人背景备注(可选,仅入档)"},
                "sales": {"type": "string", "description": "本期销售额(含税,字符串金额)"},
                "output_tax": {"type": "string", "description": "销项税额(一般纳税人)"},
                "input_tax": {"type": "string", "description": "本期认证进项税额"},
                "input_carryforward": {"type": "string", "description": "上期留抵税额"},
                "vat_scheme": {"type": "string", "description": "小规模征收率:0.01 或 0.03"},
                "profit": {"type": "string", "description": "会计利润总额(所得税预缴基数之一)"},
                "taxable_income": {"type": "string", "description": "应纳税所得额(缺省取 profit)"},
                "loss_carryforward": {"type": "string", "description": "可弥补以前年度亏损"},
                "purchases": {"type": "string", "description": "采购额(印花税基数缺省=销售+采购)"},
                "stamp_base": {"type": "string", "description": "印花税计税依据(合同金额)"},
                "stamp_rate": {"type": "string", "description": "印花税税率,缺省 0.0003"},
                "cit_rate": {"type": "string", "description": "企业所得税率,一般企业用;小微走 small_micro_cit"},
                "small_micro_cit": {"type": "boolean", "description": "小型微利企业实际税负 5%(默认按纳税人类型推)"},
                "six_tax_half": {"type": "boolean", "description": "六税两费减半(小规模默认 True)"},
                "city_rate": {"type": "string", "description": "城建税率覆盖(默认 7%)"},
                "small_exemption_threshold": {
                    "type": "string",
                    "description": "小规模免征起征点(按月,万元销售额换算后字符串),默认 100000",
                },
                "wages": {
                    "type": "string",
                    "description": "工资表 JSON:[{name,gross,social,special_deduction}] 个税累计预扣法",
                },
                "state": {"type": "string", "description": "上一阶段返回的 state JSON(续跑用)"},
                "output_dir": {"type": "string", "description": "草案输出目录(默认 tmp/artifacts)"},
            },
            "additionalProperties": False,
        },
    ),
    MCPTool(
        # 人事部→财务部·AI 交割(2026-11-13 立):生成某月薪资的财务交割凭证
        # 纯产出凭证不入账;权限 hr:payroll:manage 由 api RBAC 逐请求现问
        name="ai_payroll_handoff",
        description=PAYROLL_HANDOFF_DESCRIPTION,
        input_schema={
            "type": "object",
            "properties": {
                "periodMonth": {
                    "type": "string",
                    "description": "薪资期间,格式 YYYY-MM(必填,如 2026-10);须该月薪资周期已财务审批通过(approved)",
                },
            },
            "required": ["periodMonth"],
            "additionalProperties": False,
        },
    ),
    MCPTool(
        # 人事部自助(2026-11-21 实装):只查本人,入参里没有任何"指定他人"的字段。
        # 身份由 call_tool 注入 __user_id,后端 /mine* 端点票面主体恒为本人。
        name="hr_my_payroll",
        description=HR_MY_PAYROLL_DESCRIPTION,
        input_schema={
            "type": "object",
            "properties": {
                "periodMonth": {
                    "type": "string",
                    "description": "工资月,格式 YYYY-MM(必填,如 2026-10)",
                },
            },
            "required": ["periodMonth"],
            "additionalProperties": False,
        },
    ),
    MCPTool(
        name="hr_my_payroll_periods",
        description=HR_MY_PAYROLL_PERIODS_DESCRIPTION,
        input_schema={
            "type": "object",
            "properties": {},
            "additionalProperties": False,
        },
    ),
    MCPTool(
        name="hr_my_attendance",
        description=HR_MY_ATTENDANCE_DESCRIPTION,
        input_schema={
            "type": "object",
            "properties": {
                "periodMonth": {
                    "type": "string",
                    "description": "月份 YYYY-MM(传则返回该月月结汇总;不传返回最近考勤明细)",
                },
                "startDate": {
                    "type": "string",
                    "description": "明细起始日 YYYY-MM-DD(仅不传 periodMonth 时生效)",
                },
                "endDate": {
                    "type": "string",
                    "description": "明细截止日 YYYY-MM-DD(仅不传 periodMonth 时生效)",
                },
            },
            "additionalProperties": False,
        },
    ),
    MCPTool(
        name="hr_my_leaves",
        description=HR_MY_LEAVES_DESCRIPTION,
        input_schema={
            "type": "object",
            "properties": {
                "status": {
                    "type": "string",
                    "description": "请假状态过滤(可选,如 pending/approved/rejected)",
                },
            },
            "additionalProperties": False,
        },
    ),
    MCPTool(
        # 管理侧算薪(2026-11-21):写工资单但不改审批状态、不发放;
        # 权限由 apps/api requirePermission('hr:payroll:manage') 逐请求现问。
        name="hr_payroll_calc",
        description=HR_PAYROLL_CALC_DESCRIPTION,
        input_schema={
            "type": "object",
            "properties": {
                "periodMonth": {
                    "type": "string",
                    "description": "薪资月,格式 YYYY-MM(必填,该月考勤须已月结)",
                },
                "regionName": {
                    "type": "string",
                    "description": "参保地区名(对应社保费率配置;不传取该年首条启用配置)",
                },
                "overwriteApproved": {
                    "type": "boolean",
                    "description": "是否覆盖已审批周期(默认 false,财务审过的账不许改)",
                },
            },
            "required": ["periodMonth"],
            "additionalProperties": False,
        },
    ),
    MCPTool(
        # 社保配置体检(2026-11-21):算薪前先查"当年+参保地"配置齐不齐。
        # 算薪在配置缺失/不完整时会直接 400 拒绝,这枚工具让 AI 能提前把原因讲清。
        name="hr_insurance_readiness",
        description=HR_INSURANCE_READINESS_DESCRIPTION,
        input_schema={
            "type": "object",
            "properties": {
                "effectiveYear": {
                    "type": "integer",
                    "description": "费率配置所属年份(4 位,可选;默认取当年)",
                },
                "regionName": {
                    "type": "string",
                    "description": "参保地名(可选;同一年存在多个参保地时算薪必须指定)",
                },
            },
            "additionalProperties": False,
        },
    ),
    MCPTool(
        # 动作型财务账套工具(2026-11-23 立):把"算出来的账"真正写进正式账套
        name="finance_ledger_ops",
        description=FINANCE_LEDGER_DESCRIPTION,
        input_schema={
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "description": "动作名(取值见工具描述里的清单,如 client.create / voucher.post / period.close)",
                },
                "payload": {
                    "type": "object",
                    "description": "该动作的参数对象;路径参数(id/code)放同名键,其余键自动进 query 或 body",
                    "additionalProperties": True,
                },
            },
            "required": ["action"],
            "additionalProperties": False,
        },
    ),
    MCPTool(
        # 动作型税务/发票/银行工具(2026-11-23 立)
        name="finance_tax_ops",
        description=FINANCE_TAX_DESCRIPTION,
        input_schema={
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "description": "动作名(如 invoice.import / tax.profile.upsert / filing.task.update)",
                },
                "payload": {
                    "type": "object",
                    "description": "该动作的参数对象;路径参数(id)放同名键,其余键自动进 query 或 body",
                    "additionalProperties": True,
                },
            },
            "required": ["action"],
            "additionalProperties": False,
        },
    ),
    MCPTool(
        # 动作型人事生命周期工具(2026-11-23 立):合同/转正/离职/招聘
        name="hr_lifecycle_ops",
        description=HR_LIFECYCLE_DESCRIPTION,
        input_schema={
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "description": "动作名(如 contract.sign / probation.review / resign.settle / candidate.hire)",
                },
                "payload": {
                    "type": "object",
                    "description": "该动作的参数对象;路径参数(id/employeeId)放同名键",
                    "additionalProperties": True,
                },
            },
            "required": ["action"],
            "additionalProperties": False,
        },
    ),
    MCPTool(
        # 动作型发薪闭环工具(2026-11-23 立):卡号/代发批次/导出/工资条
        name="hr_payout_ops",
        description=HR_PAYOUT_DESCRIPTION,
        input_schema={
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "description": "动作名(如 batch.build / batch.export / payslip.push)",
                },
                "payload": {
                    "type": "object",
                    "description": "该动作的参数对象;路径参数(id/employeeId)放同名键",
                    "additionalProperties": True,
                },
            },
            "required": ["action"],
            "additionalProperties": False,
        },
    ),
    MCPTool(
        # 财务部五腿·AI 一键报销(2026-11-13 立):入参口径单源 = AI_REIMBURSEMENT_DESCRIPTION
        name="ai_reimbursement",
        description=AI_REIMBURSEMENT_DESCRIPTION,
        input_schema={
            "type": "object",
            "properties": {
                "reimbursements": {
                    "type": "string",
                    "description": (
                        "报销明细 JSON 数组:每条 {employee,category(travel_transport/travel_lodging/"
                        "travel_meal/entertainment/education/welfare/office/other),amount(字符串金额),"
                        "date,invoice_type(special/general/e_general/none),description,"
                        "vat_rate(缺省 0.06),city_tier(一线/新一线/二线),nights(住宿晚数),"
                        "fund_source(资金科目,缺省 银行存款)};金额一律字符串防精度漂移"
                    ),
                },
                "revenue": {"type": "string", "description": "营业收入(算业务招待费 0.5% 限额)"},
                "wage_total": {"type": "string", "description": "工资薪金总额(算教育 8% / 福利 14% 限额)"},
                "city_tier": {
                    "type": "string",
                    "description": "城市档(一线/新一线/二线,定住宿限额缺省)",
                },
                "period": {"type": "string", "description": "所属期间,如 2026-11(跨期费用 warning 用)"},
                "state": {"type": "string", "description": "上一阶段返回的 state JSON(续跑用)"},
                "output_dir": {
                    "type": "string",
                    "description": "报销单草案输出目录(默认 tmp/artifacts,必须位于项目根)",
                },
            },
            "required": ["reimbursements"],
            "additionalProperties": False,
        },
    ),
    MCPTool(
        # 财务部五腿·社保医保精算(2026-11-13 立):入参口径单源 = SOCIAL_INSURANCE_DESCRIPTION
        name="social_insurance_calc",
        description=SOCIAL_INSURANCE_DESCRIPTION,
        input_schema={
            "type": "object",
            "properties": {
                "period": {"type": "string", "description": "缴费期间,如 2026-11(必填)"},
                "employees": {
                    "type": "string",
                    "description": (
                        "参保人员 JSON 数组:每条 {name, gross(应发), base(缴费基数,缺省=gross),"
                        "injury_class(1~8 工伤行业费率档,可选)};兼容 JSON 字符串"
                    ),
                },
                "social_avg_wage": {"type": "string", "description": "社平工资(定基数上下限锚,缺省 8000)"},
                "city": {"type": "string", "description": "参保城市(提示口径差异)"},
                "province": {"type": "string", "description": "参保省份(提示口径差异)"},
                "base_floor_ratio": {"type": "string", "description": "基数下限比例(缺省 0.60)"},
                "base_cap_ratio": {"type": "string", "description": "基数上限比例(缺省 3.0)"},
                "output_dir": {
                    "type": "string",
                    "description": "精算明细输出目录(默认 tmp/artifacts,必须位于项目根)",
                },
            },
            "required": ["period", "employees"],
            "additionalProperties": False,
        },
    ),
    MCPTool(
        # 财务部五腿·个税专项附加(2026-11-13 立):入参口径单源 = SPECIAL_DEDUCTION_DESCRIPTION
        name="special_deduction_calc",
        description=SPECIAL_DEDUCTION_DESCRIPTION,
        input_schema={
            "type": "object",
            "properties": {
                "employees": {
                    "type": "string",
                    "description": (
                        "员工及扣除信息 JSON 数组(简化形态只给若干字段其余按单项标准缺省);"
                        "兼容 JSON 字符串;合计直接喂 ai_tax_filing 工资表 special_deduction 字段"
                    ),
                },
                "period": {"type": "string", "description": "扣除期间,如 2026-11(缺省当月)"},
                "child_edu_monthly": {"type": "string", "description": "子女教育每孩每月覆盖(缺省 2000)"},
                "infant_monthly": {"type": "string", "description": "婴幼儿照护每孩每月覆盖(缺省 2000)"},
                "housing_loan_monthly": {"type": "string", "description": "房贷利息每月覆盖(缺省 1000)"},
                "rent_tier": {
                    "type": "string",
                    "description": "住房租金城市档覆盖(top/city_pop_gt_1m/city_pop_le_1m)",
                },
                "elderly_only_monthly": {"type": "string", "description": "赡养老人独生子女每月覆盖(缺省 3000)"},
                "output_dir": {
                    "type": "string",
                    "description": "扣除明细输出目录(默认 tmp/artifacts,必须位于项目根)",
                },
            },
            "required": ["employees"],
            "additionalProperties": False,
        },
    ),
    MCPTool(
        name="parse_document",
        description=(
            "解析本地文档为可注入上下文的文本/Markdown,支持 15 种格式:"
            "txt/md/csv/json/pdf/docx/doc/pptx/ppt/xls/xlsx/odt/ods/odp/rtf/epub"
            "(办公文档经 Firecrawl anydoc 引擎高保真提取标题/表格/列表)。"
            "用于阅读上传文档、抽取表格、总结文件内容、解析电子书。"
            "仅限项目工作区内文件,敏感文件(密钥类)拒绝。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "文件绝对路径或相对项目根路径"},
                "max_chars": {"type": "integer", "description": "返回内容上限,默认 20000(500-100000)", "default": 20000},
            },
            "required": ["path"],
            "additionalProperties": False,
        },
    ),
    MCPTool(
        name="sheet_formula_eval",
        description=(
            "重算本地 xlsx/xlsm 表格里的公式,返回逐格 {value, formula, source} 三态 provenance、"
            "依赖图(每个公式格引用了谁)与结构化错误(循环引用/坏引用/未知函数/类型错/除零/无匹配)。"
            "支持 SUM/AVERAGE/MIN/MAX/ROUND/ABS/IF/VLOOKUP/COUNT/COUNTA/CONCAT、四则运算、"
            "A1/$A$1/区域/跨表引用。只读不写;文件里上次存盘的缓存值单独给出并标记是否与重算一致。"
            "用于核对表格计算结果、排查公式错误、审计数据来源。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "xlsx/xlsm 文件绝对路径或相对项目根路径"},
                "sheet": {"type": "string", "description": "可选。只处理该工作表(大小写不敏感)"},
                "range": {
                    "type": "string",
                    "description": "可选。只处理该区域内的公式格,如 A1:C20 或 'Sheet1!A1:C20'",
                },
                "include_inputs": {
                    "type": "boolean",
                    "description": "是否附带公式引用到的输入格(默认 true,便于追溯数据来源)",
                    "default": True,
                },
                "max_cells": {
                    "type": "integer",
                    "description": "返回格数上限,默认 2000(1-20000)",
                    "default": 2000,
                },
            },
            "required": ["path"],
            "additionalProperties": False,
        },
    ),
    MCPTool(
        name="sheet_formula_validate",
        description=(
            "校验本地 xlsx/xlsm 表格的公式,逐条返回 findings(severity/code/cell/formula/message):"
            "语法错、未知函数、坏引用、循环引用(带闭环路径)、类型错、除零、VLOOKUP 无匹配,"
            "以及文件缓存值与重算值不一致(CACHED_VALUE_MISMATCH,提示缓存是旧值)。"
            "clean=true 表示没有任何 error 级问题。只读不写,用于交付前自检表格。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "xlsx/xlsm 文件绝对路径或相对项目根路径"},
                "sheet": {"type": "string", "description": "可选。只校验该工作表(大小写不敏感)"},
                "range": {
                    "type": "string",
                    "description": "可选。只校验该区域内的公式格,如 A1:C20 或 'Sheet1!A1:C20'",
                },
                "max_findings": {
                    "type": "integer",
                    "description": "findings 上限,默认 200(1-2000)",
                    "default": 200,
                },
                "include_cache_mismatch": {
                    "type": "boolean",
                    "description": "是否检查缓存值漂移(默认 true)",
                    "default": True,
                },
            },
            "required": ["path"],
            "additionalProperties": False,
        },
    ),
    MCPTool(
        name="init_agents_md",
        description=(
            "扫描工作区(package.json scripts / 构建文件 / 目录结构 / 既有约定文档)生成"
            "AGENTS.md 草稿文本。默认只返回草稿、不落盘;仅当显式传 output_path 才写入,"
            "且路径必须位于 workspace_root 内并避开 .git/node_modules 等敏感目录。"
            "用于给仓库补齐 AI 协作约定文档。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "workspace_root": {"type": "string", "description": "工作区绝对路径(必填)"},
                "output_path": {
                    "type": "string",
                    "description": "可选。显式传入才写盘,且须落在 workspace_root 内",
                },
            },
            "required": ["workspace_root"],
            "additionalProperties": False,
        },
    ),
    MCPTool(
        name="extract_document_assets",
        description=(
            "提取办公文档(Word/Excel/PPT/ODF/RTF/EPUB 等)内嵌的图片/对象等二进制资产,"
            "落盘到项目临时目录并返回资产清单(含本地路径/相对路径/字节数/媒体类型)。"
            "用于把 docx/xlsx/pptx 里的插图从文档中抢救出来供多模态使用。"
            "基于 Firecrawl anydoc 的文档模型;PDF 无文档模型不支持资产提取。"
            "仅限项目工作区内文件,敏感文件拒绝。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "文件绝对路径或相对项目根路径(不支持 pdf)"},
            },
            "required": ["path"],
            "additionalProperties": False,
        },
    ),
    MCPTool(
        name="document_tables",
        description=(
            "提取文档(Word/Excel/PPT/ODF/RTF/EPUB 等)中规范化数据表格,含合并单元格 span"
            "展开,输出二维文本数组 headers/rows 及 GFM Markdown/CSV,供结构化入库或对话引用。"
            "基于 Firecrawl anydoc 的文档模型;PDF 无文档模型不支持表格提取。"
            "仅限项目工作区内文件,敏感文件拒绝。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "文件绝对路径或相对项目根路径(不支持 pdf)"},
            },
            "required": ["path"],
            "additionalProperties": False,
        },
    ),
    # ===== Web 网络抓取(Firecrawl Scrape/Map/Crawl/Extract 极致融合, 2026-09)=====
    MCPTool(
        name="fetch_readable",
        description=(
            "抓取单个网页并抽取正文为干净 GFM markdown(对齐 Firecrawl Scrape 的 clean markdown,"
            "剥离 nav/footer/header/script/style 等噪声)。返回可注入 LLM 上下文的正文 + title/metadata。"
            "用于阅读新闻报道、文档页、产品页等网页正文。SSRF 防护同 fetch_url。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "url": {"type": "string", "description": "目标 URL(http/https, 必填)"},
                "max_chars": {"type": "integer", "description": "正文上限, 默认 8000(500-50000)", "default": 8000},
                "include_links": {"type": "boolean", "description": "markdown 是否保留内链, 默认 False", "default": False},
            },
            "required": ["url"],
            "additionalProperties": False,
        },
    ),
    MCPTool(
        name="map_site",
        description=(
            "抓取起始页面并提取其全部站内链接, 返回站点 URL 地图(对齐 Firecrawl Map)。"
            "默认仅同域、去 fragment、去重, 附带锚文本。常用于快速摸清站点结构。SSRF 防护同 fetch_url。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "url": {"type": "string", "description": "目标 URL(http/https, 必填)"},
                "same_domain_only": {"type": "boolean", "description": "仅保留同域链接, 默认 True", "default": True},
                "max_links": {"type": "integer", "description": "返回链接上限, 默认 200", "default": 200},
                "include_text": {"type": "boolean", "description": "是否附带锚文本, 默认 True", "default": True},
            },
            "required": ["url"],
            "additionalProperties": False,
        },
    ),
    MCPTool(
        name="crawl_site",
        description=(
            "从起始 URL 递归抓取同域名页面(对齐 Firecrawl Crawl,BFS 限深度/页数/并发),"
            "输出分页清单或合并 markdown。全站探索/站点总结用。SSRF 防护 + 同域约束,"
            "默认深度 1 限 10 页(硬上限深度 3/页数 50, 单页 15s)。资源较重, 限 admin 调用。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "url": {"type": "string", "description": "起始 URL(http/https, 必填)"},
                "max_depth": {"type": "integer", "description": "最大爬取深度, 默认 1(硬上限 3)", "default": 1},
                "max_pages": {"type": "integer", "description": "最多抓取页数, 默认 10(硬上限 50)", "default": 10},
                "format": {"type": "string", "description": "输出格式: pages(分页清单)/concatenated(合并单篇), 默认 concatenated", "default": "concatenated", "enum": ["pages", "concatenated"]},
                "respect_robots": {"type": "boolean", "description": "是否尊重 robots.txt, 默认 False", "default": False},
            },
            "required": ["url"],
            "additionalProperties": False,
        },
    ),
    MCPTool(
        name="extract_web",
        description=(
            "按显式字段 schema 从网页抽取结构化数据(对齐 Firecrawl Extract)。"
            "fields 传 JSON 字符串如 {\"price\":\"number\",\"author\":\"string\"}。"
            "LLM 通道优先, 未配置时启发式兜底。用于价格/作者/联系方式等字段抽取。SSRF 防护同 fetch_url。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "url": {"type": "string", "description": "目标 URL(http/https, 必填)"},
                "fields": {"type": "string", "description": "JSON 对象: 字段名->类型, 如 {\"price\":\"number\"}(必填)"},
                "max_chars": {"type": "integer", "description": "正文上限, 默认 8000(500-50000)", "default": 8000},
            },
            "required": ["url", "fields"],
            "additionalProperties": False,
        },
    ),
    # ===== 工具定义 deferral 反查工具(2026-09-02 立)=====
    MCPTool(
        name="get_tool_schema",
        description=(
            "返回指定工具的完整参数 schema(name/description/input_schema),只读。"
            "当工具定义被 deferral 精简(上下文只放压缩描述;api_* 长尾还删掉了"
            "字段级 description)后,模型用本工具按工具名取回完整参数说明。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "name": {
                    "type": "string",
                    "description": "要查询完整 schema 的工具名(可用 tools/list 获取全部工具名)",
                },
            },
            "required": ["name"],
        },
    ),
    # ===== 后台任务工具(Phase 1 第 6 项 · 2026-09-02 立)=====
    MCPTool(
        name="run_in_background",
        description=(
            "提交后台任务并立即返回 task_id(不阻塞循环),"
            "完成后经 IM 推送完成通知。支持 "
            + _bg_task_types_prose()
            + "(真实长任务 + 演示档;清单派生自 task_executors 注册表,勿在此写死)"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "task": {
                    "type": "string",
                    "description": (
                        "后台任务类型(白名单:"
                        + _bg_task_types_prose()
                        + ";各类型的 arguments 形状见 task_executors 注册表)"
                    ),
                },
                "arguments": {
                    "type": "object",
                    "description": (
                        "任务参数,如 sleep 的 {seconds:number}、echo 的 {message:string}、"
                        "test_suite 的 {target:string}、patrol 的 {root:string}"
                    ),
                },
                "name": {"type": "string", "description": "任务显示名(可选,默认=task)"},
                "idempotency_key": {
                    "type": "string",
                    "description": (
                        "幂等键(可选)。同一键的重复提交命中同一条任务记录、不重复执行;"
                        "缺省由 task 类型 + arguments 规范化派生"
                    ),
                },
                "notify_on_done": {
                    "type": "boolean",
                    "description": "完成后经 message_bus 推送 IM 通知(默认 true)",
                    "default": True,
                },
                "timeout_s": {
                    "type": "integer",
                    "description": "任务超时秒数(默认 300,最小 1)",
                    "default": 300,
                },
            },
            "required": ["task"],
            "additionalProperties": False,
        },
    ),
    MCPTool(
        name="bg_task_status",
        description=(
            "查询后台任务状态(凭 task_id)或列出某用户的任务。只传 task_id 时立即返回;"
            "wait_s>0 时最多等待该秒数到终态,到点未终态如实回 waitTimedOut;"
            "cancel=true 终止任务(已终态则不再变更)。cancel/wait_s 仅指定 task_id 时可用"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "task_id": {
                    "type": "string",
                    "description": "查询指定任务状态(不传则进入列表模式)",
                },
                "wait_s": {
                    "type": "number",
                    "description": "等待终态的最长秒数(0-300,默认 0=立即返回);仅指定 task_id 时有效",
                    "minimum": 0,
                    "maximum": 300,
                },
                "cancel": {
                    "type": "boolean",
                    "description": "true=取消该任务(仅指定 task_id 时有效);已终态时返回不再变更",
                },
                # user_id 已从本工具的对外 schema 摘除(2026-10-31):它是路由身份键
                # (ROUTING_IDENTITY_KEYS),只能由宿主注入 __user_id,不得作为模型可填参数
                # 存在 —— 只要还暴露在 schema 里,就必然再被某条 handler 读回去。
                "limit": {
                    "type": "integer",
                    "description": "列表返回上限(默认 20)",
                    "default": 20,
                },
            },
            "additionalProperties": False,
        },
    ),
    # ===== D11 浏览器自检截图(2026-09)=====
    # 注意:本名刻意避开已存在的 extension 端 browser_screenshot(由 agent-control
    # handler 转发浏览器扩展执行),避免覆盖既有 12 个浏览器控制工具。
    MCPTool(
        name="browser_selfcheck_screenshot",
        description=(
            "D11 浏览器自检截图:用 headless Chromium 对指定 URL 截图,返回 base64 PNG、"
            "视口宽高、页面 console 错误列表、页面标题与最终 URL。agent 完成前端/UI 任务后"
            "用于自主截图自检(对齐统一规范)。"
            "仅允许 http/https,禁止 file:// 等非常规协议。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "url": {
                    "type": "string",
                    "description": "目标页面 URL(http/https,必填)",
                },
                "viewport": {
                    "type": "object",
                    "description": "视口尺寸(可选),如 {\"width\":1280,\"height\":720}",
                    "properties": {
                        "width": {"type": "integer"},
                        "height": {"type": "integer"},
                    },
                },
                "full_page": {
                    "type": "boolean",
                    "description": "是否截取整页(默认 false=仅视口)",
                    "default": False,
                },
                "wait_ms": {
                    "type": "integer",
                    "description": "截图前等待渲染的毫秒数(默认 1500,给前端组件挂载留时间)",
                    "default": 1500,
                },
            },
            "required": ["url"],
            "additionalProperties": False,
        },
    ),
    MCPTool(
        name="browser_selfcheck",
        description=(
            "D11 浏览器自检报告:对 URL 截图后,把给定检查点(如『提交按钮可见』『无白屏』"
            "『标题含登录』)交给视觉 LLM 逐项判定 pass/fail 并给理由;LLM/视觉不可用时"
            "降级为仅返回截图 + console 错误,不报错。agent 完成前端任务后做闭环自检。"
            "仅允许 http/https,禁止 file:// 等非常规协议。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "url": {
                    "type": "string",
                    "description": "目标页面 URL(http/https,必填)",
                },
                "checks": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "检查点列表,如 [\"提交按钮可见\",\"无白屏\",\"标题含『登录』\"]",
                },
            },
            "required": ["url", "checks"],
            "additionalProperties": False,
        },
    ),
    # ===== 教育管理(edu_* 2026-09-19):读 8 + 写 6,经 internal token 调 api =====
    # 权限收敛在 api 侧 RBAC(edu:view 读 / edu:manage 写);不入 _ADMIN_ONLY_TOOLS
    # (对话链 user_role=0,入名单即断链,同 image_generation 2026-09-08 先例)
    MCPTool(
        name="edu_list_students",
        description=(
            "教育管理-学员名册检索:按关键词(姓名/手机号)/业务线/班级/学期分页查询报名学员,"
            "返回 enrollmentId/studentId/studentName/studentPhone/className/totalFee/paidAmount"
            "/dueAmount(欠费金额,单位元)。用于把学员姓名解析成催费/缴费/退费所需的 ID。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "keyword": {"type": "string", "description": "学员姓名或手机号模糊搜索(可选)"},
                "businessLine": {"type": "string", "enum": ["after_school_care", "kindergarten", "academic", "ai_course", "other"], "description": "业务线过滤(可选)"},
                "classId": {"type": "string", "description": "班级 ID 过滤(可选)"},
                "termId": {"type": "string", "description": "学期 ID 过滤(可选)"},
                "page": {"type": "integer", "description": "页码(默认 1)"},
                "pageSize": {"type": "integer", "description": "每页条数 1-100(默认 20)"},
            },
            "additionalProperties": False,
        },
    ),
    MCPTool(
        name="edu_list_arrears",
        description=(
            "教育管理-欠费学员名单:只看 totalFee > paidAmount 的报名记录,返回结构同"
            " edu_list_students(含 dueAmount 欠费金额)。批量催费前先查本名单,再把"
            " enrollmentId 列表交给 edu_send_fee_reminder_batch。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "keyword": {"type": "string", "description": "学员姓名或手机号模糊搜索(可选)"},
                "businessLine": {"type": "string", "enum": ["after_school_care", "kindergarten", "academic", "ai_course", "other"], "description": "业务线过滤(可选)"},
                "classId": {"type": "string", "description": "班级 ID 过滤(可选)"},
                "termId": {"type": "string", "description": "学期 ID 过滤(可选)"},
                "page": {"type": "integer", "description": "页码(默认 1)"},
                "pageSize": {"type": "integer", "description": "每页条数 1-100(默认 20)"},
            },
            "additionalProperties": False,
        },
    ),
    MCPTool(
        name="edu_list_fee_reminders",
        description="教育管理-催费记录查询:按学员/班级/渠道分页查询历史催费发送记录(含状态与欠费金额快照)。",
        input_schema={
            "type": "object",
            "properties": {
                "studentId": {"type": "string", "description": "学员 ID 过滤(可选)"},
                "classId": {"type": "string", "description": "班级 ID 过滤(可选)"},
                "channel": {"type": "string", "description": "发送渠道过滤 in_app/sms/wechat(可选)"},
                "page": {"type": "integer", "description": "页码(默认 1)"},
                "pageSize": {"type": "integer", "description": "每页条数 1-100(默认 20)"},
            },
            "additionalProperties": False,
        },
    ),
    MCPTool(
        name="edu_list_payment_records",
        description="教育管理-缴费记录查询:按学员/班级/状态(paid/pending 等)分页查询缴费流水(amount 单位元)。",
        input_schema={
            "type": "object",
            "properties": {
                "studentId": {"type": "string", "description": "学员 ID 过滤(可选)"},
                "classId": {"type": "string", "description": "班级 ID 过滤(可选)"},
                "status": {"type": "string", "description": "缴费状态过滤,如 paid/pending(可选)"},
                "page": {"type": "integer", "description": "页码(默认 1)"},
                "pageSize": {"type": "integer", "description": "每页条数 1-100(默认 20)"},
            },
            "additionalProperties": False,
        },
    ),
    MCPTool(
        name="edu_payment_summary",
        description=(
            "教育管理-缴费汇总统计:返回 totalIncome(实收总额,元)/paidStudentCount(已缴人数)"
            "/arrearsCount(欠费人数)/arrearsTotal(欠费总额,元),可按班级/学期过滤。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "classId": {"type": "string", "description": "班级 ID 过滤(可选)"},
                "termId": {"type": "string", "description": "学期 ID 过滤(可选)"},
            },
            "additionalProperties": False,
        },
    ),
    MCPTool(
        name="edu_list_refunds",
        description="教育管理-退费记录查询:按学员/班级/状态分页查询退费单(status: pending 待审批/approved 已通过/rejected 已驳回)。",
        input_schema={
            "type": "object",
            "properties": {
                "studentId": {"type": "string", "description": "学员 ID 过滤(可选)"},
                "classId": {"type": "string", "description": "班级 ID 过滤(可选)"},
                "status": {"type": "string", "description": "状态过滤 pending/approved/rejected(可选)"},
                "page": {"type": "integer", "description": "页码(默认 1)"},
                "pageSize": {"type": "integer", "description": "每页条数 1-100(默认 20)"},
            },
            "additionalProperties": False,
        },
    ),
    MCPTool(
        name="edu_list_tuition_fees",
        description="教育管理-学费标准查询:按班级/学期分页查询学费标准(feeName/amount 单位元/billingCycle/effectiveDate)。",
        input_schema={
            "type": "object",
            "properties": {
                "classId": {"type": "string", "description": "班级 ID 过滤(可选)"},
                "termId": {"type": "string", "description": "学期 ID 过滤(可选)"},
                "page": {"type": "integer", "description": "页码(默认 1)"},
                "pageSize": {"type": "integer", "description": "每页条数 1-100(默认 20)"},
            },
            "additionalProperties": False,
        },
    ),
    MCPTool(
        name="edu_my_bills",
        description="教育管理-我的学费账单:查当前聊天用户自己的报名(应缴/已缴/欠费)与最近缴费记录(家长自查,无需管理权限)。",
        input_schema={"type": "object", "properties": {}, "additionalProperties": False},
    ),
    MCPTool(
        name="edu_send_fee_reminder",
        description=(
            "教育管理-发送学费催缴(写操作):向指定报名记录发送催费通知,站内信必达。"
            "channel=wechat 尽力发微信订阅消息(用户未订阅/一次性额度用尽会明确回 "
            "user_refused,不当作成功);channel=sms 会**真实发送**到学员与已确认绑定家长"
            "各自的手机号,无号码回 no_phone、服务端未配置回 not_configured,都不是失败即静默。"
            "enrollmentId 先用 edu_list_students 或 edu_list_arrears 查得;该报名无欠费会被拒绝。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "enrollmentId": {"type": "string", "description": "报名记录 ID(必填)"},
                "channel": {"type": "string", "enum": ["in_app", "sms", "wechat"], "description": "发送渠道(默认 in_app)"},
                "message": {"type": "string", "description": "自定义催费文案(可选,留空用默认文案,最长 500 字)"},
            },
            "required": ["enrollmentId"],
            "additionalProperties": False,
        },
    ),
    MCPTool(
        name="edu_send_fee_reminder_batch",
        description=(
            "教育管理-批量催费(写操作):对多个报名记录(1-100 个)批量发送催缴通知;"
            "不存在/无欠费的记录自动跳过并返回 skipped 明细。常配 edu_list_arrears 先拉欠费名单再整批发送。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "enrollmentIds": {"type": "array", "items": {"type": "string"}, "description": "报名记录 ID 列表(1-100 个,必填)"},
                "channel": {"type": "string", "enum": ["in_app", "sms", "wechat"], "description": "发送渠道(默认 in_app)"},
                "message": {"type": "string", "description": "自定义催费文案(可选,留空用默认文案)"},
            },
            "required": ["enrollmentIds"],
            "additionalProperties": False,
        },
    ),
    MCPTool(
        name="edu_create_payment_record",
        description=(
            "教育管理-登记缴费(写操作):为**某一条报名的某个期次**新增一条缴费记录,"
            "服务端会据此重算该报名的已缴额与欠费。amount 单位为元(整数);"
            "paymentDate 格式 YYYY-MM-DD;paymentMethod 如 现金/微信/支付宝/银行转账;"
            "status 默认 paid。enrollmentId 必填,用 edu_list_students(返回 enrollmentId)"
            "或 edu_list_arrears 查得 —— 同一学员在同一班级可能有多期报名(续读),"
            "钱必须记到确定的那一期上,因此不接受只给 studentId/classId 的写法。"
            "缺金额/日期/方式时先向用户确认再调用。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "enrollmentId": {
                    "type": "string",
                    "description": "归属报名(期次)ID(必填;edu_list_students 返回里的 enrollmentId)",
                },
                "studentId": {"type": "string", "description": "学员 ID(可选,仅做一致性校验)"},
                "classId": {"type": "string", "description": "班级 ID(可选,仅做一致性校验)"},
                "amount": {"type": "integer", "description": "缴费金额,单位元(必填)"},
                "paymentDate": {"type": "string", "description": "缴费日期 YYYY-MM-DD(必填)"},
                "paymentMethod": {"type": "string", "description": "缴费方式,如 现金/微信/支付宝/银行转账(必填)"},
                "status": {"type": "string", "description": "状态 paid/pending(默认 paid)"},
                "receiptNo": {"type": "string", "description": "收据号(可选)"},
                "remark": {"type": "string", "description": "备注(可选)"},
            },
            "required": ["enrollmentId", "amount", "paymentDate", "paymentMethod"],
            "additionalProperties": False,
        },
    ),
    MCPTool(
        name="edu_create_refund",
        description=(
            "教育管理-创建退费申请(写操作):登记退费单(初始 pending),需再用"
            " edu_approve_refund/edu_reject_refund 审批。amount 单位为元(整数);"
            "refundDate 格式 YYYY-MM-DD;reason 退费原因必填。"
            "审批通过会**冲减该报名的已缴额**(欠费随之回升),不是只改状态。"
            "归属规则:带 paymentId 时按该笔缴费所属报名记账;不带 paymentId 时仅当该学员"
            "在该班级只有一条有效报名才自动归属,多期报名(续读)会返回 unattributed=true 且"
            "不影响任何报名的账 —— 所以要退某一期的钱,请先用 edu_list_payment_records 取 "
            "paymentId 一并传入。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "studentId": {"type": "string", "description": "学员 ID(必填)"},
                "classId": {"type": "string", "description": "班级 ID(必填)"},
                "amount": {"type": "integer", "description": "退费金额,单位元(必填)"},
                "refundDate": {"type": "string", "description": "退费日期 YYYY-MM-DD(必填)"},
                "reason": {"type": "string", "description": "退费原因(必填)"},
                "paymentId": {"type": "string", "description": "关联缴费记录 ID(可选)"},
                "refundMethod": {"type": "string", "description": "退回方式,如 原路退回/银行转账(可选)"},
            },
            "required": ["studentId", "classId", "amount", "refundDate", "reason"],
            "additionalProperties": False,
        },
    ),
    MCPTool(
        name="edu_approve_refund",
        description=(
            "教育管理-审批通过退费(写操作):把 pending 状态的退费记录置为 approved;"
            "refundId 用 edu_list_refunds(status=pending) 查得。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "refundId": {"type": "string", "description": "退费记录 ID(必填)"},
                "approveRemark": {"type": "string", "description": "审批备注(可选)"},
            },
            "required": ["refundId"],
            "additionalProperties": False,
        },
    ),
    MCPTool(
        name="edu_reject_refund",
        description=(
            "教育管理-驳回退费(写操作):把 pending 状态的退费记录置为 rejected;"
            "refundId 用 edu_list_refunds(status=pending) 查得。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "refundId": {"type": "string", "description": "退费记录 ID(必填)"},
                "approveRemark": {"type": "string", "description": "驳回理由/备注(可选)"},
            },
            "required": ["refundId"],
            "additionalProperties": False,
        },
    ),
    # ===== 工作流动作模型可见化(G-01 补齐腿之二,2026-10-31 立)=====
    # 三张 schema 都 additionalProperties=False 且**没有 script/scriptPath/code 字段**:
    # RCE 面不是靠拦住的,是靠不存在(见上方 _tool_workflow_trigger 头注的超越轴)。
    MCPTool(
        name="workflow_trigger",
        description=(
            "触发一个已存在的工作流(异步执行,立即返回 pending 实例)。workflow_id 用工作流列表查得;"
            "只能触发当前身份名下的工作流,别人的与不存在同形返回。不接收脚本文本或脚本路径。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "workflow_id": {"type": "string", "description": "工作流 ID(必填,形如 wf-xxxx)"},
                "input": {
                    "type": "object",
                    "description": "工作流数据入参(可选;供步骤模板 {var} 渲染,只放数据不放代码)",
                },
            },
            "required": ["workflow_id"],
            "additionalProperties": False,
        },
    ),
    MCPTool(
        name="workflow_resume",
        description=(
            "续跑一个历史实例:入参未变的已完成步瞬时取回缓存 output(结构上不执行),"
            "被改动或新增的步才真跑。instance_id 用 workflow_instance_status 查得。"
            "取不到可比对的记录时返回具名错误码(WF_RESUME_*),不会静默降级成整条重跑。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "instance_id": {"type": "string", "description": "源实例 ID(必填,形如 wi-xxxx)"},
                "input": {
                    "type": "object",
                    "description": (
                        "新的工作流数据入参(可选;缺省=沿用源实例)。"
                        "传了即所有步的调用键都变 ⇒ 等价整条重跑,只在确实要换数据时传"
                    ),
                },
            },
            "required": ["instance_id"],
            "additionalProperties": False,
        },
    ),
    MCPTool(
        name="workflow_instance_status",
        description=(
            "查工作流实例状态与逐步 trace(只读):每步的 step/name/type/status/error + output 字数。"
            "非本人可见的实例与不存在同形返回。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "instance_id": {"type": "string", "description": "实例 ID(必填,形如 wi-xxxx)"},
            },
            "required": ["instance_id"],
            "additionalProperties": False,
        },
    ),
    # ===== 代码库只读调查 + 跨会话点名消息(G-11 / G-07 补齐,2026-10-31 立)=====
    # 三张 schema 均 additionalProperties=False;身份/会话由承载层注入,不入 schema。
    MCPTool(
        name="investigate_codebase",
        description=(
            "只读代码库调查:把检索/语义/仓库记忆出口组合成带证据锚点的结论,"
            "逐条标注 observed/inferred/unknown 三态;零写入、零子进程、零网络直连。"
            "仓库未索引/无命中一律记为 unknown,不冒充查过。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "intent": {"type": "string", "description": "调查意图(必填,逐字记进结果)"},
                "query": {"type": "string", "description": "词法检索关键词(可选,缺省用 intent)"},
                "path": {"type": "string", "description": "调查根目录(可选,默认仓根)"},
                "max_results": {"type": "integer", "description": "每腿命中上限(可选,默认 20,封顶 100)"},
                "use_semantic": {"type": "boolean", "description": "是否走语义腿(可选,默认 True)"},
                "use_wiki": {"type": "boolean", "description": "是否读仓库记忆缓存(可选,默认 True)"},
            },
            "required": ["intent"],
            "additionalProperties": False,
        },
    ),
    MCPTool(
        name="send_team_message",
        description=(
            "向点名的同伴代理投递一条消息(单播,绝不广播);仅可投给当前身份在同一会话内"
            "已绑定的同伴,未注册/未绑定一律拒绝并入队失败。sender 只认承载层注入身份,不接受自报顶替。"
            "triggers_agent=true 时会在入队后尝试把收件方**正在跑**的回合叫醒,结果见响应的 wakeUp"
            "(woken/not_running/unknown_session/not_steerable/forbidden);唤醒失败不影响已入队事实。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "recipient": {"type": "string", "description": "收件代理名(必填,须已在本会话绑定)"},
                "content": {"type": "string", "description": "消息正文(必填,非空)"},
                "message_type": {"type": "string", "description": "消息类型(notification/question/handoff,默认 notification)"},
                "require_reply": {"type": "boolean", "description": "是否需要回信(默认 False)"},
                "sub_task_id": {"type": "string", "description": "关联子任务 ID(可选)"},
                "enters_context": {
                    "type": "boolean",
                    "description": "是否注入收件方模型上下文(默认 true;false = 只记账不进上下文)",
                },
                "triggers_agent": {
                    "type": "boolean",
                    "description": "是否唤醒收件方起一个回合(默认 false = 等它下次主动读)",
                },
                "artifact_refs": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "产物引用(文件/截图/报告,最多 20 条),用来替代大段正文",
                },
                "priority": {"type": "integer", "description": "优先级,越大越先处理(默认 0)"},
                "hop_depth": {"type": "integer", "description": "协作链深度(默认 0,上限 3;超限拒绝转发)"},
                "source_event_id": {"type": "string", "description": "来源事件幂等键(窗口内重复投递会被丢弃)"},
            },
            "required": ["recipient", "content"],
            "additionalProperties": False,
        },
    ),
    MCPTool(
        name="read_team_inbox",
        description=(
            "读本席(当前代理)的收件箱;按会话 ∧ 属主两维过滤,拒读时不消费任何(零 receive)。"
            "只读已投递给本代理且属主一致的消息。按 priority 从高到低投递(同优先级保持到达序);"
            "entersContext=false 的消息仍会被消费,但正文不返回(contentOmitted=true,"
            "只留 contentLength 与来源供核对)。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "agent_name": {"type": "string", "description": "本席代理名(必填)"},
                "limit": {"type": "integer", "description": "最多读取条数(默认 10)"},
                "wait_seconds": {"type": "number", "description": "阻塞等待秒数(默认 0 不等待)"},
            },
            "required": ["agent_name"],
            "additionalProperties": False,
        },
    ),
    MCPTool(
        name="send_to_session",
        description=(
            "按会话 id 向另一个会话投递一条消息(单播,绝不广播)。只可投给同一属主名下的"
            "目标会话;目标无属主登记、跨属主、或调用方会话已登记为他人一律拒绝且零副作用。"
            "身份只认承载层注入,不接受模型自报。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "target_session_id": {"type": "string", "description": "目标会话 id(必填,不可为 * 或自身)"},
                "message": {"type": "string", "description": "消息正文(必填,非空白)"},
                "kind": {"type": "string", "description": "消息类型(notification/request/handoff,默认 notification)", "enum": sorted(_NAMABLE_MESSAGE_TYPES)},
            },
            "required": ["target_session_id", "message"],
            "additionalProperties": False,
        },
    ),
    # ===== Notebook 结构编辑(G-NotebookEdit 补齐,2026-11-01 立)=====
    # 对齐对方 NotebookEdit 三键(cell_id/cell_type/edit_mode);身份不入 schema
    # (ROUTING_IDENTITY_KEYS 纪律:只认宿主注入 __user_id,模型自报即越权)。
    MCPTool(
        name="notebook_edit",
        description=(
            "按单元格结构编辑 .ipynb 笔记本:cell_id 定位(cell-N 0 基序号或 notebook 原生 id),"
            "edit_mode=replace 改写目标 cell 的 source(可顺带改 cell_type)、insert 在其后插入新 cell"
            "(cell_type 必填)、delete 删除目标 cell;其余 cell 逐字节不变。写回复用 write_file "
            "串行化腿(路径白名单+并发漂移判定),越权/非属主一律拒绝且零磁盘副作用。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "notebook_path": {"type": "string", "description": "目标 .ipynb 路径(必填,限工作区白名单内)"},
                "cell_id": {"type": "string", "description": "目标单元格标识(必填):cell-N(0 基序号)或 notebook 原生 cell id"},
                "cell_type": {"type": "string", "enum": ["code", "markdown", "raw"], "description": "单元格类型:insert 必填;replace 可选,用于改目标 cell 类型;delete 忽略"},
                "new_source": {"type": "string", "description": "单元格新源码(replace/insert 必填非空;delete 忽略)"},
                "edit_mode": {"type": "string", "enum": ["replace", "insert", "delete"], "description": "编辑模式(默认 replace)"},
            },
            "required": ["notebook_path", "cell_id"],
            "additionalProperties": False,
        },
    ),
    # ===== advisor 咨询(G-11 协议层补齐,2026-10-31 立)=====
    # 身份 / 预算键不入 schema(ROUTING_IDENTITY_KEYS 纪律:只认宿主注入 __user_id,
    # 模型自报即越权);max_uses 的 1..10 与 advisor.ADVISOR_MAX_USES_CAP 同值。
    MCPTool(
        name="advisor_consult",
        description=(
            "向指定的另一个模型咨询一个子问题(带会话级次数上限);未指定模型则用默认模型。"
            "指定了模型就只认那一个:该模型不可用即回具名错误码 ADVISOR_MODEL_UNAVAILABLE,"
            "绝不静默回落到默认模型。次数用尽回 ADVISOR_BUDGET_EXHAUSTED。"
            "身份只认承载层注入,不接受模型自报。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "prompt": {"type": "string", "description": "要咨询的子问题(必填,非空白,≤8000 字符)"},
                "model": {"type": "string", "description": "咨询用的模型名(可选;缺省=网关默认模型)"},
                "max_uses": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": 10,
                    "description": "本会话(属主+会话)的咨询次数上限(可选,默认 3,硬上限 10)",
                },
            },
            "required": ["prompt"],
            "additionalProperties": False,
        },
    ),
    # ===== 工作流续跑(G-独立分析对齐 Workflow/RunWorkflow,2026-11-02 立)=====
    # 身份不入 schema(ROUTING_IDENTITY_KEYS 纪律:只认宿主注入 __user_id,模型自报即越权);
    # 与 _TOOL_HANDLERS 里 "run_workflow" 同批双射,漏一侧即 test_tools_count_matches_registry 红。
    MCPTool(
        name="run_workflow",
        description=(
            "执行多节点 agent 工作流:nodes 为节点声明数组(id/agent/arguments/depends_on),"
            "按拓扑序逐节点执行(agent 取已注册任务类型)。带 resume_from_run_id 续跑时,"
            "入参未变的节点瞬时回缓存不重跑,只有入参变化或此前失败的节点真执行;"
            "run 不存在/脚本非法/跨主体一律显式错误码且零执行。身份只认承载层注入,不接受模型自报。"
            "长工作流传 run_in_background=true:立即返回 task_id,用 bg_task_status 查结果;"
            "后台任务被拒/禁用时显式回 BACKGROUND_REJECTED,不会伪装成已开始。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "nodes": {
                    "type": "array",
                    "description": (
                        "节点声明数组(必填,非空),每项 {id, agent, arguments?, depends_on?};"
                        "id 唯一,depends_on 引用同批 id,存在环即拒绝"
                    ),
                },
                "resume_from_run_id": {
                    "type": "string",
                    "description": "续跑的目标 run_id(可选;缺省=新建 run 全量执行)",
                },
                "run_in_background": {
                    "type": "boolean",
                    "description": "true=提交后台执行并立即返回 task_id;缺省=false 同步等待结果",
                },
                "timeout_s": {
                    "type": "number",
                    "description": "后台执行超时秒数(1-3600,默认 1800);仅 run_in_background=true 生效",
                    "minimum": 1,
                    "maximum": 3600,
                },
                "notify_on_done": {
                    "type": "boolean",
                    "description": "后台完成时是否推送 IM 通知(默认 false)",
                },
            },
            "required": ["nodes"],
            "additionalProperties": False,
        },
    ),
    # ===== 工作簿 agent 面(goal-b45 F 席,2026-11-02 立)=====
    # 遵循统一工程规范
    # 那一族(取证 T8-sidecar-native-surface.md §B);**只取五枚最小集**,不照抄 14 条凑数。
    # 身份不入 schema(ROUTING_IDENTITY_KEYS 纪律:只认宿主注入 __user_id,模型自报即越权);
    # 与 _TOOL_HANDLERS 里四枚 workbook_* 同批双射,漏一侧即 test_tools_count_matches_registry 红。
    # 不入 _ADMIN_ONLY_TOOLS:归属判据在 api 侧逐请求现问(句柄绑主体 + 文件绑 ownerId),
    # 对话链 user_role=0 也能安全用 —— 与 edu_* 同一档处置(入名单即断链,见 2026-09-08 先例)。
    MCPTool(
        name="workbook_open",
        description=(
            "打开 api 侧**已存在**的工作簿(xlsx/xlsm),返回会话句柄、工作表清单与公式读数。"
            "只按 file_id 开已登记的本人文件:非本人、不存在、不是工作簿 ⇒ 显式错误码且零副作用。"
            "句柄绑定调用主体,别人的句柄一律拒。身份只认承载层注入,不接受模型自报。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "file_id": {
                    "type": "string",
                    "description": "已登记工作簿的文件 id(必填;必须是当前主体可访问的文件)",
                },
            },
            "required": ["file_id"],
            "additionalProperties": False,
        },
    ),
    MCPTool(
        name="workbook_read_range",
        description=(
            "按 A1 形态区域读工作簿单元格。**公式格不回值**:只回公式原文与 state=formula-uncomputed "
            "(本仓无计算引擎,缓存值可能已陈旧 —— 宁可明说未判定,也不给一个可能是错的数字);"
            "合并从格同样不回主格的值。普通数值/文本/日期格正常回值。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "handle": {"type": "string", "description": "workbook_open 返回的会话句柄(必填)"},
                "sheet": {"type": "string", "description": "工作表名(必填,须是 open 返回清单里的名字)"},
                "range": {
                    "type": "string",
                    "description": "A1 形态区域,如 A1:C20 或单格 B7(必填)",
                },
            },
            "required": ["handle", "sheet", "range"],
            "additionalProperties": False,
        },
    ),
    MCPTool(
        name="workbook_write_cells",
        description=(
            "写单元格并**非破坏式落新档**:保存只写一份新工作簿,原档一字节不动(返回 savedFileId)。"
            "两条边界:① 目标格本身是公式 ⇒ 整批拒写(WORKBOOK_FORMULA_OVERWRITE,不把公式换成静态值,"
            "不做部分写);② 本次改动波及公式 ⇒ 结果带 recalcUnsupported=true 并点名到格,"
            "因为本仓不重算公式(对照件带原生计算引擎,这一格我们刻意不做)。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "handle": {"type": "string", "description": "workbook_open 返回的会话句柄(必填)"},
                "sheet": {"type": "string", "description": "工作表名(必填)"},
                "cells": {
                    "type": "array",
                    "description": (
                        "待写格子数组(必填,1-500 项),每项 {address, value};"
                        "value 只接受 string|number|boolean|null;地址与合法性由 api 侧单源判"
                    ),
                    "items": {"type": "object"},
                },
                "name": {
                    "type": "string",
                    "description": "新档展示名(可选;缺省沿用原档名),不影响原档",
                },
            },
            "required": ["handle", "sheet", "cells"],
            "additionalProperties": False,
        },
    ),
    MCPTool(
        name="workbook_close",
        description=(
            "释放工作簿会话句柄。关闭之后同一句柄再使用一律判「未判定」(WORKBOOK_HANDLE_UNDETERMINED)"
            "—— 不猜它当时改了啥;没保存的改动即失效,要续作必须重新 workbook_open。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "handle": {"type": "string", "description": "待释放的会话句柄(必填)"},
            },
            "required": ["handle"],
            "additionalProperties": False,
        },
    ),
    # ---- Qoder 行为对齐(2026-11-08):skill / todo_write / todo_read ----
    MCPTool(
        name="skill",
        description=(
            "按名加载一个技能的 SKILL.md 指令(渐进披露)。返回 instructions 正文与其声明的"
            " allowed-tools。该声明是**授权**不是限制:名单内工具在本会话免走高危审批"
            "(角色矩阵/能力门/路径校验/沙箱不受影响),名单外工具照常可用。"
            "传 {release: true} 收回授权。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "技能名(来自 available_skills 资源或 build_skill 产物)"},
                "arguments": {
                    "type": "object",
                    "description": "可选:模板变量键值(如 {'path': 'src/app.ts'}),按 {key} 渲染",
                    "additionalProperties": {"type": "string"},
                },
                "release": {"type": "boolean", "description": "true=结束当前会话的技能作用域(与 name 互斥)"},
            },
            "additionalProperties": False,
        },
    ),
    MCPTool(
        name="todo_write",
        description=(
            "整表替换本会话的任务板(不是追加)。状态五档 pending/in_progress/completed/"
            "cancelled/blocked;同一时刻最多一条 in_progress;最多 50 条,单条正文上限 200 字。"
            "传入 [] 表示清空。校验失败时任务板保持原样。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "todos": {
                    "type": "array",
                    "description": "完整计划表(整表替换)",
                    "maxItems": 50,
                    "items": {
                        "type": "object",
                        "properties": {
                            "content": {"type": "string", "description": "计划项正文(≤200 字)"},
                            "status": {
                                "type": "string",
                                "enum": [
                                    "pending",
                                    "in_progress",
                                    "completed",
                                    "cancelled",
                                    "blocked",
                                ],
                            },
                            "activeForm": {"type": "string", "description": "进行中时的口语化描述(可选)"},
                        },
                        "required": ["content", "status"],
                        "additionalProperties": False,
                    },
                },
            },
            "required": ["todos"],
            "additionalProperties": False,
        },
    ),
    MCPTool(
        name="todo_read",
        description="读回本会话当前任务板(按会话隔离、2 小时滑动过期)。",
        input_schema={
            "type": "object",
            "properties": {},
            "additionalProperties": False,
        },
    ),
    MCPTool(
        name="ask_user_question",
        description=(
            "向用户提一个结构化问题并等待答复(交互宿主会把问题帧下发到"
            "当前会话)。schema 对齐 CLI AskUserQuestion:"
            "单选默认、multiSelect=true 为多选、allowCustom=true 允许自由文本。"
            "可选 timeout_s 进入定时模式:前台等待到期后返回 pending(pending=true),"
            "模型继续推进;用户之后仍可答复并以 answer_to_pending_question 消息送达。"
            "省略 timeout_s 为阻塞等待(默认 300s),-1 表示等到答复/会话中断。"
            "无交互宿主的执行面会直接返回 question_host_unsupported,不会等待。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "question": {"type": "string", "description": "要问用户的完整问题文本(必填)"},
                "header": {"type": "string", "description": "短标题(可选,≤12 字,用于问题卡片标题)"},
                "options": {
                    "type": "array",
                    "description": "选项数组(1-8 项;每项 id/label 必填,description 可选)",
                    "minItems": 1,
                    "maxItems": 8,
                    "items": {
                        "type": "object",
                        "properties": {
                            "id": {"type": "string", "description": "选项稳定标识(唯一)"},
                            "label": {"type": "string", "description": "选项展示文本"},
                            "description": {"type": "string", "description": "选项补充说明(可选)"},
                        },
                        "required": ["id", "label"],
                        "additionalProperties": False,
                    },
                },
                "multiSelect": {"type": "boolean", "description": "true=允许多选,默认 false(单选)"},
                "allowCustom": {"type": "boolean", "description": "true=允许自由文本答复,默认 true"},
                "timeout_s": {
                    "type": "integer",
                    "description": (
                        "前台等待秒数(定时继续):到期返回 pending=true,模型继续;"
                        "用户仍可后续答复。-1 表示等到答复/会话中断。"
                        "省略则阻塞等待(默认 300s)。"
                    ),
                },
            },
            "required": ["question"],
            "additionalProperties": False,
        },
    ),
]


def get_registered_tool_names() -> set[str]:
    """返回所有已注册工具的名字集合(只读 helper,2026-07-31 立)。

    供 llm.py 的 resolve_tool_source() 派生工具来源(serverSource)使用:
    - 工具名在本集合中且不属于 builtin/plugin → serverSource='mcp'
    - 当前所有工具均为本地实现(无外部 MCP server 注册),server_id/server_name 暂为 None
    - 未来接入外部 MCP server(如 context7/filesystem)后,扩展本函数返回 (name, server_id, server_name) 三元组
    """
    return {t.name for t in _TOOLS}


# 全仓**唯一一份** `_TOOL_ALIASES`(V3 #47 第三格,2026-09-26 合成):
# A 内核(llm.py tool loop 的执行前归一,原 llm.py 本地定义已删、改为 import 本表)
# 与 call_tool 未命中时的 `_normalize_tool_name` 归一共用同一对象。
# 2026-09-26 之前这里是第二份独立真相(只有 2 条 execute_command/list_directory),
# 与 llm.py 那份 26 条表各自漂移 —— 同一个模型写的别名在一个入口被归一、在另一个
# 入口报「未知工具」随机出现,且没有任何东西校验这一份。守门
# scripts/check-tool-registry-integrity.mjs 的 J2/J3/J4 校验本表值域/键域,
# J11 对账「全 app 包内模块级定义恰好 1 处」,防本表合成后又长回两份。
#
# 2026-08-06 生产修复:LLM(stepfun step_plan 等)返回的工具名可能与系统注册名不一致
# (模型幻觉/跨平台别名),导致 call_tool 报"未知工具"→ 工具执行失败 → 对话显示失败。
# 统一映射到实际注册的工具名(execute_command 是 Claude/Codex 风格别名,本项目为 run_command)。
#
# 2026-09-26(V3 #49)扩充:原仅 2 条,对抗模型工具名幻觉的覆盖面过窄。扩充原则 ——
#   ① 值域必须是 _TOOLS 里真实注册的名字(守门 check-tool-registry-integrity 校验);
#   ② 只收**语义等价**的别名:写操作一律不收(如 create_file→write_file 会把「新建」
#      语义静默变成「覆盖」,宁可让它走到 _DELEGATE_ONLY_HINTS 的明确报错);
#   ③ 只读与命令类可放心扩,映射错了最坏是行为略偏,不会静默破环。
_TOOL_ALIASES: dict[str, str] = {
    # 命令执行(Claude / Codex / 通用 LLM 习惯名)
    "execute_command": "run_command",
    "execute_bash": "run_command",
    "bash": "run_command",
    "shell": "run_command",
    "run_shell": "run_command",
    # 2026-11-15:移除 "terminal" -> run_command 别名 —— 真工具 terminal 已注册,归一化会把
    # 正确调用静默改写成 run_command,导致 terminal 不可达(守门 J3 拦截)。
    # 目录列举
    "list_directory": "list_files",
    "list_dir": "list_files",
    "find_files": "list_files",
    "glob_files": "list_files",
    # 文件读取
    "read": "read_file",
    "view": "read_file",
    "view_file": "read_file",
    "open_file": "read_file",
    "cat_file": "read_file",
    # 内容搜索
    "search_files": "file_search",
    "search_content": "file_search",
    "grep": "file_search",
    "grep_files": "file_search",
    "search_in_files": "file_search",
    # 语义/符号检索
    "code_search": "search_codebase",
    "search_symbol": "search_codebase",
    # 网页抓取
    "fetch": "fetch_url",
    "browse": "fetch_url",
    "http_request": "fetch_url",
    "open_url": "fetch_url",
    # 多智能体编排:2026-11-16 模型面更名为 orchestrate_agents,旧名归一到新名。
    "dispatch_subagent": "orchestrate_agents",
}


def _suggest_close_tool(name: str, limit: int = 3) -> list[str]:
    """未知工具的近似候选推荐(did-you-mean):别名/大小写/分隔符差异 + 模糊匹配。

    工具清单上百个时直接铺全清单=信息淹没,这里只回 Top-N 真正可能被误写的名字。
    """
    import difflib as _dl

    def _norm(s: str) -> str:
        return _normalize_tool_name(s.strip()).lower().replace("-", "_")

    candidates = sorted(_TOOL_HANDLERS.keys())
    norm_t = _norm(name)
    if not norm_t:
        return []
    norm_map = {_norm(c): c for c in candidates}
    if norm_t in norm_map:
        return [norm_map[norm_t]]
    scored = sorted(
        ((_dl.SequenceMatcher(None, norm_t, _norm(c)).ratio(), c) for c in candidates),
        key=lambda x: (-x[0], x[1]),
    )
    return [c for ratio, c in scored[:limit] if ratio >= 0.62]


def _normalize_tool_name(name: str) -> str:
    """工具名归一化:优先映射别名,否则原样返回。"""
    return _TOOL_ALIASES.get(name, name)


# ---------------------------------------------------------------------------
# 工具定义 deferral(瘦身)数据层(2026-09-02 立)
# ---------------------------------------------------------------------------
# 把"完整工具 schema"与"放进 LLM 上下文的精简定义"解耦:默认(TOOL_DEFERRAL=on)
# 下,agent loop 把"压缩描述 + 分层参数"(内置/桥接完整保留,api_* 长尾保留键名/类型/
# required、只删字段 description)塞进上下文,模型需要被删掉的字段说明时通过内置
# get_tool_schema 工具按需拉取,遵循统一工程规范
# 自动 deferral)。本注册表是两来源(内置 _TOOLS / 外部 register_external_tool)的统一落点。
_DEFERRED_TOOL_SCHEMAS: dict[str, dict[str, Any]] = {}


def _register_deferred_schema(tool: MCPTool) -> None:
    """把单个工具的完整 schema 写入 deferral 注册表(name → 完整 schema)。"""
    _DEFERRED_TOOL_SCHEMAS[tool.name] = {
        "name": tool.name,
        "description": tool.description,
        "input_schema": tool.input_schema,
    }


def _populate_deferred_schemas() -> None:
    """把当前 _TOOLS 全部内置工具的完整 schema 批量灌入注册表(幂等)。

    在模块加载、_TOOLS 彻底构建完成后调用一次;外部工具走 register_external_tool
    各自增量写入,二者共同保证注册表覆盖两来源。重复调用安全(后者覆盖前者)。
    """
    for t in _TOOLS:
        _register_deferred_schema(t)


def get_full_tool_schema(name: str) -> dict[str, Any] | None:
    """返回 deferral 注册表中某工具的完整 schema(name/description/input_schema)。

    name 不存在返回 None。供内置 get_tool_schema 工具与 agent loop 的按需展开复用。

    D145 评审修复轮 1①:这条面**也是**一条广告面。TOOL_DEFERRAL=on 时模型只看到被截断的
    骨架,完整描述只能经本函数反查(`_tool_get_tool_schema` → routers/agents.py 的工具清单),
    所以带 provider 的工具必须在返回时现读同一份 `_ADVERTISED_DESCRIPTION_PROVIDERS` ——
    原样交回 import 期快照等于向模型广告 0 个可用名。返回浅拷贝:注册表里那份仍是
    import 期的完整 schema 真相,回写它会让两条面各自漂移(deferral 的 input_schema 不动)。
    """
    name = _normalize_tool_name(name)
    entry = _DEFERRED_TOOL_SCHEMAS.get(name)
    if entry is None:
        return None
    provider = _ADVERTISED_DESCRIPTION_PROVIDERS.get(name)
    if provider is None:
        return entry
    return {**entry, "description": provider()}


def list_deferred_tool_names() -> list[str]:
    """返回当前已登记完整 schema 的工具名列表(排序,输出稳定)。"""
    return sorted(_DEFERRED_TOOL_SCHEMAS.keys())


async def _tool_get_tool_schema(arguments: dict[str, Any]) -> dict[str, Any]:
    """get_tool_schema: 返回指定工具的完整参数 schema(deferral 反查入口,只读)。

    模型在工具定义被 deferral 精简后,用本工具按 name 取回完整 input_schema/描述,
    再决定是否调用该工具。name 为空或不存在均返回 ok=False 并附带可用工具名清单。
    """
    name = str(arguments.get("name", "")).strip()
    if not name:
        return {"ok": False, "error": "name 不能为空(get_tool_schema 需要目标工具名)"}
    schema = get_full_tool_schema(name)
    if schema is None:
        return {
            "ok": False,
            "error": f"未找到工具: {name}",
            "available": list_deferred_tool_names(),
        }
    # 缺口表 #7:反查面与列表面同尺。被能力门摘掉的工具若在这里照旧交回完整 schema,
    # 模型会拿到一份"看起来能调、一调就被拒"的定义 —— 那正是 D145 那一型双广告面漂移。
    # 这里给具名回执(不是"未找到":工具在注册表里,只是本次调用方形态无权使用)。
    _denial = _tool_capability_denial(name)
    if _denial is not None:
        return {"ok": False, "tool": name, "schema": None, **_denial}
    return {"ok": True, "tool": name, "schema": schema}


# ---------------------------------------------------------------------------
# 教育管理工具(edu_* 2026-09-19 立,读 8 + 写 6):经 internal service token
# 调用 api /api/edu-ai-management/* 端点。权限由 api 侧 RBAC 对真实聊天用户
# 兜底(edu:view 读 / edu:manage 写);不入 _ADMIN_ONLY_TOOLS(对话链
# user_role=0,入名单即断链,同 image_generation 2026-09-08 先例)。
# 身份链路:web 主链 llm.py call_tool(user_id=owner_uuid) 直通 __user_id;
# conversation 链 _execute_tool_call 传入 _resolve_user_id(sid) 解析结果。
# ---------------------------------------------------------------------------
_EDU_API_BASE_URL = os.environ.get("API_SERVICE_URL", "http://localhost:8802").rstrip("/")


def _edu_internal_headers(user_id: Any) -> dict[str, str]:
    """edu 工具调 api 的鉴权头:走 ``app/core/internal_ticket.py`` 的
    ``internal_service_headers`` 唯一出口(默认 ticket 档发票;显式 dual/legacy 档才
    同时带旧 ``x-internal-service-token``);api 侧校验后把 X-User-Id 注入
    request.userId 供 requireAnyPermission 的 RBAC 对真实用户兜底。

    票与常驻密钥是两把互不替代的凭据:默认 ticket 档下只要 ``JWT_SECRET`` 配好就能
    发票,不再把 ``AI_CALLBACK_SECRET`` 当"发不发头"的前提(那会让纯票部署被判成
    无凭据)。两者都拿不到、或身份不合法 ⇒ 返回 {},调用方不发请求。"""
    uid = str(user_id or "").strip()
    if not uid or not re.fullmatch(r"[a-zA-Z0-9-]{1,128}", uid):
        return {}
    secret = os.environ.get("AI_CALLBACK_SECRET", "").strip()
    return internal_service_headers(uid, "mcp-edu", legacy_token=secret)


def _edu_query_params(args: dict[str, Any], keys: tuple[str, ...]) -> dict[str, Any]:
    """从 handler args 挑选非空字段组装参数(过滤 None/空串,丢弃 __ 前缀内部键)。"""
    params: dict[str, Any] = {}
    for key in keys:
        value = args.get(key)
        if value not in (None, ""):
            params[key] = value
    return params


def _edu_coerce_amount(body: dict[str, Any]) -> dict[str, Any] | None:
    """把 amount 归一为整数(元);非法返回错误 dict,None 表示成功。"""
    if "amount" not in body:
        return None
    try:
        body["amount"] = int(float(body["amount"]))
    except (TypeError, ValueError):
        return {"ok": False, "error": "amount 必须为数字(单位:元)"}
    return None


async def _edu_api_request(
    method: str,
    path: str,
    *,
    user_id: Any,
    params: dict[str, Any] | None = None,
    json_body: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """edu 工具统一 HTTP 出口:调 api 并剥 success() 壳({code,message,data})。

    2xx → {ok: True, **data};非 2xx → {ok: False, error, errorCode}。
    鉴权头缺失(既签不出内部票也没有旧密钥 / 无用户身份)时直接返回可读错误,
    不发请求。
    """
    import httpx

    headers = _edu_internal_headers(user_id)
    if not headers:
        return {
            "ok": False,
            "error": "内部服务凭证不可用(既签不出内部票,也没有旧密钥)或用户身份缺失,无法调用教育管理接口",
            "errorCode": "INTERNAL_AUTH_UNAVAILABLE",
        }
    url = f"{_EDU_API_BASE_URL}/api/edu-ai-management{path}"
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.request(method, url, headers=headers, params=params, json=json_body)
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": f"教育管理接口请求失败: {e}", "errorCode": "NETWORK_ERROR"}
    try:
        payload = resp.json()
    except Exception:  # noqa: BLE001
        payload = {}
    if resp.status_code < 400:
        data = payload.get("data") if isinstance(payload, dict) else None
        if isinstance(data, dict):
            return {"ok": True, **data}
        return {"ok": True, "data": data}
    message = payload.get("message") if isinstance(payload, dict) else None
    return {
        "ok": False,
        "error": str(message) if message else f"教育管理接口返回 HTTP {resp.status_code}",
        "errorCode": f"HTTP_{resp.status_code}",
    }


async def _tool_edu_list_students(args: dict[str, Any]) -> dict[str, Any]:
    """edu_list_students: 学员名册检索(姓名/手机号 → enrollmentId/studentId 解析)。"""
    params = _edu_query_params(args, ("keyword", "businessLine", "classId", "termId", "page", "pageSize"))
    return await _edu_api_request("GET", "/student-roster", user_id=args.get("__user_id"), params=params)


async def _tool_edu_list_arrears(args: dict[str, Any]) -> dict[str, Any]:
    """edu_list_arrears: 欠费学员名单(totalFee > paidAmount)。"""
    params = _edu_query_params(args, ("keyword", "businessLine", "classId", "termId", "page", "pageSize"))
    params["arrearsOnly"] = "true"
    return await _edu_api_request("GET", "/student-roster", user_id=args.get("__user_id"), params=params)


async def _tool_edu_list_fee_reminders(args: dict[str, Any]) -> dict[str, Any]:
    """edu_list_fee_reminders: 催费发送记录查询。"""
    params = _edu_query_params(args, ("studentId", "classId", "channel", "page", "pageSize"))
    return await _edu_api_request("GET", "/fee-reminder", user_id=args.get("__user_id"), params=params)


async def _tool_edu_list_payment_records(args: dict[str, Any]) -> dict[str, Any]:
    """edu_list_payment_records: 缴费流水查询。"""
    params = _edu_query_params(args, ("studentId", "classId", "status", "page", "pageSize"))
    return await _edu_api_request("GET", "/payment-record", user_id=args.get("__user_id"), params=params)


async def _tool_edu_payment_summary(args: dict[str, Any]) -> dict[str, Any]:
    """edu_payment_summary: 缴费汇总(实收/已缴人数/欠费人数/欠费总额)。"""
    params = _edu_query_params(args, ("classId", "termId"))
    return await _edu_api_request("GET", "/payment-record/summary", user_id=args.get("__user_id"), params=params)


async def _tool_edu_list_refunds(args: dict[str, Any]) -> dict[str, Any]:
    """edu_list_refunds: 退费记录查询(pending/approved/rejected)。"""
    params = _edu_query_params(args, ("studentId", "classId", "status", "page", "pageSize"))
    return await _edu_api_request("GET", "/refund-record", user_id=args.get("__user_id"), params=params)


async def _tool_edu_list_tuition_fees(args: dict[str, Any]) -> dict[str, Any]:
    """edu_list_tuition_fees: 学费标准查询。"""
    params = _edu_query_params(args, ("classId", "termId", "page", "pageSize"))
    return await _edu_api_request("GET", "/tuition-fee", user_id=args.get("__user_id"), params=params)


async def _tool_edu_my_bills(args: dict[str, Any]) -> dict[str, Any]:
    """edu_my_bills: 当前聊天用户(家长)自己的报名与最近缴费。"""
    return await _edu_api_request("GET", "/my-bills", user_id=args.get("__user_id"))


async def _tool_edu_send_fee_reminder(args: dict[str, Any]) -> dict[str, Any]:
    """edu_send_fee_reminder: 单发催费(站内信必达,wechat 渠道尽力外发)。"""
    body = _edu_query_params(args, ("enrollmentId", "channel", "message"))
    if "enrollmentId" not in body:
        return {"ok": False, "error": "enrollmentId 不能为空(可用 edu_list_students/edu_list_arrears 查得)"}
    return await _edu_api_request("POST", "/fee-reminder", user_id=args.get("__user_id"), json_body=body)


async def _tool_edu_send_fee_reminder_batch(args: dict[str, Any]) -> dict[str, Any]:
    """edu_send_fee_reminder_batch: 批量催费(1-100 条,无欠费/不存在自动跳过)。"""
    ids = args.get("enrollmentIds")
    if not isinstance(ids, list) or not ids:
        return {"ok": False, "error": "enrollmentIds 必须为非空 ID 数组(1-100 个)"}
    body: dict[str, Any] = {"enrollmentIds": [str(i) for i in ids]}
    body.update(_edu_query_params(args, ("channel", "message")))
    return await _edu_api_request("POST", "/fee-reminder/batch", user_id=args.get("__user_id"), json_body=body)


async def _tool_edu_create_payment_record(args: dict[str, Any]) -> dict[str, Any]:
    """edu_create_payment_record: 登记缴费记录(amount 单位元)。

    归属只认 enrollmentId(=哪一期报名)。api 侧同一契约:报名行是唯一权威,
    自报的 studentId/classId 仅用于一致性校验,不一致直接拒 ——
    让模型/调用方自报归属等于把钱记到别人账上。
    """
    body = _edu_query_params(
        args,
        ("enrollmentId", "studentId", "classId", "feeId", "amount", "paymentDate", "paymentMethod", "status", "receiptNo", "remark"),
    )
    missing = [k for k in ("enrollmentId", "amount", "paymentDate", "paymentMethod") if k not in body]
    if missing:
        return {"ok": False, "error": f"缺少必填字段: {', '.join(missing)}(enrollmentId 可用 edu_list_students 或 edu_list_arrears 查得)"}
    err = _edu_coerce_amount(body)
    if err:
        return err
    return await _edu_api_request("POST", "/payment-record", user_id=args.get("__user_id"), json_body=body)


async def _tool_edu_create_refund(args: dict[str, Any]) -> dict[str, Any]:
    """edu_create_refund: 创建退费申请(pending 待审批;amount 单位元)。"""
    body = _edu_query_params(
        args,
        ("studentId", "classId", "paymentId", "amount", "refundDate", "refundMethod", "reason"),
    )
    missing = [k for k in ("studentId", "classId", "amount", "refundDate", "reason") if k not in body]
    if missing:
        return {"ok": False, "error": f"缺少必填字段: {', '.join(missing)}(studentId/classId 可用 edu_list_students 查得)"}
    err = _edu_coerce_amount(body)
    if err:
        return err
    return await _edu_api_request("POST", "/refund-record", user_id=args.get("__user_id"), json_body=body)


_EDU_RESOURCE_ID_RE: Final[re.Pattern[str]] = re.compile(r"^[A-Za-z0-9_-]{1,64}$")


def _edu_resource_id_denial(value: str, field: str) -> dict[str, Any] | None:
    """AIS-110:edu 资源 id 直接拼进上游 URL 路径(`f"/refund-record/{refund_id}/approve"`)。

    旧码只判空 ⇒ `refundId="../../admin/x"` 会把上游请求带到别的路径。id 只允许
    字母/数字/`-`/`_`(退费号/学号形态),其余一律在本地拒绝,一次上游都不发。
    """
    if _EDU_RESOURCE_ID_RE.match(value):
        return None
    logger.warning("[mcp][edu] 非法资源 id 被拒(AIS-110): field=%s", field)
    return {
        "ok": False, "errorCode": "INVALID_ARGUMENT",
        "error": f"{field} 只允许字母/数字/-/_ 且长度 ≤ 64",
    }


async def _tool_edu_approve_refund(args: dict[str, Any]) -> dict[str, Any]:
    """edu_approve_refund: 审批通过退费(pending → approved)。"""
    refund_id = str(args.get("refundId") or "").strip()
    if not refund_id:
        return {"ok": False, "error": "refundId 不能为空(可用 edu_list_refunds(status=pending) 查得)"}
    denial = _edu_resource_id_denial(refund_id, "refundId")
    if denial is not None:
        return denial
    body = _edu_query_params(args, ("approveRemark",))
    return await _edu_api_request(
        "PUT", f"/refund-record/{refund_id}/approve", user_id=args.get("__user_id"), json_body=body
    )


async def _tool_edu_reject_refund(args: dict[str, Any]) -> dict[str, Any]:
    """edu_reject_refund: 驳回退费(pending → rejected)。"""
    refund_id = str(args.get("refundId") or "").strip()
    if not refund_id:
        return {"ok": False, "error": "refundId 不能为空(可用 edu_list_refunds(status=pending) 查得)"}
    denial = _edu_resource_id_denial(refund_id, "refundId")
    if denial is not None:
        return denial
    body = _edu_query_params(args, ("approveRemark",))
    return await _edu_api_request(
        "PUT", f"/refund-record/{refund_id}/reject", user_id=args.get("__user_id"), json_body=body
    )


# ---------------------------------------------------------------------------
# 工作簿 agent 面(workbook_* 2026-11-02 立,goal-b45 F 席)
# 遵循统一工程规范
# (取证 docs/benchmark-evidence/2026-11/qoder-trae-rea-20261101/T8-sidecar-native-surface.md §B)。
# 判据(归属 / 公式 / 形状)全部住在 apps/api src/services/workbook-service.ts —— 下面四枚
# handler 只做薄壳,零复算(§0.6)。身份只认宿主注入的 __user_id,并先过 resolve_caller
# 把开发降级身份归一成"无身份"(ROUTING_IDENTITY_KEYS 纪律:模型自报即越权);
# 拿不到主体 ⇒ 一次请求都不发。
# 与对照件分道的两格:① 保存**只落新档**,绝不原地覆盖用户原档;② **不做公式重算**,
# 因此公式单元格一律不回缓存值 —— 失效方向是"明说未重算",不是"悄悄给个旧数"(§0.3)。
# ---------------------------------------------------------------------------


async def _tool_workbook_open(args: dict[str, Any]) -> dict[str, Any]:
    """workbook_open:打开 api 侧**已存在**的工作簿,返回会话句柄 + 结构读数。"""
    from .workbook_agent import workbook_agent
    from .workflow_engine import resolve_caller

    out = await workbook_agent.open_workbook(
        file_id=str(args.get("file_id") or ""),
        user_id=resolve_caller(args.get("__user_id")),
    )
    return {"tool": "workbook_open", **out}


async def _tool_workbook_read_range(args: dict[str, Any]) -> dict[str, Any]:
    """workbook_read_range:按 A1 区域回格;公式格只回公式原文 + formula-uncomputed。"""
    from .workbook_agent import workbook_agent
    from .workflow_engine import resolve_caller

    out = await workbook_agent.read_range(
        handle=str(args.get("handle") or ""),
        sheet=str(args.get("sheet") or ""),
        cell_range=str(args.get("range") or ""),
        user_id=resolve_caller(args.get("__user_id")),
    )
    return {"tool": "workbook_read_range", **out}


async def _tool_workbook_write_cells(args: dict[str, Any]) -> dict[str, Any]:
    """workbook_write_cells:写单元格并**非破坏式落新档**(原档一字节不动)。"""
    from .workbook_agent import workbook_agent
    from .workflow_engine import resolve_caller

    # cells 原样透传(2026-11-02 N 席修):原先 `... if isinstance(cells, list) else []`
    # 把"模型给了个对象"折成空数组,客户端只能报"cells 不能为空"—— 结论换了个型,
    # 该改的方向也被带偏。形状判据单源在 apps/api,本层连"是不是数组"都不该替它判死。
    out = await workbook_agent.write_cells(
        handle=str(args.get("handle") or ""),
        sheet=str(args.get("sheet") or ""),
        cells=args.get("cells"),
        user_id=resolve_caller(args.get("__user_id")),
        name=str(args.get("name") or "") or None,
    )
    return {"tool": "workbook_write_cells", **out}


async def _tool_workbook_close(args: dict[str, Any]) -> dict[str, Any]:
    """workbook_close:释放会话(之后该句柄一律判「未判定」,不猜它当时改了啥)。"""
    from .workbook_agent import workbook_agent
    from .workflow_engine import resolve_caller

    out = await workbook_agent.close_workbook(
        handle=str(args.get("handle") or ""),
        user_id=resolve_caller(args.get("__user_id")),
    )
    return {"tool": "workbook_close", **out}


async def _tool_sandbox_session(
    arguments: dict[str, Any], cancel: asyncio.Event | None = None
) -> dict[str, Any]:
    """长寿命沙箱。判定与文件树都在 sandbox_lifecycle，这里只转一次。"""
    del cancel
    from app.services.sandbox_lifecycle import dispatch_sandbox_session

    payload = arguments if isinstance(arguments, dict) else {}
    return await dispatch_sandbox_session(payload)


_BROWSER_OBSERVE_MAX_LIMIT = 200


def _clamp_read_limit(value: Any, *, default: int = 50, maximum: int = _BROWSER_OBSERVE_MAX_LIMIT) -> int:
    """读取类工具的统一上限:非法输入回默认值,越界夹到 [1, maximum]。"""
    try:
        number = int(value)
    except (TypeError, ValueError):
        number = default
    return max(1, min(number, maximum))


def _browser_observe_target(
    arguments: dict[str, Any], tool_name: str
) -> tuple[Any | None, dict[str, Any] | None]:
    """观测类工具的公共前置:主体 → 会话(属主过滤)。

    console/network 都是**读取面**,用 `hub.get_session`(读出口)而不是 `require_tab`
    (动作面);但仍必须带主体,否则等同于"任何 token 都能读别人的页面日志"。
    会话不存在与无权访问同码同形,不给 session_id 探针。
    """
    from .agent_security_prefs import current_security_principal
    from .browser_hub import hub

    caller_uid = current_security_principal()
    if not caller_uid:
        return None, {
            "tool": tool_name,
            "ok": False,
            "error": "缺少调用者身份,拒绝读取他人浏览器会话",
            "errorCode": "PRINCIPAL_REQUIRED",
        }
    session_id = str(arguments.get("session_id") or "").strip()
    if not session_id:
        return None, {
            "tool": tool_name,
            "ok": False,
            "error": "缺少 session_id(浏览器会话 id)",
            "errorCode": "MISSING_SESSION_ID",
        }
    session = hub.get_session(session_id, caller_uid)
    if session is None:
        return None, {
            "tool": tool_name,
            "ok": False,
            "error": "浏览器会话不存在或无权访问",
            "errorCode": "SESSION_NOT_FOUND",
        }
    return session, None


async def _tool_browser_console_messages(arguments: dict[str, Any]) -> dict[str, Any]:
    """读取浏览器 console / 未捕获异常 / 浏览器日志(环形缓冲,有界)。"""
    session, error = _browser_observe_target(arguments, "browser_console_messages")
    if error is not None:
        return error
    # 契约:error 与 session 互斥 —— error 为 None 时必然给出了会话。mypy 看不到这层关联
    # (二元组的两个元素在类型上各自独立),显式断言把不变式写进类型面,而不是用类型忽略
    # 注释把门戳瞎(那样真接错属性时也不再有提示)。
    assert session is not None
    result = await session.console_messages(
        level=str(arguments.get("level") or "all"),
        limit=_clamp_read_limit(arguments.get("limit", 50)),
        text_contains=str(arguments.get("textContains") or ""),
    )
    return {"tool": "browser_console_messages", "sessionId": session.session_id, "ok": True, **result}


async def _tool_browser_network_requests(arguments: dict[str, Any]) -> dict[str, Any]:
    """读取浏览器已完成的网络请求(一条请求一行,未完成的不落库)。"""
    session, error = _browser_observe_target(arguments, "browser_network_requests")
    if error is not None:
        return error
    assert session is not None  # 同上:error/session 互斥
    raw_status = arguments.get("statusMin")
    try:
        status_min = int(raw_status) if raw_status not in (None, "") else None
    except (TypeError, ValueError):
        status_min = None
    result = await session.network_requests(
        limit=_clamp_read_limit(arguments.get("limit", 50)),
        url_contains=str(arguments.get("urlContains") or ""),
        method=str(arguments.get("method") or ""),
        status_min=status_min,
        failed_only=bool(arguments.get("failedOnly")),
    )
    return {"tool": "browser_network_requests", "sessionId": session.session_id, "ok": True, **result}


_DIAGNOSTIC_SEVERITIES = {"error": "Error", "warning": "Warning", "info": "Info", "hint": "Hint"}


async def _tool_get_diagnostics(arguments: dict[str, Any]) -> dict[str, Any]:
    """读取某文件的语言服务诊断。

    复用 `api/v1/lsp` 的既有判据(白名单工作区 + 文件 containment + 可用性),不另造
    一套 AST/编译;失败面按具名 errorCode 返回,不把服务器路径回显给模型。
    """
    from fastapi import HTTPException

    from ..api.v1.lsp import (
        LspClient,
        _assert_workspace_root,
        _check_lsp_available,
        _format_diagnostic,
        _resolve_file,
    )
    from .agent_security_prefs import current_security_principal

    tool = "get_diagnostics"
    if not current_security_principal():
        return {
            "tool": tool,
            "ok": False,
            "error": "缺少调用者身份,拒绝读取语言服务诊断",
            "errorCode": "PRINCIPAL_REQUIRED",
        }
    workspace = str(arguments.get("workspacePath") or arguments.get("workspace_path") or "").strip()
    file_value = str(arguments.get("file") or arguments.get("path") or "").strip()
    if not workspace or not file_value:
        return {
            "tool": tool,
            "ok": False,
            "error": "workspacePath 与 file 必填",
            "errorCode": "MISSING_ARGUMENTS",
        }
    try:
        _check_lsp_available()
        real_ws = _assert_workspace_root(workspace)
        file_path = _resolve_file(file_value, real_ws)
    except HTTPException as exc:
        detail = exc.detail
        if isinstance(detail, dict):
            detail = detail.get("detail") or detail.get("error") or detail
        return {
            "tool": tool,
            "ok": False,
            "error": str(detail)[:500],
            "errorCode": "WORKSPACE_REJECTED" if 400 <= exc.status_code < 500 else "LSP_UNAVAILABLE",
        }
    try:
        client = LspClient.get(real_ws)
        await client._ensure_started()
        raw = await client.get_diagnostics(file_path)
    except HTTPException as exc:
        return {"tool": tool, "ok": False, "error": str(exc.detail)[:500], "errorCode": "LSP_UNAVAILABLE"}
    except Exception as exc:  # noqa: BLE001 - LSP 运行时失败统一具名降级
        return {"tool": tool, "ok": False, "error": str(exc)[:500], "errorCode": "LSP_UNAVAILABLE"}
    formatted = [_format_diagnostic(item) for item in raw]
    wanted = _DIAGNOSTIC_SEVERITIES.get(str(arguments.get("severity") or "").strip().lower())
    if wanted:
        formatted = [item for item in formatted if item["severity"] == wanted]
    limit = _clamp_read_limit(arguments.get("limit", 100), default=100, maximum=500)
    return {
        "tool": tool,
        "ok": True,
        "workspacePath": real_ws,
        "file": file_value,
        "count": len(formatted),
        "errors": sum(1 for item in formatted if item["severity"] == "Error"),
        "warnings": sum(1 for item in formatted if item["severity"] == "Warning"),
        "diagnostics": formatted[:limit],
    }


_TOOL_HANDLERS: dict[str, Any] = {
    # ===== 工具定义 deferral 反查工具(2026-09-02 立)=====
    "get_tool_schema": _tool_get_tool_schema,
    "search_codebase": _tool_search_codebase,
    "list_symbol_definitions": _tool_list_symbol_definitions,
    "read_project_rule": _tool_read_project_rule,
    "list_project_rules": _tool_list_project_rules,
    "find_import_edges": _tool_find_import_edges,
    "index_codebase": _tool_index_codebase,
    "auto_rebuild_codebase": _tool_auto_rebuild_codebase,
    "knowledge_lookup": _tool_knowledge_lookup,
    "context_recall": _tool_context_recall,
    # V3 #63:对话流业务表单请求。主对话流由 llm.py 的拦截位处理(不进 call_tool);
    # 这里注册的是**其它执行路径**的兜底答复,同时满足
    # test_tools_count_matches_registry 的"定义 ↔ 处理函数"双射。
    "request_business_form": _tool_request_business_form,
    "read_file": _tool_read_file,
    "read_image": _tool_read_image,
    "read_tool_output": _tool_read_tool_output,
    "list_files": _tool_list_files,
    "render_repo_tree": _tool_render_repo_tree,
    "write_file": _tool_write_file,
    "apply_patch_set": _tool_apply_patch_set,
    "file_edit": _tool_file_edit,
    "run_command": _tool_run_command,
    "sandbox_session": _tool_sandbox_session,
    "terminal": _tool_terminal,
    "web_search": _tool_web_search,
    "image_search": _tool_image_search,
    "search_web": _tool_search_web,
    "analyze_code": _tool_analyze_code,
    "generate_test": _tool_generate_test,
    "file_search": _tool_file_search,
    "git_operations": _tool_git_operations,
    "db_query": _tool_db_query,
    # ===== 视频生成(2026-09-05 新增;2026-09-07 补注册——工具已定义但漏入此表,
    # _TOOLS 53 vs _TOOL_HANDLERS 52 失配,test_tools_count_matches_registry 拦截)=====
    "video_generation": _tool_video_generation,
    "music_generation": _tool_music_generation,
    "voice_tts": _tool_voice_tts,
    # ===== 文件上传(2026-09-09 全模态深度适配;视频参考素材/声纹/改图输入先传文件拿 URL)=====
    # ===== 图片编辑(2026-09-09 全模态深度适配)=====
    "image_edit": _tool_image_edit,
    # ===== 语音转文字 + 余额查询(2026-09-09 全模态深度适配)=====
    "audio_transcription": _tool_audio_transcription,
    # ===== 声纹克隆(2026-09-09 全模态深度适配;补注册——handler 已存在但漏入此表,
    # 导致对话链调工具永远"未知工具",test_tools_count_matches_registry 会拦截)=====
    # ===== AI 自动控制浏览器(12 个)=====
    "browser_screenshot": _make_agent_control_handler("browser", "screenshot"),
    "browser_click_element": _make_agent_control_handler("browser", "click_element"),
    "browser_type_text": _make_agent_control_handler("browser", "type_text"),
    "browser_scroll": _make_agent_control_handler("browser", "scroll"),
    "browser_extract_dom": _make_agent_control_handler("browser", "extract_dom"),
    "browser_navigate": _make_agent_control_handler("browser", "navigate"),
    "browser_wait_for_element": _make_agent_control_handler("browser", "wait_for_element"),
    "browser_get_attribute": _make_agent_control_handler("browser", "get_attribute"),
    "browser_hover": _make_agent_control_handler("browser", "hover"),
    "browser_select_option": _make_agent_control_handler("browser", "select_option"),
    "browser_switch_tab": _make_agent_control_handler("browser", "switch_tab"),
    "browser_close_tab": _make_agent_control_handler("browser", "close_tab"),
    # ===== 浏览器运行时观测(2026-11-08,后端 Browser Hub + CDP;非 extension 动作面)=====
    "browser_console_messages": _tool_browser_console_messages,
    "browser_network_requests": _tool_browser_network_requests,
    # ===== 语言服务诊断(2026-11-08,复用 api/v1/lsp 判据)=====
    "get_diagnostics": _tool_get_diagnostics,
    # ===== AI 自动控制电脑(10 个)=====
    "computer_screenshot_screen": _make_agent_control_handler("computer", "screenshot_screen"),
    "computer_mouse_move": _make_agent_control_handler("computer", "mouse_move"),
    "computer_mouse_click": _make_agent_control_handler("computer", "mouse_click"),
    "computer_keyboard_type": _make_agent_control_handler("computer", "keyboard_type"),
    "computer_mouse_scroll": _make_agent_control_handler("computer", "mouse_scroll"),
    "computer_keyboard_press": _make_agent_control_handler("computer", "keyboard_press"),
    "computer_keyboard_hotkey": _make_agent_control_handler("computer", "keyboard_hotkey"),
    "computer_active_window": _make_agent_control_handler("computer", "active_window"),
    "computer_clipboard_get": _make_agent_control_handler("computer", "clipboard_get"),
    "computer_clipboard_set": _make_agent_control_handler("computer", "clipboard_set"),
    # ===== 自动化任务配置(2026-07-22 新增)=====
    "configure_automation_task": _tool_configure_automation_task,
    # ===== 截图工具(2026-07-22 新增,WorkPanel iframe 降级)=====
    "screenshot_url": _tool_screenshot_url,
    # ===== 图像分析(P2-3,对齐 Hermes 多模态输入)=====
    "vision_analyze": _tool_vision_analyze,
    # ===== 子智能体编排(2026-07-24 新增;2026-11-16 模型面更名为 orchestrate_agents)=====
    # 旧名 dispatch_subagent 不占 handler 槽位:call_tool 先查 handler 失败后经
    # _TOOL_ALIASES 归一到本名,既保住 _TOOLS ↔ _TOOL_HANDLERS 一一对应,又兼容旧调用。
    "orchestrate_agents": _tool_dispatch_subagent,
    "subagent_job": _tool_subagent_job,
    # ===== D08①(2026-10-25):团队共享任务列表(与派发面同一协作域)=====
    "team_task": _tool_team_task,
    "session_search": _tool_session_search,
    # ===== 扩展工具(2026-07-24 新增,自研)=====
    "fetch_url": _tool_fetch_url,
    "image_generation": _tool_image_generation,
    "review_pr": _tool_review_pr,
    "summarize_artifacts": _tool_summarize_artifacts,
    # 显式交付声明(2026-11-14,对标 DSH dsh-tool-present):补"命令产物不进
    # filesChanged"的缺口;只登记不读盘,故不进 _ADMIN_ONLY_TOOLS / 委托面。
    "present_files": _tool_present_files,
    "schedule_task": _tool_schedule_task,
    # 定时任务工具面投影(2026-10-30 立):服务层早有 list_tasks/remove_task,
    # 此前只有创建动词 ⇒ 模型自建的任务看不见也撤不掉。
    # 与 schedule_task 同档(admin):任务记录无归属字段,且 remove_task 无归属校验,
    # 放给 role 0 = 跨用户枚举 + 任意撤销,比"看不见"更糟。
    "list_scheduled_tasks": _tool_list_scheduled_tasks,
    "cancel_scheduled_task": _tool_cancel_scheduled_task,
    "schedule_wakeup": _tool_schedule_wakeup,
    # 延迟唤醒(2026-10-31):定时面第四个动词"稍后叫我";入参只有 delay_seconds + prompt,
    # 调度判据仍走 _build_scheduler_params 单源,不另写一份。
    "proactive_suggestion": _tool_proactive_suggestion,
    # ===== P0 新增工具(2026-09-01,竞品对齐:图表生成 + 文档解析)=====
    "generate_chart": _generate_chart,
    # PROJECT_PLAN #81 最小一环:报表模板生成器(2026-09-28,与 chart 共用产物基础设施)
    "generate_report": _generate_report,
    # 财务部板块插件(RP-46,2026-11-12):AI 一键代账 / AI 一键报税(分阶段+实时进度回显)
    "ai_bookkeeping": _ai_bookkeeping,
    "ai_tax_filing": _ai_tax_filing,
    # 人事部→财务部交割(2026-11-13 立):生成某月薪资的财务交割凭证
    "ai_payroll_handoff": _ai_payroll_handoff,
    # 人事部 AI 工具(2026-11-21 实装):员工自助四枚 + 月度算薪一枚
    "hr_my_payroll": _hr_my_payroll,
    "hr_my_payroll_periods": _hr_my_payroll_periods,
    "hr_my_attendance": _hr_my_attendance,
    "hr_my_leaves": _hr_my_leaves,
    "hr_payroll_calc": _hr_payroll_calc,
    "hr_insurance_readiness": _hr_insurance_readiness,
    # 动作型财务/人事工具(2026-11-23 立):持久化账套、税务申报、人事生命周期、发薪闭环
    "finance_ledger_ops": _finance_ledger_ops,
    "finance_tax_ops": _finance_tax_ops,
    "hr_lifecycle_ops": _hr_lifecycle_ops,
    "hr_payout_ops": _hr_payout_ops,
    # 财务部五腿扩展(2026-11-13 立):一键报销 / 社保医保精算 / 个税专项附加
    "ai_reimbursement": _ai_reimbursement,
    "social_insurance_calc": _social_insurance_calc,
    "special_deduction_calc": _special_deduction_calc,
    # G3 Beyond-Coding 泛化(2026-10-30 立):统一交付物工具
    "create_artifact": _create_artifact,
    # G2 Automations 产品闭环(2026-10-30 立):对话式创建定时自动化(调 apps/api 端点)
    "create_automation": _create_automation,
    "parse_document": _parse_document,
    # G1(2026-11-14):表格公式重算/校验(与 _TOOLS 同名条目双射)
    "sheet_formula_eval": _sheet_formula_eval,
    "sheet_formula_validate": _sheet_formula_validate,
    # D07 残余②:AGENTS.md 草稿生成(默认不落盘,写盘须显式 output_path;
    # workspace_root 经 MCP 面校验后才下传,见 _init_agents_md_guarded)
    "init_agents_md": _init_agents_md_guarded,
    # ===== P1 文档资产/表格(2026-09-09,anydoc 文档模型极致融合)=====
    "extract_document_assets": _extract_document_assets,
    "document_tables": _document_tables,
    # ===== Web 网络抓取(Firecrawl Scrape/Map/Crawl/Extract 极致融合, 2026-09)=====
    "fetch_readable": _fetch_readable,
    "map_site": _map_site,
    "crawl_site": _crawl_site,
    "extract_web": _extract_web,
    # ===== 后台任务工具(Phase 1 第 6 项 · 2026-09-02 立)=====
    "run_in_background": _tool_run_in_background,
    "bg_task_status": _tool_bg_task_status,
    # ===== 补丁冲突处理(1-2 · 2026-09-08):3-way merge 局部拒绝 =====
    "resolve_conflict": _tool_resolve_conflict,
    # ===== D11 浏览器自检截图(2026-09)=====
    "browser_selfcheck_screenshot": _tool_browser_selfcheck_screenshot,
    "browser_selfcheck": _tool_browser_selfcheck,
    # ===== 教育管理(edu_* 2026-09-19,读 8 + 写 6;internal token → api RBAC 兜底)=====
    "edu_list_students": _tool_edu_list_students,
    "edu_list_arrears": _tool_edu_list_arrears,
    "edu_list_fee_reminders": _tool_edu_list_fee_reminders,
    "edu_list_payment_records": _tool_edu_list_payment_records,
    "edu_payment_summary": _tool_edu_payment_summary,
    "edu_list_refunds": _tool_edu_list_refunds,
    "edu_list_tuition_fees": _tool_edu_list_tuition_fees,
    "edu_my_bills": _tool_edu_my_bills,
    "edu_send_fee_reminder": _tool_edu_send_fee_reminder,
    "edu_send_fee_reminder_batch": _tool_edu_send_fee_reminder_batch,
    "edu_create_payment_record": _tool_edu_create_payment_record,
    "edu_create_refund": _tool_edu_create_refund,
    "edu_approve_refund": _tool_edu_approve_refund,
    "edu_reject_refund": _tool_edu_reject_refund,
    # ===== 工作流动作(G-01 补齐腿之二,2026-10-31 立;与上面三枚 _TOOLS 声明同批双射,
    # 漏一枚即 test_tools_count_matches_registry 红)=====
    "workflow_trigger": _tool_workflow_trigger,
    "workflow_resume": _tool_workflow_resume,
    "workflow_instance_status": _tool_workflow_instance_status,
    # 代码库调查 + 点名消息(G-11 / G-07,2026-10-31 立;与上面三枚 _TOOLS 声明同批双射)
    "investigate_codebase": _tool_investigate_codebase,
    "send_team_message": _tool_send_team_message,
    "read_team_inbox": _tool_read_team_inbox,
    # 会话寻址投递(G-07 第二形态,2026-10-31 立;与上方 _TOOLS 声明同批双射)
    "send_to_session": _tool_send_to_session,
    # Notebook 结构编辑(G-NotebookEdit,2026-11-01 立;与上方 _TOOLS 声明同批双射)
    "notebook_edit": _tool_notebook_edit,
    "advisor_consult": _tool_advisor_consult,
    # 工作流续跑(G-独立分析对齐,2026-11-02 立;与上方 _TOOLS 声明同批双射)
    "run_workflow": _tool_run_workflow,
    # 工作簿 agent 面(goal-b45 F 席,2026-11-02 立;与上方四枚 _TOOLS 声明同批双射,
    # 漏一枚即 test_tools_count_matches_registry 红。判据全在 apps/api,这里只是薄壳)
    "workbook_open": _tool_workbook_open,
    "workbook_read_range": _tool_workbook_read_range,
    "workbook_write_cells": _tool_workbook_write_cells,
    "workbook_close": _tool_workbook_close,
    # Qoder 行为对齐(2026-11-08):与上方三枚 _TOOLS 声明同批双射;
    # 漏一侧即 test_tools_count_matches_registry 红。
    "skill": _tool_skill,
    "todo_write": _tool_todo_write,
    "todo_read": _tool_todo_read,
    "ask_user_question": _tool_ask_user_question,
}


# 外部注入工具名单(2026-09-02 立,P2-1):register_external_tool 注册成功的工具名集合,
# 供卸载/停用时精确清理(_TOOLS/_TOOL_HANDLERS 还含大量本地工具,不能整表操作)。
# 同名工具已被占用时 register 返回 False,不进入本集合。
_EXTERNAL_TOOL_NAMES: set[str] = set()


def register_external_tool(tool: MCPTool, handler: Any) -> bool:
    """注册外部 MCP 工具(2026-09-01 立,stdio bridge 注入外部 server 工具用)。

    自研工具注册表(_TOOLS + _TOOL_HANDLERS)是唯一权威工具来源,LLM tool schema、
    mcp_official 协议层、agent loop 均从这里读取。外部 stdio MCP server 发现工具后,
    通过本函数把远程工具包装成内部 MCPTool + 转发 handler 注入注册表,复用既有
    权限矩阵与调用链,LLM 无需感知工具是本地实现还是外部子进程。

    幂等:同名工具已注册(handler 已存在)时返回 False 且不覆盖,防止多个 stdio
    server 或本地工具被外部工具同名覆盖。

    Args:
        tool: 待注册的 MCPTool(名称/描述/input_schema 来自外部 server 的 list_tools)
        handler: async (arguments: dict) -> dict 转发 handler,与本地工具 handler 同签名

    Returns:
        True=注册成功;False=同名工具已存在,跳过
    """
    if tool.name in _TOOL_HANDLERS:
        return False
    _TOOLS.append(tool)
    _TOOL_HANDLERS[tool.name] = handler
    _EXTERNAL_TOOL_NAMES.add(tool.name)
    # 同步写入 deferral 注册表:外部工具也需可被 get_tool_schema 反查完整 schema。
    _register_deferred_schema(tool)
    return True


def unregister_external_tools(names: list[str] | set[str] | tuple[str, ...]) -> list[str]:
    """按精确工具名批量移除外部注入的工具(2026-09-02 立,P2-1)。

    只清理由 register_external_tool 注入的工具(_EXTERNAL_TOOL_NAMES 名单内的),
    不触碰本地工具表;从 _TOOLS / _TOOL_HANDLERS / _EXTERNAL_TOOL_NAMES 三个容器
    同步移除。幂等:目标名不存在或非外部注入时静默跳过。

    Args:
        names: 待移除的外部工具名(可迭代;空集合/未安装名均安全)

    Returns:
        实际移除的工具名列表
    """
    target = {n for n in names if n}
    removed = sorted(n for n in target if n in _EXTERNAL_TOOL_NAMES)
    if not removed:
        return []
    for n in removed:
        _EXTERNAL_TOOL_NAMES.discard(n)
        _TOOL_HANDLERS.pop(n, None)
        _DEFERRED_TOOL_SCHEMAS.pop(n, None)
    _TOOLS[:] = [t for t in _TOOLS if t.name not in removed]
    return removed


def unregister_external_tool_by_prefix(prefix: str) -> list[str]:
    """按工具名前缀批量移除外部注入的工具(2026-09-02 立,P2-1,幂等)。

    供按 server 维度清理:外部 server 注入的工具名以统一前缀命名时,传前缀即可
    批量移除;否则调用方应改用 unregister_external_tools(精确名单)。

    Args:
        prefix: 工具名前缀(如 "mcp:filesystem__")

    Returns:
        实际移除的工具名列表
    """
    target = [n for n in _EXTERNAL_TOOL_NAMES if n.startswith(prefix)]
    return unregister_external_tools(target)


def list_external_tools_injected() -> list[str]:
    """返回当前由 register_external_tool 注入的外部工具名列表(2026-09-02 立,P2-1)。

    只含外部注入且注册成功的工具,不含本地工具;按名排序保证输出稳定。
    """
    return sorted(_EXTERNAL_TOOL_NAMES)


# ---------------------------------------------------------------------------
# 资源(3 个)
# ---------------------------------------------------------------------------

_RESOURCES: list[MCPResource] = [
    MCPResource(
        uri="memory://current",
        name="current_memory",
        description="当前会话记忆",
    ),
    MCPResource(
        uri="skills://available",
        name="available_skills",
        description="可用 skill 列表",
    ),
    MCPResource(
        uri="config://agent",
        name="agent_config",
        description="agent 配置",
    ),
]


# ---------------------------------------------------------------------------
# 提示词(3 个)
# ---------------------------------------------------------------------------

_PROMPTS: list[MCPPrompt] = [
    MCPPrompt(
        name="code_review",
        description="代码审查提示词",
        arguments=[
            {"name": "code", "description": "待审查的代码", "required": True},
            {"name": "language", "description": "代码语言", "required": False},
        ],
    ),
    MCPPrompt(
        name="bug_fix",
        description="Bug 修复提示词",
        arguments=[
            {"name": "error", "description": "错误信息", "required": True},
            {"name": "code", "description": "相关代码", "required": True},
            {"name": "language", "description": "代码语言", "required": False},
        ],
    ),
    MCPPrompt(
        name="feature_plan",
        description="功能规划提示词",
        arguments=[
            {"name": "feature", "description": "功能描述", "required": True},
            {"name": "requirements", "description": "详细需求", "required": False},
        ],
    ),
]


def _render_prompt(name: str, arguments: dict[str, Any]) -> str:
    """根据 name 和 arguments 渲染提示词模板。"""
    language = arguments.get("language", "未指定")
    if name == "code_review":
        return (
            "请审查以下代码,关注质量、bug、安全与最佳实践:\n\n"
            f"语言: {language}\n代码:\n```\n{arguments.get('code', '')}\n```"
        )
    if name == "bug_fix":
        return (
            "请根据错误信息修复代码:\n\n"
            f"语言: {language}\n错误:\n{arguments.get('error', '')}\n\n"
            f"代码:\n```\n{arguments.get('code', '')}\n```\n"
            "输出: 根因分析 + 修复方案 + 修复后代码"
        )
    if name == "feature_plan":
        return (
            "请规划以下功能的实现方案:\n\n"
            f"功能: {arguments.get('feature', '')}\n"
            f"需求: {arguments.get('requirements', '(无)')}\n\n"
            "输出: 技术方案、任务拆解、风险点、验收标准"
        )
    return f"未知提示词: {name}"


# ---------------------------------------------------------------------------
# MCPServer
# ---------------------------------------------------------------------------


class MCPServer:
    """MCP 服务端,统一管理工具/资源/提示词的查询与调用。"""

    def list_tools(
        self, *, surface_context: _SurfaceRoundContext | None = None
    ) -> list[MCPTool]:
        """列出本轮可见工具;批58(w3):on 时把延迟工具命名空间声明并入清单。

        off 时直接返回 list(_TOOLS)(逐字节等价);on 时仅追加由 world_state_tools
        归一化出的延迟工具条目,不改动既有 _TOOLS。

        缺口表 ⑤(2026-11-05,工具面惰性装载):`surface_context` 是**本轮上下文**
        (会话模式 / 已声明意图 / 上轮用过与被拒的工具名)。它缺席时本轴整体不生效 ⇒
        既有调用点(把它们当**查找表**用:先按 agent_tools 收窄再 `tool_map.get(name)`)
        一条都不会少拿。真正的收口只发生在有人显式交入上下文、或部署侧设了
        `MCP_TOOL_SURFACE_BUDGET` 那一格 —— 且判不了时仍按全量交回(失效方向=多给)。
        """
        tools: list[MCPTool] = list(_TOOLS)
        # D145① + 评审修复轮 1①:广告名单在**每次现读注册表**时拼接,而不是 import 期烘死。
        # 凡登记进 `_ADVERTISED_DESCRIPTION_PROVIDERS` 的工具都走同一条出口 —— 与
        # get_full_tool_schema()(TOOL_DEFERRAL=on 时模型唯一的完整描述来源)**同源**,
        # 否则两条广告面会各自漂移:本票的原病灶正是"清单面修了、反查面仍是骨架"。
        # 判据/反向对照见 _DISPATCH_SUBAGENT_DESC_CORE 定义处注释。
        # 重建对象而非原地改,避免污染 _TOOLS。
        for i, t in enumerate(tools):
            provider = _ADVERTISED_DESCRIPTION_PROVIDERS.get(t.name)
            if provider is None:
                continue
            tools[i] = MCPTool(
                name=t.name,
                description=provider(),
                input_schema=t.input_schema,
            )
        if (
            _mcp_world_state_tools_enabled_from_env()
            and _MCP_WORLD_STATE_DEFERRED_NAMESPACES
        ):
            try:
                from app.core.world_state_tools import ToolsState

                _state = ToolsState(_MCP_WORLD_STATE_DEFERRED_NAMESPACES)
                for _ns, _desc in _state.deferred_namespaces.items():
                    tools.append(
                        MCPTool(
                            name=f"deferred:{_ns}",
                            description=_desc,
                            input_schema={"type": "object", "properties": {}},
                        )
                    )
            except Exception as e:  # noqa: BLE001 - 合并失败绝不改变工具清单
                logger.warning("world_state_tools 合并失败(降级跳过): %s", e)
        # 缺口表 #7(2026-11-01,对齐对侧 products.<form> 能力表):列表面收口。
        # 零扰动:未设任何 env 时声明族的能力键都取台账默认(开),本步与入参逐字同序同集
        # (tests/test_tool_surface_gate.py ① 是反向对照,不是口头保证)。
        # `deferred:<ns>` 一族不命中任何族前缀 ⇒ 不受影响。
        gated = _filter_visible_tools(tools)
        # 缺口表 ⑤(2026-11-05,工具面惰性装载):能力门**在前**,预算**在后** ⇒ 被能力
        # 门摘掉的工具绝不因预算重新出现(次序在消费点显式可读,不靠被调方自觉;
        # tool_surface_budget 同时把它作为 ineligible 下传,双保险)。
        # 只在"有人交入本轮上下文"或"部署侧设了 MCP_TOOL_SURFACE_BUDGET"时才动集合,
        # 其余一律逐字交回 —— 上面的 `tool_map.get(name)` 型消费点因此一条都不会少拿。
        return _apply_tool_surface_budget(gated, context=surface_context)

    async def call_tool(
        self,
        name: str,
        arguments: dict[str, Any] | None = None,
        *,
        user_role: int = 0,
        user_id: str | None = None,
        session_id: str | None = None,
        credit_balance: int | None = None,
        credit_approval: str | None = None,
    ) -> dict[str, Any]:
        """调用指定工具(带权限矩阵校验)。

        Args:
            name: 工具名
            arguments: 工具参数
            user_role: 调用者角色 ID(0=普通用户,>=1=admin)。admin 专属工具
                       需 user_role >= 1,其他工具所有用户可用。
            user_id: 调用者用户 ID(可选)。从 FastAPI request 上下文注入,
                     供 knowledge_lookup 查 long_term_memory 源(跨会话历史)。
                     service 层(agent_loop/orchestrator/conversation)无 request 上下文,
                     传 None 时 _tool_knowledge_lookup 跳过 LTM(与 G5 旧行为一致)。
            session_id: 会话 ID(可选)。供 knowledge_lookup 限定 RAG 检索会话范围。
        """
        handler = _TOOL_HANDLERS.get(name)
        if not handler:
            # 2026-08-06 修复:LLM 返回的别名工具名归一化后再查(execute_command → run_command)
            normalized = _normalize_tool_name(name)
            if normalized != name:
                handler = _TOOL_HANDLERS.get(normalized)
                name = normalized
        if not handler:
            # V3 #47 第二格(2026-09-26):引擎内核(AgentEngine)自带的内置名此前在主链路
            # 一律得到「未知工具」—— 同一能力在注册表里另有正式名,于是"C 的工具在 A/B 调不到"
            # 就是这条分裂本身。现经**唯一解析出口** `resolve_engine_tool` 归到注册表那一份实现:
            # 先认注册表本身,再经能力桥回查(桥表里登记的等价物必须真注册,否则不解析)。
            # 关键是解析发生在 `_ADMIN_ONLY_TOOLS` 判定**之前** —— 否则 unified_exec 这类
            # "起 shell"的名字会在归口后绕过角色矩阵(那是 fail-open)。
            resolved = resolve_engine_tool(name)
            if resolved is not None:
                handler = _TOOL_HANDLERS.get(resolved)
                if handler:
                    # 归口是"名字换了、执行的是注册表那一份",留一行可诊断痕迹;
                    # 静默换名与 §5e「失败必须响」同一条禁令(只是这里是成功路径,故 info)。
                    logger.info("[mcp] 引擎内置名归口: %s → %s", name, resolved)
                name = resolved
        if not handler:
            # 可纠错回执(体验优化):工具清单很长,直接铺全会淹没真正有用的信息,
            # 先给最近似的几个候选;匹配不上才回退全量清单。
            suggestions = _suggest_close_tool(name)
            message = f"未知工具: {name}"
            if suggestions:
                message += f"。是否想调用: {' / '.join(suggestions)}"
            else:
                message += f"。可用: {', '.join(sorted(_TOOL_HANDLERS.keys()))}"
            return {
                "ok": False,
                "error": message,
                "suggestions": suggestions,
                "available": sorted(_TOOL_HANDLERS.keys()),
            }
        # 权限矩阵:admin 专属工具(write_file/run_command/db_query/computer_* 等)
        # 普通用户(user_role < 1)调用 → 直接拒绝,不执行 handler
        if name in _ADMIN_ONLY_TOOLS and user_role < 1:
            return {
                "ok": False,
                "error": f"工具 '{name}' 需要 admin 权限(role >= 1),当前 role={user_role}",
                "errorCode": "PERMISSION_DENIED",
            }
        # 缺口表 #7:能力门具名拒绝。位置刻意选在这里 ——
        # ① 在角色矩阵**之后** ⇒ 普通用户调 admin 工具仍先拿 PERMISSION_DENIED(既有行为零扰动,
        #    也不因能力门提前泄露"这枚工具存在且有能力要求");
        # ② 在 handler 查找**之后** ⇒ 不把"未知工具"改写成"能力不足"(两件事不许同形);
        # ③ 在 `try:` **之前** ⇒ 被摘掉的工具绝不进入执行链(测试③ 断言零副作用)。
        _capability_denial = _tool_capability_denial(name)
        if _capability_denial is not None:
            return dict(_capability_denial)
        # 注:Skill 的 allowed-tools 是**授权**不是收窄(Qoder 原文见 skill_scope.py
        # 头注),消费点在 AgentLoopV2 的审批门;这里刻意不插任何拒绝分支 ——
        # 角色矩阵/能力门/路径校验仍是硬边界,授权不许在工具出口改写它们。
        try:
            # Wave 8:注入 __user_role 供 handler 内的写操作权限校验使用
            # (git_operations 写操作在 handler 内部做 defense-in-depth 校验)
            # G6(2026-07-26):同时注入 __user_id/__session_id 供 knowledge_lookup
            # 查 long_term_memory 源(从 FastAPI request 上下文透传,LLM 不可控)
            from ..core.mcp_tool_approval import apply_host_credit_facts

            args_with_role = apply_host_credit_facts(
                arguments,
                balance=credit_balance,
                approval=credit_approval,
            )
            args_with_role["__user_role"] = user_role
            args_with_role["__user_id"] = user_id
            args_with_role["__session_id"] = session_id
            # D201:会话级附加目录注入 —— handler 与其 await 链同处一个 asyncio task,
            # ContextVar 对整个 handler 执行期生效;finally 复位防异常路径泄漏到复用
            # 该 task 的后续协程(漏复位 = A 会话的附加根污染 B 会话的校验)。
            # 2026-11-01:键含已验证主体 —— 只取本次调用主体的登记,不取"会话 id 相同
            # 的任意用户登记"(conversationId 是客户端自报字段)。
            _extra_roots_token = _ACTIVE_SESSION_EXTRA_ROOTS.set(
                get_session_extra_roots(session_id, user_id=user_id)
            )
            # 2026-10-21(五开关按用户生效):把**承载层已验证的主体**发布进安全档位
            # 作用域,handler 及其 await 链同处一个 asyncio task ⇒ `_tool_run_command`
            # 在策略评估处读得到"谁在调"。来源只有这一个形参(由 routers/mcp.py 从
            # request.state.user_id 即 JWT 注入);`args_with_role["__user_id"]` 是给
            # handler 内部既有逻辑用的旧通道,本档位链**不读它** —— 入参形状是模型可填面。
            # 空主体不覆盖已有主体(见 set_security_principal):agent_loop_v2 已经把它那轮
            # 的主体发布过,这里传 None 只表示"这条通道没带主体",不该把已证明的降回无。
            with security_principal_scope(user_id):
                # 2026-07-22 P1 鲁棒性加固:全局超时,防 handler 无限挂起
                try:
                    result = await asyncio.wait_for(
                        handler(args_with_role), timeout=MCP_GLOBAL_TIMEOUT
                    )
                finally:
                    _ACTIVE_SESSION_EXTRA_ROOTS.reset(_extra_roots_token)
            # 2026-09-09 媒体任务统一落库:对话内媒体工具(video/music/tts/image/改图)
            # 提交即持久化到 media_tasks,支撑"我的媒体任务"查询/取消;DB 异常仅告警,
            # 绝不阻断对话主流程(与 video_generation_tasks 并存:该表是 REST 视频任务队列)。
            try:
                from .media_tasks import persist_media_task

                await persist_media_task(
                    name,
                    result if isinstance(result, dict) else {},
                    user_uuid=user_id or "",
                    chat_id=session_id or "",
                )
            except Exception:  # noqa: BLE001
                logger.warning("[mcp] 媒体任务落库异常(忽略): tool=%s", name)
            # 0-2 出口统一输出护栏:token 上限截断(保持结构与控制字段完整)
            return _truncate_tool_output(result, tool_name=name, session_id=session_id)
        except TimeoutError:
            logger.warning(
                "[mcp] 工具执行超时: tool=%s timeout=%ss", name, MCP_GLOBAL_TIMEOUT
            )
            return {
                "ok": False,
                "error": f"工具 {name} 执行超时({MCP_GLOBAL_TIMEOUT}s)",
                "errorCode": "TIMEOUT",
            }
        except Exception:
            # AIS-057:原始异常只入日志,回执按 handler 契约给 errorCode 并脱敏,
            # 避免内部路径/配置经 error 文本回灌模型或前端。
            logger.warning("[mcp] 工具执行失败: tool=%s", name, exc_info=True)
            return {
                "ok": False,
                "error": f"工具 {name} 执行失败(内部错误)",
                "errorCode": "TOOL_FAILED",
            }

    def list_resources(self) -> list[MCPResource]:
        """列出全部资源。"""
        return list(_RESOURCES)

    async def read_resource(self, uri: str) -> dict[str, Any]:
        """读取指定 URI 的资源内容。"""
        if uri == "memory://current":
            from .agent_security_prefs import current_security_principal
            from .memory import memory_store

            # 2026-10-31 安全强化第 14 批:此前不传 user_id ⇒ list_sessions 回全站会话,
            # 再逐个回读最近 10 条消息 —— 任何登录用户读一次资源就拿到别人的对话内容。
            # 主体取宿主注入的 security principal(与工具执行同一出口),取不到一律拒。
            principal = current_security_principal()
            if not principal:
                return {
                    "uri": uri,
                    "content": None,
                    "ok": False,
                    "error": "缺少调用者身份,拒绝读取会话记忆",
                }
            sessions = await memory_store.list_sessions(user_id=principal)
            data: dict[str, Any] = {"sessions": sessions}
            for sid in sessions[:5]:
                # key 形态必须与 list_sessions 的过滤前缀一致(memory:{uid}:{sid}),
                # 否则读的是另一个 key 空间(旧实现依赖"不带前缀 = 全站"那条路)。
                data[sid] = await memory_store.get(sid, limit=10, user_id=principal)
            return {"uri": uri, "content": data, "ok": True}
        if uri == "skills://available":
            skills = skill_registry.list_skills()
            return {
                "uri": uri,
                "content": [
                    {"name": s.name, "description": s.description} for s in skills
                ],
                "ok": True,
            }
        if uri == "config://agent":
            from ..core.config import settings

            return {
                "uri": uri,
                "content": {
                    "app_name": settings.app_name,
                    "litellm_model": settings.litellm_model,
                    "max_agent_iterations": settings.max_agent_iterations,
                    "debug": settings.debug,
                },
                "ok": True,
            }
        if uri == "sampling://handler":
            return {
                "uri": uri,
                "content": sampling_handler.get_stats(),
                "ok": True,
            }
        return {"uri": uri, "content": None, "ok": False, "error": f"未知资源 URI: {uri}"}

    def list_prompts(self) -> list[MCPPrompt]:
        """列出全部提示词。"""
        return list(_PROMPTS)

    def invoke_prompt(self, name: str, arguments: dict[str, Any] | None = None) -> dict[str, Any]:
        """调用指定提示词,返回渲染后的 prompt 文本。"""
        prompt_names = {p.name for p in _PROMPTS}
        if name not in prompt_names:
            return {"ok": False, "error": f"未知提示词: {name}。可用: {', '.join(prompt_names)}"}
        return {"name": name, "prompt": _render_prompt(name, arguments or {}), "ok": True}

    # =========================================================================
    # Sampling(反向调用 LLM,P1-3)
    # =========================================================================

    def list_sampling_capabilities(self) -> dict[str, Any]:
        """列出 Sampling 能力(供 MCP 客户端发现 sampling/createMessage)。"""
        return {
            "uri": "sampling://handler",
            "name": "sampling_handler",
            "description": (
                "MCP Sampling 反向调用:让 MCP 工具请求 LLM 推理(createMessage)。"
                "5 层护栏:速率限制 / 模型白名单 / 工具调用轮数 / 超时 / 审计日志。"
            ),
            "guardrails": sampling_handler.get_stats()["guardrails"],
        }

    async def call_sampling(self, request: dict[str, Any]) -> dict[str, Any]:
        """处理 MCP Sampling 请求(反向让 MCP 工具调用 LLM)。

        Args:
            request: McpSamplingRequest 字典(callerTool/messages/model/maxTokens/
                     temperature/context)。

        Returns:
            McpSamplingResponse 字典(content/model/usage/blocked/blockedReason)。
        """
        return await sampling_handler.handle_sampling(request)


mcp_server = MCPServer()

# 模块加载末段:把全部内置工具(含本文件新增的 get_tool_schema)的完整 schema 灌入
# deferral 注册表。外部工具在 register_external_tool 时各自增量写入,二者共同覆盖两来源。
_populate_deferred_schemas()


# ---------------------------------------------------------------------------
# SamplingHandler — MCP Sampling 反向调用处理器(5 层护栏,P1-3)
# ---------------------------------------------------------------------------


class SamplingHandler:
    """MCP Sampling 反向调用处理器(5 层护栏)。

    让 MCP 工具能反向请求 LLM 推理(sampling/createMessage)。
    对齐 packages/types 的 McpSamplingRequest/Response/Guardrails 契约。
    """

    # 默认护栏配置(对齐 McpSamplingGuardrails 类型)
    DEFAULT_GUARDRAILS: dict[str, Any] = {
        "rate_limit_rpm": 10,       # 速率限制 10 RPM
        "model_whitelist": [],      # 空白名单=允许所有(非空时只允许白名单内模型)
        "max_tool_rounds": 5,       # 单个 callerTool 最大调用轮数
        "timeout_seconds": 30,      # LLM 调用超时
        "audit_log": True,          # 审计日志
    }

    def __init__(self, guardrails: dict[str, Any] | None = None) -> None:
        self._guardrails: dict[str, Any] = {
            **self.DEFAULT_GUARDRAILS, **(guardrails or {})
        }
        self._call_timestamps: list[float] = []  # 滑动窗口速率限制
        self._audit_logs: list[dict[str, Any]] = []

    async def handle_sampling(self, request: dict[str, Any]) -> dict[str, Any]:
        """处理 MCP Sampling 请求。

        Args:
            request: McpSamplingRequest 字典(callerTool/messages/model/maxTokens/
                     temperature/context)。

        Returns:
            McpSamplingResponse 字典(content/model/usage/blocked/blockedReason)。

        5 层护栏:
        1. 速率限制:滑动窗口检查 RPM
        2. 模型白名单:request.model 非空且白名单非空时校验
        3. 工具调用轮数:记录每个 callerTool 的成功调用次数,超限拦截
        4. 超时:asyncio.wait_for 包装 llm_gateway.complete
        5. 审计日志:记录每次调用(callerTool/model/timestamp/blocked)
        """
        import asyncio
        import time
        from datetime import datetime

        from ..core.llm_gateway import llm_gateway

        # 1. 速率限制(滑动窗口 60s)
        now = time.monotonic()
        self._call_timestamps = [t for t in self._call_timestamps if now - t < 60]
        if len(self._call_timestamps) >= self._guardrails["rate_limit_rpm"]:
            return {
                "content": "", "model": "", "usage": None,
                "blocked": True, "blockedReason": "rate_limit_exceeded",
            }

        # 2. 模型白名单
        model = request.get("model")
        whitelist = self._guardrails["model_whitelist"]
        if model and whitelist and model not in whitelist:
            return {
                "content": "", "model": model or "", "usage": None,
                "blocked": True, "blockedReason": "model_not_whitelisted",
            }

        # 3. 工具调用轮数(用 audit_logs 统计每个 callerTool 的成功次数)
        caller = request.get("callerTool", "unknown")
        caller_count = sum(
            1 for log in self._audit_logs
            if log.get("callerTool") == caller and not log.get("blocked")
        )
        if caller_count >= self._guardrails["max_tool_rounds"]:
            return {
                "content": "", "model": model or "", "usage": None,
                "blocked": True, "blockedReason": "max_tool_rounds_exceeded",
            }

        # 记录时间戳(通过速率检查后才记录)
        self._call_timestamps.append(now)

        # 4. 超时调用 LLM
        messages = request.get("messages", [])
        try:
            result = await asyncio.wait_for(
                llm_gateway.complete(messages, model=model),
                timeout=self._guardrails["timeout_seconds"],
            )
            content = str(result.get("content", "") or "")
            used_model = str(result.get("model", model or "") or "")
            usage = result.get("usage")

            # 5. 审计日志
            if self._guardrails["audit_log"]:
                self._audit_logs.append({
                    "callerTool": caller,
                    "model": used_model,
                    # 等价替代弃用的 datetime.utcnow()（naive UTC 语义不变，2026-09-19 技术债清理）
                    "timestamp": datetime.now(UTC).replace(tzinfo=None).isoformat(),
                    "blocked": False,
                    "context": str(request.get("context", ""))[:200],
                })
            return {
                "content": content,
                "model": used_model,
                "usage": usage,
                "blocked": False,
            }
        except TimeoutError:
            if self._guardrails["audit_log"]:
                self._audit_logs.append({
                    "callerTool": caller,
                    "model": model or "",
                    "timestamp": datetime.now(UTC).replace(tzinfo=None).isoformat(),
                    "blocked": True,
                    "blockedReason": "timeout",
                })
            return {
                "content": "", "model": model or "", "usage": None,
                "blocked": True, "blockedReason": "timeout",
            }
        except Exception as e:
            return {
                "content": "", "model": model or "", "usage": None,
                "blocked": True, "blockedReason": f"error: {e}",
            }

    def get_audit_logs(self) -> list[dict[str, Any]]:
        """获取审计日志。"""
        return list(self._audit_logs)

    def get_stats(self) -> dict[str, Any]:
        """获取统计信息。"""
        return {
            "total_calls": len(self._audit_logs),
            "blocked_calls": sum(1 for log in self._audit_logs if log.get("blocked")),
            "guardrails": dict(self._guardrails),
        }


sampling_handler = SamplingHandler()
# ⁠​‌​​‌​​‌‍‍​‌​​‌​​​‍‍​‌​‌​‌​‌‍‍​‌​​‌​​‌‍‍​​‌​‌‌​‌‍‍​‌​​​​​‌‍‍​‌​​‌​​‌‍‍‌​‌‌​‌‌‌‍‍‌‌​​‌‌​​‌‌‌‌​‌​‍‍‌‌​‌‌​​​‌​​​‌‌‌‍‍​‌​​​​​‌‍‍​‌​​‌​​‌‍‍‌​‌‌​‌‌‌‍‍‌‌​​‌‌‌​‌​​‌‌‌​‍‍‌‌​​‌‌​​​‌​​‌​‌‍‍‌​‌‌‌​‌‌‌​‌‌‌​‌‍‍‌​‌‌​‌‌‌‍‍​‌​​‌‌​​‍‍​‌​​​​‌‌‍‍‌​‌‌​‌‌‌‍‍​‌‌​​​​‌‍‍​‌‌​‌​​‌‍‍​‌‌‌‌​‌​‍‍​‌‌​‌​​​‍‍​‌‌‌​​‌‌‍‍​​‌​‌‌‌​‍‍​‌‌‌​‌​​‍‍​‌‌​‌‌‌‌‍‍​‌‌‌​​​​‍‍‌​‌‌​‌‌‌‍‍​‌​‌​​​​‍‍​‌​‌​​‌​‍‍​‌​​‌‌‌‌‍‍​‌​‌​‌‌​‍‍​‌​​​‌​‌‍‍​‌​​‌‌‌​‍‍​‌​​​​​‌‍‍​‌​​‌‌‌​‍‍​‌​​​​‌‌‍‍​‌​​​‌​‌‍‍​​‌​‌‌​‌‍‍​​‌‌​​‌​‍‍​​‌‌​​​​‍‍​​‌‌​​‌​‍‍​​‌‌​‌‌​⁠
