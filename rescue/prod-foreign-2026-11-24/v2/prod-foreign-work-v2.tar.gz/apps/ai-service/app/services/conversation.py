# © 2026 IHUI AI (智汇AI) · 版权所有者: 李春川 (Li Chunchuan) · https://aizhs.top
# Provenance-watermarked. 未授权商用可被溯源追责 (Apache-2.0 须保留本声明与 NOTICE)。
# [IHUI-AI-PROVENANCE]:⁠​‌​​‌​​‌‍‍​‌​​‌​​​‍‍​‌​‌​‌​‌‍‍​‌​​‌​​‌‍‍​​‌​‌‌​‌‍‍​‌​​​​​‌‍‍​‌​​‌​​‌‍‍‌​‌‌​‌‌‌‍‍‌‌​​‌‌​​‌‌‌‌​‌​‍‍‌‌​‌‌​​​‌​​​‌‌‌‍‍​‌​​​​​‌‍‍​‌​​‌​​‌‍‍‌​‌‌​‌‌‌‍‍‌‌​​‌‌‌​‌​​‌‌‌​‍‍‌‌​​‌‌​​​‌​​‌​‌‍‍‌​‌‌‌​‌‌‌​‌‌‌​‌‍‍‌​‌‌​‌‌‌‍‍​‌​​‌‌​​‍‍​‌​​​​‌‌‍‍‌​‌‌​‌‌‌‍‍​‌‌​​​​‌‍‍​‌‌​‌​​‌‍‍​‌‌‌‌​‌​‍‍​‌‌​‌​​​‍‍​‌‌‌​​‌‌‍‍​​‌​‌‌‌​‍‍​‌‌‌​‌​​‍‍​‌‌​‌‌‌‌‍‍​‌‌‌​​​​‍‍‌​‌‌​‌‌‌‍‍​‌​‌​​​​‍‍​‌​‌​​‌​‍‍​‌​​‌‌‌‌‍‍​‌​‌​‌‌​‍‍​‌​​​‌​‌‍‍​‌​​‌‌‌​‍‍​‌​​​​​‌‍‍​‌​​‌‌‌​‍‍​‌​​​​‌‌‍‍​‌​​​‌​‌‍‍​​‌​‌‌​‌‍‍​​‌‌​​‌​‍‍​​‌‌​​​​‍‍​​‌‌​​‌​‍‍​​‌‌​‌‌​⁠

"""Conversation service — 对话编排服务。

完整的对话业务流程:
1. intent_classify: 意图分类(LLM 分析用户输入,识别 intent + entities + 需要 tool)
2. tool_select:     工具选择(基于意图 + 可用 tools 列表,选最相关的 N 个)
3. llm_call:       LLM 调用(OpenAI tools 格式,带 function calling)
4. tool_execute:   工具执行(解析 LLM 返回的 tool_calls,调用 MCP tools)
5. response:       汇总回复(把 tool 结果回灌 LLM,生成最终回复)

支持:
- 单轮对话(无 tool 走默认路径)
- 多轮 tool loop(LLM 决定调用工具 → 工具执行 → 结果回灌 → 再次 LLM)
- 滑动窗口 + intent 增强的 system prompt
- 完整 trace(每个阶段的耗时/输入/输出)
- stub 降级(无 API key 时返回固定响应)
"""

from __future__ import annotations

import asyncio
import json
import logging
import re
import time
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

from ..core.llm_gateway import llm_gateway
from .mcp_server import mcp_server
from .memory import memory_store
from .stage_telemetry import StageRecord, StageRecorder
from .tool_context_boundary import scan_and_frame_tool_result

logger = logging.getLogger(__name__)

# P1-2 并行工具执行:单轮最大并行数(防工具过多打爆),超出分批 gather
MAX_PARALLEL_TOOL_CALLS = 5

# 幂等只读工具:失败可安全重试 1 次(无副作用);写操作工具不重试
_RETRYABLE_TOOLS: frozenset[str] = frozenset({
    "web_search", "search_web", "knowledge_lookup", "read_file", "list_files",
    "file_search", "search_codebase", "analyze_code", "parse_document",
    "generate_chart", "summarize_artifacts",
})

# ---------------------------------------------------------------------------
# 全模态自动路由(2026-09-08):媒体模态强信号正则 → 无条件注入对应工具
# 兜底 LLM 意图分类漏判/幻觉 suggested_tools,保证"画一张/做个视频/写首歌/
# 朗读这段"永远能在 tool loop 里调到正确的媒体工具(自动切换多模态调用)。
# 仅做"工具可见性"注入,是否真正调用仍由 LLM tool_choice=auto 决策。
# ---------------------------------------------------------------------------
_MEDIA_INTENT_PATTERNS: dict[str, tuple[re.Pattern[str], ...]] = {
    "image_generation": (
        re.compile(r"(帮我|给我|给我来)?画(一|几)?(张|幅|个|下|只)"),
        re.compile(r"(画|绘)(出|一个|一幅|一张)"),
        re.compile(r"(生成|制作|做|来|设计)(一)?(张|幅|个)?[\s的]{0,2}(图片|图像|配图|插画|海报|头像|封面|图标|logo|吉祥物|表情包)"),
        re.compile(r"(图片|图像|海报|头像|插画|封面|logo|图标)的?(生成|绘制|设计)"),
        re.compile(r"\b(draw|paint|sketch|generate (an? )?(image|picture|photo)|create (an? )?(image|picture|logo))\b", re.IGNORECASE),
    ),
    "video_generation": (
        re.compile(r"(做|生成|制作|来|拍|帮我做)(一)?(个|段|部|条)?[^。]{0,8}视频"),
        re.compile(r"(视频|短片|动画片?|火柴人|MV)的?(生成|制作)|出片|视频生成"),
        re.compile(r"\b(make|generate|create) (a )?video\b", re.IGNORECASE),
        # 任务取件查询(2026-09-09):长任务提交后"视频好了吗"带 task_id 查询模式取件
        re.compile(r"(视频|视频任务|片子)(好了吗|好了没|好了么|做完了吗|生成完了吗|出来了吗)"),
        re.compile(r"出片(了吗|了没|了么)"),
    ),
    "music_generation": (
        re.compile(r"(写|做|来|创作|生成|帮我写)(一)?首?(歌|曲|音乐)"),
        re.compile(r"(写|创作|生成|帮我写)(一)?首[^。]{0,10}歌"),
        re.compile(r"(生成|制作|做|来)(一)?(个|段|首)?(音乐|配乐|背景音乐|BGM|纯音乐)"),
        re.compile(r"配乐|背景音乐|BGM|作曲|编曲|主题曲"),
        re.compile(r"\b(make|write|generate|compose) (a )?(song|music)\b", re.IGNORECASE),
        # 任务取件查询(2026-09-09):音乐长任务"歌好了吗"
        re.compile(r"(歌|音乐|音乐任务|曲子)(好了吗|好了没|好了么|做完了吗|生成完了吗|出来了吗)"),
    ),
    "voice_tts": (
        re.compile(r"朗读|读出来|念出来|配(个|段|一)?音|语音合成|转语音|播报|文字转语音|文本转语音"),
        re.compile(r"\b(text to speech|read (it |this )?aloud|speak (it )?out)\b", re.IGNORECASE),
    ),
    # 声纹克隆(2026-09-09 深能力补齐):上传参考音频克隆音色/列声纹库/查声纹详情
    # ---- 2026-09-09 全模态深度适配:理解/转写/账务 三类深能力入对话路由 ----
    "vision_analyze": (
        re.compile(r"(看|瞧|识别|分析|描述|解读)(一)?下?这(张|个|幅)?(图|图片|照片|截图|漫画|海报)"),
        re.compile(r"这(张|个|幅)?(图|图片|照片|截图)(里|中|上)?(有|是|画|写|说|讲|啥|什么)"),
        re.compile(r"(识别|提取|读取)(一)?下?(图|图里|图中|图片|截图)(里|中)?的?(文字|字|二维码|人脸|物体|内容)"),
        re.compile(r"(分析|描述|解释)(一)?下?(这|该)?(张|个|幅)?(图|图片|照片|截图)"),
        re.compile(r"\b(describe|analyze|what('?s| is) in) (this|the) (image|picture|photo|screenshot)\b", re.IGNORECASE),
    ),
    "audio_transcription": (
        re.compile(r"(录音|音频|语音|这段话|唱的?)(给)?(转|翻译|识别|听写|变成|写成)(成)?(文字|文本|字幕)"),
        re.compile(r"(转|识别|听写|提取)(成)?(文字|文本|字幕)"),
        re.compile(r"听写|转写"),  # ASR 专用词,独立强信号无误触
        re.compile(r"\b(transcribe|speech[- ]to[- ]text|audio[- ]to[- ]text)\b", re.IGNORECASE),
    ),
    # ---- 2026-09-09 全模态深度适配(二):改图 / 取消长任务 / 模型价目问答 ----
    "image_edit": (
        re.compile(r"(把|帮|给)?(我|这)?(张|个|幅)?(图|图片|照片|头像|封面)(给|帮我)?(改|编辑|修|换|去掉|去个|去除|加上|加个|改成|改成是|转成|变|P|修一下|处理)"),
        re.compile(r"(改|修|编辑|处理|调整|美化)(一)?下?(这|那)?(张|个|幅)?(图|图片|照片|头像|封面)"),
        re.compile(r"(去|去掉|移除|删掉|清除|抹去)(一)?(下)?(这)?(张)?(图|图片|照片)?(里|中|上)?的?(水印|背景|文字|logo|人物|物体)"),
        re.compile(r"(扩图|局部重绘|改图|修图|图片编辑|编辑图片|去水印|抠图|换背景|改背景|调色)"),
        re.compile(r"\b(edit|modify|retouch|photoshop|remove (watermark|background|text)) (this|the|my) (image|picture|photo)\b", re.IGNORECASE),
    ),
}

# 媒体工具结果渲染规范:注入 system,让 LLM 把工具返回的媒体 URL 以 Markdown
# 形式直接嵌入回复(对话即所得,前端无需二次处理;data URI 超长禁止回贴)。
_MEDIA_RENDER_PROMPT = (
    "媒体生成工具结果渲染规范(务必遵守):\n"
    "- image_generation / image_edit 成功且 image_url 是 http(s) 链接:必须在回复中用 "
    "![图片](image_url) 原样嵌入,让用户直接看到图片(改图结果同样处理)\n"
    "- video_generation 成功且 video_url 是 http(s) 链接:用 [▶️ 观看视频](video_url) 嵌入\n"
    "- music_generation 成功且 audio_url 是 http(s) 链接:用 [🎧 播放音乐](audio_url) 嵌入\n"
    "- voice_tts 的 audio_url 是 data URI(base64,超长):绝不要把 base64 内容贴进回复,"
    "只告知语音已生成可播放;有 saved_path 时一并告知\n"
    "- 返回 submitted=true 且带 task_id(视频/音乐长任务):明确告知任务已提交与预计耗时,"
    "提醒用户稍后让你用该 task_id 查询取件,严禁谎称已完成\n"
    "- ok=false 时如实告知失败原因与已尝试的 provider,不要编造链接"
)

# 跨模态链式编排 + 任务取件指引(2026-09-09 全模态深度适配):
# 让 LLM 会把媒体工具串起来用(图生视频/先理解后生成),并会用记忆里的
# task_id 完成长任务取件("视频好了吗"→ 带上轮 task_id 调查询模式)。
_MEDIA_CHAIN_PROMPT = (
    "跨模态链式编排(把媒体工具串起来完成复杂任务,务必善用):\n"
    "- 图生视频:用户要'让这张图动起来/把图做成视频'时,先调 image_generation 拿到 "
    "image_url,再把该 URL 作为 video_generation 的 image 参数提交(mode=first-frame);"
    "用户已给图片 URL 或上轮产物里有 image_url 时直接复用,不要重复生成\n"
    "- 先理解后生成:涉及用户提供的图片内容时,先 vision_analyze 理解,再按理解结果调用生成类工具\n"
    "- 转写后加工:先 audio_transcription 拿到文本,再做朗读/翻译/总结等后续工具调用\n"
    "- 改图:用户要'改/修/去水印/换背景'时用 image_edit(需待编辑图 URL/data URI,"
    "可复用上轮 image_generation 的 image_url;改前可先 vision_analyze 确认原图内容)\n"

    "- 长任务取件:会话历史(含 media_context)里出现 task_id 时,用户问"
    "'视频/音乐好了吗'直接带该 task_id 调对应工具(只传 task_id 即查询模式),"
    "严禁编造 task_id,严禁谎称已完成;完成后按渲染规范嵌入链接"
)

# ---- 2026-09-09 Firecrawl web 网络能力对话自动路由(极致融合补齐)----
# 强信号正则:命中 URL 抓取/整站/结构化抽取意图 → 无条件注入对应只读 web 工具。
# 仅含 fetch_readable / map_site / extract_web(crawl_site 递归爬取重操作,刻意在
# _ADMIN_ONLY_TOOLS,普通对话 user_role=0 不可调,故不进自动路由)。
_WEB_INTENT_PATTERNS: dict[str, tuple[re.Pattern[str], ...]] = {
    "fetch_readable": (
        re.compile(r"https?://\S+", re.IGNORECASE),
        re.compile(r"(读取|抓取|看看|看下|阅读|总结|概括|讲讲|介绍一下)(这|该|那个|这个)?(网页|网站|页面|网页内容|文章|博客|新闻|网址|链接)"),
        re.compile(r"(这|那个|这个|该)(篇|个|张)?(网页|网站|页面|文章|博客|新闻|内容)讲(了|着|的|什么|的是)"),
        re.compile(r"\b(fetch|read|parse|scrape)( this| the)? (url|page|webpage|site|article|link)\b", re.IGNORECASE),
    ),
    "map_site": (
        re.compile(r"(这|该|这个)(网站|站点|域名|网址)的?的?(结构|链接|页面|导航|有哪些|都有什么|目录|子页面|收录)"),
        re.compile(r"(看看|探查|了解|摸清|查看)(一)?(下)?(这个)?(网站|站点|域名)的?(结构|链接|页面|地图|有哪些|全貌)"),
        re.compile(r"(网站|站点|网址)?(地图|结构|链接|页面)?(是|有哪些|列一下|给我看|找一找|扫描一下)"),
        re.compile(r"\b(map|sitemap|site ?map|list (all )?urls? of) (this|the) (site|website|domain)\b", re.IGNORECASE),
    ),
    "extract_web": (
        re.compile(r"(提取|抽取|爬取|抓取|结构化|整理)(一)?(下)?(这|该|那个|这个)?(网页|网站|页面|网站里|页面里)的?(字段|价格|产品|信息|数据|表格|列表|参数|规格)"),
        re.compile(r"(从|在|把)(这|该|那个)?(网页|网站|页面)里(提取|抽取|扒|拿到|整理)(出)?(字段|价格|产品|信息|数据|一句话|要点)"),
        re.compile(r"(把|将)(这|该|那个|这个)?(网页|网站|页面)的?(字段|价格|信息|数据|内容|产品|规格|参数)(抽|提取|抽取|扒|整理)(出来|一下)?"),
        re.compile(r"帮我(列|整理|提取)出?(这|该)?(网页|网站|页面上)?的?(标题|价格|联系方式|信息|内容)"),
        re.compile(r"\b(extract|scrape) (structured )?(data|fields|info|prices?) from (this|the) (page|site)\b", re.IGNORECASE),
    ),
}

# ---- 2026-09-19 教育管理(edu_*)对话自动路由 ----
# 强信号正则:催费/欠费/缴费/退费/账单/学员等教育业务意图 → 无条件注入对应 edu 工具。
# 写操作同样进路由(LLM 侧有二次确认规范,api 侧 RBAC 兜底权限)。
_EDU_INTENT_PATTERNS: dict[str, tuple[re.Pattern[str], ...]] = {
    "edu_list_students": (
        re.compile(r"(学员|学生)(名单|列表|花名册|都在|有哪些|多少人|有几个)"),
        re.compile(r"(查一下|查询|看看|列出|找出)(在读|所有|全部)?(学员|学生)"),
    ),
    "edu_list_arrears": (
        re.compile(r"欠费|欠款|欠缴|未缴费|没缴费|还没交费|哪些人?没交"),
    ),
    "edu_list_fee_reminders": (
        re.compile(r"(催费|催缴|提醒)(记录|历史|情况|了哪些|发过)"),
    ),
    "edu_list_payment_records": (
        re.compile(r"(缴费|收款|支付)(记录|历史|流水|明细)"),
    ),
    "edu_payment_summary": (
        re.compile(r"(缴费|收款|学费|收入)(汇总|统计|情况|得怎么样)"),
    ),
    "edu_list_refunds": (
        re.compile(r"(退费|退款)(记录|历史|申请|列表|有哪些)"),
    ),
    "edu_list_tuition_fees": (
        re.compile(r"学费(标准|设置|价格|多少|收费)|收费标准|收费方案"),
    ),
    "edu_my_bills": (
        re.compile(r"我的(账单|缴费|欠费|学费)"),
    ),
    "edu_send_fee_reminder": (
        re.compile(r"(发|发送)(个|一条|一下)?(催费|催缴|缴费提醒)"),
        re.compile(r"给.{0,16}(发)?(催费|催缴|缴费提醒)"),
        re.compile(r"(提醒|通知)(家长|学员|学生)(缴费|交费)"),
    ),
    "edu_send_fee_reminder_batch": (
        re.compile(r"(批量|全部|一键|统一)(催费|催缴|提醒缴费)"),
    ),
    "edu_create_payment_record": (
        re.compile(r"(登记|录入|补录|记)(一?笔)?(缴费|收款|学费)"),
    ),
    "edu_create_refund": (
        re.compile(r"(办|办理|申请|发起|登记)(一?笔)?(退费|退款)"),
    ),
    "edu_approve_refund": (
        re.compile(r"(批准|同意|通过)(该|这笔|这个|那笔)?(退费|退款)"),
    ),
    "edu_reject_refund": (
        re.compile(r"(驳回|拒绝|否决)(该|这笔|这个|那笔)?(退费|退款)"),
    ),
}

# ---- 2026-09-20 AI 全量操控本站对话自动路由(web_ui_* + api_* 入口)----
# 强信号正则:用户要求"操控我们这个程序"(而非问答)→ 无条件注入前端 UI 动作工具
# 或后端 API 入口工具。命中即进 tool loop,不受 LLM 意图分类质量影响。
_UI_INTENT_PATTERNS: dict[str, tuple[re.Pattern[str], ...]] = {
    "web_ui_describe": (
        re.compile(r"(这个|当前|现在)?(页面|界面|后台|前端)(上)?(有|能)(哪些|什么|多少)(可操控|可操作|能操作|按钮|功能|操作|入口)"),
        re.compile(r"(你能|能不能|可以)(帮我)?(操作|控制|操控|驱动)(这个|咱们|我们|本站)?(程序|应用|系统|页面|前端|后台)"),
    ),
    "web_ui_read": (
        re.compile(r"(看|读|瞧|瞅|检查)(一)?(下)?(我|用户)?(当前|现在|这个|正)?(页面|界面|屏幕)(上|里)?(显示|有|的|存在)?(了|着)?(什么|内容|信息|状态)"),
        re.compile(r"(我|我们)(现在|当前)在(哪|什么)(页面|路由)|页面(显示|内容)是"),
    ),
    "web_ui_navigate": (
        re.compile(r"(打开|跳转|跳到|切到|切换到|进入|去|回到|导航到|带我到)(一下|下)?(我|你|这个|咱们的)?"
                   r"(设置|偏好设置|个人中心|我的?订单|钱包|充值|提现|订阅|会员|积分|团队|工作区|知识库|"
                   r"后台|管理|控制台|会话|聊天|首页|市场|插件|技能|工作流|代理|智能体|文档|报表|数据|"
                   r"账单|发票|通知|消息|权限|安全|模型配置|网关|API ?Key|回收站|草稿|发布|日历|看板)"),
        re.compile(r"(打开|跳转到|切到|进入)(这|那)?(个)?(页面|菜单|标签页|栏目)"),
        re.compile(r"\b(open|go to|navigate to|jump to) (the )?(settings|orders|dashboard|wallet|admin)\b", re.IGNORECASE),
    ),
    "web_ui_click": (
        re.compile(r"(点击|单击|双击|按一?下|按一下|按下|戳)(一下)?(那个?)?"
                   r"(保存|提交|确认|取消|新建|新增|添加|删除|编辑|搜索|刷新|上传|下载|导出|导入|发布|关闭|展开|收起|启用|禁用|同意|通过)?"
                   r"(按钮|入口|标签|选项|开关|链接|图标)"),
        re.compile(r"(帮|给)我(点|按)(一下)?(那个|这个)"),
        re.compile(r"\bclick( on)? (the )?(save|submit|new|delete|edit|confirm) button\b", re.IGNORECASE),
    ),
    "web_ui_fill": (
        re.compile(r"(填|填写|填入|填上|写|输入|录入|设置|改|修改)(一下|入)?(这个|那个|下面|对应)??"
                   r"(表单|输入框|文本框|搜索框|用户名|账号|邮箱|手机号|金额|数量|价格|标题|名称|备注|地址|密码|"
                   r"下拉框|选项|日期|时间|关键字|分类)"),
        re.compile(r"\b(fill|type|enter) (in )?(the )?(form|field|input|name|amount)\b", re.IGNORECASE),
        # "把充值金额填成 100" 这类把字句:字段名词在动词之前
        re.compile(r"把.{0,12}(金额|数量|价格|标题|名称|备注|邮箱|手机号|账号|用户名|关键字|地址|日期|时间|"
                   r"分类|选项|表单)(填|改成|改为|设为|设置为|填成|输入|写成)"),
        re.compile(r"(在|往)(这个|当前|下面)?(输入框|表单|搜索框|下拉框)(里|中)?(填|输入|写|选)"),
    ),
    "web_ui_submit": (
        re.compile(r"(提交|保存)(这个|那个|当前|一下)?(表单|页面|填写|内容|修改|草稿)"),
        re.compile(r"(填好了|录好了|写好了)(,|，)?(就)?(提交|保存)"),
    ),
    "web_ui_invoke": (
        # 模式名与"模式"之间可能有空格("切换到 plan 模式"),\s* 兼容
        re.compile(r"(切换|换|切)(到|成|为)?\s*(ask|build|plan|review|spec)?\s*(模式)"),
        re.compile(r"(打开|关闭|收起|展开)(一?下)?(AI ?)?(侧边栏|侧栏|面板|对话框|工作台|命令面板|工作区)"),
        re.compile(r"新建(一?个)?(会话|对话|任务|窗口)|清空(当前)?会话"),
    ),
    "api_endpoints_search": (
        # 动词与"接口/API"之间常有空格("调用 api 查一下"),\s* 兼容
        re.compile(r"(调用|请求|走|查|用)(一下|下)?\s*(后端|服务端|接口|API|api)(接口|端点)?"),
        re.compile(r"(系统|后台|数据库|平台)里(有|是)(多少|哪些|什么)"),
        # "用户"必须带业务宾语才算数据查询意图,否则"查一下用户认证的实现"这类
        # 代码问答会被误路由成后端接口调用
        re.compile(r"(列出|查一下|统计|看看)(所有|全部|最近的)?(用户(列表|名单|都有|有多少|数据|记录|信息)|订单|文章|商品|交易|工单|评论|团队|席位|模型|供应商|渠道|密钥)"),
        re.compile(r"\bcall (the )?(api|endpoint)\b", re.IGNORECASE),
    ),
}

# api_* 入口是"先搜后调"的一对,任一命中即两个一起注入(否则模型只能搜不能调)。
_API_ENTRY_TOOLS: tuple[str, ...] = ("api_endpoints_search", "api_endpoint_call")
# UI 动作类工具依赖 describe 返回的 actionId/target 清单,命中动作即补 describe。
_UI_ACTION_TOOLS: tuple[str, ...] = (
    "web_ui_click", "web_ui_fill", "web_ui_submit", "web_ui_invoke", "web_ui_navigate",
)

# 操控类工具结果呈现规范:注入 system,约束"操作型"工具的成功/失败表述。
_UI_RENDER_PROMPT = (
    "本站操控工具(web_ui_* / api_*)使用规范(务必遵守):\n"
    "- 先探后动:执行 click/fill/submit/invoke 前,若还没有本次会话的 web_ui_describe 结果,"
    "必须先调 web_ui_describe 拿准确的 target/id,不要凭猜测的元素名操作\n"
    "- 动作类工具返回 ok=true 只代表前端已执行,不代表业务写入成功(如表单可能校验失败);"
    "要确认结果就再调 web_ui_read 看页面状态,严禁未确认就声称已保存/已提交\n"
    "- DESTRUCTIVE_BLOCKED:该目标被前端安全黑名单拦截(删除/注销/提现/支付类),"
    "如实告知用户需其本人手动操作,严禁反复重试或改走其他路径绕过\n"
    "- ROUTE_NOT_ALLOWED:目标不在站内路由白名单,给出可用路由,不要硬凑 URL\n"
    "- TARGET_NOT_CONNECTED:说明用户前端(浏览器页面)未连接,引导其打开应用并保持登录,"
    "不要转而编造操作结果\n"
    "- api_endpoint_call 必须先有 api_endpoints_search 的 name;返回 ok=false 时如实转述 "
    "errorCode/error(权限不足/参数缺失等),严禁编造接口数据\n"
    "- 一次只推进一个 UI 动作并核对结果,不要连续盲发多个动作"
)

# 网页工具结果呈现规范:注入 system,让 LLM 把抓取到的正文/链接/结构化结果以可读方式呈现。
_WEB_RENDER_PROMPT = (
    "网页抓取工具结果呈现规范(务必遵守):\n"
    "- fetch_readable 成功:把 content 正文提炼成要点向用户汇报,标明来源 URL;"
    "不要原文整段搬运超长内容,truncated=true 时如实说明已截断\n"
    "- map_site 成功:以列表形式汇报重点链接(带锚文本),link_count 说明收录规模\n"
    "- extract_web 成功:逐字段列出抽取结果(字段=值);confidence 低(<0.5)的字段提醒『抽取置信度不高』\n"
    "- ok=false 时如实告知失败原因(SSRF_BLOCKED/FETCH_FAILED 等),不要编造网页内容"
)

# 教育管理工具(edu_*)使用规范(2026-09-19):读操作汇报要点,写操作必须二次确认。
_EDU_RENDER_PROMPT = (
    "教育管理工具(edu_*)使用规范:\n"
    "- 查询类(edu_list_*/edu_payment_summary/edu_my_bills):用表格或要点汇报关键数字"
    "(人数/金额,金额单位一律是元,不要换算单位),超长列表只摘前几条并说明总数\n"
    "- 写操作(edu_send_fee_reminder*/edu_create_*/edu_approve_refund/edu_reject_refund):"
    "调用前必须向用户复述将执行的操作与关键参数(给谁/金额/日期),得到确认后再调用;"
    "参数缺失时先向用户询问,或先用查询工具查得 ID,禁止凭空编造 ID/金额\n"
    "- ok=false 时如实告知失败原因(权限不足/参数错误等),禁止谎报成功"
)

# ---- 财务部(RP-46,2026-11-12)AI 一键代账/一键报税对话自动路由 ----
# 强信号正则:代账/记账凭证/结报销账类 → ai_bookkeeping;报税/申报/计税类 → ai_tax_filing。
# 与 apps/web 侧 use-chat/tool-config.ts FINANCE keywords 同思路(双保险):
# 命中即进 tool loop,不受 LLM 意图分类质量影响。
_FINANCE_INTENT_PATTERNS: dict[str, tuple[re.Pattern[str], ...]] = {
    "ai_bookkeeping": (
        re.compile(r"一键代账|代账|一键记账|自动记账|做账|帮我记账|登账"),
        re.compile(r"(记账|会计)凭证|生成(记账)?凭证|录入凭证"),
        re.compile(r"(试算|借贷)(平衡|平衡表)|科目余额表|账簿|结账|损益结转"),
        # 取数腿(RP-47):底账/回单类意图先并 ai_bookkeeping(它产 browser_* 取数计划)
        re.compile(r"发票底账|底账(查询|导出|取数)|勾选(确认|认证)|(取得|认证|抵扣).{0,4}发票"),
        re.compile(r"银行(回单|流水|对账单)|回单(下载|导出)|入金?流水导出"),
        re.compile(r"\b(bookkeep\w*|journal entr\w*|trial balance)\b", re.IGNORECASE),
    ),
    "ai_tax_filing": (
        re.compile(r"一键报税|报税|纳税申报|申报纳税|税费申报|个税申报|增值税申报|所得税申报"),
        re.compile(r"(计税|算税|测算.*(税|费)|税费(计算|测算))|(计算|算一下).*(增值税|个税|所得税|印花税)"),
        re.compile(r"申报表|纳税表|税表"),
        # 国标平台自动化腿(RP-47):电子税务局/社保医保申报缴费类意图
        re.compile(r"电子税务局|税务局.*(登录|申报|缴纳|提交)|(登录|上).?税务局"),
        re.compile(r"(社保|医保|公积金).*(申报|缴费|增减员|缴纳|办理)|(申报|缴费|增减员).{0,4}(社保|医保)"),
        re.compile(r"(增值税|所得税|个税).*(提交|申报提交|网上申报)|(提交|办理).{0,6}(增值税|所得税|个税)申报"),
        re.compile(r"\b(tax filing|file (my |the )?tax(es)?|tax return)\b", re.IGNORECASE),
        re.compile(r"\be-?tax|elektronische? belasting", re.IGNORECASE),
    ),
    # 财务部五腿扩展(2026-11-13):报销 / 社保精算 / 个税专项附加强信号
    "ai_reimbursement": (
        re.compile(r"一键报销|报销|报账|费用报销|差旅报销|招待费报销|报销单"),
        re.compile(r"进项(税额)?转出|借款冲销|费用分摊|差旅费(标准|限额)"),
        re.compile(r"\breimbursement\b", re.IGNORECASE),
    ),
    "social_insurance_calc": (
        re.compile(r"五险一金|社保(基数|精算|缴费|费用|滞纳金)|医保(基数|统筹|个人账户|缴费)"),
        re.compile(r"(公积金|养老保险|医疗保险|失业保险|工伤保险|生育保险).{0,6}(基数|缴费|比例|费率)"),
        re.compile(r"(社保|公积金)基数(调整|上下限|封顶|保底)|基数补差|跨年补缴"),
        re.compile(r"\bsocial insurance\b", re.IGNORECASE),
    ),
    "special_deduction_calc": (
        re.compile(r"专项附加(扣除)?|子女教育(扣除|抵扣)?|婴幼儿照护|继续教育(扣除|抵扣)?"),
        re.compile(r"大病医疗(扣除|抵扣)?|住房(贷款利息|租金)(扣除|抵扣)?|赡养老人(扣除|抵扣)?"),
        re.compile(r"扣除申报|个税扣除|七项扣除"),
    ),
}

# 财务部工具使用规范(注入 system):分阶段推进 + 绝不为配平改数 + 草案红线转述。
_FINANCE_RENDER_PROMPT = (
    "财务部插件(ai_bookkeeping / ai_tax_filing / ai_reimbursement / social_insurance_calc / "
    "special_deduction_calc)使用规范(务必遵守):\n"
    "- 先收资料:缺会计期间/流水/税额基数时先向用户索取,或用 parse_document、document_tables "
    "从上传发票与银行回单中抽取,禁止凭空编造金额\n"
    "- 分阶段推进:ai_bookkeeping 按 classify→voucher→trial_balance→close→report 依次调用"
    "(或 phase=all 串全程);每次把返回的 progress(第几阶段/共几阶段/下一步)同步更新到任务板,"
    "让用户实时看到代账进度;续下一阶段必须回传上一次输出的 state\n"
    "- ai_tax_filing 按 compute→validate→draft 依次调用;validate 勾稽校验报出的异常项必须"
    "逐条向用户列明,不得为了让报表数字好看而回改入参\n"
    "- 五腿协同(2026-11-13):报销先用 ai_reimbursement 出四维判定与分录草案,获认可后把分录"
    "并入 ai_bookkeeping transactions;社保医保用 social_insurance_calc 逐人精算,代扣合计直接"
    "喂工资表 social 字段;专项附加用 special_deduction_calc 逐人算七项,合计喂 special_deduction "
    "字段——三条腿产物都是草案,须复核后才入账\n"
    "- 诚实红线:VOUCHER_UNBALANCED / TRIAL_UNBALANCED 等不平错误要如实报差异;"
    "ok=false 时原样转述 errorCode 与 message,严禁假装已平、假装已报\n"
    "- 草案纪律:报税产物是申报表**草案**,必须转述「正式申报须纳税主体与执业资格人员复核,"
    "在电子税务局由纳税人自行提交」,本系统不代理对外申报;账务产物同理提示需执业会计复核\n"
    "- 国标平台自动化腿(RP-47):phase=automation 返回的步骤计划由你按序调用 browser_*(内置浏览器"
    "执行面)逐步执行,每步一张实时工具卡;原生社保/医保客户端步骤走 computer_*(高危:人在旁);"
    "先探后动——选择器/坐标一律 screenshot/extract_dom 探明再用,禁止臆造;"
    "TARGET_NOT_CONNECTED 引导用户打开已连接页面后断点续跑;portal 缺地址先问用户,绝不猜 URL\n"
    "- 提交闸(manual_gate 缺省=停在提交前一步由人来点;user_confirmed=向用户复述目标·期间·应缴额"
    "并获明示『确认』后才执行提交步;不存在静默 auto 提交),平台校验差异、验证码/人脸/U 盾一律"
    "如实转给人类完成,绝不为通过校验而改数或换路径绕过"
)


async def _execute_tool_call(
    tool_name: str,
    args: dict[str, Any],
    user_id: str | None = None,
    session_id: str | None = None,
) -> tuple[dict[str, Any], float]:
    """执行单个工具调用,返回 (result, duration_ms)。

    - 幂等只读工具首次失败时重试 1 次(写操作工具不重试)。
    - 异常归一化为 {"ok": False} 不向外抛 —— 保证并行批次中单工具失败
      不中断整体(asyncio.gather(return_exceptions=True) 兜底)。
    - user_id/session_id 透传给 mcp_server.call_tool(2026-09-19):
      edu_* 等需要真实聊天用户身份的工具依赖 __user_id 注入。
    """

    async def _once() -> tuple[dict[str, Any], float]:
        t1 = time.monotonic()
        try:
            result = await mcp_server.call_tool(
                tool_name, args, user_id=user_id, session_id=session_id
            )
        except Exception as e:
            result = {"ok": False, "error": f"工具 {tool_name} 执行失败: {e}"}
        return result, round((time.monotonic() - t1) * 1000, 2)

    result, duration_ms = await _once()
    if not result.get("ok") and tool_name in _RETRYABLE_TOOLS:
        logger.debug("工具 %s 首次执行失败,重试 1 次: %s", tool_name, result.get("error"))
        retry_result, retry_ms = await _once()
        result = retry_result
        duration_ms += retry_ms
    return result, duration_ms


# ---------------------------------------------------------------------------
# 媒体产物记忆延续(2026-09-09 全模态深度适配):
# 把本轮媒体工具的关键产物(task_id/媒体 URL/转写与理解文本摘录)压成一条
# 短 JSON 摘要写入会话记忆 → 下一轮"视频好了吗/再画一张类似的"LLM 能从
# history 里看到 task_id/image_url 接上上下文。data URI 超长绝不入库。
# ---------------------------------------------------------------------------
_MEDIA_RESULT_FIELDS: tuple[tuple[str, str], ...] = (
    ("task_id", "task_id"),
    ("image_url", "image_url"),
    ("video_url", "video_url"),
    ("audio_url", "audio_url"),
    ("saved_path", "saved_path"),
    ("status", "status"),
    ("provider", "provider"),
)


def _media_artifact_summary(tool_calls: list[ToolCallRecord]) -> str:
    """提取本轮成功媒体工具的产物摘要;无媒体产物返回空串(不写记忆)。"""
    items: list[dict[str, Any]] = []
    for tc in tool_calls:
        if not tc.ok:
            continue
        r = tc.result or {}
        entry: dict[str, Any] = {}
        if tc.tool in ("image_generation", "image_edit", "video_generation", "music_generation"):
            for src, dst in _MEDIA_RESULT_FIELDS:
                v = r.get(src)
                if isinstance(v, (str, int, float)) and v != "":
                    if src == "audio_url" and str(v).startswith("data:"):
                        v = "[data-uri-omitted]"  # voice/music data URI 超长不入库
                    entry[dst] = v
        elif tc.tool == "voice_tts":
            entry = {"voice": r.get("voice", ""), "engine": r.get("engine", "")}
            if r.get("saved_path"):
                entry["saved_path"] = r["saved_path"]
        elif tc.tool == "token6688_voice_clone":
            # 声纹克隆产物记忆(2026-09-09):voice_id 是下轮 voice_tts 复用克隆音色的钥匙,
            # 必须入记忆,否则"用刚才克隆的声音朗读"会断链
            vid = r.get("voice_id")
            if vid:
                entry = {"voice_id": vid}
        elif tc.tool == "vision_analyze":
            desc = str(r.get("analysis") or "")[:200]
            if desc:
                entry = {"analysis_excerpt": desc}
        elif tc.tool == "audio_transcription":
            t = str(r.get("text") or "")[:200]
            if t:
                entry = {"transcript_excerpt": t}
        if entry:
            entry["tool"] = tc.tool
            items.append(entry)
    if not items:
        return ""
    return json.dumps(
        {
            "media_context": items,
            "_hint": "上一轮媒体工具产物;带 task_id 的未完成任务用该 id 调对应工具查询取件",
        },
        ensure_ascii=False,
    )[:1200]


class SessionOwnershipError(ValueError):
    """会话键与已认证主体不符(跨用户冒用),由路由层转 403。"""


def _resolve_user_id(sid: str) -> str:
    """**仅兼容旧调用方**的降级解析;HTTP 路由必须显式传 user_id。

    当 session_id 为冒号分隔的复合格式(如 {user_id}:{session})时提取首段,
    否则返回空串跳过注入。新调用链一律以 `chat(user_id=...)` 的显式主体为准,
    本函数只用于 chat 未传 user_id 的进程内旧路径。
    """
    if sid and ":" in sid:
        head = sid.split(":", 1)[0].strip()
        # 排除系统前缀,避免把 conv-xxx/session-xxx 等误判为用户标识
        if head and head.lower() not in {"session", "conv", "sess", "u", "user", "chat"}:
            return head
    return ""


# ---------------------------------------------------------------------------
# 意图枚举(对内,LLM 输出 + 后处理)
# ---------------------------------------------------------------------------

INTENT_LABELS = (
    "chat",        # 闲聊 / 一般对话
    "qa",          # 知识问答(基于上下文回答)
    "tool_use",    # 需要调用工具
    "code",        # 写代码 / 代码相关
    "analysis",    # 分析 / 调研
    "creative",    # 创意 / 写作
    "other",       # 其他
)


@dataclass
class IntentResult:
    """意图分类结果。"""

    intent: str
    confidence: float
    entities: dict[str, Any] = field(default_factory=dict)
    reasoning: str = ""
    needs_tool: bool = False
    suggested_tools: list[str] = field(default_factory=list)


@dataclass
class ToolCallRecord:
    """单次工具调用记录。"""

    tool: str
    arguments: dict[str, Any]
    result: dict[str, Any]
    ok: bool
    duration_ms: float = 0.0


@dataclass
class ConversationResult:
    """对话完整结果。"""

    session_id: str
    user_input: str
    intent: IntentResult
    tool_calls: list[ToolCallRecord]
    final_response: str
    model: str
    iterations: int
    duration_ms: float
    stub: bool
    trace: list[dict[str, Any]] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Service
# ---------------------------------------------------------------------------


class ConversationService:
    """对话编排服务。"""

    def __init__(self) -> None:
        # 工具 → 关键词映射(用于无 LLM 时的快速工具选择)
        self._tool_keywords: dict[str, list[str]] = {
            "search_codebase": ["代码", "函数", "类", "符号", "code", "function", "class"],
            "search_web": ["搜索", "网页", "网上", "web", "search", "google"],
            "web_search": ["搜索", "网页", "web", "search"],
            "file_search": ["文件", "查找", "file", "search"],
            "read_file": ["读取", "打开", "read", "view"],
            "write_file": ["写入", "保存", "write", "save"],
            "analyze_code": ["分析", "静态", "analyze", "review"],
            "generate_test": ["测试", "test", "pytest", "unittest"],
            "git_operations": ["git", "提交", "commit", "diff", "log", "branch"],
            "run_command": ["运行", "命令", "run", "exec", "command"],
            "db_query": ["数据库", "查询", "sql", "select", "database", "query"],
            # AI 浏览器控制(12 browser tools)
            "browser_screenshot": ["浏览器截图", "网页截图", "browser screenshot", "截屏"],
            "browser_click_element": ["点击元素", "点击按钮", "browser click", "click element"],
            "browser_type_text": ["浏览器输入", "网页输入", "browser type", "type text"],
            "browser_scroll": ["浏览器滚动", "网页滚动", "browser scroll", "scroll page"],
            "browser_navigate": ["打开网页", "导航到", "browser navigate", "goto url"],
            "browser_extract_dom": ["提取网页", "提取dom", "browser extract", "extract dom"],
            "browser_wait_for_element": ["等待元素", "browser wait", "wait element"],
            "browser_get_attribute": ["获取属性", "browser get attribute", "get attribute"],
            "browser_hover": ["悬停", "browser hover", "hover element"],
            "browser_select_option": ["选择选项", "browser select", "select option"],
            "browser_switch_tab": ["切换标签", "browser switch tab", "switch tab"],
            "browser_close_tab": ["关闭标签", "browser close tab", "close tab"],
            # AI 电脑控制(10 computer tools)
            "computer_screenshot_screen": [
                "电脑截图", "屏幕截图", "screen screenshot", "desktop screenshot"
            ],
            "computer_mouse_move": ["鼠标移动", "mouse move", "move mouse"],
            "computer_mouse_click": ["鼠标点击", "mouse click", "click mouse"],
            "computer_keyboard_type": ["键盘输入", "keyboard type", "type keyboard"],
            "computer_mouse_scroll": ["鼠标滚动", "mouse scroll", "scroll mouse"],
            "computer_keyboard_press": ["按键", "keyboard press", "press key"],
            "computer_keyboard_hotkey": ["快捷键", "hotkey", "keyboard hotkey", "组合键"],
            "computer_active_window": ["活动窗口", "active window", "current window"],
            "computer_clipboard_get": ["读取剪贴板", "clipboard get", "paste clipboard"],
            "computer_clipboard_set": ["设置剪贴板", "clipboard set", "copy clipboard"],
            # 视频生成(2026-09-08):说"做视频"时引导触发统一编排出片
            "video_generation": ["视频", "video", "出片", "短片", "动画片", "火柴人"],
            # 音乐生成(2026-09-08):说"做首歌/配乐"时触发 token6688 Suno 风格生成
            "music_generation": ["音乐", "歌曲", "写歌", "做首歌", "唱", "配乐", "作曲", "编曲", "music", "song"],
            # 语音合成(2026-09-08):说"朗读/读出来/配音"时触发文本转语音(edge 零成本默认)
            "voice_tts": ["朗读", "读出来", "读一下", "念出来", "配音", "语音合成", "转语音", "播报", "tts", "text to speech"],
            # 图片生成(2026-09-08 全模态自动路由):说"画一张/生成图片"时触发图片生成
            "image_generation": [
                "画", "绘图", "插画", "海报", "头像", "生成图片", "生成一张", "画一张",
                "画个", "来一张图", "封面图", "图标", "logo", "image", "draw", "poster",
            ],
            # 图片理解(2026-09-09 全模态深度适配):说"看看/识别这张图"时触发视觉分析
            "vision_analyze": ["看看图", "识别图", "图片里", "图中", "这张图", "截图分析", "识图"],
            # 语音转文字(2026-09-09):说"录音转文字/听写"时触发本地 whisper 转写
            "audio_transcription": ["转文字", "转成文字", "听写", "转写", "语音识别", "录音转", "transcribe"],
            # 余额查询(2026-09-09):说"还剩多少额度"时查 token6688 账户
            "token6688_balance": ["余额", "额度", "还剩多少", "balance", "credit"],
            # 图片编辑(2026-09-09 深度适配二):说"改这张图/去水印"时编辑已有图
            "image_edit": ["改图", "修图", "去水印", "抠图", "换背景", "编辑图片", "图片编辑", "扩图", "局部重绘", "edit image", "retouch"],
            # 声纹克隆(2026-09-09 深能力补齐):说"克隆我的声音/上传声音"时管理声纹库
            "token6688_voice_clone": ["克隆声音", "克隆音色", "复刻声音", "我的声音", "声纹", "声音库", "上传声音", "voice clone", "clone voice"],
            # 任务取消(2026-09-09 深度适配二):说"取消这个任务"时撤销长任务
            "token6688_cancel_task": ["取消任务", "取消生成", "停止生成", "撤销任务", "别做了", "cancel", "stop task"],
            # 模型价目(2026-09-09 深度适配二):说"生成视频多少钱"时查价目/参数
            "token6688_model_info": ["多少钱", "什么价", "价格", "费用", "怎么收费", "参数有哪些", "模型参数", "pricing", "how much"],
            # 教育管理(2026-09-19):催费/欠费/学费/缴费/退费/账单 → edu 工具(internal token 调 api,身份来自聊天用户)
            "edu_list_students": ["学员", "学生名单", "学生列表", "花名册", "学员名单", "在读学生", "students"],
            "edu_list_arrears": ["欠费", "欠款", "未缴费", "欠缴", "催缴名单", "arrears"],
            "edu_list_fee_reminders": ["催费记录", "催缴记录", "提醒记录", "催费历史"],
            "edu_list_payment_records": ["缴费记录", "收款记录", "支付记录", "payment record"],
            "edu_payment_summary": ["缴费汇总", "收款汇总", "缴费统计", "学费统计", "收入统计", "营收"],
            "edu_list_refunds": ["退费记录", "退款记录", "refund list"],
            "edu_list_tuition_fees": ["学费", "学费单", "收费标准", "学费设置", "tuition"],
            "edu_my_bills": ["我的账单", "我的缴费", "查我的账单", "my bills"],
            "edu_send_fee_reminder": ["发催费", "催费", "催缴", "提醒缴费", "发提醒"],
            "edu_send_fee_reminder_batch": ["批量催费", "批量催缴", "批量提醒缴费", "一键催费"],
            "edu_create_payment_record": ["登记缴费", "缴费登记", "登记收款", "录入缴费", "记一笔缴费"],
            "edu_create_refund": ["办退费", "申请退费", "发起退费", "登记退费", "给学生退费"],
            "edu_approve_refund": ["批准退费", "同意退费", "通过退费", "审批退费"],
            "edu_reject_refund": ["驳回退费", "拒绝退费", "否决退费"],
            # 本站操控(2026-09-20 AI 全量操控桥接):intent 判 needs_tool 时的关键词兜底,
            # 与 _UI_INTENT_PATTERNS 正则预路由互补(正则走"强信号",这里走"弱信号 top3")
            "web_ui_describe": ["可操控", "能操作什么", "有哪些按钮", "页面能力", "ui describe"],
            "web_ui_read": ["看看页面", "当前页面", "页面状态", "页面上显示", "read page"],
            "web_ui_navigate": ["打开页面", "跳转到", "切到", "进入页面", "带我到"],
            "web_ui_click": ["点击按钮", "按下按钮", "点一下", "click button"],
            "web_ui_fill": ["填写", "填入", "输入框", "填表单", "fill form", "填一下"],
            "web_ui_submit": ["提交表单", "保存表单", "提交这个表单", "submit form"],
            "web_ui_invoke": ["切换模式", "打开面板", "关闭面板", "新建会话", "命令面板"],
            "api_endpoints_search": ["接口", "端点", "endpoint", "调用api", "后端接口", "api"],
        }

    # =========================================================================
    # 公共 API
    # =========================================================================

    async def chat(
        self,
        user_input: str,
        session_id: str | None = None,
        model: str | None = None,
        allowed_tools: list[str] | None = None,
        max_iterations: int = 3,
        user_id: str | None = None,
    ) -> ConversationResult:
        """完整对话流程:intent → tool select → LLM → tool exec → response。

        Args:
            user_input: 用户输入。
            session_id: 会话 ID(为空则新建)。
            model: 模型名称(空用默认)。
            allowed_tools: 允许的工具列表(空则尝试自动选择)。
            max_iterations: tool loop 最大迭代次数。

        Returns:
            ConversationResult 包含完整 trace + 最终回复。
        """
        start = time.monotonic()
        # 等价替代弃用的 datetime.utcnow()（naive UTC 语义不变，2026-09-19 技术债清理）
        sid = session_id or f"conv-{int(datetime.now(UTC).replace(tzinfo=None).timestamp())}"
        # AIS-032:HTTP 路由传入的已认证主体是唯一身份来源。session_id 只是会话键:
        #   · 复合键首段与主体不符 ⇒ 拒绝(冒用他人 `{victim}:{session}`);
        #   · 其余情况记忆读写按主体命名空间隔离(memory_store.scope_user_id)。
        requester_id = (user_id or "").strip()
        if requester_id and ":" in sid:
            head = sid.split(":", 1)[0].strip()
            if head and head != requester_id:
                raise SessionOwnershipError("session_id 不属于当前用户")
        # 未显式传主体的进程内旧路径才回落到 session_id 解析(保持既有测试/兼容)。
        effective_user_id = requester_id or _resolve_user_id(sid)
        memory_user_id = memory_store.scope_user_id(sid, requester_id)
        trace: list[dict[str, Any]] = []
        # Z28 格 2:段账的**登记处**改吃 stage_telemetry 单源(段清单/结论词表/结论行/
        # metrics 全在那一处落册);trace 的出参形状与数值口径一字未改。
        # 循环段(llm_call / tool_execute)按器物在册的「一格一读数」只登记首轮并落一条
        # [stage_result] 行,后续轮复用同一份投影取整 ⇒ 逐轮明细留在 trace,不补发第二行。
        stages = StageRecorder("conversation_run")
        seen_stages: set[str] = set()

        def _stage_ms(
            node: str, result: str, elapsed: float | None, count: int | None, detail: str | None = None,
        ) -> float | None:
            """段落册唯一出口:耗时读数一律取器物投影(本文件不复算 round)。"""
            if node not in seen_stages:
                seen_stages.add(node)
                settled = stages.record(
                    node, result, duration_ms=elapsed, count=count, detail=detail,
                )
            else:
                settled = StageRecord(
                    stage=node, result=result, duration_ms=elapsed, count=count, detail=detail,
                )
            projected: float | None = settled.as_dict()["duration_ms"]
            return projected

        iterations = 0
        tool_calls: list[ToolCallRecord] = []
        stub = False
        intent = IntentResult(intent="other", confidence=0.0)
        used_model = model or "default"
        final_response = ""
        # G-815969(2026-10-31)「已到达本进程的半截回答必须显式落库」——三条**显式**
        # 本地状态,不是猜测,也不是从 memory_store 反查(反查要读库,取消路径不该再
        # 发查询):
        # - arrived_text:本轮 answer 文本(LLM 真实返回过的 content)。只有它进快照,
        #   意图分类轮的 JSON、工具结果都不进 —— 语义就是"用户可能已经看到的回答文本"。
        # - assistant_written:第 6 步正常路径落库成功后置 True。它是那条记录**唯一**的
        #   写入点,所以 False 严格等价于"成功路径没写过这条 assistant",finally 支路
        #   据此补写,不可能与成功路径重复写同一条。
        # - interrupted:只在 except asyncio.CancelledError 里置 True。取消语义原样
        #   不变(照样 raise),但编排异常([对话编排失败])不会误触发补写。
        arrived_text = ""
        assistant_written = False
        interrupted = False

        try:
            # 1. 写入用户消息到记忆
            try:
                await memory_store.add(sid, "user", user_input, user_id=memory_user_id)
            except Exception as e:
                logger.warning("memory_store.add user 消息失败: %s", e)

            # 2. 意图分类
            intent_clock = stages.clock()
            intent = await self._classify_intent(user_input, model=model)
            trace.append({
                "node": "intent_classify",
                "duration_ms": _stage_ms(
                    "intent_classify", "ok", intent_clock.elapsed_ms(), 1,
                    f"intent={intent.intent} needs_tool={intent.needs_tool}",
                ),
                "intent": intent.intent,
                "needs_tool": intent.needs_tool,
            })

            # 3. 工具选择
            tool_select_clock = stages.clock()
            tools: list[dict[str, Any]] = []
            media_tools: list[str] = []
            web_tools: list[str] = []
            edu_tools: list[str] = []
            app_tools: list[str] = []
            finance_tools: list[str] = []
            if allowed_tools is not None:
                tools = self._filter_tools(allowed_tools)
            elif intent.needs_tool and intent.suggested_tools:
                tools = self._filter_tools(intent.suggested_tools)
            elif intent.needs_tool:
                # 关键词 fallback
                guessed = self._keyword_tool_select(user_input)
                tools = self._filter_tools(guessed)
            else:
                # 全模态自动路由(2026-09-08):intent 未判 needs_tool 但媒体强信号命中
                # → 直接注入对应媒体工具(自动切换多模态调用)
                media_tools = self._media_intent_tools(user_input)
                # Firecrawl web 自动路由(2026-09-09 极致融合补齐):URL 抓取/整站/结构化意图
                web_tools = self._web_intent_tools(user_input)
                # 教育管理自动路由(2026-09-19):催费/欠费/缴费/退费/账单强信号
                edu_tools = self._edu_intent_tools(user_input)
                # 本站操控自动路由(2026-09-20):"帮我操作这个程序"类强信号
                app_tools = self._app_control_intent_tools(user_input, effective_user_id)
                # 财务部自动路由(RP-46):一键代账/一键报税类强信号
                finance_tools = self._finance_intent_tools(user_input)
                if media_tools or web_tools or edu_tools or app_tools or finance_tools:
                    tools = self._filter_tools(
                        media_tools + web_tools + edu_tools + app_tools + finance_tools
                    )
            # intent 已选工具时补并媒体/web/edu/操控/财务 预路由命中项(去重),防 LLM 分类漏判
            if allowed_tools is None and not (
                media_tools or web_tools or edu_tools or app_tools or finance_tools
            ):
                media_tools = self._media_intent_tools(user_input)
                web_tools = self._web_intent_tools(user_input)
                edu_tools = self._edu_intent_tools(user_input)
                app_tools = self._app_control_intent_tools(user_input, effective_user_id)
                finance_tools = self._finance_intent_tools(user_input)
                existing = {t.get("function", {}).get("name") for t in tools}
                extra = [
                    m for m in media_tools + web_tools + edu_tools + app_tools + finance_tools
                    if m not in existing
                ]
                if extra:
                    tools.extend(self._filter_tools(extra))
            trace.append({
                "node": "tool_select",
                "duration_ms": _stage_ms(
                    "tool_select", "ok" if tools else "empty", tool_select_clock.elapsed_ms(),
                    len(tools),
                ),
                "tool_count": len(tools),
                "tool_names": [t.get("function", {}).get("name") for t in tools],
                **({"media_routed": media_tools} if media_tools else {}),
                **({"web_routed": web_tools} if web_tools else {}),
                **({"edu_routed": edu_tools} if edu_tools else {}),
                **({"app_control_routed": app_tools} if app_tools else {}),
                **({"finance_routed": finance_tools} if finance_tools else {}),
            })

            # 4. 加载历史上下文
            history = await memory_store.get(sid, limit=20, user_id=memory_user_id)
            messages: list[dict[str, Any]] = []
            # 工具结果诚实报告指令:防止 LLM 在 tool 失败时幻觉"已完成"
            if tools:
                guidance = (
                    "你是一个能调用工具的 AI 助手。调用工具后,务必检查返回结果中的 ok 字段:\n"
                    "- ok=true:工具执行成功,可以告诉用户已完成\n"
                    "- ok=false:工具执行失败,必须如实告知用户失败原因"
                    "(包括 errorCode/error 字段),"
                    "禁止声称已完成或成功\n"
                    "常见失败场景:TARGET_NOT_CONNECTED(浏览器扩展/桌面端/Web 前端未连接)、"
                    "TIMEOUT(执行超时)、"
                    "SELECTOR_NOT_FOUND(元素未找到)。遇到这些错误时,引导用户检查对应端是否已启动。"
                )
                # 媒体工具在场 → 追加 Markdown 渲染规范(图/音/视频对话即所得)
                _media_set = set(_MEDIA_INTENT_PATTERNS)
                if any(t.get("function", {}).get("name") in _media_set for t in tools):
                    guidance += "\n\n" + _MEDIA_RENDER_PROMPT + "\n\n" + _MEDIA_CHAIN_PROMPT
                # 网页工具在场 → 追加网页内容呈现规范(2026-09-09 极致融合补齐)
                _web_set = set(_WEB_INTENT_PATTERNS)
                if any(t.get("function", {}).get("name") in _web_set for t in tools):
                    guidance += "\n\n" + _WEB_RENDER_PROMPT
                # 教育管理工具在场 → 追加 edu 使用规范(2026-09-19:写操作二次确认+金额单位元)
                _edu_set = set(_EDU_INTENT_PATTERNS)
                if any(t.get("function", {}).get("name") in _edu_set for t in tools):
                    guidance += "\n\n" + _EDU_RENDER_PROMPT
                # 本站操控工具在场 → 追加"先探后动 + 未核对不得声称已提交"规范(2026-09-20)
                _app_set = set(_UI_INTENT_PATTERNS) | set(_API_ENTRY_TOOLS)
                if any(t.get("function", {}).get("name") in _app_set for t in tools):
                    guidance += "\n\n" + _UI_RENDER_PROMPT
                # 财务部插件在场 → 追加代账/报税分阶段推进与草案红线规范(RP-46,2026-11-12)
                _finance_set = set(_FINANCE_INTENT_PATTERNS)
                if any(t.get("function", {}).get("name") in _finance_set for t in tools):
                    guidance += "\n\n" + _FINANCE_RENDER_PROMPT
                messages.append({"role": "system", "content": guidance})
            # P0:用户画像 + 跨会话记忆注入(孤岛能力打通,与 v2 的 L1-1 记忆闭环一致;
            # 失败/拿不到 user_id 均降级不阻塞对话)
            try:
                user_id = effective_user_id
                if not user_id:
                    logger.debug(
                        "conversation 未解析到 user_id,跳过画像/长期记忆注入(sid=%s)", sid
                    )
                else:
                    parts: list[str] = []
                    try:
                        from .user_profile import user_profile_builder

                        profile_snippet = user_profile_builder.build_system_prompt_snippet(user_id)
                        if profile_snippet:
                            parts.append(profile_snippet)
                    except Exception as e:
                        logger.warning(
                            "user_profile.build_system_prompt_snippet 失败(降级,不阻塞): %s", e
                        )
                    try:
                        from .memory_service import memory_service as _memory_svc

                        memory_ctx = await _memory_svc.load_context_for_conversation(
                            user_id=user_id,
                            session_id=sid,
                        )
                        if memory_ctx:
                            parts.append(memory_ctx)
                    except Exception as e:
                        logger.warning(
                            "memory_service.load_context_for_conversation 失败(降级,不阻塞): %s", e
                        )
                    if parts:
                        snippet = "\n\n".join(parts)
                        if messages and messages[0].get("role") == "system":
                            existing = messages[0].get("content", "")
                            messages[0]["content"] = (
                                f"{existing}\n\n{snippet}" if existing else snippet
                            )
                        else:
                            messages.insert(0, {"role": "system", "content": snippet})
            except Exception as e:
                logger.warning("conversation 画像/记忆注入失败(降级,不阻塞): %s", e)
            for m in history[:-1]:  # 排除最后一条刚加入的 user
                role = m.get("role")
                content = m.get("content", "")
                if role in ("user", "assistant") and content:
                    messages.append({"role": role, "content": content})
            messages.append({"role": "user", "content": user_input})

            # 5. Tool loop
            for it in range(max_iterations):
                iterations = it + 1
                llm_clock = stages.clock()
                call_kwargs: dict[str, Any] = {}
                if tools:
                    call_kwargs["tools"] = tools
                    call_kwargs["tool_choice"] = "auto"
                result = await llm_gateway.complete(
                    messages, model=model, **call_kwargs
                )
                used_model = result.get("model", used_model)
                stub = result.get("stub", False) or stub

                # P0-7: LLM error 字段检查 — 不把 error 响应当正常回复
                if result.get("error"):
                    err_msg = result.get("error_message", "未知错误")
                    logger.warning(
                        "LLM 调用失败: %s, model=%s, iter=%d",
                        err_msg, used_model, iterations,
                    )
                    trace.append({
                        "node": "llm_call",
                        "iteration": iterations,
                        "duration_ms": _stage_ms(
                            "llm_call", "failed", llm_clock.elapsed_ms(), 0,
                            f"iter={iterations}: {err_msg}",
                        ),
                        "model": used_model,
                        "stub": stub,
                        "error": True,
                        "error_message": err_msg,
                    })
                    final_response = f"[LLM 调用失败] {err_msg}"
                    break

                content = str(result.get("content", "") or "")
                tool_calls_raw = result.get("tool_calls") or []
                # G-815969:answer 文本已"到达本进程"⇒ 记入快照(取消时的唯一可落库
                # 内容)。刻意只记文本:工具在飞时不记任何工具载荷,半截 result 归
                # 第 5.3 回灌的终态路径处理(给工具写半截 result 会造出"调用无回复"
                # 的历史)。空 content 不覆盖快照 ⇒ arrived_text 始终是"最近一次真正
                # 到手的回答文本",从未拿到过文本时保持初始空串(零字符判据的来源)。
                if content:
                    arrived_text = content

                trace.append({
                    "node": "llm_call",
                    "iteration": iterations,
                    "duration_ms": _stage_ms(
                        "llm_call", "ok", llm_clock.elapsed_ms(), len(tool_calls_raw),
                        f"iter={iterations} stub={stub}",
                    ),
                    "model": used_model,
                    "stub": stub,
                    "tool_call_count": len(tool_calls_raw),
                })

                # 5.1 无 tool_call:最终回复
                if not tool_calls_raw:
                    final_response = content
                    break

                # 5.2 把 assistant 消息(含 tool_calls)加入上下文
                messages.append({
                    "role": "assistant",
                    "content": content,
                    "tool_calls": tool_calls_raw,
                })

                # 5.3 解析并执行 tool_calls —— P1-2:同轮独立工具并行执行(无依赖假设)
                # 结果回灌顺序必须与 tool_calls_raw 顺序一致(LLM 依赖顺序结构),仅执行并发;
                # 单工具失败不整体中断,失败项独立标注(见下方回灌错误处理)。
                parsed_calls: list[tuple[dict[str, Any], str, dict[str, Any]]] = []
                for tc in tool_calls_raw:
                    if not isinstance(tc, dict):
                        continue
                    fn = tc.get("function") or {}
                    tool_name = fn.get("name", "")
                    raw_args = fn.get("arguments", "")
                    if isinstance(raw_args, str):
                        try:
                            args = json.loads(raw_args) if raw_args.strip() else {}
                        except (json.JSONDecodeError, ValueError):
                            args = {"_raw": raw_args}
                    else:
                        args = raw_args or {}
                    parsed_calls.append((tc, tool_name, args))

                # 并行执行,单轮最大 MAX_PARALLEL_TOOL_CALLS,超出分批 gather
                round_exec: list[
                    tuple[dict[str, Any], str, dict[str, Any], dict[str, Any], float]
                ] = []
                for i in range(0, len(parsed_calls), MAX_PARALLEL_TOOL_CALLS):
                    batch = parsed_calls[i:i + MAX_PARALLEL_TOOL_CALLS]
                    outcomes = await asyncio.gather(
                        *(
                            _execute_tool_call(
                                name, args, user_id=user_id, session_id=sid
                            )
                            for _, name, args in batch
                        ),
                        return_exceptions=True,
                    )
                    for (tc, tool_name, args), outcome in zip(batch, outcomes, strict=True):
                        if isinstance(outcome, BaseException):
                            # 防御:helper 已归一化,理论上到不了这里
                            exec_result = {
                                "ok": False,
                                "error": f"工具 {tool_name} 执行失败: {outcome}",
                            }
                            duration_ms = 0.0
                        else:
                            exec_result, duration_ms = outcome
                        round_exec.append((tc, tool_name, args, exec_result, duration_ms))

                for tc, tool_name, args, exec_result, duration_ms in round_exec:
                    ok = bool(exec_result.get("ok"))
                    record = ToolCallRecord(
                        tool=tool_name,
                        arguments=args,
                        result=exec_result,
                        ok=ok,
                        duration_ms=duration_ms,
                    )
                    tool_calls.append(record)
                    # 段账登记(tool_execute 是循环段:首轮落一条结论行,后续轮复用投影)
                    _stage_ms(
                        "tool_execute", "ok" if ok else "failed", record.duration_ms, 1,
                        f"tool={tool_name}",
                    )
                    # P0-7: 工具失败时在 trace 显式记录 _tool_error
                    tool_trace: dict[str, Any] = {
                        "node": "tool_execute",
                        "tool": tool_name,
                        "ok": ok,
                        "duration_ms": record.duration_ms,
                    }
                    if len(round_exec) > 1:
                        tool_trace["parallel"] = True
                    if not ok:
                        tool_trace["_tool_error"] = (
                            exec_result.get("error")
                            or exec_result.get("message")
                            or "tool execution failed"
                        )
                    trace.append(tool_trace)

                    # 把工具结果回灌 — 失败时显式标注,防止 LLM 幻觉"已完成"
                    # 2026-10-31 安全强化第 10 批:外部数据先进宿主定界块(保留标签
                    # 中和),宿主失败指令保持在块外
                    raw_tool_json = scan_and_frame_tool_result(
                        json.dumps(exec_result, ensure_ascii=False)[:4000],
                        tool_name=tool_name,
                    )
                    result_json = raw_tool_json
                    if not ok:
                        err_detail = (
                            exec_result.get("error")
                            or exec_result.get("message")
                            or "unknown error"
                        )
                        err_code = exec_result.get("errorCode", "UNKNOWN")
                        # 嵌入 result.result 兼容 agent_control 返回格式
                        inner = exec_result.get("result", {})
                        if isinstance(inner, dict) and inner.get("errorCode"):
                            err_code = inner.get("errorCode", err_code)
                            err_detail = inner.get("error", err_detail)
                        result_json = (
                            f"TOOL EXECUTION FAILED. errorCode={err_code}. error={err_detail}. "
                            f"You MUST tell the user the tool failed and suggest checking if the "
                            f"browser extension / desktop app is running. "
                            f"Do NOT claim success. Raw result: {raw_tool_json}"
                        )
                    messages.append({
                        "role": "tool",
                        "tool_call_id": tc.get("id", ""),
                        "name": tool_name,
                        "content": result_json,
                    })

                # 5.3.1 全部 tool 失败时直接构造失败响应,不让 LLM 总结(防止幻觉"已完成")
                round_calls = tool_calls[-len(round_exec):] if round_exec else []
                if round_calls and all(not tc.ok for tc in round_calls):
                    failed_details = []
                    for tc in round_calls:
                        inner = tc.result.get("result", {})
                        err_code = (
                            inner.get("errorCode", tc.result.get("errorCode", "UNKNOWN"))
                            if isinstance(inner, dict)
                            else "UNKNOWN"
                        )
                        err_msg = (
                            inner.get("error", tc.result.get("error", "unknown"))
                            if isinstance(inner, dict)
                            else "unknown"
                        )
                        failed_details.append(f"- {tc.tool}: {err_code} — {err_msg}")
                    final_response = (
                        "工具执行失败,未能完成您的请求:\n" + "\n".join(failed_details) + "\n\n"
                        "可能的原因:\n"
                        "- TARGET_NOT_CONNECTED:浏览器扩展或桌面端未启动,请确保对应端已打开并登录\n"
                        "- TIMEOUT:操作超时,请稍后重试\n"
                        "- SELECTOR_NOT_FOUND:页面元素未找到,请检查选择器是否正确\n"
                    )
                    _stage_ms(
                        "all_tools_failed", "failed", None, len(round_calls),
                        "本段旧实现不测耗时 ⇒ 段账按 unjudged 记,不拿 0 冒充",
                    )
                    trace.append({
                        "node": "all_tools_failed",
                        "failed_count": len(round_calls),
                        "skipped_llm_summarize": True,
                    })
                    break

                # 5.4 最后一轮不再继续
                if it == max_iterations - 1:
                    # 让 LLM 总结工具结果
                    summary = await llm_gateway.complete(messages, model=model)
                    # P0-7: summarize 调用检查 error
                    if summary.get("error"):
                        err_msg = summary.get("error_message", "未知错误")
                        logger.warning(
                            "LLM summarize 失败: %s, model=%s",
                            err_msg, used_model,
                        )
                        _stage_ms(
                            "llm_summarize", "failed", None, 0, f"摘要腿失败: {err_msg}",
                        )
                        trace.append({
                            "node": "llm_summarize",
                            "duration_ms": 0.0,
                            "stub": summary.get("stub", False),
                            "error": True,
                            "error_message": err_msg,
                        })
                        # final_response 保留之前的 content 或设置错误提示
                        if not final_response:
                            final_response = f"[LLM 摘要失败] {err_msg}"
                    else:
                        final_response = str(summary.get("content", "") or "")
                        stub = stub or summary.get("stub", False)
                        _stage_ms("llm_summarize", "ok", None, 0, "摘要腿给出回复(旧实现耗时写死 0.0 ⇒ 段账按未判定记)")
                        trace.append({
                            "node": "llm_summarize",
                            "duration_ms": 0.0,
                            "stub": summary.get("stub", False),
                        })
                    break

            # 6. 写入 assistant 响应
            # G-815969:进入本行即视为"这条 assistant 已由成功路径接管"。判据为何成立:
            # 本行是 assistant 记录的唯一正常写入点,置位发生在 await **之前** ⇒ 只要
            # 走到第 6 步,finally 支路就绝不会再补写一条(同一次回复不会落库两遍)。
            # 写失败时也不回退置位:那次失败已由上面的 warning 暴露,不该由"半截回答"
            # 支路用中断标注补一条形状不同的记录 —— 把完整回答标成中断是新的事实错误。
            assistant_written = True
            try:
                await memory_store.add(sid, "assistant", final_response, user_id=memory_user_id)
            except Exception as e:
                logger.warning("memory_store.add assistant 响应失败: %s", e)
            # 6.1 媒体产物记忆延续(2026-09-09 全模态深度适配):
            # 把本轮成功媒体工具的 task_id/媒体 URL/文本摘录压成一条摘要写入
            # 记忆(assistant role,history 读取可见)→ 下一轮取件/续作能接上下文。
            try:
                media_note = _media_artifact_summary(tool_calls)
                if media_note:
                    await memory_store.add(sid, "assistant", media_note)
            except Exception as e:
                logger.warning("媒体产物摘要写入记忆失败(降级,不阻塞): %s", e)
        except asyncio.CancelledError:
            # G-815969:取消语义逐零差异(仍立即 raise,不吞不重试),仅立一个显式标记,
            # 让下面的 finally 支路能把"用户按停止"与"编排异常"分开。
            interrupted = True
            raise
        except Exception as e:
            logger.exception("对话编排失败: %s", e)
            final_response = f"[对话编排失败] {e}"
        finally:
            # G-815969「用户按停止时,已到达本进程的半截回答必须显式落库」:票面那句
            # 结构事实在这里成立 —— except asyncio.CancelledError 在 memory_store.add
            # (第 6 步)**之前**被到达,取消时一条都不写,重开会话时那条回复比用户
            # 亲眼见过的短,且没有"被中断"的痕迹。
            # 三条判据都是显式本地状态,不做猜测也不反查库(反查要在取消路径再发一次
            # 查询,本身就是不该做的事):
            # - interrupted:仅取消路径置位 ⇒ 正常完成/编排异常都不补写;
            # - not assistant_written:成功路径没接管这条记录 ⇒ 补写不会写两遍;
            # - arrived_text 非空:一个字都没到达本进程时**不写**空 assistant 气泡。
            # 范围刻意收窄:只 flush 已到达本进程的 answer 文本,不读任何工具载荷
            # (工具在飞时给它写半截 result 会造出"调用无回复"的历史,那条路仍归
            # 第 5.3 回灌的终态路径处理)。
            if interrupted and not assistant_written and arrived_text.strip():
                try:
                    await memory_store.add(
                        sid,
                        "assistant",
                        arrived_text,
                        # 中断标注落在 memory_store.add 已有的 metadata 参数(写进消息
                        # 记录既有的 metadata 字段)⇒ 零新增列、零迁移。
                        {"interrupted": True, "interrupt_reason": "user_cancelled"},
                        user_id=memory_user_id,
                    )
                except Exception as e:
                    # 落库失败不把取消路径炸成 500:与第 6 步同一形状,logger.warning
                    # 后让 CancelledError 继续传播(取消语义不变)。
                    logger.warning(
                        "取消路径半截 assistant 落库失败(降级,不阻塞取消): %s", e
                    )

        return ConversationResult(
            session_id=sid,
            user_input=user_input,
            intent=intent,
            tool_calls=tool_calls,
            final_response=final_response,
            model=used_model,
            iterations=iterations,
            duration_ms=round((time.monotonic() - start) * 1000, 2),
            stub=stub,
            trace=trace,
        )

    # =========================================================================
    # 私有:意图分类
    # =========================================================================

    async def _classify_intent(
        self, user_input: str, model: str | None = None
    ) -> IntentResult:
        """LLM 分类意图 + 抽取 entities + 决定是否需要 tool。

        失败/降级时返回基于关键词的 fallback 意图。
        """
        fallback = self._fallback_intent(user_input)

        classification_prompt = [
            {
                "role": "system",
                "content": (
                    "你是意图分类助手。分析用户输入并以 JSON 形式返回:\n"
                    "{\n"
                    '  "intent": "chat|qa|tool_use|code|analysis|creative|other",\n'
                    '  "confidence": 0.0-1.0,\n'
                    '  "entities": {"key": "value"},\n'
                    '  "needs_tool": true/false,\n'
                    '  "suggested_tools": ["tool_name1", "tool_name2"],\n'
                    '  "reasoning": "为什么这么分类"\n'
                    "}\n"
                    f"可用工具: {', '.join(t.name for t in mcp_server.list_tools())}"
                ),
            },
            {"role": "user", "content": user_input},
        ]

        try:
            result = await llm_gateway.complete(classification_prompt, model=model)
            content = str(result.get("content", "") or "")
            parsed = self._parse_json_object(content)
            if parsed:
                intent_label = str(parsed.get("intent", "other")).lower()
                if intent_label not in INTENT_LABELS:
                    intent_label = "other"
                try:
                    confidence = float(parsed.get("confidence", 0.5))
                except (TypeError, ValueError):
                    confidence = 0.5
                return IntentResult(
                    intent=intent_label,
                    confidence=max(0.0, min(1.0, confidence)),
                    entities=parsed.get("entities") or {},
                    reasoning=str(parsed.get("reasoning", "")),
                    needs_tool=bool(parsed.get("needs_tool", False)),
                    suggested_tools=list(parsed.get("suggested_tools") or []),
                )
        except Exception as e:
            logger.warning("意图分类 JSON 解析失败,使用 fallback: %s", e)
        return fallback

    def _fallback_intent(self, user_input: str) -> IntentResult:
        """基于关键词的 fallback 意图(LLM 不可用时)。"""
        text = user_input.lower()
        needs_tool = False
        suggested: list[str] = []

        # 工具关键词检测
        for tool, kws in self._tool_keywords.items():
            if any(kw in text for kw in kws):
                needs_tool = True
                suggested.append(tool)

        # 意图粗分类
        if any(k in text for k in ["代码", "函数", "class", "def ", "code", "function"]):
            intent = "code"
        elif any(k in text for k in ["分析", "调研", "研究", "analyze", "research"]):
            intent = "analysis"
        elif any(k in text for k in ["写", "创作", "写一", "creative", "write"]):
            intent = "creative"
        elif any(k in text for k in ["?", "？", "是什么", "怎么", "how", "what", "why"]):
            intent = "qa"
        elif needs_tool:
            intent = "tool_use"
        else:
            intent = "chat"

        return IntentResult(
            intent=intent,
            confidence=0.5,
            needs_tool=needs_tool,
            suggested_tools=suggested,
            reasoning="基于关键词的 fallback 分类",
        )

    @staticmethod
    def _parse_json_object(text: str) -> dict[str, Any] | None:
        """从文本中提取首个 JSON object。"""
        if not text:
            return None
        # 尝试整段解析
        try:
            obj = json.loads(text)
            if isinstance(obj, dict):
                return obj
        except (json.JSONDecodeError, ValueError):
            pass
        # 尝试正则提取 {...}
        match = re.search(r"\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}", text, re.DOTALL)
        if match:
            try:
                obj = json.loads(match.group())
                if isinstance(obj, dict):
                    return obj
            except (json.JSONDecodeError, ValueError):
                pass
        return None

    # =========================================================================
    # 私有:工具选择
    # =========================================================================

    def _filter_tools(self, names: list[str]) -> list[dict[str, Any]]:
        """根据 name 列表返回 OpenAI tools 格式定义。"""
        all_tools = mcp_server.list_tools()
        available = {t.name: t for t in all_tools}
        out: list[dict[str, Any]] = []
        for n in names:
            if n in available:
                t = available[n]
                out.append({
                    "type": "function",
                    "function": {
                        "name": t.name,
                        "description": t.description,
                        "parameters": t.input_schema,
                    },
                })
        return out

    def _keyword_tool_select(self, text: str) -> list[str]:
        """基于关键词的快速工具选择。"""
        text_l = text.lower()
        matches: list[tuple[int, str]] = []
        for tool, kws in self._tool_keywords.items():
            score = sum(1 for kw in kws if kw in text_l)
            if score > 0:
                matches.append((score, tool))
        matches.sort(reverse=True)
        return [t for _, t in matches[:3]]

    @staticmethod
    def _media_intent_tools(text: str) -> list[str]:
        """媒体模态预路由(2026-09-08 全模态自动切换):强信号正则命中 → 对应工具名。

        与 _keyword_tool_select 的区别:那里是"猜 top3"的兜底,这里是按模态精确判定,
        命中即无条件并入 tool loop 工具集(不受 LLM 意图分类质量影响)。
        负样本控制:模式要求"动词+媒体宾语"结构,"看看图片/上传图片/这张照片"不会命中。
        """
        out: list[str] = []
        for tool, patterns in _MEDIA_INTENT_PATTERNS.items():
            if any(p.search(text) for p in patterns):
                out.append(tool)
        return out

    @staticmethod
    def _web_intent_tools(text: str) -> list[str]:
        """Firecrawl web 网络意图预路由(2026-09-09 极致融合补齐):命中 URL 抓取/整站/
        结构化抽取强信号 → 注入对应只读 web 工具(fetch_readable/map_site/extract_web)。

        刻意不含 crawl_site(递归爬取重操作, 在 _ADMIN_ONLY_TOOLS, 普通对话 user_role=0
        不可调)。与 _media_intent_tools 同语义: 命中即并入 tool loop 工具集, 不受 LLM
        意图分类质量影响。
        """
        out: list[str] = []
        for tool, patterns in _WEB_INTENT_PATTERNS.items():
            if any(p.search(text) for p in patterns):
                out.append(tool)
        return out

    @staticmethod
    def _edu_intent_tools(text: str) -> list[str]:
        """教育管理意图预路由(2026-09-19):催费/欠费/缴费/退费/账单等强信号 → 对应 edu 工具。

        与 _media_intent_tools/_web_intent_tools 同语义:命中即无条件并入 tool loop
        工具集,不受 LLM 意图分类质量影响。写操作同样进路由 —— LLM 侧 _EDU_RENDER_PROMPT
        要求二次确认,api 侧 RBAC 兜底权限。
        """
        out: list[str] = []
        for tool, patterns in _EDU_INTENT_PATTERNS.items():
            if any(p.search(text) for p in patterns):
                out.append(tool)
        return out

    @staticmethod
    def _finance_intent_tools(text: str) -> list[str]:
        """财务部预路由(RP-46,2026-11-12):一键代账/一键报税强信号 → 财务插件工具。

        与 _edu_intent_tools 同语义:命中即无条件并入 tool loop 工具集,不受 LLM
        意图分类质量影响;规范注入见 _FINANCE_RENDER_PROMPT(分阶段推进+草案红线)。
        """
        out: list[str] = []
        for tool, patterns in _FINANCE_INTENT_PATTERNS.items():
            if any(p.search(text) for p in patterns):
                out.append(tool)
        return out

    @staticmethod
    def _app_control_intent_tools(text: str, user_id: str = "") -> list[str]:
        """本站操控意图预路由(2026-09-20):要求操作我们自己的程序 → UI 动作工具
        或后端 API 入口工具。

        两处补全(缺一即断链):
        - 命中任一 UI 动作类工具时补 web_ui_describe —— 动作要靠 describe 返回的
          id/target 定位,LLM 无从猜出元素标识;
        - 命中 api_ 入口任一工具时补齐全对 —— 只有 search 会让模型搜到却调不了。

        身份门(2026-09-21):这些工具最终都要按 user_id 定位"这个用户的哪一端",
        无身份时发出去必然 PERMISSION_DENIED(_ui_call 的 fail-closed 分支)。
        预先不发比发了让模型误以为"已经操作了"更诚实。
        """
        if not user_id.strip():
            return []
        out: list[str] = []
        for tool, patterns in _UI_INTENT_PATTERNS.items():
            if any(p.search(text) for p in patterns):
                out.append(tool)
        if any(t in out for t in _UI_ACTION_TOOLS) and "web_ui_describe" not in out:
            out.append("web_ui_describe")
        if any(t in out for t in _API_ENTRY_TOOLS):
            out.extend(t for t in _API_ENTRY_TOOLS if t not in out)
        return out

    # =========================================================================
    # 私有:序列化
    # =========================================================================

    @staticmethod
    def result_to_dict(result: ConversationResult) -> dict[str, Any]:
        """将 ConversationResult 序列化为可 JSON 化的 dict。"""
        return {
            "session_id": result.session_id,
            "user_input": result.user_input,
            "intent": {
                "intent": result.intent.intent,
                "confidence": result.intent.confidence,
                "entities": result.intent.entities,
                "reasoning": result.intent.reasoning,
                "needs_tool": result.intent.needs_tool,
                "suggested_tools": result.intent.suggested_tools,
            },
            "tool_calls": [
                {
                    "tool": tc.tool,
                    "arguments": tc.arguments,
                    "ok": tc.ok,
                    "duration_ms": tc.duration_ms,
                    "result_preview": str(tc.result)[:300],
                }
                for tc in result.tool_calls
            ],
            "final_response": result.final_response,
            "model": result.model,
            "iterations": result.iterations,
            "duration_ms": result.duration_ms,
            "stub": result.stub,
            "trace": result.trace,
        }


conversation_service = ConversationService()
# ⁠​‌​​‌​​‌‍‍​‌​​‌​​​‍‍​‌​‌​‌​‌‍‍​‌​​‌​​‌‍‍​​‌​‌‌​‌‍‍​‌​​​​​‌‍‍​‌​​‌​​‌‍‍‌​‌‌​‌‌‌‍‍‌‌​​‌‌​​‌‌‌‌​‌​‍‍‌‌​‌‌​​​‌​​​‌‌‌‍‍​‌​​​​​‌‍‍​‌​​‌​​‌‍‍‌​‌‌​‌‌‌‍‍‌‌​​‌‌‌​‌​​‌‌‌​‍‍‌‌​​‌‌​​​‌​​‌​‌‍‍‌​‌‌‌​‌‌‌​‌‌‌​‌‍‍‌​‌‌​‌‌‌‍‍​‌​​‌‌​​‍‍​‌​​​​‌‌‍‍‌​‌‌​‌‌‌‍‍​‌‌​​​​‌‍‍​‌‌​‌​​‌‍‍​‌‌‌‌​‌​‍‍​‌‌​‌​​​‍‍​‌‌‌​​‌‌‍‍​​‌​‌‌‌​‍‍​‌‌‌​‌​​‍‍​‌‌​‌‌‌‌‍‍​‌‌‌​​​​‍‍‌​‌‌​‌‌‌‍‍​‌​‌​​​​‍‍​‌​‌​​‌​‍‍​‌​​‌‌‌‌‍‍​‌​‌​‌‌​‍‍​‌​​​‌​‌‍‍​‌​​‌‌‌​‍‍​‌​​​​​‌‍‍​‌​​‌‌‌​‍‍​‌​​​​‌‌‍‍​‌​​​‌​‌‍‍​​‌​‌‌​‌‍‍​​‌‌​​‌​‍‍​​‌‌​​​​‍‍​​‌‌​​‌​‍‍​​‌‌​‌‌​⁠
