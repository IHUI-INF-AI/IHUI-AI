# © 2026 IHUI AI (智汇AI) · 版权所有者: 李春川 (Li Chunchuan) · https://aizhs.top
# Provenance-watermarked. 未授权商用可被溯源追责 (Apache-2.0 须保留本声明与 NOTICE)。
# [IHUI-AI-PROVENANCE]:⁠​‌​​‌​​‌‍‍​‌​​‌​​​‍‍​‌​‌​‌​‌‍‍​‌​​‌​​‌‍‍​​‌​‌‌​‌‍‍​‌​​​​​‌‍‍​‌​​‌​​‌‍‍‌​‌‌​‌‌‌‍‍‌‌​​‌‌​​‌‌‌‌​‌​‍‍‌‌​‌‌​​​‌​​​‌‌‌‍‍​‌​​​​​‌‍‍​‌​​‌​​‌‍‍‌​‌‌​‌‌‌‍‍‌‌​​‌‌‌​‌​​‌‌‌​‍‍‌‌​​‌‌​​​‌​​‌​‌‍‍‌​‌‌‌​‌‌‌​‌‌‌​‌‍‍‌​‌‌​‌‌‌‍‍​‌​​‌‌​​‍‍​‌​​​​‌‌‍‍‌​‌‌​‌‌‌‍‍​‌‌​​​​‌‍‍​‌‌​‌​​‌‍‍​‌‌‌‌​‌​‍‍​‌‌​‌​​​‍‍​‌‌‌​​‌‌‍‍​​‌​‌‌‌​‍‍​‌‌‌​‌​​‍‍​‌‌​‌‌‌‌‍‍​‌‌‌​​​​‍‍‌​‌‌​‌‌‌‍‍​‌​‌​​​​‍‍​‌​‌​​‌​‍‍​‌​​‌‌‌‌‍‍​‌​‌​‌‌​‍‍​‌​​​‌​‌‍‍​‌​​‌‌‌​‍‍​‌​​​​​‌‍‍​‌​​‌‌‌​‍‍​‌​​​​‌‌‍‍​‌​​​‌​‌‍‍​​‌​‌‌​‌‍‍​​‌‌​​‌​‍‍​​‌‌​​​​‍‍​​‌‌​​‌​‍‍​​‌‌​‌‌​⁠

"""多平台发布调度器(单例)。

职责:
1. 接收发布任务(submit_task),异步并发执行多平台发布
2. 每 60s 轮询 DB,执行 scheduled_at 到期的定时任务
3. 同用户最多 3 个并发任务(超出排队)
4. 不自动重试(由用户手动 /tasks/{id}/retry)
5. 完成后写入 publish_history 表 + 推送通知

DB 表(自动建):
- publish_tasks:  任务主表(id, user_id, content, targets, status, scheduled_at, ...)
- publish_history: 单平台执行历史(task_id, platform, success, url, error, duration_ms)
"""
from __future__ import annotations

import asyncio
import contextlib
import copy
import json
import re
from collections.abc import Coroutine
from dataclasses import replace as _dc_replace
from datetime import UTC, datetime
from typing import Any

import asyncpg

from app.core.background_tasks import spawn
from app.core.config import settings
from app.core.db import get_db_conn
from app.core.logging import get_logger

from . import notifications

# Anti-Risk 反风控(2026-07-31 强化):发布前冷却检查 + 风险评分检查,
# 发布后审计日志 + 失败关键词检测 + 自动冷却
from .anti_risk import (
    AuditLogger,
    CooldownManager,
    RiskScore,
    RiskScorer,
    cooldown_duration_for_error,
    get_deduplicator,
    get_monitor,
    get_solver,
)
from .base_adapter import PublishContent, PublishResult, get_adapter
from .content_parser import enrich_content, enrich_content_for_platform
from .credentials_crypto import decrypt
from .db_write_guard import log_db_write_failure
from .image_uploader import process_external_images
from .platform_rules import truncate_to_platform, validate_content

logger = get_logger(__name__)


def _command_tag_count(tag: str | None) -> int:
    """解析 asyncpg 的 DML 命令标签("UPDATE 1"/"DELETE 0")里的行数;异常一律 0。

    AIS-024:CAS 必须靠 rowcount 判定"谁抢到",不能把 execute 成功当命中 ——
    `UPDATE ... WHERE status='scheduled'` 在竞态下会返回 `UPDATE 0`。
    """
    try:
        return int(str(tag).split()[-1])
    except (IndexError, TypeError, ValueError):
        return 0


# 同用户最大并发任务数
_MAX_CONCURRENT_PER_USER = 3
# AIS-024:running 行的租约。超过该时长仍未 finished 视为抢占方已崩溃,回收重排。
_RUNNING_LEASE_SEC = 30 * 60
# 调度器轮询间隔(秒)
_POLL_INTERVAL_SEC = 60
# DB 连接失败指数退避(2026-08-13 立,修复 Postgres 未启动时每 62s 空转重试)
_DB_BACKOFF_BASE_SEC = 5.0
_DB_BACKOFF_MAX_SEC = 300.0
# 历史保留上限(内存 LRU)
_HISTORY_LIMIT = 200


class PublishScheduler:
    """多平台发布调度器(单例)。"""

    def __init__(self) -> None:
        self._poll_task: asyncio.Task[None] | None = None
        self._running: dict[str, asyncio.Task[None]] = {}  # task_id -> asyncio.Task
        self._user_running: dict[str, int] = {}  # user_id -> 正在执行的任务数
        # AIS-023:spawn 之后到协程真正启动之间存在窗口,仅靠 `_running` 去重会漏;
        # `_reserved` 在提交侧同步占位,`_run_task` 起跑时摘掉并换成真实 task。
        self._reserved: set[str] = set()
        # AIS-042:task_id -> 属主。`_running` 里只有 Task 引用,运行/历史查询要按主体过滤
        self._task_users: dict[str, str | None] = {}
        self._history: list[dict[str, Any]] = []  # 内存 LRU 历史
        self._started = False
        # 持有 spawn 出的 task 引用,避免 CPython GC 回收未完成的 task
        self._pending_tasks: set[asyncio.Task[None]] = set()

    def _spawn_task(self, coro: Coroutine[Any, Any, None]) -> asyncio.Task[None]:
        """创建 task 并持有引用,完成后自动从集合移除。"""
        task = asyncio.create_task(coro)
        self._pending_tasks.add(task)
        task.add_done_callback(self._pending_tasks.discard)
        return task

    def _reserve(self, task_id: str, user_id: str | None) -> bool:
        """提交侧同步占位:task_id 去重 + 每用户并发上限(AIS-023)。

        所有 spawn `_run_task` 的路径(轮询/立即/重试)都必须先占位;占位与
        spawn 之间不许 await,否则同一 task_id 可重入。计数在 `_run_task`
        的 finally 里统一释放,成功/失败/取消/崩溃都不会泄漏。
        """
        if task_id in self._running or task_id in self._reserved:
            return False
        user_key = user_id or "_anonymous"
        if self._user_running.get(user_key, 0) >= _MAX_CONCURRENT_PER_USER:
            return False
        self._reserved.add(task_id)
        self._task_users[task_id] = user_id
        self._user_running[user_key] = self._user_running.get(user_key, 0) + 1
        return True

    def _release_slot(self, task_id: str, user_id: str | None) -> None:
        """释放 `_reserve` 占的位(任务终态/落库失败兜底共用)。"""
        user_key = user_id or "_anonymous"
        self._user_running[user_key] = max(0, self._user_running.get(user_key, 1) - 1)
        self._reserved.discard(task_id)
        self._running.pop(task_id, None)
        self._task_users.pop(task_id, None)

    # ===== 启停 =====

    def start(self) -> None:
        """启动调度器(轮询定时任务)。"""
        if self._started:
            return
        self._started = True
        self._poll_task = asyncio.create_task(self._poll_loop())
        logger.info("[publish.scheduler] started, poll interval=%ds", _POLL_INTERVAL_SEC)

    async def stop(self) -> None:
        """停止调度器。"""
        self._started = False
        if self._poll_task:
            self._poll_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._poll_task
            self._poll_task = None
        # 等待所有运行中任务完成(最多 30s)
        if self._running:
            logger.info(
                "[publish.scheduler] waiting %d running tasks to finish",
                len(self._running),
            )
            try:
                await asyncio.wait_for(
                    asyncio.gather(*self._running.values(), return_exceptions=True),
                    timeout=30,
                )
            except TimeoutError:
                for t in self._running.values():
                    t.cancel()
        self._running.clear()
        self._user_running.clear()
        self._reserved.clear()
        self._task_users.clear()

    # ===== DB 连接 =====

    async def _get_conn(self) -> asyncpg.Connection | None:
        dsn = getattr(settings, "database_url", None)
        if not dsn:
            return None
        try:
            return await get_db_conn()
        except Exception as e:
            logger.warning("[publish.scheduler] db connect failed: %s: %s", type(e).__name__, e)
            return None

    async def _ensure_tables(self, conn: asyncpg.Connection) -> None:
        """确保调度器所需表存在(idempotent)。"""
        await conn.execute(
            """
            CREATE TABLE IF NOT EXISTS publish_tasks (
                id BIGSERIAL PRIMARY KEY,
                task_id VARCHAR(64) UNIQUE NOT NULL,
                user_id VARCHAR(64),
                title VARCHAR(500) NOT NULL,
                format VARCHAR(32) NOT NULL,
                content JSONB NOT NULL,
                targets JSONB NOT NULL,
                status VARCHAR(32) NOT NULL DEFAULT 'pending',
                scheduled_at TIMESTAMPTZ,
                started_at TIMESTAMPTZ,
                finished_at TIMESTAMPTZ,
                results JSONB,
                error TEXT,
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
            )
            """
        )
        await conn.execute(
            """
            CREATE TABLE IF NOT EXISTS publish_history (
                id BIGSERIAL PRIMARY KEY,
                task_id VARCHAR(64) NOT NULL,
                user_id VARCHAR(64),
                platform VARCHAR(32) NOT NULL,
                success BOOLEAN NOT NULL,
                published_url TEXT,
                platform_content_id VARCHAR(255),
                error_message TEXT,
                duration_ms INTEGER DEFAULT 0,
                payload JSONB,
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
            )
            """
        )
        await conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_publish_tasks_user_id ON publish_tasks(user_id)"
        )
        await conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_publish_tasks_status ON publish_tasks(status)"
        )
        await conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_publish_tasks_scheduled_at ON publish_tasks(scheduled_at) "
            "WHERE status = 'scheduled'"
        )
        await conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_publish_history_task_id ON publish_history(task_id)"
        )

    # ===== 轮询循环 =====

    async def _poll_loop(self) -> None:
        """主轮询循环:每 60s 检查 scheduled_at 到期的任务。

        DB 连接失败时指数退避(5s → 300s 上限),恢复后回落到 _POLL_INTERVAL_SEC,
        避免 Postgres 未启动时高频空转(2026-08-13 立)。
        """
        # 启动延迟 30s,避免与 schema_check/DB 初始化争抢
        await asyncio.sleep(30)
        backoff = _DB_BACKOFF_BASE_SEC
        while self._started:
            try:
                ok = await self._poll_once()
            except asyncio.CancelledError:
                raise
            except Exception as e:
                logger.warning("[publish.scheduler] poll error: %s: %s", type(e).__name__, e)
                ok = False
            if ok:
                backoff = _DB_BACKOFF_BASE_SEC
                await asyncio.sleep(_POLL_INTERVAL_SEC)
            else:
                logger.warning(
                    "[publish.scheduler] db unavailable, backoff %.0fs (max %ds)",
                    backoff,
                    _DB_BACKOFF_MAX_SEC,
                )
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, _DB_BACKOFF_MAX_SEC)

    async def _poll_once(self) -> bool:
        """单次轮询:捞起到期任务并提交执行。返回 DB 是否可用(True=正常轮询)。"""
        conn = await self._get_conn()
        if conn is None:
            return False
        try:
            await self._ensure_tables(conn)
            now = datetime.now(UTC)
            # AIS-024:租约回收 —— 抢占后进程被 kill(滚动重启/panic)会留下永久
            # running 行,而启动只捞 scheduled,该定时任务从此不再被发布。超过租约
            # 时限仍处于 running 的行视为悬挂,退回 scheduled 等待下一轮重新抢占。
            tag = await conn.execute(
                """
                UPDATE publish_tasks
                SET status = 'scheduled', started_at = NULL, updated_at = $1
                WHERE status = 'running'
                  AND started_at < $1::timestamptz - ($2::float8 * INTERVAL '1 second')
                """,
                now,
                _RUNNING_LEASE_SEC,
            )
            reclaimed = _command_tag_count(tag)
            if reclaimed:
                logger.warning(
                    "[publish.scheduler] 回收悬挂 running 任务 %dan(租约 %ds)",
                    reclaimed,
                    _RUNNING_LEASE_SEC,
                )
            rows = await conn.fetch(
                """
                SELECT task_id, user_id, title, format, content, targets
                FROM publish_tasks
                WHERE status = 'scheduled' AND scheduled_at <= $1
                ORDER BY scheduled_at ASC
                LIMIT 20
                """,
                now,
            )
            for r in rows:
                task_id = r["task_id"]
                user_id = r["user_id"] or ""
                # AIS-023:去重与每用户上限与立即提交分支同一份判据(_reserve),先占位后落库
                if not self._reserve(task_id, user_id):
                    continue
                content = PublishContent(
                    format=r["format"],
                    title=r["title"],
                    text=r["content"].get("text") if isinstance(r["content"], dict) else None,
                    file_path=r["content"].get("file_path") if isinstance(r["content"], dict) else None,
                    cover_path=r["content"].get("cover_path") if isinstance(r["content"], dict) else None,
                    html=r["content"].get("html") if isinstance(r["content"], dict) else None,
                    images=r["content"].get("images", []) if isinstance(r["content"], dict) else [],
                    extra=r["content"].get("extra", {}) if isinstance(r["content"], dict) else {},
                )
                targets = r["targets"] if isinstance(r["targets"], list) else []
                # 标记为 running(AIS-023:落库失败要退掉已占的位,否则该任务永久悬挂)
                # AIS-024:CAS —— 两个调度实例同时捞到同一行时,只有 UPDATE 命中
                # (status 仍为 scheduled)的那个实例拿到所有权,另一个放弃并退位。
                try:
                    tag = await conn.execute(
                        "UPDATE publish_tasks SET status='running', started_at=$1, updated_at=$1 "
                        "WHERE task_id=$2 AND status='scheduled'",
                        now,
                        task_id,
                    )
                except Exception:
                    self._release_slot(task_id, user_id)
                    raise
                if _command_tag_count(tag) == 0:
                    logger.info("[publish.scheduler] 抢占失败(已被其他实例取走): %s", task_id)
                    self._release_slot(task_id, user_id)
                    continue
                self._spawn_task(self._run_task(task_id, user_id, content, targets))
            return True
        finally:
            await conn.close()

    # ===== 提交任务 =====

    async def submit_task(
        self,
        task_id: str,
        user_id: str | None,
        content: PublishContent,
        targets: list[dict[str, Any]],  # [{'platform': 'wordpress', 'account_id': 123, 'config': {...}}]
        scheduled_at: datetime | None = None,
    ) -> dict[str, Any]:
        """提交发布任务。

        scheduled_at 为空 → 立即执行
        scheduled_at 非空 → 写入 DB,等待调度器轮询触发
        """
        # 持久化到 DB
        conn = await self._get_conn()
        if conn is not None:
            try:
                await self._ensure_tables(conn)
                content_dict = {
                    "text": content.text,
                    "file_path": content.file_path,
                    "cover_path": content.cover_path,
                    "html": content.html,
                    "images": content.images,
                    "extra": content.extra,
                }
                status = "scheduled" if scheduled_at else "pending"
                await conn.execute(
                    """
                    INSERT INTO publish_tasks (task_id, user_id, title, format, content, targets, status, scheduled_at)
                    VALUES ($1, $2, $3, $4, $5::jsonb, $6::jsonb, $7, $8)
                    ON CONFLICT (task_id) DO UPDATE SET updated_at=NOW()
                    """,
                    task_id,
                    user_id,
                    content.title,
                    content.format,
                    json.dumps(content_dict, ensure_ascii=False),
                    json.dumps(targets, ensure_ascii=False),
                    status,
                    scheduled_at,
                )
            except Exception as e:
                logger.warning("[publish.scheduler] db persist failed: %s: %s", type(e).__name__, e)
            finally:
                await conn.close()

        if scheduled_at:
            return {"ok": True, "task_id": task_id, "status": "scheduled", "scheduled_at": scheduled_at.isoformat()}

        # 立即执行(AIS-023:与轮询分支同款门 —— task_id 去重 + 每用户并发上限,
        # 且先同步占位再 spawn,避免同一 task_id 双击/重放在启动窗口内并发两次)
        if not self._reserve(task_id, user_id):
            user_key = user_id or "_anonymous"
            reason = (
                "task already running"
                if task_id in self._running or task_id in self._reserved
                else "too many running tasks"
            )
            return {
                "ok": False,
                "task_id": task_id,
                "status": "rejected",
                "error": reason,
                "running": self._user_running.get(user_key, 0),
            }
        self._spawn_task(self._run_task(task_id, user_id, content, targets))
        return {"ok": True, "task_id": task_id, "status": "running"}

    # ===== 执行任务 =====

    async def _run_task(
        self,
        task_id: str,
        user_id: str | None,
        content: PublishContent,
        targets: list[dict[str, Any]],
    ) -> None:
        """执行单个发布任务(并发多平台)。"""
        # 计数/去重位已由提交侧 `_reserve` 占好;这里只把占位换成真实 task 句柄
        self._reserved.discard(task_id)
        self._running[task_id] = asyncio.current_task()  # type: ignore[assignment]

        try:
            # 解析内容为 HTML(若未解析)
            try:
                enrich_content(content)
            except Exception as e:
                logger.warning("[publish.scheduler] content parse failed: %s: %s", type(e).__name__, e)

            results: list[PublishResult] = []
            # 并发执行(每平台一个 task)
            coros = [self._run_single_platform(task_id, user_id, content, t) for t in targets]
            if coros:
                # BUG-34①:return_exceptions=True 让单平台异常作为结果返回,gather 会等
                # 全部兄弟协程结束才返回 ⇒ finally 里 pop _running 时不再有"仍在后台
                # 发布"的兄弟协程(旧写法异常立即上抛、兄弟未取消 ⇒ 用户可立刻重提,重复发布)。
                gathered = await asyncio.gather(*coros, return_exceptions=True)
                for target, item in zip(targets, gathered, strict=False):
                    if isinstance(item, BaseException):
                        # 只把异常平台补成失败项,已成功平台的结果原样保留,不整体抹空。
                        results.append(PublishResult(
                            success=False,
                            platform=str(target.get("platform", "")),
                            error_message=f"{type(item).__name__}: {item}",
                        ))
                    else:
                        results.append(item)

            # 汇总
            success_count = sum(1 for r in results if r.success)
            total = len(results)
            if total == 0:
                status = "failed"
                summary = "无目标平台"
            elif success_count == total:
                status = "success"
                summary = f"全部 {total} 个平台发布成功"
            elif success_count > 0:
                status = "partial"
                summary = f"{success_count}/{total} 个平台发布成功"
            else:
                status = "failed"
                summary = f"全部 {total} 个平台发布失败"

            results_payload = [
                {
                    "platform": r.platform,
                    "success": r.success,
                    "published_url": r.published_url,
                    "platform_content_id": r.platform_content_id,
                    "error_message": r.error_message,
                    "duration_ms": r.duration_ms,
                }
                for r in results
            ]

            # 更新 DB
            await self._finish_task_db(task_id, status, results_payload, summary)

            # 推送通知
            try:
                await notifications.notify_publish_complete(
                    task_id=task_id,
                    user_id=user_id,
                    status=status,
                    summary=summary,
                    payload={"results": results_payload},
                )
            except Exception as e:
                logger.warning("[publish.scheduler] notify failed: %s: %s", type(e).__name__, e)

            # 内存历史
            self._append_history({
                "task_id": task_id,
                "user_id": user_id,
                "status": status,
                "summary": summary,
                "success_count": success_count,
                "total": total,
                "results": results_payload,
                "finished_at": datetime.now(UTC).isoformat(),
            })
        except asyncio.CancelledError:
            # BUG-8:task.cancel() 投递的是 BaseException,except Exception 捕不到;
            # 旧实现路由只回响应不写库 ⇒ DB 的 running 行永久悬挂(_poll_once 只捞
            # scheduled,进程重启也不回收)。统一收口:任何取消来源都写回终态 cancelled。
            # shield 保证这次写库不被"再来一次取消"打断。
            with contextlib.suppress(Exception):
                await asyncio.shield(
                    self._finish_task_db(task_id, "cancelled", [], "任务已取消")
                )
            raise
        except Exception as e:
            logger.exception("[publish.scheduler] task crashed: %s", task_id)
            await self._finish_task_db(task_id, "failed", [], f"crashed: {e}")
            raise
        finally:
            # 清理(无论成功/失败/崩溃都执行:并发计数、去重位、running 句柄、属主映射)
            self._release_slot(task_id, user_id)

    async def _run_single_platform(
        self,
        task_id: str,
        user_id: str | None,
        content: PublishContent,
        target: dict[str, Any],
    ) -> PublishResult:
        """执行单平台发布(含凭证解密、进度通知、历史写入)。"""
        platform = target.get("platform", "")
        account_id = target.get("account_id")
        platform_config = target.get("config", {})

        adapter = get_adapter(platform)
        if adapter is not None:
            # 反风控身份键的稳定锚点:适配器实例每次新建(非单例),这里赋值不会跨任务串号
            adapter.db_account_id = account_id
        if adapter is None:
            result = PublishResult(
                success=False, platform=platform,
                error_message=f"adapter not found for platform: {platform}",
            )
            # 2026-08-17:失败也写 history,保证任务详情 platforms 完整
            await self._write_history(task_id, user_id, result)
            return result

        # 取凭证(从 publish_accounts 表解密;AIS-073:带任务 user_id 限定归属)
        credentials = await self._load_credentials(account_id, platform, user_id)
        if credentials is None:
            result = PublishResult(
                success=False, platform=platform,
                error_message=f"credentials not found for account_id={account_id}",
            )
            # 2026-08-17:失败也写 history,保证任务详情 platforms 完整
            await self._write_history(task_id, user_id, result)
            return result

        # 进度通知
        try:
            await notifications.notify_progress(task_id, user_id, platform, "start")
        except Exception as e:
            logger.warning("publish.scheduler 进度通知(start)失败: %s", e, exc_info=True)

        # ===== R8:发布前规则预检(字数/标签/敏感词)=====
        try:
            validation = validate_content(platform, content, platform_config)
            if not validation.valid:
                err_msg = "发布前预检失败: " + "; ".join(validation.errors)
                logger.warning("[publish.scheduler] %s validation failed: %s", platform, err_msg)
                result = PublishResult(
                    success=False, platform=platform,
                    error_message=err_msg,
                )
                await self._write_history(task_id, user_id, result)
                try:
                    await notifications.notify_progress(
                        task_id, user_id, platform, "failed", err_msg,
                    )
                except Exception as e:
                    logger.warning("publish.scheduler 进度通知(skip)失败: %s", e, exc_info=True)
                return result
            # 自动截断到平台限制(超长内容)
            content = truncate_to_platform(platform, content)
            if validation.warnings:
                logger.info(
                    "[publish.scheduler] %s validation warnings: %s",
                    platform, "; ".join(validation.warnings),
                )
        except Exception as e:
            logger.warning(
                "[publish.scheduler] %s validate_content error: %s: %s",
                platform, type(e).__name__, e,
            )

        # ===== R7 + R6:按平台做专属排版 + 图床替换(深拷贝避免污染其他平台)=====
        platform_content = copy.deepcopy(content)
        try:
            enrich_content_for_platform(platform_content, platform)
        except Exception as e:
            logger.warning(
                "[publish.scheduler] %s enrich_content_for_platform failed: %s: %s",
                platform, type(e).__name__, e,
            )
        try:
            if platform_content.html:
                platform_content.html = await process_external_images(
                    platform_content.html, platform, credentials,
                )
        except Exception as e:
            logger.warning(
                "[publish.scheduler] %s process_external_images failed: %s: %s",
                platform, type(e).__name__, e,
            )

        # ===== Anti-Risk:内容差异化(2026-08-01 深度强化)=====
        # 同内容多平台发布会被识别为机器操作,用 SimHash + 同义词改写做差异化
        account_id_str = str(account_id) if account_id is not None else ""
        if account_id_str:
            try:
                deduplicator = get_deduplicator()
                platform_content = deduplicator.diversify_for_platform(
                    platform_content, platform, account_id_str,
                )
            except Exception as e:
                logger.warning(
                    "[publish.scheduler] %s content diversify failed: %s: %s",
                    platform, type(e).__name__, e,
                )

        # ===== Anti-Risk:发布前冷却检查 + 风险评分检查(2026-07-31 强化)=====
        # 检查账号是否在冷却中(平台风控触发后自动冷却)
        # 检查账号风险评分(高频/高失败率/指纹变化等 → 强制冷却)
        risk_score: RiskScore | None = None
        if account_id_str and platform:
            try:
                cooldown_mgr = CooldownManager.get_instance()
                in_cooldown, cooldown_state = cooldown_mgr.is_in_cooldown(
                    account_id_str, platform,
                )
                if in_cooldown and cooldown_state is not None:
                    remaining = cooldown_mgr.get_remaining_time(
                        account_id_str, platform,
                    )
                    err_msg = (
                        f"账号冷却中(原因: {cooldown_state.reason}),"
                        f"剩余 {remaining}s"
                    )
                    logger.warning(
                        "[publish.scheduler] %s account %s in cooldown: %s",
                        platform, account_id_str, cooldown_state.reason,
                    )
                    result = PublishResult(
                        success=False, platform=platform,
                        error_message=err_msg,
                    )
                    await self._write_history(task_id, user_id, result)
                    try:
                        await notifications.notify_progress(
                            task_id, user_id, platform, "failed", err_msg,
                        )
                    except Exception as e:
                        logger.warning(
                            "publish.scheduler 进度通知(cooldown)失败: %s",
                            e, exc_info=True,
                        )
                    return result

                scorer = RiskScorer.get_instance()
                safe, risk_score = scorer.is_account_safe_to_publish(
                    account_id_str, platform,
                )
                if not safe:
                    cooldown_mgr.enter_cooldown(
                        account_id_str, platform, 3600,
                        f"风险评分过高: {risk_score.score}",
                    )
                    err_msg = (
                        f"账号风险评分过高({risk_score.score}/100),"
                        f"已进入 1 小时冷却。"
                        f"风险因素: {'; '.join(risk_score.factors)}"
                    )
                    logger.warning(
                        "[publish.scheduler] %s account %s risk too high: %d",
                        platform, account_id_str, risk_score.score,
                    )
                    result = PublishResult(
                        success=False, platform=platform,
                        error_message=err_msg,
                    )
                    await self._write_history(task_id, user_id, result)
                    try:
                        await notifications.notify_progress(
                            task_id, user_id, platform, "failed", err_msg,
                        )
                    except Exception as e:
                        logger.warning(
                            "publish.scheduler 进度通知(risk)失败: %s",
                            e, exc_info=True,
                        )
                    return result
            except Exception as e:
                logger.warning(
                    "[publish.scheduler] %s anti_risk pre-check error: %s: %s",
                    platform, type(e).__name__, e,
                )

        # ===== Anti-Risk:Cookie 健康度检查(2026-08-01 深度强化)=====
        # 发布前检查 Cookie 是否过期/即将过期,避免发布时才发现失效
        if account_id_str and platform:
            try:
                cookie_monitor = get_monitor()
                cookie_health = await cookie_monitor.check_cookie_health(
                    account_id_str, platform, credentials,
                )
                if cookie_health.status in ("expired", "invalid"):
                    # 2026-09-15 修复死锁:status=invalid 表示"从未实测过"(fail-closed
                    # 默认值),不阻断——真实登录态由适配器 publish 内的 /signin 重定向
                    # 检测兜底;否则扫码刷新凭据后仍被旧缓存永久拦截,只能重扫死循环。
                    # 仅 status=expired(有实测过期证据)才在此拦截。
                    if cookie_health.status == "expired":
                        err_msg = "Cookie 已过期或无效,请重新登录"
                        logger.warning(
                            "[publish.scheduler] %s account %s cookie expired,预检拦截",
                            platform, account_id_str,
                        )
                        result = PublishResult(
                            success=False, platform=platform,
                            error_message=err_msg,
                        )
                        await self._write_history(task_id, user_id, result)
                        try:
                            await notifications.notify_progress(
                                task_id, user_id, platform, "failed", err_msg,
                            )
                        except Exception as e:
                            logger.warning(
                                "publish.scheduler 进度通知(cookie)失败: %s",
                                e, exc_info=True,
                            )
                        return result
                    logger.info(
                        "[publish.scheduler] %s account %s cookie health=invalid(未实测),跳过预检拦截,交由适配器实测",
                        platform, account_id_str,
                    )
                elif cookie_health.status == "expiring_soon":
                    # 即将过期:记录但不阻塞(适配器发布时会自动续期)
                    logger.info(
                        "[publish.scheduler] %s account %s cookie 即将过期(剩余 %d 天)",
                        platform, account_id_str, cookie_health.days_until_expiry,
                    )
            except Exception as e:
                logger.warning(
                    "[publish.scheduler] %s cookie health check error: %s: %s",
                    platform, type(e).__name__, e,
                )

        # ===== Anti-Risk:设备关联图谱检测(2026-08-01 深度强化)=====
        # 发布前检测账号是否与其他账号共享设备/IP/指纹/UA(跨会话持久化检测)
        # 委托 DeviceGraphGuard.detect_linkage,命中关联则记录风险事件 + 自动冷却
        if account_id_str:
            try:
                from .anti_risk import CrossAccountGuard
                from .anti_risk.account_identity import (
                    resolve_account_id,
                    row_id_from_account_id,
                )

                # 检测键必须与 browser_factory 登记绑定用的键**同源**:此前这里传数据库行 id("12"),
                # 而登记用的是适配器派生键(csdn_db12 形态)⇒ 两个键空间永不相交,联动检测
                # 对被检账号永远查不到它自己的绑定,这道防护在正常发布路径上等于没生效。
                # 行 id 已是稳定锚点,故两侧都经同一出口算键。
                identity_key = resolve_account_id(platform, {}, account_id)
                cross_guard = CrossAccountGuard.get_instance()
                # 归属作用域：一个人运营十几个平台账号是**本产品的前提**，它们天然同一台机器、
                # 同一个 UA。不作用域化时每次发布都会自己给自己判一次"跨会话关联"并自动冷却 1h
                # （2026-09-27 实测：16 个账号在 UA 维度命中 3 组，第二篇推广文就是这样被拦下的）。
                # 查不到主人的键（字段哈希档 / legacy 档）一律照旧计入 —— 保守方向不能反。
                owner_by_row = await self._load_account_owners()

                def _owner_of(key: str, _m: dict[str, str] = owner_by_row) -> str | None:
                    rid = row_id_from_account_id(key)
                    return _m.get(rid) if rid else None

                is_linked, linkage_risk, linkage_types = (
                    await cross_guard.async_check_device_linkage(identity_key, owner_of=_owner_of)
                )
                if is_linked and linkage_risk >= 60:
                    # 高危关联(>=60):自动冷却 1h + 记录风险事件
                    cooldown_mgr = CooldownManager.get_instance()
                    cooldown_mgr.enter_cooldown(
                        account_id_str, platform, 3600,
                        f"设备关联图谱检测命中({','.join(linkage_types)},风险={linkage_risk})",
                    )
                    audit = AuditLogger()
                    audit.log_risk_event(
                        account_id_str, platform,
                        "device_linkage_detected",
                        "critical",
                        {
                            "linkage_types": linkage_types,
                            "risk_score": linkage_risk,
                        },
                    )
                    err_msg = (
                        f"账号检测到跨会话设备关联"
                        f"(类型:{','.join(linkage_types)},风险:{linkage_risk}/100),"
                        f"已自动冷却 1h,请检查账号隔离配置"
                    )
                    logger.warning(
                        "[publish.scheduler] %s account %s device linkage: %s",
                        platform, account_id_str, err_msg,
                    )
                    result = PublishResult(
                        success=False, platform=platform,
                        error_message=err_msg,
                    )
                    await self._write_history(task_id, user_id, result)
                    try:
                        await notifications.notify_progress(
                            task_id, user_id, platform, "failed", err_msg,
                        )
                    except Exception as e:
                        logger.warning(
                            "publish.scheduler 进度通知(device_linkage)失败: %s",
                            e, exc_info=True,
                        )
                    return result
                if is_linked:
                    # 中低危关联(<60):仅记录警告,不阻塞发布
                    logger.info(
                        "[publish.scheduler] %s account %s 设备关联风险较低(%d),继续发布",
                        platform, account_id_str, linkage_risk,
                    )
            except Exception as e:
                logger.warning(
                    "[publish.scheduler] %s device linkage check error: %s: %s",
                    platform, type(e).__name__, e,
                )

        # ===== Anti-Risk B5: 时区地理一致性校验(2026-08-01 终极强化)=====
        # 校验账号绑定的代理 IP 与 profile 时区是否一致(不一致 → warning,不阻塞)
        # TimezoneGeoValidator.validate 接受字符串参数(account_id/timezone/proxy_ip/language),
        # 无需 BrowserContext,scheduler 层可调用;字段缺失则跳过(不阻塞发布)
        if account_id_str:
            try:
                proxy_ip = str(platform_config.get("proxy_ip") or credentials.get("proxy_ip") or "")
                tz = str(platform_config.get("timezone") or "")
                lang = str(platform_config.get("language") or "")
                if proxy_ip and tz:
                    from .anti_risk import get_timezone_geo_validator
                    geo_validator = get_timezone_geo_validator()
                    geo_report = await geo_validator.validate(
                        account_id_str, tz, proxy_ip, lang,
                    )
                    if not geo_report.consistent:
                        logger.warning(
                            "[publish.scheduler] %s account %s 时区-地理不一致: %s"
                            "(profile 可能需要修正,不阻塞发布)",
                            platform, account_id_str, geo_report.suggestion,
                        )
                else:
                    logger.debug(
                        "[publish.scheduler] %s account %s 跳过 B5:缺少 proxy_ip/timezone 配置",
                        platform, account_id_str,
                    )
            except Exception as e:
                logger.warning(
                    "[publish.scheduler] %s timezone-geo check error: %s: %s",
                    platform, type(e).__name__, e,
                )

        # ===== Anti-Risk B6: TLS 指纹建议(2026-08-01 终极强化)=====
        # 为账号绑定固定 TLS 配置推荐(跨会话稳定),注入 platform_config 传给 adapter
        # 注意:Python Playwright 无法修改真实 TLS 握手,adapter 层可用此配置做 UA-TLS 一致性注入
        if account_id_str:
            try:
                from .anti_risk import get_tls_recommendation
                tls_profile = get_tls_recommendation(account_id_str)
                platform_config["tls_profile"] = tls_profile.to_dict()
                logger.debug(
                    "[publish.scheduler] %s account %s TLS 配置已注入: %s",
                    platform, account_id_str, tls_profile.browser_name,
                )
            except Exception as e:
                logger.warning(
                    "[publish.scheduler] %s tls recommendation error: %s: %s",
                    platform, type(e).__name__, e,
                )

        started = datetime.now(UTC)
        try:
            result = await adapter.publish(platform_content, credentials, platform_config)
        except Exception as e:
            result = PublishResult(
                success=False, platform=platform,
                error_message=f"{type(e).__name__}: {e}",
            )
        elapsed = int((datetime.now(UTC) - started).total_seconds() * 1000)
        result.duration_ms = elapsed

        # ===== 发布后存活监测 + 自动修复重提(2026-09-15 新增)=====
        # 内容平台(知乎等)会在发布后数分钟内做内容风控,营销外链类内容被静默移除。
        # 后台看护:180s 后 API 实核;被移除 → 自动去外链重提一次并全程留痕。
        if (
            result.success
            and result.published_url
            and result.platform_content_id
            and platform == "zhihu"
        ):
            spawn(
                _survival_watch_zhihu(
                    scheduler=self,
                    task_id=task_id,
                    user_id=user_id,
                    content=platform_content,
                    content_id=str(result.platform_content_id),
                    credentials=credentials,
                    platform_config=platform_config,
                    adapter=adapter,
                    attempt=1,
                ),
                name="publish-survival-watch",
            )
            logger.info(
                "[publish.scheduler] %s 存活看护已启动 task=%s content_id=%s",
                platform, task_id, result.platform_content_id,
            )

        # ===== Anti-Risk:验证码失败重试(2026-08-01 深度强化)=====
        # 发布失败且错误含验证码关键词时,记录验证码事件(供适配器后续处理)
        # 注意:scheduler 无 Page 访问权限,实际验证码解决需适配器集成 CaptchaSolver
        if not result.success and account_id_str:
            error_msg = result.error_message or ""
            captcha_keywords = ("验证", "captcha", "slider", "滑块", "人机")
            if any(kw in error_msg.lower() or kw in error_msg for kw in captcha_keywords):
                logger.info(
                    "[publish.scheduler] %s account %s 发布遇到验证码,记录事件",
                    platform, account_id_str,
                )
                try:
                    solver = get_solver()
                    # 记录验证码事件到风险评分(提高该账号风险等级)
                    scorer = RiskScorer.get_instance()
                    scorer.record_risk_event(
                        account_id_str, platform, "platform_risk_trigger",
                        {"error": error_msg, "captcha_detected": True},
                    )
                    # 若配置了第三方打码服务,记录可用性(适配器可读取此标志)
                    if solver._provider != "none":
                        logger.info(
                            "[publish.scheduler] %s 第三方打码服务已配置(%s),"
                            "适配器可集成 CaptchaSolver 自动处理",
                            platform, solver._provider,
                        )
                except Exception as e:
                    logger.warning(
                        "[publish.scheduler] %s captcha event record failed: %s",
                        platform, e,
                    )

        # ===== Anti-Risk:发布后审计 + 风险事件记录 + 失败关键词检测(2026-07-31 强化)=====
        # 成功:记录 publish_success 事件(风险评分衰减)
        # 失败:检查错误信息是否含风控关键词 → 自动冷却 + 记录 platform_risk_trigger
        #       非风控失败 → 记录 publish_failed + 累计连续失败次数(达 3 次自动冷却)
        if account_id_str and platform:
            try:
                audit = AuditLogger.get_instance()
                score_val = risk_score.score if risk_score is not None else 0
                audit.log_publish_attempt(
                    account_id_str, platform, result.success, score_val,
                    result.duration_ms,
                    {
                        "published_url": result.published_url,
                        "error_message": result.error_message,
                        "task_id": task_id,
                    },
                )

                scorer = RiskScorer.get_instance()
                cooldown_mgr = CooldownManager.get_instance()
                if result.success:
                    scorer.record_risk_event(
                        account_id_str, platform, "publish_success",
                        {"url": result.published_url},
                    )
                    cooldown_mgr.record_success(account_id_str, platform)
                else:
                    error_msg = result.error_message or ""
                    if RiskScorer.is_platform_risk_error(error_msg):
                        # 平台风控触发:按错误关键词严重度冷却
                        duration, reason = cooldown_duration_for_error(error_msg)
                        if duration > 0:
                            cooldown_mgr.enter_cooldown(
                                account_id_str, platform, duration, reason,
                            )
                            audit.log_cooldown_event(
                                account_id_str, platform, "enter",
                                reason, duration,
                            )
                        scorer.record_risk_event(
                            account_id_str, platform, "platform_risk_trigger",
                            {"error": error_msg},
                        )
                    else:
                        # 普通失败:记录 + 累计连续失败(达 3 次自动冷却 1h)
                        scorer.record_risk_event(
                            account_id_str, platform, "publish_failed",
                            {"error": error_msg},
                        )
                        cd_state = cooldown_mgr.record_failure(
                            account_id_str, platform,
                        )
                        if cd_state is not None:
                            audit.log_cooldown_event(
                                account_id_str, platform, "enter",
                                cd_state.reason, 3600,
                            )
            except Exception as e:
                logger.warning(
                    "[publish.scheduler] %s anti_risk post-check error: %s: %s",
                    platform, type(e).__name__, e,
                )

        # ===== Anti-Risk B7: 行为熵分析(2026-08-01 终极强化)=====
        # 分析本账号近期发布间隔序列的香农熵,熵值过低(行为过于规律)→ 记录风险事件
        # 数据源:publish_history 表查询近期成功发布的间隔时间(秒),样本<5 跳过
        if account_id_str and user_id:
            try:
                from .anti_risk import BEHAVIOR_TYPE, get_entropy_analyzer
                conn_b7 = await self._get_conn()
                if conn_b7 is not None:
                    try:
                        rows_b7 = await conn_b7.fetch(
                            """
                            SELECT EXTRACT(EPOCH FROM created_at)::float8 AS ts
                            FROM publish_history
                            WHERE user_id = $1 AND platform = $2 AND success = TRUE
                            ORDER BY created_at DESC
                            LIMIT 10
                            """,
                            user_id, platform,
                        )
                        if len(rows_b7) >= 5:
                            # rows 倒序(最新在前),反转为正序后计算相邻间隔
                            ts_list: list[float] = [
                                float(r["ts"]) for r in reversed(rows_b7)
                            ]
                            intervals_b7: list[float] = [
                                ts_list[i + 1] - ts_list[i]
                                for i in range(len(ts_list) - 1)
                            ]
                            if len(intervals_b7) >= 5:
                                entropy_report = get_entropy_analyzer().analyze(
                                    intervals_b7, BEHAVIOR_TYPE,
                                )
                                if not entropy_report.is_human_like:
                                    logger.warning(
                                        "[publish.scheduler] %s account %s 行为熵值异常"
                                        "(%.2f,%s),发布间隔过于规律",
                                        platform, account_id_str,
                                        entropy_report.shannon_entropy,
                                        entropy_report.suggestion,
                                    )
                                    audit_b7 = AuditLogger.get_instance()
                                    audit_b7.log_risk_event(
                                        account_id_str, platform,
                                        "low_behavior_entropy",
                                        "warning",
                                        entropy_report.to_dict(),
                                    )
                    finally:
                        await conn_b7.close()
            except Exception as e:
                logger.warning(
                    "[publish.scheduler] %s behavior entropy analysis error: %s: %s",
                    platform, type(e).__name__, e,
                )

        # 写历史
        await self._write_history(task_id, user_id, result)

        # 进度通知
        try:
            await notifications.notify_progress(
                task_id, user_id, platform,
                "success" if result.success else "failed",
                result.error_message or "",
            )
        except Exception as e:
            logger.warning("publish.scheduler 进度通知(end)失败: %s", e, exc_info=True)

        return result

    async def _load_credentials(
        self,
        account_id: int | None,
        platform: str,
        user_id: str | None,
    ) -> dict[str, Any] | None:
        """从 publish_accounts 表加载并解密凭证(AIS-073:须归属任务 user_id)。

        查询口径带 user_id,防止调用链上游漏校验时用他人账号凭证代发。
        """
        # fail-closed:缺归属主体时直接拒绝,连库都不碰 —— 否则 user_id=NULL 的查询
        # 语义依赖驱动/列约束(历史上就有 `WHERE user_id=$3` 传 None 全落空的隐式行为),
        # 且会给攻击面留一次不必要的出站。
        if account_id is None or not user_id:
            return None
        conn = await self._get_conn()
        if conn is None:
            return None
        try:
            row = await conn.fetchrow(
                "SELECT credentials_enc FROM publish_accounts "
                "WHERE id=$1 AND platform=$2 AND user_id=$3",
                account_id,
                platform,
                user_id,
            )
            if not row:
                return None
            cipher = row["credentials_enc"]
            if not cipher:
                return None
            return decrypt(cipher)
        except Exception as e:
            logger.warning(
                "[publish.scheduler] load credentials failed: %s: %s", type(e).__name__, e
            )
            return None
        finally:
            await conn.close()

    async def _load_account_owners(self) -> dict[str, str]:
        """`publish_accounts` 行 id → user_id 的一次性映射（设备关联检测的归属解析器用）。

        失败方向刻意是**返回空表**而不是抛：空表 ⇒ 所有候选都"查不到主人" ⇒ 判据退回本次改动前
        的保守行为（照样计入关联、照样冷却）。也就是说这条降级**只会多拦不会少拦**，
        所以它可以只喊一行 warning 而不阻断发布 —— 反过来的降级方向（查不到就当同主人放行）
        等于给关联检测开后门，那是不可接受的。
        """
        conn = await self._get_conn()
        if conn is None:
            # `_get_conn` 自己就把失败咽成 None 了(它另有 12 处调用方按 None 处理)。
            # 本函数必须显式接住这一格,否则下面 `conn.fetch` 抛 AttributeError 会把整次发布打断。
            logger.warning("[publish.scheduler] 归属映射取不到连接,设备关联检测按保守口径执行")
            return {}
        try:
            rows = await conn.fetch("SELECT id, user_id FROM publish_accounts")
            return {str(r["id"]): str(r["user_id"]) for r in rows if r["user_id"] is not None}
        except Exception as e:  # noqa: BLE001
            logger.warning(
                "[publish.scheduler] 归属映射查询失败,设备关联检测按保守口径执行: %s",
                type(e).__name__,
            )
            return {}
        finally:
            await conn.close()

    async def _write_history(
        self, task_id: str, user_id: str | None, result: PublishResult
    ) -> None:
        """写入 publish_history 表。"""
        conn = await self._get_conn()
        if conn is None:
            return
        try:
            await self._ensure_tables(conn)
            await conn.execute(
                """
                INSERT INTO publish_history
                (task_id, user_id, platform, success, published_url, platform_content_id,
                 error_message, duration_ms, payload)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9::jsonb)
                """,
                task_id,
                user_id,
                result.platform,
                result.success,
                result.published_url,
                result.platform_content_id,
                result.error_message,
                result.duration_ms,
                json.dumps(result.payload or {}, ensure_ascii=False),
            )
        except Exception as e:
            # 撞主键 = 序列落后,表现是"任务判 failed 而库里一行审计都没有"—— 这类失败必须响
            log_db_write_failure(
                logger, e, table="publish_history", prefix="[publish.scheduler]"
            )
        finally:
            await conn.close()

    async def _finish_task_db(
        self, task_id: str, status: str, results: list[dict[str, Any]], summary: str
    ) -> None:
        """更新任务状态为已完成。"""
        conn = await self._get_conn()
        if conn is None:
            return
        try:
            # 2026-08-17 修复:asyncpg 对 UPDATE SET 子句的 $1 推断为 text,
            # 与 CASE WHEN $1='failed' 的 varchar 比较冲突 → AmbiguousParameterError →
            # 写库静默失败,任务状态永久 pending。彻底解法:把"是否 failed"拆成独立布尔参数 $3,
            # $1 只出现在 SET status=$1(唯一上下文),不再参与比较,无类型歧义。
            await conn.execute(
                """
                UPDATE publish_tasks
                SET status=$1, results=$2::jsonb, finished_at=NOW(), updated_at=NOW(),
                    error=CASE WHEN $3 THEN $4 ELSE error END
                WHERE task_id=$5
                """,
                status,
                json.dumps(results, ensure_ascii=False),
                status == "failed",
                summary,
                task_id,
            )
        except Exception as e:
            logger.warning("[publish.scheduler] finish task db failed: %s: %s", type(e).__name__, e)
        finally:
            await conn.close()

    def _append_history(self, entry: dict[str, Any]) -> None:
        """追加内存历史(LRU)。"""
        self._history.append(entry)
        while len(self._history) > _HISTORY_LIMIT:
            self._history.pop(0)

    # ===== 公开 API =====

    def list_running(self, owner_user_id: str | None = None) -> list[str]:
        """列出正在执行的 task_id。

        AIS-042:`owner_user_id=None` 是系统级/admin 视角(全站);带主体时只回该主体
        的任务(历史条目里本就带 user_id,这里按 `_task_users` 映射对齐)。
        """
        if owner_user_id is None:
            return list(self._running.keys())
        return [
            task_id
            for task_id in self._running
            if self._task_users.get(task_id) == owner_user_id
        ]

    def list_history(
        self, limit: int = 50, owner_user_id: str | None = None
    ) -> list[dict[str, Any]]:
        """列出最近 N 条历史(内存,倒序)。

        AIS-042:带主体时按条目 `user_id` 过滤,避免把他人 task_id/发布地址一并回出。
        """
        entries = list(reversed(self._history))
        if owner_user_id is not None:
            entries = [e for e in entries if e.get("user_id") == owner_user_id]
        return entries[: max(1, min(limit, _HISTORY_LIMIT))]

    async def cancel_task(self, task_id: str) -> bool:
        """取消任务(只能取消正在执行的)。"""
        task = self._running.get(task_id)
        if task is None:
            return False
        task.cancel()
        return True

    async def retry_platforms(
        self, task_id: str, platforms: list[str] | None = None
    ) -> dict[str, Any]:
        """重试失败的平台。

        platforms 为空 → 重试该任务所有失败平台
        platforms 非空 → 仅重试指定平台
        """
        conn = await self._get_conn()
        if conn is None:
            return {"ok": False, "error": "db unavailable"}
        try:
            row = await conn.fetchrow(
                "SELECT user_id, title, format, content, targets, results FROM publish_tasks WHERE task_id=$1",
                task_id,
            )
            if not row:
                return {"ok": False, "error": f"task not found: {task_id}"}
            results = row["results"] if isinstance(row["results"], list) else []
            failed_platforms = {
                r["platform"] for r in results if not r.get("success")
            }
            target_platforms = set(platforms) if platforms else failed_platforms
            new_targets = [
                t for t in (row["targets"] if isinstance(row["targets"], list) else [])
                if t.get("platform") in target_platforms
            ]
            if not new_targets:
                return {"ok": False, "error": "no targets to retry"}

            content = PublishContent(
                format=row["format"],
                title=row["title"],
                text=row["content"].get("text") if isinstance(row["content"], dict) else None,
                file_path=row["content"].get("file_path") if isinstance(row["content"], dict) else None,
                cover_path=row["content"].get("cover_path") if isinstance(row["content"], dict) else None,
                html=row["content"].get("html") if isinstance(row["content"], dict) else None,
                images=row["content"].get("images", []) if isinstance(row["content"], dict) else [],
            )
            retry_task_id = f"{task_id}-retry-{int(datetime.now(UTC).timestamp())}"
            # 2026-08-17 修复:参数顺序错误 _run_task(task_id, user_id, content, targets),
            # 原代码把 user_id 当 task_id、retry_task_id 当 user_id 传入 → retry 任务身份错乱。
            # AIS-023:重试同样走 _reserve(spawn 的每条路径都必须先占位)
            retry_user_id = row["user_id"] or ""
            if not self._reserve(retry_task_id, retry_user_id):
                return {"ok": False, "error": "too many running tasks"}
            self._spawn_task(
                self._run_task(retry_task_id, retry_user_id, content, new_targets)
            )
            return {"ok": True, "retry_task_id": retry_task_id, "targets": len(new_targets)}
        except Exception as e:
            return {"ok": False, "error": f"{type(e).__name__}: {e}"}
        finally:
            await conn.close()


# 单例
publish_scheduler = PublishScheduler()
# ⁠​‌​​‌​​‌‍‍​‌​​‌​​​‍‍​‌​‌​‌​‌‍‍​‌​​‌​​‌‍‍​​‌​‌‌​‌‍‍​‌​​​​​‌‍‍​‌​​‌​​‌‍‍‌​‌‌​‌‌‌‍‍‌‌​​‌‌​​‌‌‌‌​‌​‍‍‌‌​‌‌​​​‌​​​‌‌‌‍‍​‌​​​​​‌‍‍​‌​​‌​​‌‍‍‌​‌‌​‌‌‌‍‍‌‌​​‌‌‌​‌​​‌‌‌​‍‍‌‌​​‌‌​​​‌​​‌​‌‍‍‌​‌‌‌​‌‌‌​‌‌‌​‌‍‍‌​‌‌​‌‌‌‍‍​‌​​‌‌​​‍‍​‌​​​​‌‌‍‍‌​‌‌​‌‌‌‍‍​‌‌​​​​‌‍‍​‌‌​‌​​‌‍‍​‌‌‌‌​‌​‍‍​‌‌​‌​​​‍‍​‌‌‌​​‌‌‍‍​​‌​‌‌‌​‍‍​‌‌‌​‌​​‍‍​‌‌​‌‌‌‌‍‍​‌‌‌​​​​‍‍‌​‌‌​‌‌‌‍‍​‌​‌​​​​‍‍​‌​‌​​‌​‍‍​‌​​‌‌‌‌‍‍​‌​‌​‌‌​‍‍​‌​​​‌​‌‍‍​‌​​‌‌‌​‍‍​‌​​​​​‌‍‍​‌​​‌‌‌​‍‍​‌​​​​‌‌‍‍​‌​​​‌​‌‍‍​​‌​‌‌​‌‍‍​​‌‌​​‌​‍‍​​‌‌​​​​‍‍​​‌‌​​‌​‍‍​​‌‌​‌‌​⁠


async def _survival_watch_zhihu(
    scheduler: Any,
    *,
    task_id: str,
    user_id: str | None,
    content: PublishContent,
    content_id: str,
    credentials: dict[str, Any],
    platform_config: dict[str, Any],
    adapter: Any,
    attempt: int = 1,
) -> None:
    """发布后存活看护(2026-09-15 新增):180s 后 API 实核;
    被平台内容风控静默移除 → 自动去外链重提一次,全程留痕。"""
    from .anti_risk.cookie_health import get_monitor

    await asyncio.sleep(180)
    try:
        alive = await adapter.verify_alive(
            content_id=str(content_id), credentials=credentials,
        )
    except Exception as e:
        logger.warning("[publish.scheduler] 存活实核异常 task=%s: %s", task_id, e)
        return
    if alive:
        logger.info(
            "[publish.scheduler] 知乎文章存活确认 task=%s content_id=%s",
            task_id, content_id,
        )
        with contextlib.suppress(Exception):
            get_monitor().record_cookie_status(
                str(credentials.get("_account_id") or ""), "zhihu", "healthy",
            )
        return
    if attempt >= 2:
        logger.warning(
            "[publish.scheduler] 知乎文章两次被移除 task=%s,停止重提(需人工复核内容合规)",
            task_id,
        )
        return
    # 被移除 → 去外链重提
    stripped_html = re.sub(r"<a\s[^>]*href=[^>]*>(.*?)</a>", r"", content.html or "", flags=re.S)
    variant = _dc_replace(content, html=stripped_html)
    logger.warning(
        "[publish.scheduler] 知乎文章被内容风控移除 task=%s,自动去外链重提(第 %d 次)",
        task_id, attempt,
    )
    started = datetime.now(UTC)
    result = await adapter.publish(variant, credentials, platform_config)
    result.duration_ms = int((datetime.now(UTC) - started).total_seconds() * 1000)
    with contextlib.suppress(Exception):
        await scheduler._write_history(task_id, user_id, result)
    if result.success and result.platform_content_id:
        await _survival_watch_zhihu(
            scheduler, task_id=task_id, user_id=user_id, content=variant,
            content_id=str(result.platform_content_id),
            credentials=credentials, platform_config=platform_config,
            adapter=adapter, attempt=attempt + 1,
        )
