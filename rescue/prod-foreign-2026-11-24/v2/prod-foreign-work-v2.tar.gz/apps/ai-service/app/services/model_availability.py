# © 2026 IHUI AI (智汇AI) · 版权所有者: 李春川 (Li Chunchuan) · https://aizhs.top
# Provenance-watermarked. 未授权商用可被溯源追责 (Apache-2.0 须保留本声明与 NOTICE)。
# [IHUI-AI-PROVENANCE]:⁠​‌​​‌​​‌‍‍​‌​​‌​​​‍‍​‌​‌​‌​‌‍‍​‌​​‌​​‌‍‍​​‌​‌‌​‌‍‍​‌​​​​​‌‍‍​‌​​‌​​‌‍‍‌​‌‌​‌‌‌‍‍‌‌​​‌‌​​‌‌‌‌​‌​‍‍‌‌​‌‌​​​‌​​​‌‌‌‍‍​‌​​​​​‌‍‍​‌​​‌​​‌‍‍‌​‌‌​‌‌‌‍‍‌‌​​‌‌‌​‌​​‌‌‌​‍‍‌‌​​‌‌​​​‌​​‌​‌‍‍‌​‌‌‌​‌‌‌​‌‌‌​‌‍‍‌​‌‌​‌‌‌‍‍​‌​​‌‌​​‍‍​‌​​​​‌‌‍‍‌​‌‌​‌‌‌‍‍​‌‌​​​​‌‍‍​‌‌​‌​​‌‍‍​‌‌‌‌​‌​‍‍​‌‌​‌​​​‍‍​‌‌‌​​‌‌‍‍​​‌​‌‌‌​‍‍​‌‌‌​‌​​‍‍​‌‌​‌‌‌‌‍‍​‌‌‌​​​​‍‍‌​‌‌​‌‌‌‍‍​‌​‌​​​​‍‍​‌​‌​​‌​‍‍​‌​​‌‌‌‌‍‍​‌​‌​‌‌​‍‍​‌​​​‌​‌‍‍​‌​​‌‌‌​‍‍​‌​​​​​‌‍‍​‌​​‌‌‌​‍‍​‌​​​​‌‌‍‍​‌​​​‌​‌‍‍​​‌​‌‌​‌‍‍​​‌‌​​‌​‍‍​​‌‌​​​​‍‍​​‌‌​​‌​‍‍​​‌‌​‌‌​⁠

"""模型可用性服务(2026-07-31 立,用户规则:只显示可完美接通调用的模型)。

职责:
1. 启动时 + 每 5 分钟后台 ping 所有已配置 key 的 provider(调 /v1/models 端点)
2. 缓存 provider 健康状态:HEALTHY / DEGRADED / DOWN / NOT_CONFIGURED / LOCAL / ZERO_COST
3. 提供 is_model_available() + get_available_models() 过滤不可用模型

判定模型可显示的规则(任一满足即显示):
- provider 是 LOCAL(ollama/lmstudio/llamacpp/vllm):本地 LLM
- provider 已配置 key(.env / LLM_PROVIDERS JSON)+ 健康检查通过
- provider 是 zero_cost(pollinations/llm7/opencode_zen):无需 key,同样要过健康检查
  (2026-08-02 起:zero_cost 也 ping 验证,opencode_zen 429 等调不通的不显示)
- DB 来源模型(ai_model_config_models 表):用户主动配置,直接显示(由调用方决定)

过滤掉的模型:
- 未配置 key 的 provider 模型(如 openai/anthropic/groq 等 .env 未配 key)
- 健康检查 DOWN 的 provider 模型(401/403/超时/网络错误)
- 延迟过高(> 30s)的 provider 模型

设计要点:
- ping 是 provider 维度(每个 provider 取一个代表 endpoint 测试),不是模型维度
- ping 不消耗 token(调 /v1/models 列表端点,不是 chat/completions)
- 缓存 5 分钟,避免 /llm/models 端点每次请求都触发 ping
- 启动时后台跑首次 ping(不阻塞 FastAPI 启动),首次请求可能命中 PENDING 状态
  → PENDING 视为可用(给 provider 一个宽松期,等首次 ping 完成再过滤)
"""

from __future__ import annotations

import asyncio
import contextlib
import logging
import os
import time
from dataclasses import dataclass
from enum import StrEnum
from typing import Any

import httpx

from ..core.background_tasks import spawn
from ..core.config import settings
from ..core.default_model import is_retired_provider
from ..middleware.llm_metrics import is_quota_exhaustion_error
from .free_provider_registry import ProviderCategory, ProviderStatus, free_provider_registry

logger = logging.getLogger(__name__)


# ============================================================================
# 常量配置
# ============================================================================

# 延迟阈值(ms)
LATENCY_DEGRADED_MS = 10_000  # 10s 以上标记 DEGRADED(仍显示)
LATENCY_DOWN_MS = 30_000      # 30s 以上标记 DOWN(不显示)

# ping 超时(秒)
# 2026-08-02 修复:8s 对慢 provider(nvidia_nim 实测 9-16s)过严 → 误判 DOWN,
# 调不通的判定应交给 LATENCY_DOWN_MS(30s):超时 20s + 30s DOWN 阈值逻辑自洽
PING_TIMEOUT_S = 20.0

# 缓存刷新间隔(秒)— 5 分钟刷新一次全量 provider 健康状态
REFRESH_INTERVAL_S = 300

# 余额不足阈值(按币种)— 低于此值视为"账户没钱",标 DOWN + PAYMENT_REQUIRED
# 2026-07-31 立:OpenRouter 实测余额 $0.0001 仍标 HEALTHY,但实际无法调用任何模型
# (最便宜模型 gpt-4o-mini 输入 $0.00001/token,0.0001 美元只够 10 token,无法完成一次对话)
# 阈值设计:低于此值 = 一次最小调用都凑不齐 = 视为没钱
MIN_BALANCE_THRESHOLDS: dict[str, float] = {
    "USD": 0.01,   # $0.01 = 1 美分(最便宜模型约 1000 token)
    "CNY": 0.10,   # ¥0.10 = 1 角(国内 provider 最小调用成本)
    "EUR": 0.01,
    "GBP": 0.01,
}
# 默认阈值(币种未在映射里时使用)
MIN_BALANCE_DEFAULT = 0.01

# 并发 ping 限流(避免一次启动几十个并发请求)
PING_CONCURRENCY = 10

# 429 限流退避(秒)— provider 被 429 后,跳过 ping 的时间,避免反复触发限流
RATE_LIMIT_BACKOFF_S = 900

# 额度耗尽标记的可信时长(秒)= 一个探测周期:实时调用判定的额度状态只采信到下一轮
# ping 覆盖为止,充值后由既有刷新循环自动恢复,网关侧不需要任何持久化脏状态。
QUOTA_BLOCK_TRUST_S = REFRESH_INTERVAL_S

# zero_cost provider 集合(无需 key 即可调用,与 free_provider_registry._ZERO_COST_CODES 对齐)
_ZERO_COST_CODES: set[str] = {"pollinations", "llm7", "opencode_zen"}


# ============================================================================
# 模型 ID 前缀 → provider_code 映射
# ============================================================================
# 顺序敏感:长前缀优先匹配(避免 "s" 误匹配 "stepfun/")
# 与 llm_gateway._PREFIX_TO_PROVIDER_CODE 字典对齐,但本表用于"显示过滤"维度
_MODEL_PREFIX_TO_PROVIDER: list[tuple[str, str]] = [
    # === 项目主力(LLM_PROVIDERS JSON 已配置)===
    ("stepfun/", "stepfun"),
    ("agnes/", "agnes"),
    # agnes 入库的是裸名(agnes-2.0-flash / agnes-3.0-flash,官方不带 vendor 前缀):
    # 只有带斜杠那条会判成"未知 provider",整家被 /llm/models 过滤掉 —— 而 agnes 是实测
    # 免充值真能出字的通道之一(2026-09-21 逐通道探测)。与 mimo 同一类缺陷。
    ("agnes-", "agnes"),
    # (2026-10-24 移除)ihui/ → ihui_relay 映射随 SwiftAPI 弃用删除:ihui_relay
    # (极速API)已停止运营,registry 条目与 default_models.json
    # 中的 ihui/ 模型均已移除,再无 ihui/ 前缀模型需要健康检查覆盖。
    # WorkBuddy 账号池(项目自有中转站):模型 id 以 workbuddy/ 前缀暴露
    ("workbuddy/", "workbuddy_relay"),
    # 2026-09-08 新增:token6688 聚合网关(t6688/ 前缀),缺此条 is_model_available
    # 返回未知 → 模型永远被过滤,前端看不到
    # === Cloudflare Workers AI(@cf/ 前缀)===
    ("@cf/", "cloudflare_workers_ai"),
    ("cloudflare/", "cloudflare_workers_ai"),
    # === NVIDIA NIM ===
    ("nvidia/", "nvidia_nim"),
    # === GitHub Models ===
    ("github/", "github_models"),
    # === OpenCode Zen(无需 key)===
    ("opencode/", "opencode_zen"),
    # === Scaleway ===
    ("scaleway/", "scaleway"),
    # === Alibaba Intl ===
    ("alibaba-intl/", "alibaba_intl"),
    # === 免费 zero_cost provider(无需 key)===
    ("pollinations/", "pollinations"),
    ("llm7/", "llm7"),
    # === Vercel AI Gateway ===
    ("vercel/", "vercel_ai_gateway"),
    # === Qoder(需要 key)===
    ("if/", "qoder"),
    # === OVH / Requesty / Navy ===
    ("ovhcloud/", "ovhcloud"),
    ("requesty/", "requesty"),
    ("navy/", "navy"),
    # === OpenRouter / Groq / Gemini 前缀 ===
    ("openrouter/", "openrouter"),
    ("groq/", "groq"),
    # 2026-08-02 修复:与 free_provider_registry.provider_code="gemini" + LLM_PROVIDERS["gemini"] 对齐
    # 原映射 "google" 导致 is_model_available 找 LLM_PROVIDERS["google"] 找不到 key,gemini 模型被过滤
    ("gemini/", "gemini"),
    # === Anthropic ===
    ("anthropic/", "anthropic"),
    # === 本地 LLM(无需 key)===
    ("ollama/", "ollama"),
    ("lmstudio/", "lmstudio"),
    ("llamacpp/", "llamacpp"),
    ("vllm/", "vllm"),
    ("qwen-local/", "qwen_local"),
    # === 云平台 ===
    ("azure/", "azure"),
    ("bedrock/", "bedrock"),
    ("vertex/", "vertexai"),
    # === HuggingFace / Replicate ===
    ("huggingface/", "huggingface"),
    ("replicate/", "replicate"),
    # === Cerebras / SambaNova ===
    ("cerebras/", "cerebras"),
    ("sambanova/", "sambanova"),
    # === 国内聚合平台 ===
    ("siliconcloud/", "siliconcloud"),
    ("modelscope/", "modelscope"),
    ("ppio/", "ppio"),
    ("volcengine/", "volcengine"),
    ("bailian/", "bailian"),
    # === 国内厂商(无前缀,按模型名前缀匹配)===
    ("qwen", "qwen"),
    ("qwen-", "qwen"),
    ("doubao-", "doubao"),
    ("hunyuan-", "hunyuan"),
    ("glm-", "zhipu"),
    ("ernie-", "wenxin"),
    ("abab", "minimax"),
    ("minimax-", "minimax"),
    ("baichuan-", "baichuan"),
    ("spark-", "spark"),
    ("yi-", "yi"),
    ("internlm", "internlm"),
    ("sensenova-", "sensenova"),
    ("skywork-", "skywork"),
    # 小米 MiMo 官方 /v1/models 返回裸名(mimo-v2.5 等,无 vendor 前缀);缺此条则
    # _infer_provider_code 判为未知 provider,按 fail-closed 规则被 /llm/models 过滤掉
    ("mimo-", "mimo"),
    # === 推理平台扩展 ===
    ("novita/", "novita"),
    ("lambda/", "lambda"),
    ("baseten/", "baseten"),
    ("crusoe/", "crusoe"),
    ("targon/", "targon"),
    ("centml/", "centml"),
    ("nebius/", "nebius"),
    ("upstage/", "upstage"),
    ("leptonai/", "leptonai"),
    ("hyperbolic/", "hyperbolic"),
    ("featherless/", "featherless"),
    ("parasail/", "parasail"),
    ("openwebui/", "openwebui"),
    ("friendli/", "friendli"),
    ("anyscale/", "anyscale"),
    ("infermatic/", "infermatic"),
    ("replit/", "replit"),
    ("deepinfra/", "deepinfra"),
    # === 国际原厂(无前缀,按模型名前缀匹配)===
    ("gpt-", "openai"),
    ("o1-", "openai"),
    ("o3", "openai"),
    ("o4-", "openai"),
    ("claude-", "anthropic"),
    # 2026-08-02 修复:与 gemini/ 前缀映射保持一致(均走 gemini provider_code)
    ("gemini-", "gemini"),
    ("gemma-", "gemma"),
    ("llama-", "meta"),
    ("grok-", "xai"),
    ("deepseek-", "deepseek"),
    ("mistral-", "mistral"),
    ("codestral-", "mistral"),
    ("pixtral-", "mistral"),
    ("command-", "cohere"),
    # 2026-08-02 修复:与 nvidia/ 前缀统一为 nvidia_nim(健康表 key 一致,
    # 否则 nemotron-* 模型走 "nvidia" key 查不到健康状态 → 429 时漏过滤)
    ("nemotron-", "nvidia_nim"),
    ("phi-", "microsoft"),
    ("phi3", "microsoft"),
    ("sonar-", "perplexity"),
    ("amazon-nova-", "aws"),
    ("jamba-", "ai21"),
    ("stablelm-", "stability"),
    ("inflection-", "inflection"),
    ("watsonx/", "ibm"),
    ("nous-", "nous"),
    ("luminous-", "alephalpha"),
    ("snowflake-", "snowflake"),
    ("baai/", "baai"),
    ("tii/", "tii"),
    ("liquid/", "liquid"),
    ("ai2/", "ai2"),
    # === 2026-07 新模型(无前缀)===
    ("ornith-", "ornith"),
    ("codebrain-", "codebrain"),
    ("mai-", "mai"),
    ("kimi-", "moonshot"),
    ("moonshot-", "moonshot"),
]


def _infer_provider_code(model_id: str) -> str:
    """从模型 ID 推断 provider_code(用前缀字典匹配)。

    匹配规则:长前缀优先(列表顺序即优先级),返回首个匹配项。
    未知 provider 返回空字符串(视为不可显示)。
    """
    m = model_id.lower()
    for prefix, code in _MODEL_PREFIX_TO_PROVIDER:
        if m.startswith(prefix):
            return code
    return ""


# ============================================================================
# 健康状态枚举与数据类
# ============================================================================


class ProviderHealthStatus(StrEnum):
    """provider 健康状态。"""

    HEALTHY = "healthy"                    # ping 通过 + 延迟可接受
    DEGRADED = "degraded"                  # ping 通过但延迟高,或 429 限流(仍显示)
    DOWN = "down"                          # ping 失败(401/403/超时/网络错误)— 不显示
    NOT_CONFIGURED = "not_configured"      # 未配置 key — 不显示
    LOCAL = "local"                        # 本地 LLM(无需 ping)— 显示
    ZERO_COST = "zero_cost"                # 无需 key 的免费 provider — 显示
    PENDING = "pending"                    # 尚未检测(启动初期)— 宽松显示


class ProviderErrorType(StrEnum):
    """provider 错误类型(细化 DOWN 原因,2026-07-31 立)。

    用户规则:账户没钱 / key 失效 / 接不通的 provider 不应进模型列表;
    管理端需可视化错误类型 + 跳转充值按钮。
    """

    NONE = "none"                          # 无错误(健康)
    PAYMENT_REQUIRED = "payment_required"  # 402 余额不足/账户没钱(需充值)— 管理端显示"去充值"按钮
    FORBIDDEN = "forbidden"                # 403 无权限/key 失效
    RATE_LIMITED = "rate_limited"          # 429 限流(仍可用,只是慢)— DEGRADED
    TIMEOUT = "timeout"                    # 请求超时
    NETWORK_ERROR = "network_error"        # 网络错误(连不上)
    INVALID_KEY = "invalid_key"            # 401 key 无效
    UNKNOWN = "unknown"                    # 未知错误


@dataclass
class ProviderHealth:
    """单个 provider 的健康状态。"""

    status: ProviderHealthStatus = ProviderHealthStatus.PENDING
    latency_ms: int = 0
    last_check: float = 0.0  # unix timestamp
    error: str = ""
    # 2026-07-31 新增字段(用户规则:账户没钱需可视化 + 跳转充值)
    error_type: ProviderErrorType = ProviderErrorType.NONE
    balance: float | None = None
    balance_currency: str | None = None
    recharge_url: str = ""


# ============================================================================
# provider_code → LLM_PROVIDERS JSON name 映射
# ============================================================================

_PROVIDER_CODE_TO_LLM_PROVIDERS_NAME: dict[str, str] = {
    "cloudflare_workers_ai": "cloudflare",
    "nvidia_nim": "nvidia",
    "github_models": "github",
    "vercel_ai_gateway": "vercel",
    "opencode_zen": "opencode",
}


def _to_llm_providers_name(provider_code: str) -> str:
    """provider_code → LLM_PROVIDERS JSON 里的 name(用于读 cfg.api_key)。

    大多数 provider_code 与 LLM_PROVIDERS name 一致(如 stepfun/agnes/openai)。
    少数需要映射(如 cloudflare_workers_ai → cloudflare)。
    """
    return _PROVIDER_CODE_TO_LLM_PROVIDERS_NAME.get(provider_code, provider_code)


def _is_zero_price_variant(model_id: str) -> bool:
    """该模型是否为上游**官方标记**的零定价变体(OpenRouter `:free` 后缀)。

    只认上游写在模型 ID 里的零定价标记,不猜价格、不看本地库:
    本地 `input_price_per_1k = 0` 多数是"价格没同步到",拿它当"免费"用等于造假。
    """
    return model_id.strip().lower().endswith(":free")


# ============================================================================
# 服务单例
# ============================================================================


class ModelAvailabilityService:
    """模型可用性服务单例。

    生命周期:
    - main.py lifespan 启动时调用 initialize():后台跑首次 ping + 启动定时刷新
    - /llm/models 端点调用 get_available_models() 过滤
    - main.py lifespan 关闭时调用 shutdown():取消定时任务

    线程安全:用 asyncio.Lock 保护 _health 字典写操作。
    """

    def __init__(self) -> None:
        self._health: dict[str, ProviderHealth] = {}
        self._lock = asyncio.Lock()
        self._refresh_task: asyncio.Task[None] | None = None
        self._initialized = False
        # 429 限流退避记录(provider_code → 上次 429 时间戳)
        self._rate_limit_backoff: dict[str, float] = {}
        # 最近一次全量 provider 刷新完成时间(0 = 本轮进程还没跑过首轮)
        # 2026-11-07 新增:模型级探测服务启动自举目录前要等首轮 provider 刷新完成,
        # 否则 PENDING 宽松期会把实际 DOWN 的厂商模型也登记进探测候选。
        self.last_refresh_at: float = 0.0

    async def initialize(self) -> None:
        """启动时调用:后台跑首次 ping + 启动定时刷新任务。

        幂等:多次调用只初始化一次。
        不阻塞:首次 ping 用 asyncio.create_task 异步执行,FastAPI 启动立即返回。
        """
        if self._initialized:
            return
        self._initialized = True
        # 后台跑首次 ping(不阻塞启动,首次 /llm/models 请求可能命中 PENDING 状态)
        spawn(self._refresh_all_providers(), name="model-availability-initial-refresh")
        # 启动定时刷新(每 5 分钟)
        self._refresh_task = asyncio.create_task(self._refresh_loop())
        logger.info("ModelAvailabilityService initialized (refresh interval: %ds)", REFRESH_INTERVAL_S)

    async def shutdown(self) -> None:
        """关闭时调用:取消定时刷新任务。"""
        if self._refresh_task is not None and not self._refresh_task.done():
            self._refresh_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._refresh_task
            self._refresh_task = None
        self._initialized = False

    async def _refresh_loop(self) -> None:
        """定时刷新循环(每 REFRESH_INTERVAL_S 秒一次)。"""
        while True:
            try:
                await asyncio.sleep(REFRESH_INTERVAL_S)
                await self._refresh_all_providers()
            except asyncio.CancelledError:
                logger.info("ModelAvailabilityService refresh loop cancelled")
                raise
            except Exception as e:
                logger.warning("ModelAvailabilityService refresh loop error: %s", e)
                # 出错后等 60s 再试,避免高频失败循环
                await asyncio.sleep(60)

    async def _refresh_all_providers(self) -> None:
        """对所有已配置 key 的 provider 跑一次 ping。

        步骤:
        1. 遍历 free_provider_registry,找出 CONFIGURED 状态的 provider
        2. 并发 ping(限制并发 PING_CONCURRENCY)
        3. 更新 _health 字典
        """
        # 收集需要 ping 的 provider 列表
        providers_to_ping: list[tuple[str, str, str]] = []  # [(code, api_key, api_base)]
        local_to_probe: list[tuple[str, str]] = []  # [(code, base_override)]
        for p in free_provider_registry.list_all():
            # 2026-10-26 永久退役厂商不参与探测(名单与同步面/面板面同源):
            # 不 ping ⇒ 不再每 5 分钟往日志与面板写「余额不足…需充值」这类出口,
            # 也不进 _health ⇒ 面板与模型列表里列不出它(机主:永久除名,不提充值)。
            if is_retired_provider(p.provider_code):
                continue
            # 本地 LLM:2026-10-18(票85①)起不再"不 ping 直接标 LOCAL"——改走本地探针
            # 三态实证(available/unavailable/undetermined)。历史缺陷:没在跑的 ollama
            # 照样在模型列表里显示,用户选中才报错。undetermined(没探过/判不了)保持
            # 旧态 LOCAL,不冒充实证。
            if p.category == ProviderCategory.LOCAL:
                local_to_probe.append((p.provider_code, p.default_base_url))
                continue
            # zero_cost provider(无需 key):也纳入 ping 验证真实可用性
            # (opencode_zen 429 等调不通的自动过滤;pollinations/llm7 通过则正常显示)
            if p.provider_code in _ZERO_COST_CODES:
                providers_to_ping.append((p.provider_code, "", p.default_base_url))
                continue
            # 已配置 key 的 provider:加入 ping 列表
            # has_key 判断必须与 is_model_available() 保持一致:
            # 优先 LLM_PROVIDERS JSON(settings.get_provider_config),降级 free_provider_registry(查 os.environ)
            # 否则会出现"JSON 配了 key 但 os.environ 没 → is_model_available 判可用但没被 ping → health=None → 跳过 DOWN 检查 → 错误显示"
            cfg_name = _to_llm_providers_name(p.provider_code)
            cfg = settings.get_provider_config(cfg_name)
            api_key = cfg.api_key
            has_key = bool(api_key) or free_provider_registry.is_key_configured(p.provider_code) == ProviderStatus.CONFIGURED
            if has_key:
                api_base = cfg.api_base or p.default_base_url
                if api_key and api_base:
                    providers_to_ping.append((p.provider_code, api_key, api_base))
                elif api_key and not api_base:
                    # 有 key 但无 base_url,标记 DOWN(无法 ping)
                    async with self._lock:
                        self._health[p.provider_code] = ProviderHealth(
                            status=ProviderHealthStatus.DOWN,
                            last_check=time.time(),
                            error="no api_base configured",
                        )
                else:
                    # key 只配在扁平 .env 键(如 IHUI_RELAY_API_KEY / DEEPSEEK_API_KEY)、
                    # LLM_PROVIDERS JSON 里没有:registry 已判 CONFIGURED,网关按 env
                    # 能调通 —— 此处若标 NOT_CONFIGURED 会把能调通的 provider 整家藏掉
                    # (2026-10-21 实测:qwen/zhipu/ihui_relay 全中招)。从 registry
                    # 登记的 key_env_vars 把真实 key 取出来入 ping,与网关同一把钥匙。
                    # keyless provider(key_env_vars 只有 *_API_BASE)取到的是 URL
                    # 形态的值,不当 key;它们与 zero_cost 同待遇:空 key 照样 ping。
                    env_key = ""
                    for env_var in p.key_env_vars:
                        val = os.environ.get(env_var, "").strip()
                        if val and not val.startswith(("http://", "https://")):
                            env_key = val
                            break
                    api_base = cfg.api_base or p.default_base_url
                    if api_base:
                        providers_to_ping.append((p.provider_code, env_key, api_base))
                    else:
                        async with self._lock:
                            self._health[p.provider_code] = ProviderHealth(
                                status=ProviderHealthStatus.NOT_CONFIGURED,
                                last_check=time.time(),
                                error="key configured in env but no api_base to ping",
                            )

        # 并发 ping
        semaphore = asyncio.Semaphore(PING_CONCURRENCY)

        async def _ping_one(code: str, key: str, base: str) -> None:
            async with semaphore:
                health = await self._ping_provider_v2(code, key, base)
                async with self._lock:
                    self._health[code] = health

        if providers_to_ping:
            await asyncio.gather(
                *[_ping_one(c, k, b) for c, k, b in providers_to_ping],
                return_exceptions=True,
            )

        # 本地探针(票85①):available→HEALTHY / unavailable→DOWN / undetermined→LOCAL
        # (LOCAL 态 = "没实证",显示宽松、auto 不选 —— 三态各走各的,不折叠)。
        if local_to_probe:
            # 延迟导入避免循环(local_provider_health ← settings;与本模块无环)
            from .local_provider_health import LocalProbeVerdict, local_provider_health

            async def _probe_local(code: str, base_override: str) -> None:
                async with semaphore:
                    result = await local_provider_health.probe(
                        code, base_override=base_override
                    )
                    if result.verdict == LocalProbeVerdict.AVAILABLE:
                        status = ProviderHealthStatus.HEALTHY
                    elif result.verdict == LocalProbeVerdict.UNAVAILABLE:
                        status = ProviderHealthStatus.DOWN
                    else:
                        status = ProviderHealthStatus.LOCAL
                    async with self._lock:
                        self._health[code] = ProviderHealth(
                            status=status,
                            last_check=time.time(),
                            error=result.detail if status == ProviderHealthStatus.DOWN else "",
                        )

            await asyncio.gather(
                *[_probe_local(c, b) for c, b in local_to_probe],
                return_exceptions=True,
            )

        # 统计日志
        healthy = sum(1 for h in self._health.values() if h.status == ProviderHealthStatus.HEALTHY)
        degraded = sum(1 for h in self._health.values() if h.status == ProviderHealthStatus.DEGRADED)
        down = sum(1 for h in self._health.values() if h.status == ProviderHealthStatus.DOWN)
        local = sum(1 for h in self._health.values() if h.status == ProviderHealthStatus.LOCAL)
        zero_cost = sum(1 for h in self._health.values() if h.status == ProviderHealthStatus.ZERO_COST)
        logger.info(
            "ModelAvailabilityService refreshed: %d providers pinged, "
            "healthy=%d degraded=%d down=%d local=%d zero_cost=%d",
            len(providers_to_ping), healthy, degraded, down, local, zero_cost,
        )
        # 2026-10-26 补:只有计数没有名单 ⇒ 出事时只能看到"down=1"却不知道是谁,
        # 排查要靠人肉一家家 curl(10-25 stepfun 订阅失效那次就是这样熬过去的)。
        # 非健康的把死因一并打出(余额端点判不出来时,推理 ping 的 4xx 原文就在 error 里)。
        # 字符纪律:只打 ASCII + GBK 覆盖字符,避免 Windows cp936 日志静默丢整行。
        if down or degraded:
            def _fmt(code: str, h: ProviderHealth) -> str:
                err = (getattr(h, "error", "") or "").replace("\n", " ")
                err = err[:120]
                et = getattr(getattr(h, "error_type", None), "value", "") or ""
                return f"{code}[{et}{(': ' + err) if err else ''}]"
            downs = [_fmt(c, h) for c, h in self._health.items()
                     if h.status == ProviderHealthStatus.DOWN]
            degs = [_fmt(c, h) for c, h in self._health.items()
                    if h.status == ProviderHealthStatus.DEGRADED]
            if downs:
                logger.warning("[availability] DOWN(%d): %s", len(downs), ", ".join(downs))
            if degs:
                logger.info("[availability] DEGRADED(%d): %s", len(degs), ", ".join(degs))

        # 标记首轮(含后续轮)刷新已完成,供模型级探测服务对齐过滤口径
        self.last_refresh_at = time.time()

    async def wait_initial_refresh(self, timeout: float) -> bool:
        """等待本进程首轮 provider 级刷新完成(超时返回 False,不抛异常)。

        模型级探测服务在启动时自举候选目录,必须等 provider 级状态就绪,
        否则 PENDING 宽松期会把实际不可用的厂商模型也纳入探测(白耗配额)。
        """
        start = time.time()
        while time.time() - start < timeout:
            if self.last_refresh_at > 0:
                return True
            await asyncio.sleep(2)
        return False


    async def _ping_provider_v2(self, code: str, api_key: str, api_base: str) -> ProviderHealth:
        """ping 单个 provider:先查余额端点(若支持),降级推理请求 ping。

        2026-07-31 v2 升级(用户规则:账户没钱需过滤 + 可视化 + 跳转充值):
        - 策略 1:若 provider 有 balance_endpoint,优先查余额(按币种阈值判定)
          - 余额 >= 阈值(USD $0.01 / CNY ¥0.10)→ HEALTHY(附带余额信息)
          - 0 < 余额 < 阈值 → DOWN + PAYMENT_REQUIRED(余额不足,接近耗尽,管理端显示"去充值")
          - 余额 = 0 → DOWN + PAYMENT_REQUIRED(账户没钱,管理端显示"去充值")
          - 余额查询失败 → 降级到策略 2
        - 策略 2:发送 max_tokens=1 推理请求(消耗 1 token,实测可用性)
          - 200 + 延迟 ≤ 10s  → HEALTHY
          - 200 + 延迟 10-30s  → DEGRADED(仍显示)
          - 200 + 延迟 > 30s  → DOWN(不显示)
          - 401 → DOWN + INVALID_KEY
          - 402 → DOWN + PAYMENT_REQUIRED(余额不足,需充值)
          - 403 → DOWN + FORBIDDEN
          - 429 → DEGRADED + RATE_LIMITED(限流,仍可用)
          - 超时 → DOWN + TIMEOUT
          - 网络错误 → DOWN + NETWORK_ERROR
        """
        balance_endpoint = free_provider_registry.get_balance_endpoint(code)
        recharge_url = free_provider_registry.get_recharge_url(code)

        start = time.monotonic()
        # ping 与同步(model_sync)同用一套出网判据:huggingface 等直连被网络封锁、
        # 经代理可达,不接代理会被误判 DOWN+NETWORK_ERROR(2026-10-26 实测:
        # HF 直连 curl 超时、走 SYNC_PROXY_URL 200)。判据单源:专用代理表→全局→直连。
        _ping_proxy = (
            (settings.sync_proxy_url_by_provider.get(code)
             or settings.sync_proxy_url or "").strip()
        ) or None
        try:
            async with httpx.AsyncClient(timeout=PING_TIMEOUT_S, proxy=_ping_proxy) as client:
                if balance_endpoint:
                    balance, currency, err_type, err_msg = await self._query_balance(
                        client, code, balance_endpoint, api_key
                    )
                    latency = int((time.monotonic() - start) * 1000)
                    if err_type == ProviderErrorType.NONE and balance is not None:
                        # 2026-07-31 升级:按币种阈值判定(OpenRouter 余额 $0.0001 实际无法调用任何模型)
                        threshold = MIN_BALANCE_THRESHOLDS.get(currency or "", MIN_BALANCE_DEFAULT)
                        if balance >= threshold:
                            return ProviderHealth(
                                status=ProviderHealthStatus.HEALTHY,
                                latency_ms=latency,
                                last_check=time.time(),
                                balance=balance,
                                balance_currency=currency,
                                recharge_url=recharge_url,
                            )
                        # 余额低于阈值:余额为 0 或接近耗尽(如 $0.0001),都无法完成一次最小调用
                        if balance > 0:
                            err_msg = f"余额不足: {balance} {currency or 'unknown'} < 阈值 {threshold}(无法完成一次最小调用),需充值"
                        else:
                            # 负余额(透支)也走这一支:不把 -0.09 说成"余额为 0"(措辞失真)
                            err_msg = f"余额不足: {balance} {currency or 'unknown'}(≤0,账户没钱),需充值"
                        # 2026-10-21 根治:没钱 ≠ 调不通,二者不能互相冒充。
                        # OpenRouter 的 `:free` 变体零定价,余额为 0 照样实证可调通(本次
                        # minimax/minimax-m3.1-flash:free 直连实测 200 + 真实 usage)。旧逻辑见
                        # 余额为 0 就直接 DOWN,把整家 provider 连同它**唯一还能用**的免费模型
                        # 一起从选择器里抹掉 —— 用户看到的是"没这家",真相是"这家只有免费的能用"。
                        # 现改为:余额不足一律降级到推理 ping 实证,让连通性由实测说话:
                        #   ping 通 → DEGRADED(受限可用,非 HEALTHY:不把没钱粉饰成健康),
                        #             余额/error_type 原样保留,管理端"去充值"按钮不受影响;
                        #   ping 不通 → 维持 DOWN,死因仍是余额不足(不伪装成网络错误)。
                        ping = await self._inference_ping(
                            client, code, api_key, api_base, start, recharge_url
                        )
                        if ping.status in (
                            ProviderHealthStatus.HEALTHY,
                            ProviderHealthStatus.DEGRADED,
                        ):
                            return ProviderHealth(
                                status=ProviderHealthStatus.DEGRADED,
                                latency_ms=ping.latency_ms,
                                last_check=ping.last_check,
                                error=f"{err_msg};已实证通道可用,仅零定价/免费模型可调",
                                error_type=ProviderErrorType.PAYMENT_REQUIRED,
                                balance=balance,
                                balance_currency=currency,
                                recharge_url=recharge_url,
                            )
                        return ProviderHealth(
                            status=ProviderHealthStatus.DOWN,
                            latency_ms=ping.latency_ms,
                            last_check=ping.last_check,
                            error=f"{err_msg};实证 ping 亦失败: {ping.error or 'unknown'}",
                            error_type=ProviderErrorType.PAYMENT_REQUIRED,
                            balance=balance,
                            balance_currency=currency,
                            recharge_url=recharge_url,
                        )
                    logger.debug(
                        "[%s] balance query failed (%s: %s), fallback to inference ping",
                        code, err_type.value, err_msg,
                    )
                return await self._inference_ping(client, code, api_key, api_base, start, recharge_url)
        except httpx.TimeoutException:
            return ProviderHealth(
                status=ProviderHealthStatus.DOWN,
                latency_ms=int((time.monotonic() - start) * 1000),
                last_check=time.time(),
                error=f"timeout after {PING_TIMEOUT_S}s",
                error_type=ProviderErrorType.TIMEOUT,
                recharge_url=recharge_url,
            )
        except Exception as e:
            return ProviderHealth(
                status=ProviderHealthStatus.DOWN,
                last_check=time.time(),
                error=f"{type(e).__name__}: {str(e)[:200]}",
                error_type=ProviderErrorType.NETWORK_ERROR,
                recharge_url=recharge_url,
            )

    async def _query_balance(
        self,
        client: httpx.AsyncClient,
        code: str,
        balance_url: str,
        api_key: str,
    ) -> tuple[float | None, str | None, ProviderErrorType, str]:
        """查 provider 余额(支持 openrouter/deepseek/siliconcloud 等已知端点)。

        Returns:
            (balance, currency, error_type, error_msg)
            - 成功:(余额, 货币, NONE, "")
            - 失败:(None, None, 错误类型, 错误描述)
        """
        try:
            resp = await client.get(balance_url, headers={"Authorization": f"Bearer {api_key}"})
            if resp.status_code != 200:
                err_type = self._http_status_to_error_type(resp.status_code, resp.text)
                return None, None, err_type, f"HTTP {resp.status_code}"
            data = resp.json()

            if code == "openrouter":
                d = data.get("data") or {}
                total = float(d.get("total_credits") or 0)
                usage = float(d.get("total_usage") or 0)
                return max(0.0, total - usage), "USD", ProviderErrorType.NONE, ""

            if code == "deepseek":
                infos = data.get("balance_infos") or []
                if not infos:
                    return None, None, ProviderErrorType.UNKNOWN, "no balance_infos"
                info = infos[0]
                return float(info.get("total_balance") or 0), info.get("currency") or "CNY", ProviderErrorType.NONE, ""

            if code == "siliconcloud":
                d = data.get("data") or {}
                return float(d.get("balance") or 0), "CNY", ProviderErrorType.NONE, ""

            if code == "stepfun":
                # https://platform.stepfun.com/docs/api-reference/accounts/get
                # 返回 {object, type, balance, total_cash_balance, total_voucher_balance}
                # balance=可用余额(含赠送),total_cash_balance=现金余额,total_voucher_balance=赠送余额
                return float(data.get("balance") or 0), "CNY", ProviderErrorType.NONE, ""

            for key_path in (("balance",), ("data", "balance"), ("data", "total_credits"), ("total_balance",)):
                v: Any = data
                for k in key_path:
                    if not isinstance(v, dict):
                        v = None
                        break
                    v = v.get(k)
                if isinstance(v, (int, float)) and v >= 0:
                    return float(v), "USD", ProviderErrorType.NONE, ""

            return None, None, ProviderErrorType.UNKNOWN, "balance field not found in response"
        except httpx.TimeoutException:
            return None, None, ProviderErrorType.TIMEOUT, "timeout"
        except Exception as e:
            return None, None, ProviderErrorType.NETWORK_ERROR, f"{type(e).__name__}: {str(e)[:100]}"

    async def _inference_ping(
        self,
        client: httpx.AsyncClient,
        code: str,
        api_key: str,
        api_base: str,
        start: float,
        recharge_url: str,
    ) -> ProviderHealth:
        """推理请求 ping:优先尝试 /v1/models(轻量,不消耗 quota),降级 chat/completions 推理请求。

        2026-08-31 优化:为避免 ihui_relay 等 provider 429 限流,
        先尝试 GET /v1/models(仅列模型,不消耗 token),
        - 200 + 延迟 ≤ 10s  → HEALTHY
        - 200 + 延迟 10-30s → DEGRADED
        - 429 → DEGRADED + RATE_LIMITED(立即返回,不消耗额外 quota)
        - 其他错误 → 降级到 chat/completions 推理请求(max_tokens=1,消耗 1 token)
        """
        # 策略 1:优先尝试 /v1/models(轻量,不消耗 quota)
        models_health = await self._try_models_ping(client, code, api_key, api_base, start, recharge_url)
        if models_health is not None:
            return models_health

        # 策略 2:/v1/models 失败,降级到 chat/completions 推理请求(消耗 1 token 实测可用性)
        url = api_base.rstrip("/")
        # 2026-08-02 修复:Google AI Studio api_base 以 /openai 结尾(非 /v1),
        # 直接接 /chat/completions(加 /v1 会变 /v1beta/openai/v1/chat/completions → 404)
        # 2026-08-06 修复:智谱 zhipu api_base 以 /v4 结尾(BigModel OpenAI 兼容端点),
        # 同样直接接 /chat/completions(否则拼成 /v4/v1/chat/completions → 404)
        if url.endswith("/v1") or url.endswith("/openai") or url.endswith("/v4"):
            url = f"{url}/chat/completions"
        else:
            url = f"{url}/v1/chat/completions"

        provider = free_provider_registry.get_by_code(code)
        # 2026-08-02 修复:默认模型可能不可用(如 llm7 的 qwen3-235b 已下线 → 400),
        # 逐个尝试 default_models,任一成功即 HEALTHY,全部失败才 DOWN(避免误杀整个 provider)
        model_ids: list[str] = []
        if provider and provider.default_models:
            model_ids = list(provider.default_models)
        if not model_ids:
            model_ids = ["gpt-3.5-turbo"]
        # 剥离已知前缀(stepfun/agnes/gemini),模型名带 / 会被 API 拒绝
        # (2026-10-24 移除 ihui/:随 SwiftAPI 弃用,ihui_relay 已不存在)
        cleaned: list[str] = []
        for mid in model_ids:
            for prefix in ("stepfun/", "agnes/", "gemini/"):
                if mid.startswith(prefix):
                    mid = mid[len(prefix):]
                    break
            cleaned.append(mid)
        model_ids = cleaned

        headers: dict[str, str] = {"Content-Type": "application/json"}
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
        from app.core.provider_caps import resolve_provider_headers

        headers.update(resolve_provider_headers(code))

        last_err: tuple[int, str] | None = None
        try:
            for model_id in model_ids:
                try:
                    resp = await client.post(
                        url,
                        headers=headers,
                        json={
                            "model": model_id,
                            "messages": [{"role": "user", "content": "ping"}],
                            "max_tokens": 1,
                            "stream": False,
                        },
                    )
                except httpx.TimeoutException:
                    # 2026-08-02 修复:单模型超时继续尝试下一个(如 nvidia_nim 网络慢,
                    # 首个模型超时不代表整个 provider 不可用)
                    last_err = (0, f"timeout after {PING_TIMEOUT_S}s")
                    continue
                latency = int((time.monotonic() - start) * 1000)

                if resp.status_code == 200:
                    if latency > LATENCY_DOWN_MS:
                        return ProviderHealth(
                            status=ProviderHealthStatus.DOWN,
                            latency_ms=latency,
                            last_check=time.time(),
                            error=f"latency {latency}ms > {LATENCY_DOWN_MS}ms threshold",
                            error_type=ProviderErrorType.TIMEOUT,
                            recharge_url=recharge_url,
                        )
                    if latency > LATENCY_DEGRADED_MS:
                        return ProviderHealth(
                            status=ProviderHealthStatus.DEGRADED,
                            latency_ms=latency,
                            last_check=time.time(),
                            recharge_url=recharge_url,
                        )
                    return ProviderHealth(
                        status=ProviderHealthStatus.HEALTHY,
                        latency_ms=latency,
                        last_check=time.time(),
                        recharge_url=recharge_url,
                    )

                err_type = self._http_status_to_error_type(resp.status_code, resp.text)
                # 429 限流/402 余额不足:当前调不通,立即判定(换模型也无意义,同一账户)
                if err_type in (ProviderErrorType.RATE_LIMITED, ProviderErrorType.PAYMENT_REQUIRED):
                    status = ProviderHealthStatus.DEGRADED if err_type == ProviderErrorType.RATE_LIMITED else ProviderHealthStatus.DOWN
                    return ProviderHealth(
                        status=status,
                        latency_ms=latency,
                        last_check=time.time(),
                        error=f"HTTP {resp.status_code}: {resp.text[:150]}",
                        error_type=err_type,
                        recharge_url=recharge_url,
                    )
                # 其他错误(400/404/500):记下后尝试下一个模型
                last_err = (resp.status_code, resp.text[:150])

            # 所有默认模型都失败 → DOWN
            if last_err is not None:
                status_code, text = last_err
                # 全部是超时(HTTP 0)→ TIMEOUT 错误类型;有真实 HTTP 错误用其状态映射
                err_type = (
                    ProviderErrorType.TIMEOUT
                    if status_code == 0
                    else self._http_status_to_error_type(status_code, text)
                )
                return ProviderHealth(
                    status=ProviderHealthStatus.DOWN,
                    latency_ms=int((time.monotonic() - start) * 1000),
                    last_check=time.time(),
                    error=f"HTTP {status_code}: {text}",
                    error_type=err_type,
                    recharge_url=recharge_url,
                )
            return ProviderHealth(
                status=ProviderHealthStatus.DOWN,
                last_check=time.time(),
                error="no default models to ping",
                error_type=ProviderErrorType.UNKNOWN,
                recharge_url=recharge_url,
            )
        except httpx.TimeoutException:
            return ProviderHealth(
                status=ProviderHealthStatus.DOWN,
                latency_ms=int((time.monotonic() - start) * 1000),
                last_check=time.time(),
                error=f"timeout after {PING_TIMEOUT_S}s",
                error_type=ProviderErrorType.TIMEOUT,
                recharge_url=recharge_url,
            )
        except Exception as e:
            return ProviderHealth(
                status=ProviderHealthStatus.DOWN,
                last_check=time.time(),
                error=f"{type(e).__name__}: {str(e)[:200]}",
                error_type=ProviderErrorType.NETWORK_ERROR,
                recharge_url=recharge_url,
            )

    async def _try_models_ping(
        self,
        client: httpx.AsyncClient,
        code: str,
        api_key: str,
        api_base: str,
        start: float,
        recharge_url: str,
    ) -> ProviderHealth | None:
        """尝试 GET /v1/models(轻量,不消耗 quota)。

        Returns:
            - 成功:ProviderHealth(HEALTHY/DEGRADED)
            - 429:ProviderHealth(DEGRADED + RATE_LIMITED)
            - 其他 4xx/5xx:None(降级到 inference ping)
            - 网络错误:None(降级到 inference ping)
        """
        models_url = api_base.rstrip("/")
        if models_url.endswith("/v1") or models_url.endswith("/openai") or models_url.endswith("/v4"):
            models_url = f"{models_url}/models"
        else:
            models_url = f"{models_url}/v1/models"

        headers: dict[str, str] = {}
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
        from app.core.provider_caps import resolve_provider_headers

        headers.update(resolve_provider_headers(code))

        try:
            resp = await client.get(models_url, headers=headers, timeout=15.0)
            latency = int((time.monotonic() - start) * 1000)

            if resp.status_code == 200:
                if latency > LATENCY_DOWN_MS:
                    return ProviderHealth(
                        status=ProviderHealthStatus.DOWN,
                        latency_ms=latency,
                        last_check=time.time(),
                        error=f"latency {latency}ms > {LATENCY_DOWN_MS}ms threshold",
                        error_type=ProviderErrorType.TIMEOUT,
                        recharge_url=recharge_url,
                    )
                if latency > LATENCY_DEGRADED_MS:
                    return ProviderHealth(
                        status=ProviderHealthStatus.DEGRADED,
                        latency_ms=latency,
                        last_check=time.time(),
                        recharge_url=recharge_url,
                    )
                return ProviderHealth(
                    status=ProviderHealthStatus.HEALTHY,
                    latency_ms=latency,
                    last_check=time.time(),
                    recharge_url=recharge_url,
                )

            if resp.status_code == 429:
                return ProviderHealth(
                    status=ProviderHealthStatus.DEGRADED,
                    latency_ms=latency,
                    last_check=time.time(),
                    error=f"HTTP 429: {resp.text[:150]}",
                    error_type=ProviderErrorType.RATE_LIMITED,
                    recharge_url=recharge_url,
                )

            # 401/403/402/5xx 等:降级到 inference ping 进一步确认
            logger.debug(
                "[%s] /v1/models returned HTTP %d, fallback to inference ping",
                code, resp.status_code,
            )
            return None
        except httpx.TimeoutException:
            logger.debug("[%s] /v1/models timeout, fallback to inference ping", code)
            return None
        except Exception as e:
            logger.debug("[%s] /v1/models error (%s), fallback to inference ping", code, type(e).__name__)
            return None

    @staticmethod
    def _http_status_to_error_type(status: int, body: str = "") -> ProviderErrorType:
        """HTTP 状态码(+ 响应体)→ ProviderErrorType 映射。

        400 本身不足以判额度,必须带额度错误码(如 DashScope 400 Arrearage),
        否则 ping 会把"模型名不对"这类参数错标成"需充值"。
        """
        if status == 401:
            return ProviderErrorType.INVALID_KEY
        if status == 402:
            return ProviderErrorType.PAYMENT_REQUIRED
        if is_quota_exhaustion_error(body, status_code=status):
            return ProviderErrorType.PAYMENT_REQUIRED
        if status == 403:
            return ProviderErrorType.FORBIDDEN
        if status == 429:
            return ProviderErrorType.RATE_LIMITED
        if status == 408:
            return ProviderErrorType.TIMEOUT
        return ProviderErrorType.UNKNOWN

    def get_provider_health(self, provider_code: str) -> ProviderHealth:
        """获取 provider 健康状态(从缓存读,不触发 ping)。

        未命中缓存返回 PENDING 状态(首次启动时可能出现)。
        """
        return self._health.get(provider_code, ProviderHealth(status=ProviderHealthStatus.PENDING))

    async def mark_provider_quota_exhausted(self, provider_code: str, detail: str) -> None:
        """实时调用命中额度类错误 → 标 DOWN + PAYMENT_REQUIRED(与 ping 判定同一状态位)。

        恢复路径复用既有 5 分钟刷新循环:充值后下一轮 ping 通过即回到 HEALTHY;
        即便 provider 已不在 ping 清单,读取侧的 QUOTA_BLOCK_TRUST_S 也会让标记过期。
        """
        if not provider_code:
            return
        async with self._lock:
            self._health[provider_code] = ProviderHealth(
                status=ProviderHealthStatus.DOWN,
                last_check=time.time(),
                error=detail[:200],
                error_type=ProviderErrorType.PAYMENT_REQUIRED,
                recharge_url=free_provider_registry.get_recharge_url(provider_code),
            )
        logger.info("[quota] provider %s 标记额度耗尽(%s)", provider_code, detail[:120])

    def is_provider_quota_blocked(self, provider_code: str) -> bool:
        """该 provider 是否处于"刚被判定额度耗尽"窗口内(换通道时跳过同一家)。"""
        health = self._health.get(provider_code)
        if health is None or health.error_type != ProviderErrorType.PAYMENT_REQUIRED:
            return False
        if health.status not in (ProviderHealthStatus.DOWN, ProviderHealthStatus.DEGRADED):
            return False
        return (time.time() - health.last_check) < QUOTA_BLOCK_TRUST_S

    def is_model_available(self, model_id: str) -> bool:
        """判断单个模型是否可显示(用于 /llm/models 过滤)。

        判定规则(按顺序):
        1. 推断 provider_code,未知 → 不显示
        2. LOCAL provider(ollama/lmstudio/llamacpp/vllm)→ 显示
        3. 已配置 key / zero_cost(无需 key)→ 继续健康检查
        4. 其他情况(未配置 key)→ 不显示

        特殊处理:
        - PENDING(尚未检测):视为可用(给 provider 一个宽松期,等首次 ping 完成)
        - DEGRADED 无错误(仅延迟高):仍显示(实测可调通,只是慢,如 agnes/nvidia)
        - DEGRADED + 明确错误(429 限流/配额耗尽、402 余额不足、401 key 失效):不显示
          (2026-08-02 修复:调不通的免费模型不进列表;恢复后 ping 成功自动重新显示)
        - DOWN(401/403/超时):不显示(确实接不通)
        - NOT_CONFIGURED:不显示(没配 key 用不了)

        Args:
            model_id: 模型 ID(如 "stepfun/step-router-v1" / "gpt-4o" / "@cf/zai-org/glm-4.7-flash")

        Returns:
            True 显示该模型;False 过滤掉
        """
        code = _infer_provider_code(model_id)
        if not code:
            return False  # 未知 provider,不显示

        # 2026-10-26 永久退役厂商的模型一律不显示(名单与同步面/面板面同源)。
        # 不能只靠「没健康记录 ⇒ 宽松显示」那条默认:退役厂商本就不 ping,
        # 永远没有健康记录,落进宽松分支反而会继续显示 —— 与「永久除名」正相反。
        if is_retired_provider(code):
            return False

        # LOCAL provider(本地 LLM):票85①起按探针实证分格——
        # DOWN(连接拒绝/HTTP 错)不显示;HEALTHY/LOCAL(在跑或没实证)显示。
        # 旧缺陷:恒 True,"没在跑"装作可用,用户选中才报错。
        provider = free_provider_registry.get_by_code(code)
        if provider and provider.category == ProviderCategory.LOCAL:
            from .local_provider_health import local_provider_health

            health = self._health.get(code)
            if health is not None and health.status == ProviderHealthStatus.DOWN:
                return False  # 探针实证不可用:调不通的不进列表(与 DOWN 同一纪律)
            # 没刷新过(_health 空)时看探针快照,避免"服务确实没跑但还没轮到刷新"的窗口
            if health is None and local_provider_health.snapshot(code) is not None:
                snap = local_provider_health.snapshot(code)
                from .local_provider_health import LocalProbeVerdict

                if snap is not None and snap.verdict == LocalProbeVerdict.UNAVAILABLE:
                    return False
            return True

        # 已配置 key 检查(zero_cost 无需 key,跳过):优先 LLM_PROVIDERS JSON,降级 free_provider_registry(查 os.environ)
        is_zero_cost = code in _ZERO_COST_CODES
        if not is_zero_cost:
            cfg_name = _to_llm_providers_name(code)
            cfg = settings.get_provider_config(cfg_name)
            has_key = bool(cfg.api_key) or free_provider_registry.is_key_configured(code) == ProviderStatus.CONFIGURED
            if not has_key:
                return False  # 未配置 key,不显示

        # 健康检查(统一规则,zero_cost 也参与):
        # - DOWN / NOT_CONFIGURED:不显示(接不通 / 没配 key)
        # - DEGRADED + 明确错误(402 余额不足、401 key 失效、403 权限):不显示
        # - DEGRADED + RATE_LIMITED(429 限流):非 zero_cost(即用户主动配置 key)的 provider 仍显示
        #   (2026-08-02 修复:调不通的免费模型不进列表;2026-08-31 调整:官方中转/key 配置的 provider 限流时仍显示)
        # - DEGRADED 无错误(仅延迟高):显示(实测可调通,只是慢,如 agnes/nvidia)
        # - PENDING / None:尚未检测(启动初期),宽松显示(等首次 ping 完成)
        health = self._health.get(code)
        if not health:
            return True
        if health.status in (ProviderHealthStatus.DOWN, ProviderHealthStatus.NOT_CONFIGURED):
            return False
        if health.status == ProviderHealthStatus.DEGRADED:
            # 用户主动配置 key 的 provider 即使限流也显示(如智汇AI 官方中转 429 时仍应给用户使用机会)
            # zero_cost 免费 provider 限流时仍隐藏(用户未主动配置,恢复后自动显示)
            if health.error_type == ProviderErrorType.RATE_LIMITED:
                return not is_zero_cost
            if health.error_type == ProviderErrorType.PAYMENT_REQUIRED:
                # 余额不足:付费模型点了必然 402,不能进列表;但上游零定价变体
                # (OpenRouter `:free`)实证仍可调通,必须留下(否则"能用的也被抹掉")。
                return _is_zero_price_variant(model_id)
            if health.error_type in (
                ProviderErrorType.INVALID_KEY,
                ProviderErrorType.FORBIDDEN,
            ):
                return False
        return True

    def get_available_models(self, default_models: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """过滤默认模型清单,只返回可用模型。

        Args:
            default_models: 来自 default_models.json + DB 的完整模型清单

        Returns:
            过滤后的模型清单(只含可用模型,顺序与输入一致)
        """
        return [m for m in default_models if self.is_model_available(m.get("id", ""))]

    def get_health_summary(self) -> dict[str, Any]:
        """获取所有 provider 健康状态摘要(供 Admin 端 Provider 健康面板消费)。

        2026-07-31 升级:返回 error_type/balance/balance_currency/recharge_url 字段,
        管理端用 error_type=payment_required 或 balance<=0 判断是否显示"去充值"按钮。
        """
        return {
            "providers": [
                {
                    "provider_code": code,
                    "status": h.status.value,
                    "latency_ms": h.latency_ms,
                    "last_check": h.last_check,
                    "error": h.error,
                    "error_type": h.error_type.value,
                    "balance": h.balance,
                    "balance_currency": h.balance_currency,
                    "recharge_url": h.recharge_url,
                }
                for code, h in self._health.items()
            ],
            "summary": {
                "total": len(self._health),
                "healthy": sum(1 for h in self._health.values() if h.status == ProviderHealthStatus.HEALTHY),
                "degraded": sum(1 for h in self._health.values() if h.status == ProviderHealthStatus.DEGRADED),
                "down": sum(1 for h in self._health.values() if h.status == ProviderHealthStatus.DOWN),
                "local": sum(1 for h in self._health.values() if h.status == ProviderHealthStatus.LOCAL),
                "zero_cost": sum(1 for h in self._health.values() if h.status == ProviderHealthStatus.ZERO_COST),
            },
        }


# 模块级单例
model_availability = ModelAvailabilityService()
# ⁠​‌​​‌​​‌‍‍​‌​​‌​​​‍‍​‌​‌​‌​‌‍‍​‌​​‌​​‌‍‍​​‌​‌‌​‌‍‍​‌​​​​​‌‍‍​‌​​‌​​‌‍‍‌​‌‌​‌‌‌‍‍‌‌​​‌‌​​‌‌‌‌​‌​‍‍‌‌​‌‌​​​‌​​​‌‌‌‍‍​‌​​​​​‌‍‍​‌​​‌​​‌‍‍‌​‌‌​‌‌‌‍‍‌‌​​‌‌‌​‌​​‌‌‌​‍‍‌‌​​‌‌​​​‌​​‌​‌‍‍‌​‌‌‌​‌‌‌​‌‌‌​‌‍‍‌​‌‌​‌‌‌‍‍​‌​​‌‌​​‍‍​‌​​​​‌‌‍‍‌​‌‌​‌‌‌‍‍​‌‌​​​​‌‍‍​‌‌​‌​​‌‍‍​‌‌‌‌​‌​‍‍​‌‌​‌​​​‍‍​‌‌‌​​‌‌‍‍​​‌​‌‌‌​‍‍​‌‌‌​‌​​‍‍​‌‌​‌‌‌‌‍‍​‌‌‌​​​​‍‍‌​‌‌​‌‌‌‍‍​‌​‌​​​​‍‍​‌​‌​​‌​‍‍​‌​​‌‌‌‌‍‍​‌​‌​‌‌​‍‍​‌​​​‌​‌‍‍​‌​​‌‌‌​‍‍​‌​​​​​‌‍‍​‌​​‌‌‌​‍‍​‌​​​​‌‌‍‍​‌​​​‌​‌‍‍​​‌​‌‌​‌‍‍​​‌‌​​‌​‍‍​​‌‌​​​​‍‍​​‌‌​​‌​‍‍​​‌‌​‌‌​⁠
