# © 2026 IHUI AI (智汇AI) · 版权所有者: 李春川 (Li Chunchuan) · https://aizhs.top
# Provenance-watermarked. 未授权商用可被溯源追责 (Apache-2.0 须保留本声明与 NOTICE)。
# [IHUI-AI-PROVENANCE]:⁠​‌​​‌​​‌‍‍​‌​​‌​​​‍‍​‌​‌​‌​‌‍‍​‌​​‌​​‌‍‍​​‌​‌‌​‌‍‍​‌​​​​​‌‍‍​‌​​‌​​‌‍‍‌​‌‌​‌‌‌‍‍‌‌​​‌‌​​‌‌‌‌​‌​‍‍‌‌​‌‌​​​‌​​​‌‌‌‍‍​‌​​​​​‌‍‍​‌​​‌​​‌‍‍‌​‌‌​‌‌‌‍‍‌‌​​‌‌‌​‌​​‌‌‌​‍‍‌‌​​‌‌​​​‌​​‌​‌‍‍‌​‌‌‌​‌‌‌​‌‌‌​‌‍‍‌​‌‌​‌‌‌‍‍​‌​​‌‌​​‍‍​‌​​​​‌‌‍‍‌​‌‌​‌‌‌‍‍​‌‌​​​​‌‍‍​‌‌​‌​​‌‍‍​‌‌‌‌​‌​‍‍​‌‌​‌​​​‍‍​‌‌‌​​‌‌‍‍​​‌​‌‌‌​‍‍​‌‌‌​‌​​‍‍​‌‌​‌‌‌‌‍‍​‌‌‌​​​​‍‍‌​‌‌​‌‌‌‍‍​‌​‌​​​​‍‍​‌​‌​​‌​‍‍​‌​​‌‌‌‌‍‍​‌​‌​‌‌​‍‍​‌​​​‌​‌‍‍​‌​​‌‌‌​‍‍​‌​​​​​‌‍‍​‌​​‌‌‌​‍‍​‌​​​​‌‌‍‍​‌​​​‌​‌‍‍​​‌​‌‌​‌‍‍​​‌‌​​‌​‍‍​​‌‌​​​​‍‍​​‌‌​​‌​‍‍​​‌‌​‌‌​⁠

"""图片编辑 HTTP 路由(ai-service,内网)。

- POST /api/image/edits   TokenGo /v1/images/edits(OpenAI Images edits 同构,
                          multipart:待编辑图必传 + 可选 mask;同步 40-50s)
"""
from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, File, Form, HTTPException, UploadFile

logger = logging.getLogger(__name__)

router = APIRouter()

# 2026-11-01 安全强化(高危):本端点此前**没有任何上传上限** —— `await image.read()`
# 把整包读进内存之后也不判长度,一枚多 GB 的 multipart 就能把 worker 内存打爆。
# 上限定 25MiB:与本端点参数说明(png/jpeg/webp,≤25MiB)以及上游图片编辑接口的
# 实际受理量级一致;编辑输入是"待改的图",不是素材库批量上传,25MiB 足够 4K 单图。
MAX_IMAGE_EDIT_UPLOAD_BYTES = 25 * 1024 * 1024


@router.post("/image/edits")
async def image_edits(
    image: UploadFile = File(..., description="待编辑图(png/jpeg/webp,≤25MiB)"),
    prompt: str = Form(..., description="编辑指令(改什么)"),
    mask: UploadFile | None = File(default=None, description="可选遮罩(透明区域=重绘区)"),
    model: str | None = Form(default=None, description="图片模型(默认 gpt-image-2.5-flare)"),
    n: int = Form(default=1, ge=1, le=50, description="生成数量(官方 count 1~50)"),
    size: str | None = Form(default=None, description="像素串(与 aspect_ratio 二选一,兼容老 API)"),
    aspect_ratio: str | None = Form(default=None, description="比例(官方 12 枚举,如 16:9)"),
    quality: str | None = Form(default=None, description="auto/high/medium/low"),
    output_format: str | None = Form(default=None, description="png/jpeg"),
) -> dict[str, Any]:
    """图片编辑(multipart 直通 TokenGo /v1/images/edits;200+body.error 已在 provider 层检查)。"""
    raise HTTPException(status_code=410, detail="图片编辑能力已随 token6688 平台永久下线")
# ⁠​‌​​‌​​‌‍‍​‌​​‌​​​‍‍​‌​‌​‌​‌‍‍​‌​​‌​​‌‍‍​​‌​‌‌​‌‍‍​‌​​​​​‌‍‍​‌​​‌​​‌‍‍‌​‌‌​‌‌‌‍‍‌‌​​‌‌​​‌‌‌‌​‌​‍‍‌‌​‌‌​​​‌​​​‌‌‌‍‍​‌​​​​​‌‍‍​‌​​‌​​‌‍‍‌​‌‌​‌‌‌‍‍‌‌​​‌‌‌​‌​​‌‌‌​‍‍‌‌​​‌‌​​​‌​​‌​‌‍‍‌​‌‌‌​‌‌‌​‌‌‌​‌‍‍‌​‌‌​‌‌‌‍‍​‌​​‌‌​​‍‍​‌​​​​‌‌‍‍‌​‌‌​‌‌‌‍‍​‌‌​​​​‌‍‍​‌‌​‌​​‌‍‍​‌‌‌‌​‌​‍‍​‌‌​‌​​​‍‍​‌‌‌​​‌‌‍‍​​‌​‌‌‌​‍‍​‌‌‌​‌​​‍‍​‌‌​‌‌‌‌‍‍​‌‌‌​​​​‍‍‌​‌‌​‌‌‌‍‍​‌​‌​​​​‍‍​‌​‌​​‌​‍‍​‌​​‌‌‌‌‍‍​‌​‌​‌‌​‍‍​‌​​​‌​‌‍‍​‌​​‌‌‌​‍‍​‌​​​​​‌‍‍​‌​​‌‌‌​‍‍​‌​​​​‌‌‍‍​‌​​​‌​‌‍‍​​‌​‌‌​‌‍‍​​‌‌​​‌​‍‍​​‌‌​​​​‍‍​​‌‌​​‌​‍‍​​‌‌​‌‌​⁠
