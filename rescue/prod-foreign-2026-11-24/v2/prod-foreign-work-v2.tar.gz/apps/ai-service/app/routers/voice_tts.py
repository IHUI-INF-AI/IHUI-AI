# © 2026 IHUI AI (智汇AI) · 版权所有者: 李春川 (Li Chunchuan) · https://aizhs.top
# Provenance-watermarked. 未授权商用可被溯源追责 (Apache-2.0 须保留本声明与 NOTICE)。
# [IHUI-AI-PROVENANCE]:⁠​‌​​‌​​‌‍‍​‌​​‌​​​‍‍​‌​‌​‌​‌‍‍​‌​​‌​​‌‍‍​​‌​‌‌​‌‍‍​‌​​​​​‌‍‍​‌​​‌​​‌‍‍‌​‌‌​‌‌‌‍‍‌‌​​‌‌​​‌‌‌‌​‌​‍‍‌‌​‌‌​​​‌​​​‌‌‌‍‍​‌​​​​​‌‍‍​‌​​‌​​‌‍‍‌​‌‌​‌‌‌‍‍‌‌​​‌‌‌​‌​​‌‌‌​‍‍‌‌​​‌‌​​​‌​​‌​‌‍‍‌​‌‌‌​‌‌‌​‌‌‌​‌‍‍‌​‌‌​‌‌‌‍‍​‌​​‌‌​​‍‍​‌​​​​‌‌‍‍‌​‌‌​‌‌‌‍‍​‌‌​​​​‌‍‍​‌‌​‌​​‌‍‍​‌‌‌‌​‌​‍‍​‌‌​‌​​​‍‍​‌‌‌​​‌‌‍‍​​‌​‌‌‌​‍‍​‌‌‌​‌​​‍‍​‌‌​‌‌‌‌‍‍​‌‌‌​​​​‍‍‌​‌‌​‌‌‌‍‍​‌​‌​​​​‍‍​‌​‌​​‌​‍‍​‌​​‌‌‌‌‍‍​‌​‌​‌‌​‍‍​‌​​​‌​‌‍‍​‌​​‌‌‌​‍‍​‌​​​​​‌‍‍​‌​​‌‌‌​‍‍​‌​​​​‌‌‍‍​‌​​​‌​‌‍‍​​‌​‌‌​‌‍‍​​‌‌​​‌​‍‍​​‌‌​​​​‍‍​​‌‌​​‌​‍‍​​‌‌​‌‌​⁠

"""免费 TTS 语音合成(edge-tts,零 key 零成本)。

对齐 GPT-5 Voice / Gemini TTS:提供无需任何 API key 的中文/多语语音合成,
基于微软 Edge 的免费 TTS 服务(edge-tts 库)。适用于实时语音对话/朗读场景。

- 零成本:不需要 DASHSCOPE_API_KEY 等任何凭据
- 中文质量高:默认 zh-CN-XiaoxiaoNeural(晓晓),支持多种中文/英文/日语声音
- 输出 MP3 音频字节(音频/mpeg),可直接播放
- 失败降级:网络不可达时返回 503 + 明确提示(不抛 500)

用法:
    POST /voice/tts  {"text": "你好", "voice": "zh-CN-XiaoxiaoNeural", "rate": "+0%"}
    → 200 audio/mpeg 音频流
    POST /voice/tts/stream {"text": "第一句。第二句。"}
    → 200 application/x-ndjson:policy(打断判据)→ segment × N → done(逐段流式)
    POST /voice/tts  {"text": "你好", "engine": "token6688", "voice": "alloy"}
    → 200 audio/mpeg(Token6688 网关,单 key;声纹可传声纹库 voice_id)
    GET  /voice/voices              → token6688 声纹库列表(voice-clone 用)
    POST /voice/voices (multipart)  → 上传参考音频建声纹(异步任务,轮询至终态)
    GET  /voice/voices/{voice_id}   → 单声纹详情(克隆状态确认)
    POST /voice/tts-async           → 异步 TTS 提交(≤5000 字符)→ task_id
    GET  /voice/tts-async/{task_id} → 异步 TTS 取件(audio_url=公网语音直链)
"""

from __future__ import annotations

import asyncio
import base64
import json
import logging
from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

from fastapi import APIRouter, Depends, File, HTTPException, Request, UploadFile
from fastapi.responses import Response, StreamingResponse
from pydantic import BaseModel, Field

from ..core.jwt_auth import require_request_user_id

if TYPE_CHECKING:
    from ..providers.token6688_provider import Token6688Provider

logger = logging.getLogger(__name__)

router = APIRouter()

# 常用声音白名单(edge-tts 官方 voices 子集,防滥用任意 voice 参数)
VOICE_WHITELIST: set[str] = {
    # 中文
    "zh-CN-XiaoxiaoNeural",  # 晓晓(女,默认)
    "zh-CN-YunxiNeural",     # 云希(男)
    "zh-CN-YunyangNeural",   # 云扬(新闻男)
    "zh-CN-liaoning-XiaobeiNeural",  # 辽宁小北(东北话)
    "zh-CN-shaanxi-XiaoniNeural",    # 陕西小妮
    "zh-TW-HsiaoChenNeural",  # 台湾晓臻
    "zh-HK-HiuMaanNeural",    # 香港晓曼
    # 英文
    "en-US-AriaNeural",
    "en-US-GuyNeural",
    "en-GB-SoniaNeural",
    # 日/韩
    "ja-JP-NanamiNeural",
    "ko-KR-SunHiNeural",
}

DEFAULT_VOICE = "zh-CN-XiaoxiaoNeural"
MAX_TEXT_CHARS = 2000  # 单次合成长度上限(防滥用)


class TTSRequest(BaseModel):
    """TTS 合成请求。"""

    text: str = Field(..., description="要合成的文本(≤2000 字符)")
    voice: str = Field(default=DEFAULT_VOICE, description="声音(白名单内;token6688 引擎可为官方音色或声纹库 voice_id)")
    rate: str = Field(default="+0%", description="语速,如 +10% / -20%(仅 edge 引擎)")
    engine: str = Field(
        default_factory=lambda: _default_engine(),
        description="TTS 引擎: edge(零成本) / token6688(聚合网关,单 key)。"
        "默认经 VOICE_PROVIDER 环境开关解析(edge-tts=免费 / token6688=付费)",
    )


def _default_engine() -> str:
    """VOICE_PROVIDER 环境开关 → 请求默认引擎(2026-09-24 免费替代改造)。

    VOICE_PROVIDER=edge-tts(默认/未配/未知值)→ "edge"(免费,零 key);
    VOICE_PROVIDER=token6688 → "token6688"(付费网关,需 TOKEN6688_API_KEY)。
    fail-safe:任何解析失败都回退免费通道。
    """
    return "edge"


def _require_admin(request: Request) -> None:
    """声纹库删除守卫:共享资源破坏性操作仅限 admin(roleId>=1)(2026-09-09 P1)。

    JWT 中间件已把 roleId 注入 request.state(阈值与 AGENTS.md §5、admin/layout
    的 roleId>=1 一致);测试可通过 app.dependency_overrides 覆盖本依赖。
    """
    role_id = getattr(request.state, "role_id", 0) or 0
    if int(role_id) < 1:
        raise HTTPException(status_code=403, detail="声纹库删除仅限管理员操作")


def _token6688_provider() -> Any:
    """token6688 已永久下线；旧调用方统一得到 410，不再要求配置 key。"""
    raise HTTPException(status_code=410, detail="token6688 平台已永久下线")


async def _tts_via_token6688(text: str, voice: str) -> tuple[bytes, str]:
    """Token6688 网关 TTS(POST /v1/audio/speech,OpenAI 官方同构)。"""
    from ..providers.base_provider import ProviderError

    try:
        return await _token6688_provider().tts(text, voice=voice)
    except HTTPException:
        raise
    except ProviderError as e:
        logger.warning("token6688 TTS 合成失败: %s", e)
        raise HTTPException(status_code=502, detail=f"token6688 TTS 失败: {e}") from None


def _official_tts_voices() -> frozenset[str]:
    """官方音色白名单唯一来源:复用 mcp_server 的 _TTS_OPENAI_VOICES,不复制第二份判据。"""
    from ..services.mcp_server import _TTS_OPENAI_VOICES

    return _TTS_OPENAI_VOICES


async def _assert_paid_voice_allowed(voice: str) -> None:
    """付费引擎 voice 闸门(AIS-092):官方音色或平台声纹库在册 voice_id,其余 403。

    付费分支曾把客户端 voice 原样透传给上游(可直通平台声纹库);JWT 收权后仍要
    挡住"已登录用户拿任意 voice_id 试探/盗用"。仓内声纹库是平台共享账号、无属主
    概念,故判据 = 官方音色白名单 ∪ 平台声纹库当前在册 voice_id(与 GET
    /api/voice/voices 同一数据源);查库失败 fail-closed,绝不落到合成。
    """
    normalized = (voice or "").strip()
    if not normalized:
        raise HTTPException(status_code=403, detail="token6688 引擎 voice 不能为空")
    if normalized.lower() in _official_tts_voices():
        return
    try:
        voices = await _token6688_provider().list_voices()
    except HTTPException:
        raise
    except Exception as e:  # noqa: BLE001 — 查库失败按 fail-closed 拒绝,不落合成
        logger.warning("token6688 声纹库校验失败: %s", e)
        raise HTTPException(
            status_code=502, detail=f"声纹库校验失败,拒绝非官方 voice: {e}",
        ) from None
    known = {
        str(item.get("voice_id") or item.get("id") or "").strip()
        for item in voices or []
        if isinstance(item, dict)
    }
    if normalized not in known:
        raise HTTPException(
            status_code=403,
            detail=f"voice 不在官方音色或平台声纹库白名单: {normalized}",
        )


@router.post("/voice/tts")
async def synthesize_tts(
    req: TTSRequest,
    _user_id: str = Depends(require_request_user_id),
) -> Response:
    """免费 TTS 合成(edge-tts,零 key)。返回 audio/mpeg 音频流。

    AIS-092:本端点不再匿名可达(已移出 jwt_public_paths),并加端点级身份依赖
    双保险 —— 即便部署 .env 又把路径写回白名单,无已验证主体仍 401。
    """
    text = req.text.strip()
    if not text:
        raise HTTPException(status_code=400, detail="text 不能为空")
    if len(text) > MAX_TEXT_CHARS:
        raise HTTPException(
            status_code=400,
            detail=f"text 超长({len(text)}>{MAX_TEXT_CHARS} 字符)",
        )
    rate = req.rate if req.rate.startswith(("+", "-")) and req.rate.endswith("%") else "+0%"

    # 免费引擎:统一走 free_voice_provider(2026-09-24 从内联实现抽出,
    # 与 e2e --free 共用同一 provider 代码路径;白名单校验路由层先行)
    if req.engine == "edge":
        if req.voice not in VOICE_WHITELIST:
            raise HTTPException(status_code=400, detail=f"voice 不在白名单: {req.voice}")
        try:
            from ..providers.free_voice_provider import FreeVoiceProvider, VoiceProviderError

            audio, content_type = await FreeVoiceProvider().tts(text, voice=req.voice, rate=rate)
            return Response(
                content=audio,
                media_type=content_type or "audio/mpeg",
                headers={"X-TTS-Engine": "edge-tts", "X-TTS-Voice": req.voice},
            )
        except VoiceProviderError as e:
            # 400 类(参数)原样透传;503/502 类(服务不可达)按既有语义回 503
            status = e.status_code if e.status_code == 400 else 503
            logger.warning("免费 TTS 合成失败(edge-tts): %s", e)
            raise HTTPException(status_code=status, detail=str(e)) from None
    if req.engine != "token6688":
        raise HTTPException(status_code=400, detail=f"未知 engine: {req.engine}(允许 edge/token6688)")

    await _assert_paid_voice_allowed(req.voice)
    audio, content_type = await _tts_via_token6688(text, req.voice)
    return Response(
        content=audio,
        media_type=content_type or "audio/mpeg",
        headers={"X-TTS-Engine": "token6688", "X-TTS-Voice": req.voice},
    )


class TTSStreamRequest(BaseModel):
    """逐段流式合成请求(barge-in 用;仅 edge 免费引擎)。"""

    text: str = Field(..., description="要合成的文本(≤2000 字符,按句读切段)")
    voice: str = Field(default=DEFAULT_VOICE, description="声音(白名单内)")
    rate: str = Field(default="+0%", description="语速,如 +10% / -20%")


def _ndjson(event: dict[str, Any]) -> str:
    """一行 NDJSON;中文不转义(客户端直接按 UTF-8 解析)。"""
    return json.dumps(event, ensure_ascii=False) + "\n"


@router.post("/voice/tts/stream")
async def synthesize_tts_stream(req: TTSStreamRequest) -> StreamingResponse:
    """逐段流式 TTS(NDJSON):policy → segment × N → done。

    立体因(2026-10-24 D11 第二工):整段一次返回的链路没有"段"这个概念,客户端
    无从在段间静默里判打断。本端点按句读切段、逐段合成、逐段下发,客户端播完
    一段即进入 `segmentTailSilenceMs` 静默余量 —— 这就是"可打断"的物理窗口。

    首帧下发打断判据(app/core/voice_barge_in.policy_payload),客户端不得自行
    硬编码数字;判据的三条口径与实测基线见该模块头注。

    可打断的另一半在传输层:客户端 abort 后 StreamingResponse 会取消本生成器,
    尚未合成的段落不会再向 edge-tts 发起请求(零计费、零残留;edge-tts 的
    asyncio 流式取消由 FreeVoiceProvider.tts 的 CancelledError 直通承担)。

    校验失败(空文本/超长/声音不在白名单)在任何字节下发前按 400 返回;段级合成
    失败时已发的帧无法撤回,按 `{"type":"error",...}` 帧如实上报并停止。
    """
    text = req.text.strip()
    if not text:
        raise HTTPException(status_code=400, detail="text 不能为空")
    if len(text) > MAX_TEXT_CHARS:
        raise HTTPException(
            status_code=400,
            detail=f"text 超长({len(text)}>{MAX_TEXT_CHARS} 字符)",
        )
    # 流式链路只走免费 edge 引擎:token6688 是单次整段网关,无逐段语义
    if req.voice not in VOICE_WHITELIST:
        raise HTTPException(status_code=400, detail=f"voice 不在白名单: {req.voice}")
    rate = req.rate if req.rate.startswith(("+", "-")) and req.rate.endswith("%") else "+0%"

    from ..core.voice_barge_in import policy_payload, split_speech_segments

    segments = split_speech_segments(text)
    policy = policy_payload()

    async def _events() -> AsyncIterator[str]:
        yield _ndjson(policy)
        from ..providers.free_voice_provider import FreeVoiceProvider, VoiceProviderError

        provider = FreeVoiceProvider()
        emitted = 0
        for index, segment in enumerate(segments):
            try:
                audio, content_type = await provider.tts(
                    segment, voice=req.voice, rate=rate,
                )
            except asyncio.CancelledError:
                raise  # 客户端 abort:停在这里,后续分段不再合成
            except VoiceProviderError as e:
                yield _ndjson({
                    "type": "error",
                    "stage": "tts",
                    "index": index,
                    "status": e.status_code,
                    "message": str(e),
                })
                return
            yield _ndjson({
                "type": "segment",
                "index": index,
                "total": len(segments),
                "text": segment,
                "contentType": content_type or "audio/mpeg",
                "audioBase64": base64.b64encode(audio).decode("ascii"),
            })
            emitted += 1
        yield _ndjson({"type": "done", "segments": emitted})

    return StreamingResponse(
        _events(),
        media_type="application/x-ndjson",
        headers={
            "X-TTS-Engine": "edge-tts",
            "X-TTS-Voice": req.voice,
            "X-Barge-In-Policy": policy["policy"],
            "Cache-Control": "no-store",
        },
    )


@router.get("/voice/voices")
async def list_voices() -> dict[str, Any]:
    """Token6688 声纹库列表(GET /v1/audio/voices;voice-clone 前置)。"""
    from ..providers.base_provider import ProviderError

    try:
        voices = await _token6688_provider().list_voices()
    except HTTPException:
        raise
    except ProviderError as e:
        logger.warning("token6688 声纹列表失败: %s", e)
        raise HTTPException(status_code=502, detail=f"token6688 声纹列表失败: {e}") from None
    return {"voices": voices, "count": len(voices)}


@router.post("/voice/voices")
async def upload_voice(file: UploadFile = File(..., description="参考音频(wav/mp3,建议 10~30s 干声)")) -> dict[str, Any]:
    """上传参考音频到 Token6688 声纹库(POST /v1/audio/voices,异步任务轮询至终态)。

    成功后声纹进入 /voice/voices 列表,TTS 传其 voice_id 即可克隆音色。
    """
    from ..providers.base_provider import ProviderError

    data = await file.read()
    if not data:
        raise HTTPException(status_code=400, detail="参考音频为空")
    if len(data) > 50 * 1024 * 1024:
        raise HTTPException(status_code=400, detail="参考音频超 50MB 上限")
    try:
        result = await _token6688_provider().upload_voice(data, file.filename or "ref.wav")
    except HTTPException:
        raise
    except ProviderError as e:
        logger.warning("token6688 声纹上传失败: %s", e)
        raise HTTPException(status_code=502, detail=f"token6688 声纹上传失败: {e}") from None
    return result


@router.get("/voice/voices/{voice_id}")
async def get_voice(voice_id: str) -> dict[str, Any]:
    """查询单一声纹(GET /v1/audio/voices/{voice_id};确认克隆状态/音色详情)。"""
    from ..providers.base_provider import ProviderError

    try:
        return await _token6688_provider().get_voice(voice_id)
    except HTTPException:
        raise
    except ProviderError as e:
        logger.warning("token6688 声纹查询失败: %s", e)
        raise HTTPException(status_code=502, detail=f"token6688 声纹查询失败: {e}") from None


@router.delete("/voice/voices/{voice_id}")
async def delete_voice(
    voice_id: str,
    _admin: None = Depends(_require_admin),
) -> dict[str, Any]:
    """删除克隆声纹(DELETE /v1/audio/voices/{voice_id};声纹库生命周期收口,2026-09-09 E4)。

    2026-09-09 P1 收敛:声纹库是平台共享资源(单一 token6688 账号,无归属概念),
    删除影响所有用户,故仅限 admin(roleId>=1)执行,与 AGENTS.md §5 / admin
    layout 的阈值一致;列表/上传/试听对所有登录用户开放。
    删除后该 voice_id 不可再用于克隆 TTS;失败如实返回原因不抛。
    """
    from ..providers.base_provider import ProviderError

    try:
        result = await _token6688_provider().delete_voice(voice_id)
    except HTTPException:
        raise
    except ProviderError as e:
        logger.warning("token6688 声纹删除失败: %s", e)
        raise HTTPException(status_code=502, detail=f"token6688 声纹删除失败: {e}") from None
    if not result.get("ok"):
        raise HTTPException(
            status_code=502,
            detail=f"token6688 声纹删除失败(status={result.get('status')}): {result.get('error') or '未知'}",
        )
    return result


class AsyncTTSRequest(BaseModel):
    """异步声纹 TTS 请求(长文本/免长连接场景;产物为 TokenGo CDN 公网 URL)。"""

    text: str = Field(..., min_length=1, max_length=5000, description="要合成的文本(≤5000 字符)")
    voice: str = Field("alloy", description="官方音色或声纹库 voice_id")
    model: str | None = Field(None, description="可选,TTS 模型(默认 tts-1-hd)")
    speed: float = Field(1.0, description="语速倍率 0.25~4.0")


@router.post("/voice/tts-async")
async def tts_async(req: AsyncTTSRequest) -> dict[str, Any]:
    """异步 TTS 提交(POST /v1/audio/speech/async)→ 立即返回 task_id。

    与同步 POST /voice/tts(返回音频字节)不同:本端点提交即返回,产物是公网
    语音 URL;用 GET /voice/tts-async/{task_id} 查询取件。
    """
    from ..providers.base_provider import ProviderError

    try:
        return await _token6688_provider().tts_async(
            req.text, model=req.model, voice=req.voice, speed=req.speed, wait=False,
        )
    except HTTPException:
        raise
    except ProviderError as e:
        logger.warning("token6688 异步 TTS 提交失败: %s", e)
        raise HTTPException(status_code=502, detail=f"token6688 异步 TTS 提交失败: {e}") from None


@router.get("/voice/tts-async/{task_id}")
async def tts_async_status(task_id: str) -> dict[str, Any]:
    """异步 TTS 取件(GET /v1/tasks/{task_id};completed 后 audio_url 为公网语音直链)。"""
    from ..providers.base_provider import ProviderError

    try:
        st = await _token6688_provider().get_task_status(task_id)
    except HTTPException:
        raise
    except ProviderError as e:
        logger.warning("token6688 异步 TTS 查询失败: %s", e)
        raise HTTPException(status_code=502, detail=f"token6688 异步 TTS 查询失败: {e}") from None
    return {
        "task_id": task_id,
        "status": st.get("status"),
        "ok": st.get("ok"),
        "failed": st.get("failed"),
        "audio_url": st.get("video_url"),  # get_task_status 归一化字段名,即 output_url
        "error": st.get("error"),
        "error_class": st.get("error_class"),
    }
