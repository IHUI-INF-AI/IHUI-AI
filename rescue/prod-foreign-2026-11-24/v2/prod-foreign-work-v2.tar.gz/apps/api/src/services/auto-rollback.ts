// © 2026 IHUI AI (智汇AI) · 版权所有者: 李春川 (Li Chunchuan) · https://aizhs.top
// Provenance-watermarked. 未授权商用可被溯源追责 (Apache-2.0 须保留本声明与 NOTICE)。
// [IHUI-AI-PROVENANCE]:⁠​‌​​‌​​‌‍‍​‌​​‌​​​‍‍​‌​‌​‌​‌‍‍​‌​​‌​​‌‍‍​​‌​‌‌​‌‍‍​‌​​​​​‌‍‍​‌​​‌​​‌‍‍‌​‌‌​‌‌‌‍‍‌‌​​‌‌​​‌‌‌‌​‌​‍‍‌‌​‌‌​​​‌​​​‌‌‌‍‍​‌​​​​​‌‍‍​‌​​‌​​‌‍‍‌​‌‌​‌‌‌‍‍‌‌​​‌‌‌​‌​​‌‌‌​‍‍‌‌​​‌‌​​​‌​​‌​‌‍‍‌​‌‌‌​‌‌‌​‌‌‌​‌‍‍‌​‌‌​‌‌‌‍‍​‌​​‌‌​​‍‍​‌​​​​‌‌‍‍‌​‌‌​‌‌‌‍‍​‌‌​​​​‌‍‍​‌‌​‌​​‌‍‍​‌‌‌‌​‌​‍‍​‌‌​‌​​​‍‍​‌‌‌​​‌‌‍‍​​‌​‌‌‌​‍‍​‌‌‌​‌​​‍‍​‌‌​‌‌‌‌‍‍​‌‌‌​​​​‍‍‌​‌‌​‌‌‌‍‍​‌​‌​​​​‍‍​‌​‌​​‌​‍‍​‌​​‌‌‌‌‍‍​‌​‌​‌‌​‍‍​‌​​​‌​‌‍‍​‌​​‌‌‌​‍‍​‌​​​​​‌‍‍​‌​​‌‌‌​‍‍​‌​​​​‌‌‍‍​‌​​​‌​‌‍‍​​‌​‌‌​‌‍‍​​‌‌​​‌​‍‍​​‌‌​​​​‍‍​​‌‌​​‌​‍‍​​‌‌​‌‌​⁠

import { logger } from '../utils/logger.js'
import { rollbackCanary as dbRollbackCanary } from './canary-service.js'

/**
 * 金丝雀自动回滚服务：定时监控金丝雀版本错误率，超阈值时自动回滚。
 *
 * 配置（env）：
 * - CANARY_ERROR_RATE_THRESHOLD  错误率阈值 0-1（默认 0.05，即 5%）
 * - CANARY_CHECK_INTERVAL_MS     检查间隔毫秒（默认 60000，即 1 分钟）
 * - PROMETHEUS_URL               Prometheus 查询地址（默认 http://localhost:9090）
 * - CANARY_CONFIG_NAME           DB 中 canary_configs 表的配置名（用于调用 canary-service 回滚）
 */

const CONFIGURED_THRESHOLD = Number(process.env.CANARY_ERROR_RATE_THRESHOLD ?? 0.05)
// env 写错(NaN/Infinity)时任何比较都为 false ⇒ 恒判"不健康"并秒回滚,回落默认值兜住。
const ERROR_RATE_THRESHOLD = Number.isFinite(CONFIGURED_THRESHOLD) ? CONFIGURED_THRESHOLD : 0.05
const CHECK_INTERVAL_MS = Number(process.env.CANARY_CHECK_INTERVAL_MS ?? 60000)

let checkInterval: NodeJS.Timeout | null = null

/**
 * 三态健康判定：unknown 表示"没有可用的错误率样本"(NaN / 空结果 / 查询失败),
 * 它既不等于健康也不等于不健康，绝不能据此回滚。
 */
export type CanaryHealthState = 'healthy' | 'unhealthy' | 'unknown'

export interface CanaryHealthStatus {
  /** 错误率；未知时保持 null，不用 0 顶替("没有请求"≠"零错误率") */
  errorRate: number | null
  threshold: number
  /** 兼容旧布尔判据：仅 state === 'unhealthy' 时为 false(未知不判不健康) */
  healthy: boolean
  rolledBack: boolean
  state: CanaryHealthState
  /** state === 'unknown' 时的可观测原因 */
  reason?: string
}

/**
 * 检查金丝雀版本健康状态。从 Prometheus 读取错误率，超阈值时自动回滚。
 */
export async function checkCanaryHealth(): Promise<CanaryHealthStatus> {
  const { errorRate, reason } = await fetchCanaryErrorRate()

  if (errorRate === null) {
    // 低流量窗口 0/0 会让 Prometheus 返回 "NaN"；旧判据 NaN < 阈值 === false
    // 把"未知"当成"不健康"，会反复回滚一个健康版本。未知一律只记录原因。
    logger.warn('[auto-rollback] canary health unknown, skip rollback', { reason })
    return {
      errorRate: null,
      threshold: ERROR_RATE_THRESHOLD,
      healthy: true,
      rolledBack: false,
      state: 'unknown',
      reason,
    }
  }

  if (errorRate < ERROR_RATE_THRESHOLD) {
    return {
      errorRate,
      threshold: ERROR_RATE_THRESHOLD,
      healthy: true,
      rolledBack: false,
      state: 'healthy',
    }
  }

  logger.warn('[auto-rollback] canary error rate exceeded threshold', {
    errorRate,
    threshold: ERROR_RATE_THRESHOLD,
  })
  await rollbackCanary(
    `auto-rollback: error rate ${errorRate} exceeded threshold ${ERROR_RATE_THRESHOLD}`,
  )
  return {
    errorRate,
    threshold: ERROR_RATE_THRESHOLD,
    healthy: false,
    rolledBack: true,
    state: 'unhealthy',
  }
}

/**
 * 回滚金丝雀：将 canary 流量百分比设为 0，并记录回滚事件。
 * 若 CANARY_CONFIG_NAME 已配置，同步调用 canary-service 的 DB 级回滚。
 */
export async function rollbackCanary(reason: string): Promise<void> {
  logger.error('[auto-rollback] rolling back canary', { reason })

  process.env.CANARY_PERCENTAGE = '0'
  process.env.CANARY_ENABLED = 'false'

  const configName = process.env.CANARY_CONFIG_NAME
  if (configName) {
    try {
      await dbRollbackCanary(configName, reason)
      logger.info('[auto-rollback] DB canary config rolled back', { configName })
    } catch (err) {
      logger.error('[auto-rollback] DB rollback failed', {
        configName,
        error: err instanceof Error ? err.message : String(err),
      })
    }
  }

  if (checkInterval) {
    stopAutoRollbackMonitor()
  }
}

interface CanaryErrorRateSample {
  errorRate: number | null
  reason?: string
}

/**
 * 从 Prometheus 查询金丝雀版本错误率。
 * 查询指标：canary 请求中 5xx 状态码占比。
 * 取不到有效数值时返回 errorRate=null(未知)并带原因，绝不返回 0 伪装成健康。
 */
async function fetchCanaryErrorRate(): Promise<CanaryErrorRateSample> {
  const prometheusUrl = process.env.PROMETHEUS_URL ?? 'http://localhost:8815'
  const query = encodeURIComponent(
    // 501「未实现/未配置」不是 canary 运行时故障,不得触发自动回滚。
    'sum(rate(http_requests_by_status{status=~"5..",status!="501",served_by="canary"}[1m])) / ' +
      'sum(rate(http_requests_by_status{served_by="canary"}[1m]))',
  )

  try {
    // 本行目标 host 是 PROMETHEUS_URL(Prometheus 官方查询 API),不是本仓任何自家路由。
    // route-declare-exempt: 打的是 Prometheus HTTP API(host=PROMETHEUS_URL),非本仓路由 until 2026-12-26
    const res = await fetch(`${prometheusUrl}/api/v1/query?query=${query}`, {
      signal: AbortSignal.timeout(5000),
    })
    if (!res.ok) {
      logger.warn('[auto-rollback] prometheus query failed', { status: res.status })
      return { errorRate: null, reason: `prometheus query failed with HTTP ${res.status}` }
    }

    const data = (await res.json()) as {
      status: string
      data?: { result?: Array<{ value?: [number, string] }> }
    }
    if (data.status !== 'success' || !data.data?.result?.length) {
      return { errorRate: null, reason: 'prometheus returned no sample' }
    }

    const raw = data.data.result[0]?.value?.[1]
    const value = Number(raw)
    // 与后台大屏 promQuery/sampleNum 同一判据:取不到有限数即视为"无样本"。
    // 低流量窗口 0/0 会返回字面量 "NaN",若不拦截会参与 `NaN < 阈值` 恒 false 的误判。
    if (!Number.isFinite(value)) {
      return {
        errorRate: null,
        reason: `prometheus returned non-finite error rate: ${String(raw)}`,
      }
    }
    return { errorRate: value }
  } catch (err) {
    logger.warn('[auto-rollback] failed to fetch error rate from prometheus', {
      error: err instanceof Error ? err.message : String(err),
    })
    return {
      errorRate: null,
      reason: `prometheus query error: ${err instanceof Error ? err.message : String(err)}`,
    }
  }
}

/**
 * 启动自动回滚定时监控。仅当 CANARY_ENABLED=true 时启动。
 */
export function startAutoRollbackMonitor(): void {
  if (checkInterval) return
  if (process.env.CANARY_ENABLED !== 'true') return

  const handle = setInterval(async () => {
    try {
      await checkCanaryHealth()
    } catch (err) {
      logger.error('[auto-rollback] health check failed', {
        error: err instanceof Error ? err.message : String(err),
      })
    }
  }, CHECK_INTERVAL_MS)
  // F-524:non-unref 定时器会钉住事件循环;worker 侧 onClose 若挂起,进程只能等 SIGKILL。
  handle.unref()
  checkInterval = handle

  logger.info('[auto-rollback] monitor started', {
    threshold: ERROR_RATE_THRESHOLD,
    intervalMs: CHECK_INTERVAL_MS,
  })
}

/**
 * 停止自动回滚定时监控。
 */
export function stopAutoRollbackMonitor(): void {
  if (checkInterval) {
    clearInterval(checkInterval)
    checkInterval = null
    logger.info('[auto-rollback] monitor stopped')
  }
}
// ⁠​‌​​‌​​‌‍‍​‌​​‌​​​‍‍​‌​‌​‌​‌‍‍​‌​​‌​​‌‍‍​​‌​‌‌​‌‍‍​‌​​​​​‌‍‍​‌​​‌​​‌‍‍‌​‌‌​‌‌‌‍‍‌‌​​‌‌​​‌‌‌‌​‌​‍‍‌‌​‌‌​​​‌​​​‌‌‌‍‍​‌​​​​​‌‍‍​‌​​‌​​‌‍‍‌​‌‌​‌‌‌‍‍‌‌​​‌‌‌​‌​​‌‌‌​‍‍‌‌​​‌‌​​​‌​​‌​‌‍‍‌​‌‌‌​‌‌‌​‌‌‌​‌‍‍‌​‌‌​‌‌‌‍‍​‌​​‌‌​​‍‍​‌​​​​‌‌‍‍‌​‌‌​‌‌‌‍‍​‌‌​​​​‌‍‍​‌‌​‌​​‌‍‍​‌‌‌‌​‌​‍‍​‌‌​‌​​​‍‍​‌‌‌​​‌‌‍‍​​‌​‌‌‌​‍‍​‌‌‌​‌​​‍‍​‌‌​‌‌‌‌‍‍​‌‌‌​​​​‍‍‌​‌‌​‌‌‌‍‍​‌​‌​​​​‍‍​‌​‌​​‌​‍‍​‌​​‌‌‌‌‍‍​‌​‌​‌‌​‍‍​‌​​​‌​‌‍‍​‌​​‌‌‌​‍‍​‌​​​​​‌‍‍​‌​​‌‌‌​‍‍​‌​​​​‌‌‍‍​‌​​​‌​‌‍‍​​‌​‌‌​‌‍‍​​‌‌​​‌​‍‍​​‌‌​​​​‍‍​​‌‌​​‌​‍‍​​‌‌​‌‌​⁠
