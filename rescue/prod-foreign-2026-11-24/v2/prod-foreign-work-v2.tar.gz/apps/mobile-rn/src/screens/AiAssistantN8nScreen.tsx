// © 2026 IHUI AI (智汇AI) · 版权所有者: 李春川 (Li Chunchuan) · https://aizhs.top
// Provenance-watermarked. 未授权商用可被溯源追责 (Apache-2.0 须保留本声明与 NOTICE)。
// [IHUI-AI-PROVENANCE]:⁠​‌​​‌​​‌‍‍​‌​​‌​​​‍‍​‌​‌​‌​‌‍‍​‌​​‌​​‌‍‍​​‌​‌‌​‌‍‍​‌​​​​​‌‍‍​‌​​‌​​‌‍‍‌​‌‌​‌‌‌‍‍‌‌​​‌‌​​‌‌‌‌​‌​‍‍‌‌​‌‌​​​‌​​​‌‌‌‍‍​‌​​​​​‌‍‍​‌​​‌​​‌‍‍‌​‌‌​‌‌‌‍‍‌‌​​‌‌‌​‌​​‌‌‌​‍‍‌‌​​‌‌​​​‌​​‌​‌‍‍‌​‌‌‌​‌‌‌​‌‌‌​‌‍‍‌​‌‌​‌‌‌‍‍​‌​​‌‌​​‍‍​‌​​​​‌‌‍‍‌​‌‌​‌‌‌‍‍​‌‌​​​​‌‍‍​‌‌​‌​​‌‍‍​‌‌‌‌​‌​‍‍​‌‌​‌​​​‍‍​‌‌‌​​‌‌‍‍​​‌​‌‌‌​‍‍​‌‌‌​‌​​‍‍​‌‌​‌‌‌‌‍‍​‌‌‌​​​​‍‍‌​‌‌​‌‌‌‍‍​‌​‌​​​​‍‍​‌​‌​​‌​‍‍​‌​​‌‌‌‌‍‍​‌​‌​‌‌​‍‍​‌​​​‌​‌‍‍​‌​​‌‌‌​‍‍​‌​​​​​‌‍‍​‌​​‌‌‌​‍‍​‌​​​​‌‌‍‍​‌​​​‌​‌‍‍​​‌​‌‌​‌‍‍​​‌‌​​‌​‍‍​​‌‌​​​​‍‍​​‌‌​​‌​‍‍​​‌‌​‌‌​⁠
// i18n-content-exempt-file: 多语言常量数据定义(label/title/description等选项值,内容体系定为中文单语,产品决策2026-11-15) until 2027-05-31

/**
 * AiAssistantN8nScreen AI 助手对话(mobile-rn 端,流式版)
 *
 * 对齐历史 Uniapp pages/tools/ai_assistant_n8n.vue 的对话核心:
 * - NavBar「AI 助手」+ 返回 + 菜单入口(打开 Drawer)
 *   (对齐 Uniapp page_title:路由 title/modelName 参数优先,缺省 i18n;
 *    对齐 Uniapp onLoad options.agentId / modelNamea)
 * - 消息列表:FlatList 渲染气泡(user 右 / assistant 左)
 * - 输入区:InputArea(共享组件)+ 发送/停止按钮(对齐 Uniapp BottomActionBar 输入部分)
 * - 流式输出:复用 streamChat(@ihui/api-client)SSE 端点 + agentId 绑定 N8n 工作流;
 *   onDelta 累积实时更新最后一条 assistant 消息(对齐 Uniapp onMessage 累积 data.content)
 * - 模型选择器:ModelList(共享组件)底部弹出,单选切换模型(对齐 Uniapp ModelList + pitchHandle);
 *   InputArea 上方 modelBar 展示当前模型名,点击展开选择器;
 *   路由参数 modelId 优先初始化选中模型(对齐 Uniapp onLoad options.modelNamea)
 * - 模型配置:ModelConfigDialog 弹层(温度/top_p/maxTokens/系统提示词等),
 *   入口在模型选择旁的"配置"按钮(对齐 Uniapp InputArea showModelaConfig 习惯),
 *   参数在发送时透传 streamChat(temperature/topP/maxTokens/systemPrompt)
 * - 快捷操作:无消息时输入区上方横向 suggestedQuestions chip,点击直接发送
 *   (对齐 Uniapp ai_assistant_n8n quick-actions-container + handleQuickActionClick)
 * - 图片预览:assistant 回复中提取图片 URL(对齐 Uniapp processContent + imgUrlList),
 *   渲染缩略图,点击 ImagePreviewModal 全屏预览(对齐 Uniapp previewImage)
 * - 无 agentId → 不伪造回复:移除刚加入的消息 + FloatBox 提示选择智能体
 *   (对齐 Uniapp onLoad 无 agentId 不调 processN8nAgent,2026-08-21 注释修正:
 *   原注释"模拟响应"为过时描述,实际实现已是防伪造提示)
 * - Drawer 集成:历史对话入口(对齐任务要求"Drawer 集成:历史对话入口"),
 *   复用 @ihui/rn-app Drawer 组件 + listConversations/getMessages/deleteConversation API;
 *   NavBar 右侧菜单按钮打开 Drawer,Drawer 内选择历史对话 → 加载消息,
 *   创建新对话 → 清空当前消息(对齐 ChatScreen Drawer 集成模式)
 * - 路由参数:{ agentId?: string; title?: string; conversationId?: string; modelName?: string; modelId?: string }
 *   (对齐 Uniapp onLoad options: agentId / modelNamea / pitcha / type)
 *
 * 平台独占:仅 mobile-rn 端。
 */
import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import IntelligentAssistant from '../components/IntelligentAssistant'
import {
  ActivityIndicator,
  FlatList,
  Image,
  Keyboard,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  Share,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  useWindowDimensions,
  type ImageSourcePropType,
  type ListRenderItem,
} from 'react-native'
import { appAlert } from '../components/BottomPops'
import { dialogContentHeightStyle } from '../lib/dialog-geometry'
import Clipboard from '@react-native-clipboard/clipboard'
import * as FileSystem from '@/platform/fs'
import * as MediaLibrary from '@/platform/media-library'
import * as ImagePicker from '@/platform/image-picker'
import * as DocumentPicker from '@/platform/document-picker'
import {
  AlertTriangle,
  Bot,
  Brain,
  Camera,
  ChevronDown,
  ChevronRight,
  Copy,
  Download,
  Eye,
  EyeOff,
  Folder,
  GitBranchPlus,
  Image as ImageIcon,
  MessageCircle,
  RefreshCw,
  Settings,
  Share2,
} from 'lucide-react-native'
import { useNavigation, useRoute, type RouteProp } from '@react-navigation/native'
import type { NativeStackNavigationProp } from '@react-navigation/native-stack'
import { navigateDrawerTab } from '../navigation/tab-utils'
import { AddPanel } from '../components/AddPanel'
import {
  branchConversation,
  deleteConversation,
  fetchModels,
  fetchPoolChatModels,
  formatSSEError,
  getMessages,
  getTokenBalance,
  getWorkspacePermissionDefault,
  listConversations,
  resolveFileUrl,
  streamChat,
  uploadFileMultipart,
  type ConversationDetail,
  type LlmModel,
  type TerminalDeltaEvent,
  // D151:terminal_interaction 载荷类型复用 @ihui/api-client(§3 共享层优先,禁止端内再声明同名接口)
  type TerminalInteractionEvent,
} from '@ihui/api-client'
import {
  FALLBACK_MODELS,
  humanizeToolText,
  describeToolCall,
  normalizeCategory,
  normalizeTier,
  type ToolCallView,
} from '@ihui/shared'
import { applyStreamError, isErrorTurn, resendTargetText } from '@ihui/shared/chat'
import {
  rnLightTokens as tokens,
  rnRadius,
  rnRadiusFor,
  rnSpacing,
  rnType,
  rnCssLight,
} from '@ihui/design-tokens'
import {
  CitationList,
  InjectionDisclosure,
  PermissionTierRow,
  SteerNoticeList,
} from '../components/ChatDisclosure'
// 多端一致聊天滚动淡出(2026-11-10,与 Web 端同规格:视口上下沿各一条 24px 纯渐变)
import { ChatScrollFades, useChatScrollFades } from '../components/chat/ChatScrollFades'
import { NavBar } from '../components/NavBar'
import { PanelLeftRounded } from '../components/PanelLeftRounded'
import { NavChrome } from '../components/NavChrome'
import { InputArea } from '../components/InputArea'
import { TaskStatusBar } from '../components/ai/TaskStatusBar'
import { VoiceInput } from '../components/VoiceInput'
import { ModelConfigDialog, type ModelConfig } from '../components/ModelConfigDialog'
import ModelPickerList, { type ModelListItem } from '../components/ModelPickerList'
import ImagePreviewModal from '../components/ImagePreviewModal'
import { type ImageTransferKind, type ImageTransferResult } from '@ihui/shared/chat/element-pack'
import Drawer, {
  type DrawerConversationItem,
  type DrawerExtraMenu,
  type DrawerTab,
} from '../components/Drawer'
import Empty from '../components/common/Empty'
import { FloatBox, type FloatBoxType } from '../components/FloatBox'
import { useAuth } from '../context/AuthContext'
import { useI18n } from '../i18n'
import type { RootStackParamList } from '../navigation/RootNavigator'
import { uiControlToolsFor } from '../lib/ui-control-tools'
import { rpx } from '../utils/rpx'
import { budgetNoteText } from '../utils/budget-note'
// G-425:done 帧 finishReason 判"输出被 max_tokens 截断"——共享层唯一判据,端内不留副本
import { isMaxTokensTruncatedFinishReason } from '@ihui/shared/utils/finish-reason'
// 会话级分叉的判据层(纯函数 + 五条出口文案选择),网络出口/词表/提示/切会话由本屏注入。
import {
  branchConversationFromMessage,
  isBranchableTarget,
  type OpenConversationResult,
} from '../utils/branch-conversation'
import { FREE_RESOURCE_URL } from '../constants/links'
import {
  applyPlanUpdate,
  applyTerminalEnd,
  applyInjectionFrame,
  appendCitationFrames,
  appendSteerFrames,
  readSteerAppliedFromMetadata,
  applyTerminalStart,
  applyToolCallEvent,
  applyToolDelta,
  formatDurationMs,
  formatStructured,
  mcpToolActivityTitle,
  type MessageInjection,
  type MessageCitation,
  type SteerNotice,
  type PlanStepItem,
  type TerminalTaskItem,
  type ToolCallItem,
} from '../utils/chat-render-model'
import { Tappable } from '@ihui/ui-native'

/**
 * 操控本端界面的工具族闸门(2026-09-21 立,agent-control RN 侧)。
 * 族名与本端映射在 `../lib/ui-control-tools`(关键词判定在 @ihui/shared 单一事实源)。
 *
 * 为什么必须在这里按需带:`apps/ai-service/app/routers/llm.py` 的 tool loop 只在请求带
 * 非空 agentTools 时才进入,而本端为保打字机流式,普通问答刻意不带工具(web 端
 * use-chat/send-message.ts 2026-08-29 同因)。不带 → 端侧桥接在对话里就是死代码。
 */

type LocalParamList = RootStackParamList & {
  AiAssistantN8n: {
    agentId?: string
    title?: string
    conversationId?: string
    modelName?: string
    modelId?: string
  }
}
type N8nRouteProp = RouteProp<LocalParamList, 'AiAssistantN8n'>
type NavigationProp = NativeStackNavigationProp<LocalParamList>
type RootNav = NativeStackNavigationProp<RootStackParamList>

interface N8nMessage {
  id: string
  /** 服务端消息 id(仅历史回放可得)。本地乐观消息没有它,因此**不可**作为分叉锚点 ——
   *  这是 `isBranchableTarget` 的准入条件,不是可选装饰。 */
  serverId?: string
  role: 'user' | 'assistant'
  content: string
  /** 失败轮标记(词汇与共享层 ChatMessage.error 同一份,不另立字段):
   *  有此标记的回复渲染错误卡片 + 重试,且不算内容(不给分享)。 */
  error?: boolean
  /** assistant 回复中提取的图片 URL 列表(对齐 Uniapp imgUrlList) */
  images?: string[]
  /** 对齐 Uniapp agent_content_list.total_tokens:回复消耗智汇值。
   *  RN 数据无此字段时保持 undefined,操作区不渲染消耗文案(降级,不伪造)。 */
  totalTokens?: number
  /** 对齐 Uniapp agent_content_list.isHaveSikao:回复是否含思考过程。
   *  仅 streamChat onReasoning 收到增量时置 true。 */
  isHaveSikao?: boolean
  /** 对齐 Uniapp agent_content_list.agent_content1:思考过程全文(流式累积)。 */
  thinkingContent?: string
  /** 对齐 Uniapp copyContent:复制按钮优先复制的内容,缺失时降级复制 content。 */
  copyContent?: string
  /** 工具调用可视化(W7):onToolCall 事件折叠后的消息级列表(对齐 web Message.toolCalls)。 */
  toolCalls?: ToolCallItem[]
  /** 计划步骤可视化(W7):onPlanUpdate 权威快照整体替换后的步骤列表(对齐 web Message.planSteps)。 */
  planSteps?: PlanStepItem[]
  /** 计划整体解释(W7):PlanUpdateEvent.explanation。 */
  planExplanation?: string
  /** 终端任务可视化(W7):onTerminalStart/onTerminalEnd 折叠后的列表(对齐 web Message.terminalTasks)。 */
  terminalTasks?: TerminalTaskItem[]
  /** D34 本轮上下文注入交代(第 45 轮):对齐 web message.injections。 */
  injections?: MessageInjection[]
  /** #11 引用溯源(第 51 轮):答案带了哪些知识来源,对齐 web message.citations。 */
  citations?: MessageCitation[]
  /** D106 Steer(中途引导):本轮被用户注入的引导交代,对齐 web steerNoticesByMessageId。
   *  执行期瞬时态不落库(web 同口径),故历史水合不还原。 */
  steerNotices?: SteerNotice[]
}

/**
 * 快捷问题兜底(对齐 Uniapp ai_assistant_n8n.vue suggestedQuestionsList):
 * 无消息时输入区上方横向 chip,点击直接发送。RN Agent 契约暂无 suggestedQuestions
 * 字段,使用与 miniapp-taro ai.suggestions 一致的通用兜底文案。
 */
const QUICK_SUGGESTION_KEYS: readonly string[] = [
  'profile.n8nSug1',
  'profile.n8nSug2',
  'profile.n8nSug3',
  'profile.n8nSug4',
]

// ── 图片 URL 提取(对齐 Uniapp processContent + isValidImageUrl)──

const IMAGE_EXT_RE = /\.(jpg|jpeg|png|gif|bmp|webp|svg)(\?.*)?$/i

function isValidImageUrl(url: string): boolean {
  if (!/^https?:\/\/.+/.test(url)) return false
  // noUncheckedIndexedAccess:数组下标访问需兜底
  const path = (url.split('#')[0] ?? '').split('?')[0] ?? ''
  return IMAGE_EXT_RE.test(path) || /volces\.com|fyshark\.com|tos-cn-beijing/i.test(url)
}

/** 从文本内容提取图片 URL(markdown ![](url) + 裸 URL,对齐 Uniapp processContent) */
function extractImageUrls(content: string): string[] {
  if (!content) return []
  const urls = new Set<string>()
  // 1. Markdown 图片:![alt](url)
  const mdRe = /!\[[^\]]*\]\((https?:\/\/[^\s)]+)\)/g
  let m: RegExpExecArray | null
  while ((m = mdRe.exec(content)) !== null) {
    const u = m[1]
    if (u && isValidImageUrl(u)) urls.add(u)
  }
  // 2. 裸 URL(带图片扩展名)
  const urlRe = /https?:\/\/[^\s)<>]+\.(?:jpg|jpeg|png|gif|bmp|webp|svg)(?:\?[^\s)]*)?/gi
  while ((m = urlRe.exec(content)) !== null) {
    const u = m[0]
    if (u && isValidImageUrl(u)) urls.add(u)
  }
  return Array.from(urls)
}

/** 消耗智汇值格式化(对齐 Uniapp total_tokens >= 1000 显示 K 值) */
function formatTotalTokens(totalTokens: number): string {
  return totalTokens >= 1000 ? `${(totalTokens / 1000).toFixed(1)}K` : String(totalTokens)
}

/** 从图片 URL 提取扩展名(保存相册时使用,对齐 Uniapp downloadImages 的本地文件命名) */
function imageExtFromUrl(url: string): string {
  const m = /\.(jpg|jpeg|png|gif|bmp|webp|svg)(?:\?|$)/i.exec(url)
  return m?.[1]?.toLowerCase() ?? 'jpg'
}

/** 把 API 返回的 ConversationDetail 映射为 DrawerConversationItem(对齐 ChatScreen) */
function mapConversationToDrawer(c: ConversationDetail, untitled: string): DrawerConversationItem {
  const tsStr = c.lastMessageAt ?? c.updatedAt ?? c.createdAt
  const createdAt = tsStr ? new Date(tsStr).getTime() : Date.now()
  const mdl = c.model ?? ''
  return {
    id: c.id,
    title: c.title?.trim() || untitled,
    modelConfig: mdl ? { id: mdl, name: mdl, icon: undefined } : undefined,
    createdAt,
    favorited: c.favorite === true,
  }
}

// ── W7:对话可视化原生渲染(工具调用 / 计划步骤 / 终端任务) ──
// 说明:路径 B(原生)补齐与路径 A(WebView 复用 web 全量能力)对等的能力。
// W6 计划抽出的共享「消息 → 可渲染模型」纯函数尚未落地,数据折叠逻辑见
// ../utils/chat-render-model(W7 独立实现);本区块只负责原生渲染。

/** 状态徽标语义四态(工具/计划/终端共用):pending=待开始 / active=进行中 / done=已完成 / failed=失败 */
type BadgeKind = 'pending' | 'active' | 'done' | 'failed'

/** 状态徽标(pending/active/done/failed 四态配色,工具调用/计划步骤/终端任务共用) */
function StatusBadge({ kind, label }: { kind: BadgeKind; label: string }): React.JSX.Element {
  const tone =
    kind === 'pending'
      ? { badge: bubbleStyles.badgePending, text: bubbleStyles.badgePendingText }
      : kind === 'active'
        ? { badge: bubbleStyles.badgeActive, text: bubbleStyles.badgeActiveText }
        : kind === 'done'
          ? { badge: bubbleStyles.badgeDone, text: bubbleStyles.badgeDoneText }
          : { badge: bubbleStyles.badgeFailed, text: bubbleStyles.badgeFailedText }
  return (
    <View style={[bubbleStyles.badge, tone.badge]}>
      <Text style={[bubbleStyles.badgeText, tone.text]}>{label}</Text>
    </View>
  )
}

/** 工具结果度量行:写类文件 "+18 -4";读/检索 "128 行" / "5 个结果" / "3 个文件";无度量 '' */
function formatToolMetricLine(
  view: ToolCallView,
  t: (key: string, params?: Record<string, string | number>) => string,
): string {
  if (view.writesFile) {
    if (view.added < 0 && view.removed < 0) return ''
    const plus = t('taskStatus.addedCount', { n: Math.max(0, view.added) })
    const minus = t('taskStatus.removedCount', { n: Math.max(0, view.removed) })
    return `${plus} ${minus}`
  }
  if (view.metricValue === null) return ''
  const unitKey =
    view.metricKind === 'lines'
      ? 'taskStatus.unitLines'
      : view.metricKind === 'files'
        ? 'taskStatus.unitFiles'
        : view.metricKind === 'results'
          ? 'taskStatus.unitResults'
          : ''
  if (!unitKey) return ''
  return t(unitKey, { n: view.metricValue })
}

/** 工具调用列表(W7):功能名 · 对象 · 度量 + 状态徽标 + 耗时;点击卡片行折叠查看参数/输出 */
function ToolCallList({ items }: { items: readonly ToolCallItem[] }): React.JSX.Element {
  const { t } = useI18n()
  const [openIds, setOpenIds] = useState<Record<string, boolean>>({})
  return (
    <View style={bubbleStyles.block}>
      <Text style={bubbleStyles.blockTitle}>{t('aiAssistantN8n.toolCalls')}</Text>
      {items.map((item) => {
        // 活动行语言:状态 · 功能名 · 对象 · 结果度量(单一真相源 describeToolCall,禁端内自行挖 args/result)
        const view = describeToolCall({
          toolName: item.name,
          args: item.args,
          result: item.result,
          status: item.status,
        })
        // D83 接线:MCP 调用先走共享层 server×tool 定制措辞(四形态各有其词),
        // 无定制命中即 null ⇒ 沿用下面的既有功能名口径,不吐码名也不吐键名。
        const displayName =
          mcpToolActivityTitle(item, t) ??
          (view.nameKey ? t(`taskStatus.${view.nameKey}`) : item.name)
        const metricLine = formatToolMetricLine(view, t)
        const showSubject = view.subject !== ''
        const statusLabel =
          item.status === 'running'
            ? t('aiAssistantN8n.toolStatusRunning')
            : item.status === 'success'
              ? t('aiAssistantN8n.toolStatusSuccess')
              : t('aiAssistantN8n.toolStatusError')
        const toneKind: BadgeKind =
          item.status === 'running' ? 'active' : item.status === 'success' ? 'done' : 'failed'
        const duration = formatDurationMs(item.durationMs)
        const argsText = formatStructured(item.args)
        const resultText = formatStructured(item.result)
        const expandable = Boolean(argsText) || Boolean(resultText)
        const open = expandable && openIds[item.id] === true
        return (
          <View key={item.id} style={bubbleStyles.card}>
            <Tappable
              style={bubbleStyles.cardHead}
              onPress={() => setOpenIds((prev) => ({ ...prev, [item.id]: !open }))}
              accessibilityRole="button"
              accessibilityLabel={[displayName, view.subject, statusLabel]
                .filter(Boolean)
                .join(' · ')}
            >
              {expandable ? (
                open ? (
                  <ChevronDown size={10} color={tokens.text.secondary} />
                ) : (
                  <ChevronRight size={10} color={tokens.text.secondary} />
                )
              ) : null}
              <Text style={bubbleStyles.cardTitle} numberOfLines={1}>
                {displayName}
              </Text>
              {showSubject ? (
                <Text style={bubbleStyles.cardSubject} numberOfLines={1}>
                  {view.subject}
                </Text>
              ) : null}
              {metricLine ? <Text style={bubbleStyles.cardMeta}>{metricLine}</Text> : null}
              <StatusBadge kind={toneKind} label={statusLabel} />
              {duration ? <Text style={bubbleStyles.cardMeta}>{duration}</Text> : null}
            </Tappable>
            {/* D113:流中 diff 预览 —— 仅 running 态且非空渲染(对齐 web tool-call-card
                status==='running' && partialDiff;不新增文案标签,只显示服务端下发内容,
                复用本端既有等宽样式 monoText) */}
            {item.status === 'running' && item.partialDiff ? (
              <View style={bubbleStyles.cardBody} testID="tool-call-partial-diff">
                <Text style={bubbleStyles.monoText}>{item.partialDiff}</Text>
              </View>
            ) : null}
            {open ? (
              <View style={bubbleStyles.cardBody}>
                {argsText ? (
                  <View>
                    <Text style={bubbleStyles.sectionLabel}>{t('aiAssistantN8n.toolArgs')}</Text>
                    <Text style={bubbleStyles.monoText}>{argsText}</Text>
                  </View>
                ) : null}
                {resultText ? (
                  <View style={argsText ? bubbleStyles.sectionGap : null}>
                    <Text style={bubbleStyles.sectionLabel}>{t('aiAssistantN8n.toolResult')}</Text>
                    <Text style={bubbleStyles.monoText}>{resultText}</Text>
                  </View>
                ) : null}
              </View>
            ) : null}
          </View>
        )
      })}
    </View>
  )
}

/** 计划步骤列表(W7):序号 + 步骤文本 + 状态徽标 + 耗时,顶部可选整体 explanation */
function PlanStepList({
  steps,
  explanation,
}: {
  steps: readonly PlanStepItem[]
  explanation?: string
}): React.JSX.Element {
  const { t } = useI18n()
  return (
    <View style={bubbleStyles.block}>
      <Text style={bubbleStyles.blockTitle}>{t('aiAssistantN8n.planSteps')}</Text>
      {explanation ? <Text style={bubbleStyles.blockHint}>{explanation}</Text> : null}
      {steps.map((step, index) => {
        const statusLabel =
          step.status === 'completed'
            ? t('aiAssistantN8n.planStatusCompleted')
            : step.status === 'in_progress'
              ? t('aiAssistantN8n.planStatusInProgress')
              : t('aiAssistantN8n.planStatusPending')
        const toneKind: BadgeKind =
          step.status === 'completed'
            ? 'done'
            : step.status === 'in_progress'
              ? 'active'
              : 'pending'
        const duration = formatDurationMs(step.durationMs)
        return (
          <View key={step.id} style={bubbleStyles.planRow}>
            <Text style={bubbleStyles.planIndex}>{index + 1}</Text>
            <Text style={bubbleStyles.planText}>
              {humanizeToolText(step.step, (key) => t(`taskStatus.${key}`))}
            </Text>
            <StatusBadge kind={toneKind} label={statusLabel} />
            {duration ? <Text style={bubbleStyles.cardMeta}>{duration}</Text> : null}
          </View>
        )
      })}
    </View>
  )
}

/**
 * D19 terminal_delta live 缓冲(2026-09-25 接,对齐 web store.terminalOutputs 口径)。
 * 命令执行期间后端逐块下发 terminal_delta(stdout/stderr 增量),本屏按 terminalId 累加成
 * live 缓冲;渲染端与整帧 terminal_end.output **取更长者**(terminalDisplayOutput)——
 * 后端整帧 output 截 8000 字符,构建日志尾部只存在于 live 缓冲里。
 * 刻意不写进消息正文(onDelta 的事),也不折进 task.output(applyTerminalEnd 会整体覆盖,
 * 折进去反而被短整帧吃掉)。RN 内存敏感:单键超限保**尾部**,键数超限先逐出最旧,
 * 两档上限与 web apps/web/src/stores/chat.ts(20000 字符/键、TERMINAL_OUTPUT_MAX_KEYS=20)同值。
 */
export const TERMINAL_LIVE_MAX_CHARS = 20000
export const TERMINAL_LIVE_MAX_KEYS = 20

/** 追加一帧某 terminalId 的增量(纯函数;超限保尾部)。 */
export function foldTerminalDelta(
  live: Record<string, string>,
  terminalId: string,
  text: string,
): Record<string, string> {
  const merged = live[terminalId] ?? ''
  const combined = merged + text
  const next: Record<string, string> = {
    ...live,
    [terminalId]:
      combined.length > TERMINAL_LIVE_MAX_CHARS
        ? combined.slice(-TERMINAL_LIVE_MAX_CHARS)
        : combined,
  }
  const keys = Object.keys(next)
  if (keys.length > TERMINAL_LIVE_MAX_KEYS) {
    // terminalId 为 SSE 下发的非数字串,Object.keys 插入序 = 首现序,逐出最旧键
    for (const stale of keys.slice(0, keys.length - TERMINAL_LIVE_MAX_KEYS)) delete next[stale]
  }
  return next
}

/** onTerminalDelta 回调的折叠步(导出供定向测试):空 terminalId / 空文本帧整帧丢弃,不触碰消息模型。 */
export function applyTerminalDeltaToLive(
  prev: Record<string, string>,
  event: Pick<TerminalDeltaEvent, 'terminalId' | 'text'>,
): Record<string, string> {
  if (!event.terminalId || !event.text) return prev
  return foldTerminalDelta(prev, event.terminalId, event.text)
}

/** 渲染取用口径(对齐 web terminal-section.tsx 的 effectiveOutput):live 更长用 live,否则用整帧 output。 */
export function terminalDisplayOutput(
  task: Pick<TerminalTaskItem, 'output'>,
  live: string | undefined,
): string | undefined {
  return live && live.length > (task.output?.length ?? 0) ? live : task.output
}

/**
 * D151(2026-09-29):terminal_interaction 在 RN 端的**降级形态**。
 *
 * 键 = terminalId,值恒 true —— 与上面的 terminalLive(live 缓冲)**并列**,不复用
 * `task.status`:running 说的是"在跑",waiting 说的是"停住等键盘输入",两者同时成立时
 * 界面唯一要交代的是后者(不交代就是空转,用户看到的仍是"卡住了")。
 *
 * 刻意**不做输入口**:键盘送不进 ai-service 那条进程在手机上没有可靠路径,给一个输入框
 * 属于假 affordance(web 端的上行通道 postTerminalInput 不复制到本端)。
 */
export type TerminalWaitingMap = Record<string, true>

/** 收到某 terminalId 的等待帧(空 terminalId 整帧丢弃、不触碰状态;重复帧幂等返回同一引用)。 */
export function applyTerminalInteraction(
  prev: TerminalWaitingMap,
  event: Pick<TerminalInteractionEvent, 'terminalId'>,
): TerminalWaitingMap {
  if (!event.terminalId || prev[event.terminalId] === true) return prev
  return { ...prev, [event.terminalId]: true }
}

/**
 * terminal_end 清掉该 terminalId 的等待态。
 * 没有这一步,"在等人"会永久挂在一条已经结束的卡上(与 terminalLive 的清理同理由)。
 */
export function clearTerminalWaitingFor(
  prev: TerminalWaitingMap,
  terminalId: string,
): TerminalWaitingMap {
  if (!(terminalId in prev)) return prev
  const next = { ...prev }
  delete next[terminalId]
  return next
}

/** 终端任务列表(W7 + D19 live 增量 + D151 等待输入降级态):命令 + 状态徽标 + 耗时;点击折叠查看等宽输出 + 退出码 */
export function TerminalTaskList({
  tasks,
  live,
  waiting,
}: {
  tasks: readonly TerminalTaskItem[]
  live?: Record<string, string>
  /** D151:terminalId → 该命令正等键盘输入;缺失即不渲染等待行(与改造前形态一致) */
  waiting?: TerminalWaitingMap
}): React.JSX.Element {
  const { t } = useI18n()
  const [openIds, setOpenIds] = useState<Record<string, boolean>>({})
  return (
    <View style={bubbleStyles.block}>
      <Text style={bubbleStyles.blockTitle}>{t('aiAssistantN8n.terminalTasks')}</Text>
      {/* 与 web/extension/小程序同一句执行环境交代(os_sandbox allow_network 默认 False) */}
      <Text style={bubbleStyles.blockHint} testID="terminal-isolation">
        {t('aiAssistantN8n.terminalIsolation')}
      </Text>
      {tasks.map((task) => {
        const statusLabel =
          task.status === 'completed'
            ? t('aiAssistantN8n.terminalStatusCompleted')
            : task.status === 'failed'
              ? t('aiAssistantN8n.terminalStatusFailed')
              : t('aiAssistantN8n.terminalStatusRunning')
        const toneKind: BadgeKind =
          task.status === 'completed' ? 'done' : task.status === 'failed' ? 'failed' : 'active'
        const duration = formatDurationMs(task.durationMs)
        // D19:live 缓冲与整帧 output 取更长者(web 同口径);运行中且有增量时默认展开成实时面板,
        // 用户手动折叠(openIds 记 false)仍被尊重;无增量帧时行为与改造前完全一致。
        const displayOutput = terminalDisplayOutput(task, live?.[task.id])
        const open = openIds[task.id] ?? (task.status === 'running' && displayOutput !== undefined)
        return (
          <View key={task.id} style={bubbleStyles.card}>
            <Tappable
              style={bubbleStyles.cardHead}
              onPress={() => setOpenIds((prev) => ({ ...prev, [task.id]: !open }))}
              accessibilityRole="button"
              accessibilityLabel={task.command}
            >
              {open ? (
                <ChevronDown size={10} color={tokens.text.secondary} />
              ) : (
                <ChevronRight size={10} color={tokens.text.secondary} />
              )}
              <Text style={bubbleStyles.terminalCommand} numberOfLines={1}>
                {task.command}
              </Text>
              <StatusBadge kind={toneKind} label={statusLabel} />
              {duration ? <Text style={bubbleStyles.cardMeta}>{duration}</Text> : null}
            </Tappable>
            {/* D151:命令停住等键盘输入时明写降级态(徽标一行 + 说明一行)。
                刻意放在折叠判定之外 —— "在等人"必须不展开也看得见,否则仍是空转。
                本端不渲染输入框(见 applyTerminalInteraction 头注),所以这里只有文案没有控件。 */}
            {waiting?.[task.id] === true ? (
              <View style={bubbleStyles.cardBody} testID="terminal-waiting-input">
                <StatusBadge kind="active" label={t('chat.terminal.waitingInput')} />
                <Text style={bubbleStyles.blockHint}>{t('chat.terminal.mobileUnsupported')}</Text>
              </View>
            ) : null}
            {open ? (
              <View style={bubbleStyles.cardBody}>
                {task.exitCode !== undefined ? (
                  <Text style={bubbleStyles.sectionLabel}>
                    {t('aiAssistantN8n.terminalExitCode')}: {task.exitCode}
                  </Text>
                ) : null}
                {displayOutput ? (
                  <View style={task.exitCode !== undefined ? bubbleStyles.sectionGap : null}>
                    <Text style={bubbleStyles.sectionLabel}>
                      {t('aiAssistantN8n.terminalOutput')}
                    </Text>
                    <Text style={bubbleStyles.monoText}>{displayOutput}</Text>
                    {/* 后端只下发截断文本:不交代总长就等于让用户把截断当完整 */}
                    {task.truncated ? (
                      <Text style={bubbleStyles.sectionLabel}>
                        {t('aiAssistantN8n.terminalTruncated', {
                          total: task.totalChars ?? displayOutput.length,
                        })}
                      </Text>
                    ) : null}
                  </View>
                ) : null}
              </View>
            ) : null}
          </View>
        )
      })}
    </View>
  )
}

interface MessageBubbleProps {
  message: N8nMessage
  onPreviewImage: (url: string) => void
  /** 浮层提示(复用屏幕 showToast,对齐 Uniapp uni.showToast) */
  onToast: (type: FloatBoxType, message: string) => void
  /** 失败轮重试:仅当该轮确实可重发时由父级传入;缺失即不渲染重试按钮 */
  onRetry?: () => void
  /** 会话级分叉:仅当"会话已落库 ∧ 该消息已落库"时由父级传入(同一判据 `isBranchableTarget`
   *  在渲染期与点击期共用);缺失即不渲染按钮,免得出现"渲染出来了、点下去没反应"。 */
  onBranch?: () => void
  /** D19 terminal_delta 的 live 缓冲(键 = terminalId);缺失即面板退化为改造前形态 */
  terminalLive?: Record<string, string>
  /** D151 等待键盘输入的 terminalId 集合(键 = terminalId);缺失即不渲染等待行 */
  terminalWaiting?: TerminalWaitingMap
}

function MessageBubble({
  message,
  onPreviewImage,
  onToast,
  onRetry,
  onBranch,
  terminalLive,
  terminalWaiting,
}: MessageBubbleProps): React.JSX.Element {
  const { t } = useI18n()
  const isUser = message.role === 'user'
  const hasImages = !isUser && (message.images?.length ?? 0) > 0
  // 失败轮:渲染错误卡片而非正文(与 web D22 / ChatScreen 同一形态)
  const isFailed = !isUser && isErrorTurn(message)
  // 显示/隐藏回答(对齐 Uniapp answerVisibilityStates,默认可见)
  const [answerVisible, setAnswerVisible] = useState(true)
  // 思考过程展开/收起(对齐 Uniapp agent_con1)
  const [sikaoOpen, setSikaoOpen] = useState(false)
  // 图片下载中(防重复点击,对齐 Uniapp uni.showLoading)
  const [downloading, setDownloading] = useState(false)

  // 复制回答(对齐 Uniapp copyHandle:copyContent 优先,缺失降级 content)
  const handleCopy = (): void => {
    const text = message.copyContent ?? message.content
    if (!text) return
    try {
      Clipboard.setString(text)
      onToast('success', t('profile.n8nCopyOk'))
    } catch {
      onToast('error', t('profile.n8nCopyFail'))
    }
  }

  // 下载图片(对齐 Uniapp downloadImages:下载第一张图片保存到相册)
  const handleDownloadImages = async (): Promise<void> => {
    if (downloading) return
    const url = message.images?.[0]
    if (!url) return
    setDownloading(true)
    try {
      const perm = await MediaLibrary.requestPermissionsAsync()
      if (!perm.granted) {
        onToast('warning', t('home.albumPermRequired'))
        return
      }
      const filename = `ai_image_${Date.now()}.${imageExtFromUrl(url)}`
      const destFile = new FileSystem.File(FileSystem.Paths.cache, filename)
      const downloaded = await FileSystem.File.downloadFileAsync(url, destFile, {
        idempotent: true,
      })
      await MediaLibrary.saveToLibraryAsync(downloaded.uri)
      onToast('success', t('home.imgSavedAlbum'))
    } catch {
      onToast('error', t('profile.downloadFailRetry'))
    } finally {
      setDownloading(false)
    }
  }

  // 分享回答(对齐 Uniapp share + onShareAppMessage,RN 用 Share API 分享 content)
  const handleShare = (): void => {
    if (!message.content) return
    void Share.share({ message: message.content }).catch(() =>
      onToast('error', t('profile.n8nShareFail')),
    )
  }

  const hasTokens = message.totalTokens !== undefined
  const tokensText =
    message.totalTokens !== undefined ? formatTotalTokens(message.totalTokens) : undefined

  return (
    <View style={[bubbleStyles.row, isUser ? bubbleStyles.rowUser : bubbleStyles.rowAi]}>
      {isUser ? (
        <View style={[bubbleStyles.bubble, bubbleStyles.bubbleUser]}>
          {message.content ? (
            <Text style={[bubbleStyles.text, bubbleStyles.textUser]}>{message.content}</Text>
          ) : null}
        </View>
      ) : (
        <View style={bubbleStyles.msgCol}>
          <View style={[bubbleStyles.bubble, bubbleStyles.bubbleAi]}>
            {isFailed ? (
              <View style={bubbleStyles.errorCard}>
                <View style={bubbleStyles.errorHeader}>
                  <AlertTriangle size={14} color={tokens.error.text} />
                  <Text style={bubbleStyles.errorTitle}>{t('chatAlert.errorTitle')}</Text>
                </View>
                <Text style={bubbleStyles.errorBody} selectable>
                  {message.content}
                </Text>
                {onRetry ? (
                  <TouchableOpacity
                    style={bubbleStyles.errorRetry}
                    hitSlop={8}
                    onPress={onRetry}
                    accessibilityRole="button"
                    accessibilityLabel={t('chatAlert.errorRetry')}
                  >
                    <RefreshCw size={14} color={tokens.error.text} />
                    <Text style={bubbleStyles.errorRetryText}>{t('chatAlert.errorRetry')}</Text>
                  </TouchableOpacity>
                ) : null}
              </View>
            ) : answerVisible && message.content ? (
              <Text style={[bubbleStyles.text, bubbleStyles.textAi]}>{message.content}</Text>
            ) : null}
            {answerVisible && hasImages ? (
              <View style={bubbleStyles.imageGrid}>
                {message.images!.map((url, i) => (
                  <TouchableOpacity
                    key={`${url}-${i}`}
                    activeOpacity={0.85}
                    onPress={() => onPreviewImage(url)}
                    accessibilityRole="imagebutton"
                    accessibilityLabel={t('chat.imagePreviewA11y')}
                    accessibilityHint={t('chat.imageOpen')}
                  >
                    <Image
                      source={{ uri: url }}
                      style={bubbleStyles.chatImage}
                      resizeMode="cover"
                    />
                  </TouchableOpacity>
                ))}
              </View>
            ) : null}
          </View>
          {/* 工具调用可视化(W7:原生卡片,点击折叠查看参数/输出) */}
          {answerVisible && message.toolCalls && message.toolCalls.length > 0 ? (
            <ToolCallList items={message.toolCalls} />
          ) : null}
          {/* 计划步骤可视化(W7:步骤 + 状态徽标 + 可选 explanation) */}
          {answerVisible && message.planSteps && message.planSteps.length > 0 ? (
            <PlanStepList steps={message.planSteps} explanation={message.planExplanation} />
          ) : null}
          {/* 终端任务可视化(W7 + D19:命令 + 等宽输出 + 退出码;运行中 live 增量与整帧取更长者) */}
          {answerVisible && message.terminalTasks && message.terminalTasks.length > 0 ? (
            <TerminalTaskList
              tasks={message.terminalTasks}
              live={terminalLive}
              waiting={terminalWaiting}
            />
          ) : null}
          {/* D34 本轮上下文注入交代(第 45 轮补齐该端,此前该帧在本端 0 命中) */}
          {answerVisible && message.injections && message.injections.length > 0 ? (
            <InjectionDisclosure items={message.injections} />
          ) : null}
          {answerVisible && message.citations && message.citations.length > 0 ? (
            <CitationList items={message.citations} />
          ) : null}
          {/* D106 Steer(中途引导)交代:本轮被注入了哪些引导文本 */}
          {answerVisible && message.steerNotices && message.steerNotices.length > 0 ? (
            <SteerNoticeList items={message.steerNotices} />
          ) : null}
          {/* 思考过程展开区(仅 isHaveSikao 时显示按钮,展开后渲染思考内容) */}
          {sikaoOpen && message.thinkingContent ? (
            <View style={bubbleStyles.thinkingBox}>
              <Text style={bubbleStyles.thinkingText}>{message.thinkingContent}</Text>
            </View>
          ) : null}
          {/* 操作按钮行(对齐 Uniapp action-buttons:左消耗文案 + 右按钮组) */}
          <View style={[bubbleStyles.actionRow, hasTokens ? null : bubbleStyles.actionRowNoLabel]}>
            {answerVisible && tokensText ? (
              <Text style={bubbleStyles.tokensText} numberOfLines={1}>
                {t('profile.n8nGenBadge')}
                {tokensText}
              </Text>
            ) : null}
            <View style={bubbleStyles.actionBtns}>
              {/* 显示/隐藏回答(对齐 Uniapp toggleAnswerVisibility:可见时显示"隐藏"图标) */}
              <TouchableOpacity
                style={bubbleStyles.actionBtn}
                hitSlop={6}
                onPress={() => setAnswerVisible((v) => !v)}
                accessibilityRole="button"
                accessibilityLabel={
                  answerVisible ? t('profile.n8nHideAnswer') : t('profile.n8nShowAnswer')
                }
              >
                {answerVisible ? (
                  <EyeOff size={16} color={tokens.text.secondary} />
                ) : (
                  <Eye size={16} color={tokens.text.secondary} />
                )}
              </TouchableOpacity>
              {/* 思考过程展开/收起(仅 isHaveSikao 时显示,对齐 Uniapp toggleAgentCon1) */}
              {message.isHaveSikao ? (
                <TouchableOpacity
                  style={bubbleStyles.actionBtn}
                  hitSlop={6}
                  onPress={() => setSikaoOpen((v) => !v)}
                  accessibilityRole="button"
                  accessibilityLabel={t('profile.n8nThinking')}
                >
                  <Brain
                    size={16}
                    color={sikaoOpen ? tokens.brand.DEFAULT : tokens.text.secondary}
                  />
                </TouchableOpacity>
              ) : null}
              {/* 复制回答(对齐 Uniapp copyHandle) */}
              <TouchableOpacity
                style={bubbleStyles.actionBtn}
                hitSlop={6}
                onPress={handleCopy}
                accessibilityRole="button"
                accessibilityLabel={t('profile.n8nCopyAnswer')}
              >
                <Copy size={16} color={tokens.text.secondary} />
              </TouchableOpacity>
              {/* 从该消息分叉出新会话(仅已落库消息;源会话原样保留,由后端事务保证) */}
              {onBranch ? (
                <TouchableOpacity
                  style={bubbleStyles.actionBtn}
                  hitSlop={6}
                  onPress={onBranch}
                  accessibilityRole="button"
                  accessibilityLabel={t('ai.pane.branch.ariaLabel')}
                >
                  <GitBranchPlus size={16} color={tokens.text.secondary} />
                </TouchableOpacity>
              ) : null}
              {/* 下载图片(仅消息含图片时显示,对齐 Uniapp downloadImages) */}
              {hasImages ? (
                <TouchableOpacity
                  style={bubbleStyles.actionBtn}
                  hitSlop={6}
                  onPress={() => void handleDownloadImages()}
                  disabled={downloading}
                  accessibilityRole="button"
                  accessibilityLabel={t('profile.n8nDownloadImg')}
                >
                  <Download size={16} color={tokens.text.secondary} />
                </TouchableOpacity>
              ) : null}
              {/* 分享(对齐 Uniapp share,RN 用 Share API 分享 content)
                  失败轮不给分享(它不是内容);复制保留 —— 报错排查要用那段文字 */}
              {isFailed ? null : (
                <TouchableOpacity
                  style={bubbleStyles.actionBtn}
                  hitSlop={6}
                  onPress={handleShare}
                  accessibilityRole="button"
                  accessibilityLabel={t('profile.shareBtn')}
                >
                  <Share2 size={16} color={tokens.text.secondary} />
                </TouchableOpacity>
              )}
            </View>
          </View>
        </View>
      )}
    </View>
  )
}

export default function AiAssistantN8nScreen() {
  const { t } = useI18n()
  const { user: authUser } = useAuth()
  const navigation = useNavigation<NavigationProp>()
  const rootNav = navigation.getParent<RootNav>()
  const route = useRoute<N8nRouteProp>()
  const agentId = route.params?.agentId
  // 路由 title 参数优先(对齐 Uniapp page_title:matchedAgent.agentName / modelNamea)
  const navTitle = route.params?.title ?? route.params?.modelName ?? t('aiAssistantN8n.title')
  const routeConversationId = route.params?.conversationId

  const listRef = useRef<FlatList<N8nMessage> | null>(null)
  // 滚动淡出溢出判定(本屏消息 FlatList 由本端创建,直接走标准 onScroll 接线)
  const fades = useChatScrollFades()
  const abortRef = useRef<AbortController | null>(null)
  const idCounter = useRef(0)
  const nextId = (): string => `n8n-${++idCounter.current}`

  const [messages, setMessages] = useState<N8nMessage[]>([])
  // D19:terminal_delta 的 live 缓冲(键 = terminalId,值 = 累计增量,超限保尾部)。
  // 只由 onTerminalDelta 写入、终端面板按"与整帧 output 取更长者"读取 ——
  // 与消息正文(onDelta 通道)完全分离,不落 content。
  const [terminalLive, setTerminalLive] = useState<Record<string, string>>({})
  // D151:terminal_interaction 的等待态(键 = terminalId)。与 terminalLive 并列,同为"终端卡的
  // 另一维",不另立第二套终端状态源;onTerminalEnd 逐键清、新一轮发送/切会话整体清。
  const [terminalWaiting, setTerminalWaiting] = useState<TerminalWaitingMap>({})
  const [input, setInput] = useState('')
  const [sending, setSending] = useState(false)

  // ── 输入区「+」添加面板(统一 AddPanel:相机/相册/本地文件/微信文件;
  //    上传链路与 HomeScreen/ChatScreen 同源:选择 → uploadFileMultipart → 拼入 prompt) ──
  const [addPanelVisible, setAddPanelVisible] = useState(false)
  const [addUploading, setAddUploading] = useState(false)
  const handleAddPanelToggle = (): void => {
    if (!addPanelVisible) Keyboard.dismiss()
    setAddPanelVisible(!addPanelVisible)
  }
  /** 相机(对齐 ChatScreen handleIconClick('camera'):相机拍摄待接入,占位提示) */
  const handleAddCamera = (): void => {
    setAddPanelVisible(false)
    showToast('warning', t('home.camSoonHint'))
  }
  /** 相册选图 → 上传 → 拼入输入框 */
  const handleAddAlbum = async (): Promise<void> => {
    setAddPanelVisible(false)
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsMultipleSelection: false,
        quality: 0.8,
      })
      if (result.canceled) return
      const asset = result.assets?.[0]
      if (!asset?.uri) return
      setAddUploading(true)
      const up = await uploadFileMultipart({
        uri: asset.uri,
        type: asset.mimeType ?? 'image/jpeg',
        name: asset.fileName ?? `image-${Date.now()}.jpg`,
      })
      if (up.success && up.data?.path) {
        setInput((p) => `${p ? `${p}\n` : ''}[图片] ${resolveFileUrl(up.data!.path)}`)
        showToast('success', t('home.imgUploadedHint'))
      } else {
        showToast('warning', t('home.imgUploadFailed'))
      }
    } catch {
      showToast('warning', t('home.imgPickRetry'))
    } finally {
      setAddUploading(false)
    }
  }
  /** 本地文件 / 微信文件选择 → 上传 → 拼入输入框(对齐 ChatScreen handleFileUpload:
   *  wxfile 与 file 走同一 DocumentPicker 链路) */
  const handleAddFile = async (): Promise<void> => {
    setAddPanelVisible(false)
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: [
          'application/pdf',
          'application/msword',
          'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
          'application/vnd.ms-excel',
          'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
          'text/plain',
        ],
        copyToCacheDirectory: true,
        multiple: false,
      })
      if (result.canceled || result.assets.length === 0) return
      const asset = result.assets[0]!
      setAddUploading(true)
      const up = await uploadFileMultipart({
        uri: asset.uri,
        type: asset.mimeType ?? 'application/octet-stream',
        name: asset.name ?? `file-${Date.now()}`,
      })
      if (up.success && up.data?.path) {
        const fileName = asset.name ?? t('home.fallbackFileName')
        setInput((p) => `${p ? `${p}\n` : ''}[文件] ${fileName} ${resolveFileUrl(up.data!.path)}`)
        showToast('success', t('home.uploadedNameToast', { name: fileName }))
      } else {
        showToast('warning', t('home.fileUploadFailed'))
      }
    } catch {
      showToast('warning', t('home.filePickRetry'))
    } finally {
      setAddUploading(false)
    }
  }
  // 当前对话 ID(从路由传入或后续选择历史对话时更新,用于 streamChat metadata)
  const [currentConversationId, setCurrentConversationId] = useState<string | undefined>(
    routeConversationId,
  )

  /**
   * 会话切换的**取证**装置(2026-09-25 立,配合分叉)。
   *
   * 为什么不能只看"switch 那一步没抛错":`setCurrentConversationId` 是异步生效的,
   * 而且组件已卸载时它干脆不动 —— 拿"没抛错"当"已切换",判据层就会在界面还停在源会话时
   * 提示"已分叉出新会话",用户看到的是假成功。所以:
   * ① `currentConversationIdRef` 由 `switchConversationTo` **同步**写,读回它才是"界面现在
   *    落在哪个会话"的证据;② `mountedRef` 兜住卸载后的空切换。
   */
  const currentConversationIdRef = useRef<string | undefined>(routeConversationId)
  const mountedRef = useRef(true)
  useEffect(() => {
    mountedRef.current = true
    return () => {
      mountedRef.current = false
    }
  }, [])
  /** 换会话的唯一入口:先同步写 ref(取证),再驱动 state 重渲染。两者不得只做一个。 */
  const switchConversationTo = useCallback((id: string | undefined): void => {
    currentConversationIdRef.current = id
    setCurrentConversationId(id)
  }, [])

  // 剩余智汇值(对齐 Uniapp 顶部 intelligent-assistant tokenQuantity,接 getTokenBalance 真实余额)
  const [tokenBalance, setTokenBalance] = useState(0)

  // D111:工作区权限档(null = 尚未取到/取数失败 → 整行隐藏,不假装知道档位)。
  // 此前移动端对"当前处于哪一档、该档会导致什么"零可见,而本端对话能让 AI 改文件/跑命令。
  const [workspaceTier, setWorkspaceTier] = useState<string | null>(null)
  // G-165①:消息级盖章档位(服务端从 workspace_permissions 反查后写入消息 metadata,
  // 不采信客户端自报)。undefined = 尚未见到已盖章消息;null = 明确无;string = 盖章值。
  const [stampedTier, setStampedTier] = useState<string | null | undefined>(undefined)

  // 加载智汇值余额:失败静默保持 0(不阻塞页面,充值入口仍可用)
  useEffect(() => {
    let cancelled = false
    void (async () => {
      try {
        const res = await getTokenBalance()
        if (!cancelled && res.success) {
          setTokenBalance(res.data.balance)
        }
      } catch {
        // 失败保持 0
      }
    })()
    return () => {
      cancelled = true
    }
  }, [])

  // D111:首屏交代当前权限档(档名 + 后果)。取词走共享 permissionTierWordKeys(unknown 兜底)。
  useEffect(() => {
    let cancelled = false
    getWorkspacePermissionDefault()
      .then((res) => {
        if (!cancelled && res.success && res.data) setWorkspaceTier(res.data.mode)
      })
      .catch(() => {
        // 取数失败:保持 null,该行隐藏
      })
    return () => {
      cancelled = true
    }
  }, [])

  // 模型选择器(对齐 Uniapp modelList + pitch + pitchHandle)
  // 路由参数 modelId 优先初始化(对齐 Uniapp onLoad options.modelNamea)
  // 2026-10-26 stepfun 永久退役 ⇒ 末位兜底不再写死已退役档(改用共享兜底链首档)。
  const [selectedModelId, setSelectedModelId] = useState<string>(
    route.params?.modelId ?? FALLBACK_MODELS[0]?.value ?? 'agnes/agnes-2.5-flash',
  )
  // 2026-08-27 修复:模型选择列表只展示后端 /llm/models 过滤后的可用模型
  // (可用性+配额由后端保证);null=加载中/失败 → 降级 FALLBACK_MODELS(真实可用主力)
  const [modelList, setModelList] = useState<LlmModel[] | null>(null)
  const [showModelPicker, setShowModelPicker] = useState(false)

  // 模型列表加载(后端 /llm/models 已按可用性+配额过滤,与 ChatScreen 同源)
  // 2026-11-10:并发拉个人号池模型并追加 —— 号池 id 原样可被后端反查
  // (`<平台>/<上游模型名>` 或平台登记行),选中即可用;号池接口失败返回 [] 不拖垮主列表。
  useEffect(() => {
    let cancelled = false
    Promise.all([fetchModels().catch(() => null), fetchPoolChatModels()])
      .then(([res, pool]) => {
        if (cancelled) return
        const base = res?.models ?? []
        const seen = new Set(base.map((m) => m.id))
        const extra: LlmModel[] = pool
          .filter((p) => !seen.has(p.id))
          .map((p) => ({
            id: p.id,
            name: p.name,
            provider: p.provider,
            context_length: 0,
            input_price: 0,
            // 2026-11-20 立:号池模型带代次字段(ai-service 模型目录判据下发),
            // 让 ModelPickerList 能把旧代号池模型折叠进「历史模型」;
            // 判不了时缺省 ⇒ 共享层兜底 latest+chat,不误藏。
            ...(p.category ? { category: normalizeCategory(p.category) } : {}),
            ...(p.modelTier ? { model_tier: normalizeTier(p.modelTier) } : {}),
          }))
        const merged = [...base, ...extra]
        if (merged.length) setModelList(merged)
      })
      .catch(() => {
        // 静默:保持 null,展示 FALLBACK_MODELS 降级
      })
    return () => {
      cancelled = true
    }
  }, [])

  // 模型配置弹层(对齐 Uniapp ModelConfigDialog:模型选择旁"配置"入口,
  // 温度/top_p/maxTokens 等参数设置,发送时透传给 streamChat)
  const [modelConfigVisible, setModelConfigVisible] = useState(false)
  const [modelConfig, setModelConfig] = useState<ModelConfig>({
    temperature: 0.7,
    maxTokens: 2048,
    topP: 0.9,
    systemPrompt: '',
    streamEnabled: true,
  })

  // 图片预览(对齐 Uniapp previewImage)
  const [previewImage, setPreviewImage] = useState<string | null>(null)

  // FloatBox 浮层提示状态(替代单按钮 Alert.alert 的非阻塞反馈,对齐 ChatScreen showToast 模式)
  const [toastVisible, setToastVisible] = useState(false)
  const [toastType, setToastType] = useState<FloatBoxType>('info')
  const [toastMessage, setToastMessage] = useState('')
  const showToast = useCallback((type: FloatBoxType, message: string): void => {
    setToastType(type)
    setToastMessage(message)
    setToastVisible(true)
  }, [])
  const hideToast = useCallback((): void => setToastVisible(false), [])

  // Drawer 历史对话(对齐任务要求"Drawer 集成:历史对话入口")
  const [drawerVisible, setDrawerVisible] = useState(false)
  const [drawerConversations, setDrawerConversations] = useState<DrawerConversationItem[]>([])
  const [drawerConversationsLoaded, setDrawerConversationsLoaded] = useState(false)

  // 模型选择器条目:优先后端过滤模型(fetchModels),失败/加载中降级 FALLBACK_MODELS。
  // category / modelTier 原样透传给 ModelPickerList 做「默认列表 / 历史模型折叠区」分区;
  // 降级模型没有这两个字段,由共享层兜底为 latest+chat,保证降级态不会被藏起来。
  const modelListItems: ModelListItem[] = useMemo(() => {
    if (modelList && modelList.length > 0) {
      return modelList.map((m) => ({
        id: m.id,
        name: m.name || m.id,
        description: m.provider,
        icon: Bot,
        // 免费模型标记:zero_cost provider 前缀(与后端 free_provider_registry 对齐)
        isFree: /^@cf\/|^pollinations\/|^llm7\//.test(m.id),
        category: m.category,
        modelTier: m.model_tier,
      }))
    }
    return FALLBACK_MODELS.map((m) => ({
      id: m.value,
      name: m.label,
      description: m.vendor,
      icon: Bot,
      isFree: (m.pointsMultiplier ?? 1) === 0,
    }))
  }, [modelList])

  // 弹层高度唯一源:sheet 拿到确定 height/maxHeight 后,内部列表用 flex:1 撑满剩余空间,
  // 不再另写一份「给头部留余量」的比例(见 lib/dialog-geometry.ts)。
  const { height: windowHeight } = useWindowDimensions()
  const dialogHeightStyle = useMemo(() => dialogContentHeightStyle(windowHeight), [windowHeight])

  const selectedModelLabel = useMemo(() => {
    const m = modelListItems.find((item) => item.id === selectedModelId)
    return m?.name ?? selectedModelId
  }, [modelListItems, selectedModelId])

  const previewSource: ImageSourcePropType | null = previewImage ? { uri: previewImage } : null

  // D64② 传输动作半格(宿主注入):保存相册 / 复制图片到剪贴板。
  // 平台特有:落相册依赖 expo-media-library 权限、写图剪贴板依赖原生实现 ⇒ 动作归宿主;
  // 成败**文案**判据在 element-pack(imageTransferView),本函数只如实回报成败,失败不静默吞。
  const handlePreviewTransfer = async (kind: ImageTransferKind): Promise<ImageTransferResult> => {
    const url = previewImage
    if (!url) return 'failed'
    try {
      const ext = imageExtFromUrl(url)
      const dest = new FileSystem.File(FileSystem.Paths.cache, `preview_${Date.now()}.${ext}`)
      const local = await FileSystem.File.downloadFileAsync(url, dest, { idempotent: true })
      if (kind === 'save') {
        const perm = await MediaLibrary.requestPermissionsAsync()
        if (!perm.granted) return 'failed'
        await MediaLibrary.saveToLibraryAsync(local.uri)
        return 'success'
      }
      const base64 = await local.base64()
      Clipboard.setImage(`data:image/${ext === 'jpg' ? 'jpeg' : ext};base64,${base64}`)
      return 'success'
    } catch {
      return 'failed'
    }
  }

  // 任务进度状态条数据源(对齐 web task-status-bar):plan_updated 权威快照写在
  // "那一条 assistant 消息"上,取最后一条带 planSteps 的 assistant 消息(倒序扫描)。
  const planMessage = useMemo(() => {
    for (let i = messages.length - 1; i >= 0; i--) {
      const message = messages[i]
      if (message?.role === 'assistant' && (message.planSteps?.length ?? 0) > 0) return message
    }
    return null
  }, [messages])

  const scrollToEnd = (): void => {
    requestAnimationFrame(() => {
      listRef.current?.scrollToEnd({ animated: true })
    })
  }

  // ── Drawer 历史对话加载(懒加载,首次打开 Drawer 时拉取) ──
  const loadDrawerConversations = useCallback(async (): Promise<void> => {
    const res = await listConversations({ page: 1, pageSize: 50 })
    if (res.success) {
      setDrawerConversations(
        res.data.conversations.map((c) => mapConversationToDrawer(c, t('chat.untitledChat'))),
      )
    } else {
      setDrawerConversations([])
    }
    setDrawerConversationsLoaded(true)
  }, [t])

  useEffect(() => {
    if (drawerVisible && !drawerConversationsLoaded && authUser) {
      void loadDrawerConversations()
    }
  }, [drawerVisible, drawerConversationsLoaded, authUser, loadDrawerConversations])

  // ── 加载历史对话消息(对齐 ChatScreen loadConversationMessages) ──
  // 返回 res.success:调用方(分叉后的 openConversation)要用它区分"切过去了但内容没读回来"。
  // 吞掉这个布尔值就等于把两种故障合并成同一条文案,用户按它去重试会找错方向。
  const loadConversationMessages = useCallback(async (id: string): Promise<boolean> => {
    const res = await getMessages(id, { direction: 'initial', pageSize: 100 })
    if (res.success) {
      // G-165①:档位行数据源换挡 —— 取最近一条已盖章助手消息的 metadata.permissionMode
      // (服务端从 workspace_permissions 反查盖章,不采信客户端自报)。盖章服务对
      // "不知道"不写 key,所以这里只有 string 才算数,绝不编造 default。
      const stampedMeta = [...res.data.messages]
        .reverse()
        .find(
          (m) =>
            m.role === 'assistant' &&
            typeof (m.metadata as { permissionMode?: unknown } | null)?.permissionMode === 'string',
        )
      if (stampedMeta) {
        setStampedTier((stampedMeta.metadata as { permissionMode: string }).permissionMode)
      }
      // 历史消息回放:后端把工具调用 / plan 步骤持久化在消息 metadata(D24,toolCalls 已落库;
      // planSteps 随 #15 持久化上线后自动生效)。映射回端内 N8nMessage.toolCalls / planSteps,
      // 使历史会话与实时流走同一活动行渲染口径(状态 · 功能名 · 对象 · 度量)。
      const loaded: N8nMessage[] = res.data.messages
        .filter((m) => m.role === 'user' || m.role === 'assistant')
        .map((m, idx) => {
          const meta = m.metadata as {
            toolCalls?: unknown
            planSteps?: unknown
            citations?: unknown
            injections?: unknown
            steerApplied?: unknown
          } | null
          const planSteps = Array.isArray(meta?.planSteps)
            ? (meta?.planSteps as Array<Record<string, unknown>>).flatMap((s, i) =>
                typeof s?.step === 'string'
                  ? [
                      {
                        id: typeof s.id === 'string' ? s.id : `plan-${idx}-${i}`,
                        step: s.step,
                        status: (s.status as PlanStepItem['status']) ?? 'pending',
                        ...(typeof s.durationMs === 'number' ? { durationMs: s.durationMs } : {}),
                        ...(typeof s.tokenUsage === 'number' ? { tokenUsage: s.tokenUsage } : {}),
                      },
                    ]
                  : [],
              )
            : undefined
          const toolCalls = Array.isArray(meta?.toolCalls)
            ? (meta?.toolCalls as Array<Record<string, unknown>>).flatMap((c) =>
                typeof c?.id === 'string' && typeof c.toolName === 'string'
                  ? [
                      {
                        id: c.id,
                        name: c.toolName,
                        status:
                          c.status === 'error' || c.error
                            ? ('error' as const)
                            : c.status === 'success'
                              ? ('success' as const)
                              : ('running' as const),
                        ...(c.args && typeof c.args === 'object'
                          ? { args: c.args as Record<string, unknown> }
                          : {}),
                        ...(c.result !== undefined ? { result: c.result } : {}),
                        ...(typeof c.durationMs === 'number' ? { durationMs: c.durationMs } : {}),
                      },
                    ]
                  : [],
              )
            : undefined
          // G-166:交代帧同样从 metadata 读回 —— 服务端已把"引用了哪些来源 / 本轮带了哪些
          // 上下文"随回调落库(与 SSE 帧同一真相源),此前重进历史会话这两段交代整段看不见。
          // 逐条类型守卫:脏条目单条丢弃,缺 url 不造"点不动的假链接"。
          const citations = Array.isArray(meta?.citations)
            ? (meta?.citations as Array<Record<string, unknown>>).flatMap((c) =>
                typeof c?.source === 'string' && typeof c.label === 'string'
                  ? [
                      {
                        source: c.source,
                        label: c.label,
                        ...(typeof c.url === 'string' && c.url ? { url: c.url } : {}),
                      },
                    ]
                  : [],
              )
            : undefined
          const injections = Array.isArray(meta?.injections)
            ? (meta?.injections as Array<Record<string, unknown>>).flatMap((x) =>
                typeof x?.kind === 'string' && typeof x.collapsed === 'string'
                  ? [
                      {
                        kind: x.kind,
                        collapsed: x.collapsed,
                        ...(typeof x.fullText === 'string' ? { fullText: x.fullText } : {}),
                        ...(typeof x.count === 'number' ? { count: x.count } : {}),
                      },
                    ]
                  : [],
              )
            : undefined
          // D106 收尾:steer 交代历史读回 —— api 侧已把 onSteer 载荷落库
          // metadata.steerApplied([{text, timestamp?}]),与 live 通道同源。守卫
          // (text 非空字符串、timestamp 仅 string、8 条封顶)收敛在纯函数里,
          // 无 steer / 全坏 → undefined,不给 SteerNoticeList 造空态。
          const steerNotices = readSteerAppliedFromMetadata(meta?.steerApplied)
          return {
            id: `${m.id}-${idx}`,
            serverId: m.id,
            role: m.role as 'user' | 'assistant',
            content: m.content,
            ...(planSteps && planSteps.length > 0 ? { planSteps } : {}),
            ...(toolCalls && toolCalls.length > 0 ? { toolCalls } : {}),
            ...(citations && citations.length > 0 ? { citations } : {}),
            ...(injections && injections.length > 0 ? { injections } : {}),
            ...(steerNotices && steerNotices.length > 0 ? { steerNotices } : {}),
          }
        })
      setMessages(loaded)
      // D151:切会话/回放历史同样要清等待态(历史里没有"正在等输入"的进程)
      setTerminalWaiting({})
      requestAnimationFrame(() => {
        listRef.current?.scrollToEnd({ animated: true })
      })
      return true
    }
    // 读回失败也要出声:把它折成 false,调用方才能区分"切过去了但内容没读回来"
    return false
  }, [])

  // 从路由 conversationId 加载历史对话(对齐 Uniapp onLoad 有 agentId 时拉取历史)
  useEffect(() => {
    if (routeConversationId) {
      void loadConversationMessages(routeConversationId)
    }
  }, [routeConversationId, loadConversationMessages])

  /**
   * 分叉成功后的"切到新会话"—— 两条自报值各自取证,不得互相顶替:
   * `switched` 看切换前后 ref(前值必须不同、后值必须等于新 id)**且**组件仍挂载;
   * `loaded` 看 `loadConversationMessages` 返回的 `res.success`。
   * 判据层据此把"会话建好了但界面没切过去"与"切过去了但内容没读回来"分成两句说。
   */
  const openConversationForBranch = useCallback(
    async (newId: string): Promise<OpenConversationResult> => {
      const previousId = currentConversationIdRef.current
      switchConversationTo(newId)
      const switched = mountedRef.current && previousId !== newId
      if (!switched) return { switched: false, loaded: false }
      const loaded = await loadConversationMessages(newId)
      // 加载期间可能已被卸载(用户退屏),此时读回成功也不等于界面还在新会话上
      if (!mountedRef.current || currentConversationIdRef.current !== newId) {
        return { switched: false, loaded: false }
      }
      return { switched: true, loaded }
    },
    [loadConversationMessages, switchConversationTo],
  )

  /** 消息气泡上的分叉入口:判据与提示全在 `src/utils/branch-conversation`,本屏只注入边界。 */
  const handleBranchFromMessage = useCallback(
    (message: N8nMessage): void => {
      void branchConversationFromMessage(
        {
          branch: branchConversation,
          t,
          notify: (level, text) => showToast(level, text),
          openConversation: openConversationForBranch,
        },
        { conversationId: currentConversationId, messageId: message.serverId },
      )
    },
    [currentConversationId, openConversationForBranch, showToast, t],
  )

  const onSend = async (text: string): Promise<void> => {
    if (!text || sending) return
    setInput('')
    const userMsg: N8nMessage = { id: nextId(), role: 'user', content: text }
    const aiMsg: N8nMessage = { id: nextId(), role: 'assistant', content: '' }
    setMessages((prev) => [...prev, userMsg, aiMsg])
    // D151:新一轮流开始 ⇒ 上一轮的"在等人"整体清空(它属于上一轮那条进程,
    // 留在这一轮会让等待行挂到与它无关的卡上)。
    setTerminalWaiting({})
    setSending(true)
    scrollToEnd()

    // 没有绑定工作流时不能生成伪造回复,移除刚加入的消息并提示用户选择智能体。
    if (!agentId) {
      setMessages((prev) =>
        prev.filter((message) => message.id !== userMsg.id && message.id !== aiMsg.id),
      )
      setSending(false)
      showToast('warning', t('aiAssistantN8n.emptyNoAgent'))
      return
    }

    // 有 agentId:复用 streamChat SSE 流式(对齐 Uniapp connectSocket + onMessage 累积)
    const controller = new AbortController()
    abortRef.current = controller

    // 模型配置参数透传(对齐 Uniapp ModelConfigDialog 调节请求参数)
    const apiMessages: Array<{ role: 'user' | 'assistant' | 'system'; content: string }> = []
    if (modelConfig.systemPrompt.trim()) {
      apiMessages.push({ role: 'system', content: modelConfig.systemPrompt.trim() })
    }
    apiMessages.push({ role: 'user', content: text })

    // agentTools 闸门:意图判定对象是"本次要发出去的最后一条 user 消息"(即上面的 text,
    // system 提示词不参与判定,否则提示词里的"打开/进入"等字样会让每次请求都带工具)
    const agentTools = uiControlToolsFor(text)

    // 2026-09-04 吞错修复(Fix B):streamChat 未传 onError 时对流内 error 事件耗尽重试后会 throw(reject,
    // 见 client.ts catch 块)。本屏虽传了 onError,但请求构造/网络层在进入重试循环前抛出的异常仍会 reject,
    // 此前无 try/catch 会导致 unhandled rejection 且 sending 永远不复位。补 try/catch 把错误路由到
    // 本屏既有错误状态处理(sending 复位 + 空回复填充错误提示 + toast),对齐 ChatScreen 错误处理写法。
    try {
      await streamChat({
        model: selectedModelId,
        messages: apiMessages,
        agentId,
        // 不命中意图时连字段都不出现,请求体与改造前逐字节一致(api-client 另有 length>0 守卫)
        ...(agentTools.length > 0 ? { agentTools } : {}),
        signal: controller.signal,
        // 2026-08-16 修复:显式声明流式,避免后端/中间件对 request.stream 做严格字段检测时关闭 SSE。
        stream: true,
        temperature: modelConfig.temperature,
        topP: modelConfig.topP,
        maxTokens: modelConfig.maxTokens,
        metadata: currentConversationId ? { conversationId: currentConversationId } : undefined,
        onDelta: (delta) => {
          setMessages((prev) => {
            const next = [...prev]
            const last = next[next.length - 1]
            if (last && last.role === 'assistant') {
              next[next.length - 1] = { ...last, content: last.content + delta }
            }
            return next
          })
          scrollToEnd()
        },
        // 思考过程增量(对齐 Uniapp onMessage 累积 agent_content1 + isHaveSikao)
        onReasoning: (delta) => {
          setMessages((prev) => {
            const next = [...prev]
            const last = next[next.length - 1]
            if (last && last.role === 'assistant') {
              next[next.length - 1] = {
                ...last,
                isHaveSikao: true,
                thinkingContent: (last.thinkingContent ?? '') + delta,
              }
            }
            return next
          })
          scrollToEnd()
        },
        // 消耗智汇值(对齐 Uniapp total_tokens,SSE usage chunk 映射)
        onUsage: (usage) => {
          if (usage.totalTokens <= 0) return
          setMessages((prev) => {
            const next = [...prev]
            const last = next[next.length - 1]
            if (last && last.role === 'assistant') {
              next[next.length - 1] = { ...last, totalTokens: usage.totalTokens }
            }
            return next
          })
        },
        // G-425(2026-10-07 立,web 腿先行):done 帧携带上游 finish/stop reason
        // (api-client onFinishReason,缺席不触发)。判"输出被 max_tokens 截断"用
        // @ihui/shared/utils/finish-reason 的唯一助手(与 web/extension 同一份),
        // 提示出口复用本端既有 FloatBox;其余 reason 不提示,不自动续写。
        onFinishReason: (evt) => {
          if (isMaxTokensTruncatedFinishReason(evt.finishReason)) {
            showToast('warning', t('chat.truncation.maxLengthNotice'))
          }
        },
        // 工具调用可视化(W7):tool-call-start/tool-result 折叠进最后一条 assistant 消息
        onToolCall: (event) => {
          setMessages((prev) => {
            const next = [...prev]
            const last = next[next.length - 1]
            if (last && last.role === 'assistant') {
              next[next.length - 1] = {
                ...last,
                toolCalls: applyToolCallEvent(last.toolCalls, event),
              }
            }
            return next
          })
          scrollToEnd()
        },
        // D113(2026-09-27 对齐 web G-227):文件写类工具流中 diff 预览。
        // tool-delta 帧载荷为增量正文,按 toolCallId 以 seq 收敛追加 partialDiff(重传/乱序幂等);
        // 仅 running 态渲染,tool-result 到达由 applyToolCallEvent 清除(最终 diff 以 result 为准)。
        onToolDelta: (event) => {
          setMessages((prev) => {
            const next = [...prev]
            const last = next[next.length - 1]
            if (last && last.role === 'assistant') {
              next[next.length - 1] = {
                ...last,
                toolCalls: applyToolDelta(last.toolCalls, event),
              }
            }
            return next
          })
        },
        // 计划步骤可视化(W7):plan 为权威快照,整体替换(不可与现有步骤增量合并)
        onPlanUpdate: (event) => {
          const reduced = applyPlanUpdate(event)
          setMessages((prev) => {
            const next = [...prev]
            const last = next[next.length - 1]
            if (last && last.role === 'assistant') {
              next[next.length - 1] = {
                ...last,
                planSteps: reduced.steps,
                planExplanation: reduced.explanation,
              }
            }
            return next
          })
          scrollToEnd()
        },
        // 终端任务可视化(W7):terminal_start 按 terminalId 新增/重置为 running
        onTerminalStart: (event) => {
          setMessages((prev) => {
            const next = [...prev]
            const last = next[next.length - 1]
            if (last && last.role === 'assistant') {
              next[next.length - 1] = {
                ...last,
                terminalTasks: applyTerminalStart(last.terminalTasks, event),
              }
            }
            return next
          })
          scrollToEnd()
        },
        // D19 终端实时输出增量(2026-09-18 后端起发 terminal_delta,web 2026-09-24 接,本端补齐):
        // 命令执行期间逐块下发 stdout/stderr,这里按 terminalId 累加进 live 缓冲供终端面板渲染。
        // 刻意不动 setMessages —— 增量不是正文,也不折进 task.output(terminal_end 会整体覆盖)。
        onTerminalDelta: (event) => {
          setTerminalLive((prev) => applyTerminalDeltaToLive(prev, event))
        },
        // D151 终端"等待键盘输入"(2026-09-29):后端在命令停在 tty 提示时下发 terminal_interaction。
        // 本端**只渲染降级态**(在等人 + 说明这里不能代答),刻意不接 postTerminalInput ——
        // 手机上进不去那条进程,给它输入框是假 affordance;不接则界面继续空转(本票立因)。
        onTerminalInteraction: (event) => {
          setTerminalWaiting((prev) => applyTerminalInteraction(prev, event))
        },
        // 终端任务可视化(W7):terminal_end 更新终态/输出/退出码/耗时
        onTerminalEnd: (event) => {
          // D151:命令已收尾 ⇒ "还在等输入"这一维必须跟着清,否则等待行永久挂在结束的卡上
          setTerminalWaiting((prev) => clearTerminalWaitingFor(prev, event.terminalId))
          setMessages((prev) => {
            const next = [...prev]
            const last = next[next.length - 1]
            if (last && last.role === 'assistant') {
              next[next.length - 1] = {
                ...last,
                terminalTasks: applyTerminalEnd(last.terminalTasks, event),
              }
            }
            return next
          })
          scrollToEnd()
        },
        // #11 引用溯源(第 51 轮):引用进消息,答案下方出来源列表
        onCitations: (event) => {
          setMessages((prev) => {
            const next = [...prev]
            const last = next[next.length - 1]
            if (last && last.role === 'assistant') {
              next[next.length - 1] = {
                ...last,
                citations: appendCitationFrames(
                  last.citations,
                  (event.citations ?? []).map((x) => ({
                    source: x.source,
                    label: x.label,
                    ...(typeof x.url === 'string' ? { url: x.url } : {}),
                  })),
                ),
              }
            }
            return next
          })
          scrollToEnd()
        },
        // D34 上下文注入交代(第 45 轮):本轮回答真正带上了哪些注入(对齐 web / 小程序口径)
        onInjectionApplied: (event) => {
          setMessages((prev) => {
            const next = [...prev]
            const last = next[next.length - 1]
            if (last && last.role === 'assistant') {
              next[next.length - 1] = {
                ...last,
                injections: applyInjectionFrame(last.injections, event),
              }
            }
            return next
          })
          scrollToEnd()
        },
        // D106 Steer(中途引导):ai-service 在 tool loop 边界注入引导后下发 steer 事件,
        // 这里逐字段承接(phase/text/timestamp/messageId)累积到最后一条 assistant 消息;
        // 空文本帧由 appendSteerFrames 整帧丢弃,不渲染空交代。
        onSteer: (event) => {
          setMessages((prev) => {
            const next = [...prev]
            const last = next[next.length - 1]
            if (last && last.role === 'assistant') {
              const notices = appendSteerFrames(last.steerNotices, event)
              if (notices.length > 0) {
                next[next.length - 1] = { ...last, steerNotices: notices }
              }
            }
            return next
          })
          scrollToEnd()
        },
        // D39 重试交代:网关换 key / 退避重试时提示,否则用户在流上只看到"卡住"
        onRetryScheduled: (event) => {
          showToast(
            'info',
            t('aiAssistantN8n.gatewayRetry', {
              attempt: event.attempt,
              max: event.maxRetries,
              seconds: Math.max(1, Math.round(event.retryInMs / 1000)),
            }),
          )
        },
        // 额度分档告警:网关在流首发 warning(80~95%)/ critical(95~100%),本条消息照常生成,
        // 只是让用户知道"今天快用完了"。措辞装配在 @ihui/shared/chat(两屏共用一份,见 utils/budget-note)
        onBudget: (event) => {
          showToast(event.level === 'critical' ? 'warning' : 'info', budgetNoteText(event, t))
        },
        // 上下文自动压缩提示(W7):后端达阈值自动压缩时提示用户(对齐 onCompaction 契约)
        onCompaction: (info) => {
          showToast(
            'info',
            t('aiAssistantN8n.compactionToast', {
              before: info.tokensBefore,
              after: info.tokensAfter,
            }),
          )
        },
        onError: (err, info) => {
          // info 透传:errorCode 是"厂商账号额度耗尽"等稳定码的唯一判据(HTTP 仍回落默认 502)
          const formatted = formatSSEError(new Error(err), info)
          setSending(false)
          abortRef.current = null
          // 失败轮:标 error + 仅在正文为空时写错误文案(共享层同一标记规则,与 ChatScreen / web 一致)。
          // 此前只填文案不打标 → 数据上与一次真回答同形,界面也只有一句普通文本、没有任何出口。
          setMessages((prev) =>
            applyStreamError(prev, formatted.message || t('aiAssistantN8n.callFailed')),
          )
          // 对齐 Uniapp uni.showToast + 任务要求 #2(error toast 用 FloatBox 替代 Alert.alert)
          const errMsg = formatted.message
            ? `${formatted.title}: ${formatted.message}`
            : formatted.title
          showToast('error', errMsg)
        },
        onDone: () => {
          setSending(false)
          abortRef.current = null
          // 流结束后提取回复中的图片 URL(对齐 Uniapp imgUrlList + processContent)
          setMessages((prev) => {
            const next = [...prev]
            const last = next[next.length - 1]
            if (last && last.role === 'assistant') {
              const imgs = extractImageUrls(last.content)
              if (imgs.length > 0) {
                next[next.length - 1] = { ...last, images: imgs }
              }
            }
            return next
          })
        },
      })
    } catch (err) {
      // 与上方 onError 同款错误状态处理(2026-09-04 吞错修复 Fix B 兜底)
      const formatted = formatSSEError(err)
      setSending(false)
      abortRef.current = null
      setMessages((prev) =>
        applyStreamError(prev, formatted.message || t('aiAssistantN8n.callFailed')),
      )
      const errMsg = formatted.message
        ? `${formatted.title}: ${formatted.message}`
        : formatted.title
      showToast('error', errMsg)
    }
  }

  const onStop = (): void => {
    abortRef.current?.abort()
    abortRef.current = null
    setSending(false)
  }

  // 模型切换(对齐 Uniapp pitchHandle:index → modelName)
  /** 失败轮重试:重发最后一条用户提问,并把失败气泡从视图撤掉。
   *  本屏 send 只带"本轮 + systemPrompt"(不回放历史),所以无需像 ChatScreen 那样截断历史。 */
  const retryLastTurn = (): void => {
    const text = resendTargetText(messages)
    if (!text) return
    setMessages((prev) => prev.filter((m) => !isErrorTurn(m)))
    void onSend(text)
  }

  const handleModelSelect = (ids: string[]): void => {
    const id = ids[0]
    if (id) {
      setSelectedModelId(id)
    }
    setShowModelPicker(false)
  }

  const handlePreviewImage = (url: string): void => {
    setPreviewImage(url)
  }

  // ── Drawer 回调(对齐 ChatScreen Drawer 集成模式) ──
  const closeDrawer = (): void => setDrawerVisible(false)
  const handleDrawerNavigate = (tab: DrawerTab): void => {
    if (tab === 'square') {
      navigation.navigate('Plaza')
      return
    }
    if (tab === 'share') {
      navigation.navigate('News')
      return
    }
    // DrawerTab('mine'等)必须先映射成 RN Tab 路由名('ProfileMain'),直接 cast 会静默跳转失败
    navigateDrawerTab(rootNav, tab)
  }
  const handleDrawerNavigateCompany = (): void => {
    navigation.navigate('Distribution')
  }
  const handleDrawerClaimFree = (): void => {
    // 领取免费资料:复制飞书链接 + FloatBox 提示(对齐 Uniapp lingqu → setClipboardData)
    try {
      Clipboard.setString(FREE_RESOURCE_URL)
      showToast('success', t('home.linkCopiedBrowser'))
    } catch {
      showToast('error', t('profile.copyFailRetry'))
    }
  }
  const handleDrawerCreateNewChat = (): void => {
    setMessages([])
    // D151:新建会话 = 会话切换的一种,等待态必须一起清(见 loadConversationMessages 同注释)
    setTerminalWaiting({})
    setInput('')
    switchConversationTo(undefined)
  }
  const handleDrawerSelectConversation = (id: string): void => {
    setDrawerVisible(false)
    switchConversationTo(id)
    void loadConversationMessages(id)
  }
  const handleDrawerDeleteConversation = (id: string): void => {
    appAlert(t('profile.dlgDelConvTitle'), t('profile.dlgDelConvBody'), [
      { text: t('common.cancel'), style: 'cancel' },
      {
        text: t('home.btnConfirm'),
        style: 'destructive',
        onPress: () => {
          const snapshot = drawerConversations
          setDrawerConversations((prev) => prev.filter((c) => c.id !== id))
          void (async () => {
            const res = await deleteConversation(id)
            if (!res.success) {
              setDrawerConversations(snapshot)
            }
          })()
        },
      },
    ])
  }
  const handleDrawerOpenSettings = (): void => {
    navigation.navigate('Settings')
  }
  const handleDrawerOpenMessages = (): void => {
    navigation.navigate('MessageCenter')
  }
  const handleDrawerGoHome = (): void => {
    navigation.navigate('Main', { screen: 'HomeMain' })
  }
  const handleNavigateExtra = (menu: DrawerExtraMenu): void => {
    switch (menu) {
      case 'aigc':
        navigation.navigate('AigcList')
        break
      case 'learn':
        navigation.navigate('Learn')
        break
      case 'modelPlaza':
        navigation.navigate('ModelPlaza')
        break
      case 'assistant':
        navigation?.navigate('Assistant')

        break

      case 'tools':
        // 对齐 Uniapp tools/index(AI应用商店)由 HomeScreen 承载
        navigation.navigate('Home')
        break
      case 'company':
        navigation.navigate('Distribution')
        break
    }
  }

  // Drawer user 映射(AuthUser → Drawer user)
  const drawerUser = {
    avatar: authUser?.avatar,
    nickname: authUser?.nickname ?? authUser?.username ?? t('home.notLoggedIn'),
    level: (authUser?.isVip === 1 ? 'vip' : 'normal') as 'vip' | 'normal',
  }

  const renderItem: ListRenderItem<N8nMessage> = ({ item }) => (
    <MessageBubble
      message={item}
      onPreviewImage={handlePreviewImage}
      onToast={showToast}
      onRetry={isErrorTurn(item) && resendTargetText(messages) !== null ? retryLastTurn : undefined}
      onBranch={
        // 准入与点击期共用同一条判据:本地乐观消息没有 serverId,源会话未落库时也没有
        isBranchableTarget({ conversationId: currentConversationId, messageId: item.serverId })
          ? () => handleBranchFromMessage(item)
          : undefined
      }
      terminalLive={terminalLive}
      terminalWaiting={terminalWaiting}
    />
  )

  return (
    <View style={styles.root}>
      <NavChrome>
        {/* 抽屉触发钮(2026-10-15 用户定):原 '≡' 文字字符冒充图标已收口为 PanelLeftRounded,
            与其余各屏同款;墨迹色由 NavBarActionButton 统一注入 text.medium(对齐 web foreground/80) */}
        <NavBar
          title={navTitle}
          onBack={() => navigation.goBack()}
          rightActions={[
            {
              icon: PanelLeftRounded,
              a11yLabel: t('common.menu'),
              onPress: () => setDrawerVisible(true),
            },
          ]}
        />
      </NavChrome>
      {/* 智汇值卡(对齐 Uniapp ai_assistant_n8n.vue 顶部 intelligent-assistant:
          小方欢迎卡 + 剩余智汇值 + 充值;余额接 getTokenBalance,加载失败保持 0,充值入口可用) */}
      <View style={styles.valueCardWrap}>
        <IntelligentAssistant
          tokenQuantity={tokenBalance}
          onRecharge={() => navigation.navigate('AppTopup')}
        />
      </View>
      {/* D111/G-165①:权限档交代行 —— 数据源优先级:消息盖章值 > 工作区默认档;
          两者皆缺(盖章不存在且取数失败)整行隐藏,不假装知道档位。
          渲染与取词已抽到 ChatDisclosure.PermissionTierRow,与 ChatScreen 同一实现。 */}
      <PermissionTierRow mode={stampedTier ?? workspaceTier} />
      <KeyboardAvoidingView
        style={styles.body}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        {/* 滚动淡出包装容器:与消息视口同界,遮罩绝对覆盖上下沿(仅溢出方向显示) */}
        <View style={styles.listFadeWrap}>
          <FlatList
            ref={listRef}
            data={messages}
            keyExtractor={(item) => item.id}
            renderItem={renderItem}
            contentContainerStyle={styles.listContent}
            onScroll={fades.onScroll}
            scrollEventThrottle={16}
            onContentSizeChange={(w, h) => {
              fades.onContentSizeChange(w, h)
              scrollToEnd()
            }}
            onLayout={(e) => {
              fades.onLayout(e)
              scrollToEnd()
            }}
            showsVerticalScrollIndicator={false}
            ListEmptyComponent={
              <Empty
                text={agentId ? t('aiAssistantN8n.empty') : t('aiAssistantN8n.emptyNoAgent')}
              />
            }
          />
          <ChatScrollFades topVisible={fades.topVisible} bottomVisible={fades.bottomVisible} />
        </View>
        {/* 快捷操作区(对齐 Uniapp ai_assistant_n8n quick-actions-container:
            无消息时输入区上方横向 suggestedQuestions chip,点击直接发送) */}
        {messages.length === 0 && QUICK_SUGGESTION_KEYS.length > 0 ? (
          <View style={styles.quickWrap}>
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.quickScrollContent}
            >
              {QUICK_SUGGESTION_KEYS.map((qKey) => {
                const question = t(qKey)
                return (
                  <TouchableOpacity
                    key={qKey}
                    style={styles.quickChip}
                    activeOpacity={0.75}
                    onPress={() => void onSend(question)}
                    accessibilityRole="button"
                    accessibilityLabel={question}
                  >
                    <Text style={styles.quickChipText} numberOfLines={1}>
                      {question}
                    </Text>
                  </TouchableOpacity>
                )
              })}
            </ScrollView>
          </View>
        ) : null}
        {/* 模型选择条(对齐 Uniapp ModelList + modelName 展示,位于输入区上方;
            配置按钮在模型选择旁打开 ModelConfigDialog,对齐 Uniapp 入口习惯) */}
        <TouchableOpacity
          style={styles.modelBar}
          onPress={() => setShowModelPicker(true)}
          activeOpacity={0.7}
          accessibilityRole="button"
          accessibilityLabel={t('chat.selectModel')}
        >
          <Text style={styles.modelBarLabel} numberOfLines={1}>
            {t('chat.modelLabel')}: {selectedModelLabel}
          </Text>
          <TouchableOpacity
            style={styles.modelConfigBtn}
            onPress={() => setModelConfigVisible(true)}
            activeOpacity={0.7}
            hitSlop={12}
            accessibilityRole="button"
            accessibilityLabel={t('agent.config')}
          >
            <Settings size={18} color={tokens.text.secondary} />
          </TouchableOpacity>
          <ChevronRight size={18} color={tokens.text.secondary} style={styles.modelBarArrow} />
        </TouchableOpacity>
        {/* VoiceInput 语音输入(对齐 Uniapp ai_assistant_n8n.vue 行 285/302 BottomActionBar
            :isVoiceInput + @toggle-voice-input:语音转文字回填输入框,随发送提交) */}
        <View style={styles.voiceInputWrap}>
          <VoiceInput
            placeholder={t('profile.n8nHoldToTalk')}
            onComplete={(text) => {
              if (text) setInput(text)
            }}
          />
        </View>
        {/* 任务进度状态条(对齐 web task-status-bar):plan_updated 驱动自动刷新,
            空闲(无步骤/无变更/非流式)时内部返回 null 不占高度 */}
        <TaskStatusBar
          planSteps={planMessage?.planSteps ?? []}
          toolCalls={planMessage?.toolCalls}
          isStreaming={sending}
        />
        <InputArea
          value={input}
          onChangeText={setInput}
          placeholder={t('aiAssistantN8n.placeholder')}
          maxLength={2000}
          onSubmit={(text) => void onSend(text)}
          disabled={sending}
          loading={sending}
          onStop={onStop}
          stopLabel={t('chat.stop')}
          sendLabel={t('aiAssistantN8n.send')}
          onImageAdd={handleAddPanelToggle}
        />
        {/* 「+」底部滑出添加面板(统一 AddPanel,与 HomeScreen/ChatScreen 同源) */}
        <AddPanel
          visible={addPanelVisible}
          onClose={() => setAddPanelVisible(false)}
          items={[
            {
              key: 'camera',
              label: t('home.addCamera'),
              icon: <Camera size={24} color={tokens.text.secondary} />,
              onPress: handleAddCamera,
            },
            {
              key: 'album',
              label: t('home.addAlbum'),
              icon: addUploading ? (
                <ActivityIndicator size="small" color={tokens.text.secondary} />
              ) : (
                <ImageIcon size={24} color={tokens.text.secondary} />
              ),
              onPress: () => void handleAddAlbum(),
            },
            {
              key: 'file',
              label: t('home.addLocalFile'),
              icon: <Folder size={24} color={tokens.text.secondary} />,
              onPress: () => void handleAddFile(),
            },
            {
              key: 'wxfile',
              label: t('home.addWxFile'),
              icon: <MessageCircle size={24} color={tokens.text.secondary} />,
              onPress: () => void handleAddFile(),
            },
          ]}
        />
        {sending ? (
          <View style={styles.streamingBar}>
            <ActivityIndicator color={tokens.brand.DEFAULT} size="small" />
            <Text style={styles.streamingText}>{t('aiAssistantN8n.streaming')}</Text>
          </View>
        ) : null}
      </KeyboardAvoidingView>

      {/* 模型选择器底部弹层(对齐 Uniapp ModelList sourceIs 弹出) */}
      <Modal
        visible={showModelPicker}
        transparent
        animationType="slide"
        onRequestClose={() => setShowModelPicker(false)}
      >
        <View style={pickerStyles.overlay}>
          <Pressable style={StyleSheet.absoluteFill} onPress={() => setShowModelPicker(false)} />
          <View style={[pickerStyles.sheet, dialogHeightStyle]}>
            <View style={pickerStyles.header}>
              <Text style={pickerStyles.title}>{t('chat.selectModel')}</Text>
              <TouchableOpacity
                onPress={() => setShowModelPicker(false)}
                hitSlop={8}
                accessibilityRole="button"
                accessibilityLabel={t('home.closeBtn')}
              >
                <Text style={pickerStyles.close}>{'×'}</Text>
              </TouchableOpacity>
            </View>
            <View style={pickerStyles.listWrap}>
              {/* sheet 已有确定高度(dialogHeightStyle),listWrap 以 flex:1 占满 header 之外剩余空间;
                  ModelPickerList 组件头注释契约 = 调用方提供定高/flex 容器 */}
              <ModelPickerList
                items={modelListItems}
                selectedIds={selectedModelId ? [selectedModelId] : []}
                onSelectChange={handleModelSelect}
              />
            </View>
          </View>
        </View>
      </Modal>

      {/* 图片全屏预览(对齐 Uniapp previewImage,使用共享 ImagePreviewModal) */}
      <ImagePreviewModal
        visible={previewImage !== null}
        source={previewSource}
        onClose={() => setPreviewImage(null)}
        onTransfer={handlePreviewTransfer}
      />

      {/* 模型配置弹层(对齐 Uniapp ModelConfigDialog:温度/top_p/maxTokens 等
          参数设置,入口在模型选择旁,与 uniapp InputArea showModelaConfig 一致) */}
      <ModelConfigDialog
        visible={modelConfigVisible}
        modelType="text"
        config={modelConfig}
        onChange={setModelConfig}
        onClose={() => setModelConfigVisible(false)}
      />

      {/* Drawer 历史对话入口(对齐任务要求"Drawer 集成:历史对话入口") */}
      <Drawer
        visible={drawerVisible}
        onClose={closeDrawer}
        user={drawerUser}
        conversations={drawerConversations}
        onNavigate={handleDrawerNavigate}
        onNavigateCompany={handleDrawerNavigateCompany}
        onClaimFree={handleDrawerClaimFree}
        onCreateNewChat={handleDrawerCreateNewChat}
        onSelectConversation={handleDrawerSelectConversation}
        onDeleteConversation={handleDrawerDeleteConversation}
        onOpenSettings={handleDrawerOpenSettings}
        onOpenMessages={handleDrawerOpenMessages}
        onGoHome={handleDrawerGoHome}
        onNavigateExtra={handleNavigateExtra}
      />

      {/* FloatBox 浮层提示(对齐 Uniapp uni.showToast + 任务要求 #2) */}
      <FloatBox visible={toastVisible} type={toastType} message={toastMessage} onHide={hideToast} />
    </View>
  )
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: tokens.surface.bg },
  valueCardWrap: { paddingHorizontal: rpx(16), marginTop: rpx(8) },
  body: { flex: 1 },
  // 滚动淡出包装容器:与消息视口同界(ScrollView 默认 flexGrow/flexShrink 1,几何不变)
  listFadeWrap: { flex: 1 },
  listContent: { paddingHorizontal: rpx(32), paddingVertical: rpx(16), paddingBottom: rpx(32) },
  // 语音输入行(对齐 Uniapp ai_assistant_n8n.vue 输入区语音模式,置于 InputArea 上方)
  voiceInputWrap: {
    paddingHorizontal: rpx(24),
    paddingVertical: rpx(12),
    backgroundColor: tokens.surface.card,
  },
  // 模型选择条(对齐 Uniapp ModelList 位置:输入区上方)
  modelBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: rpx(24),
    paddingVertical: rpx(16),
    backgroundColor: tokens.surface.card,
  },
  modelBarLabel: {
    flex: 1,
    fontSize: rnType.bodySm.size,
    color: tokens.text.secondary,
  },
  /** 纯图标设置键：40×40 固定命中盒(与全仓纯图标按钮同档)；文字标签删除后不再参与布局 */
  modelConfigBtn: {
    width: 40,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: rnRadius.sm,
    backgroundColor: tokens.surface.muted,
  },
  modelBarArrow: {
    fontSize: rnType.subtitle.size,
    color: tokens.text.medium,
    marginLeft: rpx(16),
  },
  // 快捷操作区(对齐 Uniapp quick-actions-container)
  quickWrap: {
    backgroundColor: tokens.surface.bg,
  },
  quickScrollContent: {
    paddingHorizontal: rpx(24),
    paddingVertical: rpx(16),
    gap: rpx(16),
  },
  quickChip: {
    paddingHorizontal: rpx(24),
    paddingVertical: rpx(12),
    borderRadius: rnRadius.md,
    backgroundColor: tokens.surface.card,
    borderWidth: 1,
    borderColor: tokens.border.light,
  },
  quickChipText: {
    fontSize: rnType.label.size,
    color: tokens.text.secondary,
  },
  streamingBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: rpx(12),
    paddingVertical: rpx(12),
    backgroundColor: tokens.surface.card,
  },
  streamingText: { fontSize: rnType.label.size, color: tokens.text.medium },
})

const bubbleStyles = StyleSheet.create({
  row: { flexDirection: 'row', marginVertical: rpx(8) },
  rowUser: { justifyContent: 'flex-end' },
  rowAi: { justifyContent: 'flex-start' },
  bubble: {
    maxWidth: '78%',
    paddingHorizontal: rpx(24),
    paddingVertical: rpx(16),
    borderRadius: rnRadiusFor.bubble,
  },
  bubbleUser: { backgroundColor: tokens.brand.DEFAULT },
  bubbleAi: { backgroundColor: tokens.surface.card },
  text: { fontSize: rnType.body.size, lineHeight: rnType.body.lineHeight },
  textUser: { color: tokens.surface.light },
  textAi: { color: tokens.text.primary },
  // 回复内图片网格(对齐 Uniapp agent-content-item-img)
  // 失败轮错误卡片(与 web D22 / ChatScreen 同一形态:警示头 + 正文 + 重试出口)
  errorCard: {
    width: '100%',
    borderRadius: rnRadius.lg,
    borderWidth: 1,
    borderColor: tokens.danger.light,
    backgroundColor: tokens.error.bg,
    overflow: 'hidden',
  },
  errorHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: rnSpacing['xs-loose'],
    paddingHorizontal: rnSpacing.md,
    paddingVertical: rnSpacing.sm,
    backgroundColor: tokens.danger.light,
  },
  errorTitle: { fontSize: rnType.label.size, fontWeight: '500', color: tokens.error.text },
  errorBody: {
    paddingHorizontal: rnSpacing.md,
    paddingVertical: rnSpacing.sm,
    fontSize: rnType.body.size,
    lineHeight: rnType.body.lineHeight,
    color: tokens.error.text,
  },
  errorRetry: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: rnSpacing.xs,
    alignSelf: 'flex-start',
    marginHorizontal: rnSpacing.sm,
    marginBottom: rnSpacing.sm,
    paddingHorizontal: rnSpacing.sm,
    paddingVertical: rnSpacing.xs,
  },
  errorRetryText: { fontSize: rnType.label.size, color: tokens.error.text },
  imageGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: rpx(12),
    marginTop: rpx(16),
  },
  chatImage: {
    width: 120,
    height: 120,
    borderRadius: rnRadius.md,
    backgroundColor: tokens.surface.muted,
  },
  // assistant 消息纵向容器:气泡 + 思考过程区 + 操作按钮行
  msgCol: {
    alignItems: 'flex-start',
  },
  // 思考过程展开区(对齐 Uniapp agent_content_con 思考内容展示)
  thinkingBox: {
    maxWidth: '78%',
    marginTop: rpx(8),
    paddingHorizontal: rpx(16),
    paddingVertical: rpx(12),
    borderRadius: rnRadius.lg,
    backgroundColor: tokens.surface.muted,
  },
  thinkingText: {
    fontSize: rnType.label.size,
    lineHeight: rnType.bodySm.lineHeight,
    color: tokens.text.secondary,
  },
  // 操作按钮行(对齐 Uniapp action-buttons:左消耗文案 + 右按钮组)
  actionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    maxWidth: '78%',
    marginTop: rpx(8),
  },
  // 无消耗文案时按钮组右对齐(对齐 Uniapp justify-content: flex-end)
  actionRowNoLabel: {
    justifyContent: 'flex-end',
  },
  tokensText: {
    flex: 1,
    marginRight: rpx(16),
    fontSize: rnType.caption.size,
    color: tokens.text.medium,
  },
  actionBtns: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: rpx(20),
  },
  actionBtn: {
    padding: rpx(4),
  },
  // ── W7:对话可视化区块样式(工具调用 / 计划步骤 / 终端任务) ──
  // 区块容器(标题 + 卡片/行列表),与 assistant 气泡同宽上限
  block: {
    maxWidth: '78%',
    marginTop: rpx(8),
    gap: rpx(6),
  },
  blockTitle: {
    fontSize: rnType.caption.size,
    fontWeight: '600',
    color: tokens.text.medium,
  },
  blockHint: {
    fontSize: rnType.label.size,
    lineHeight: rnType.bodySm.lineHeight,
    color: tokens.text.secondary,
  },
  // 卡片(工具调用 / 终端任务共用外壳)
  card: {
    borderRadius: rnRadius.lg,
    backgroundColor: tokens.surface.muted,
    overflow: 'hidden',
  },
  cardHead: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: rpx(8),
    paddingHorizontal: rpx(12),
    paddingVertical: rpx(8),
  },
  cardTitle: { flexShrink: 0, fontSize: rnType.label.size, color: tokens.text.primary },
  cardSubject: {
    flex: 1,
    fontSize: rnType.caption.size,
    color: tokens.text.medium,
    fontFamily: Platform.select({ ios: 'Menlo', android: 'monospace', default: 'monospace' }),
  },
  cardMeta: { fontSize: rnType.badge.size, color: tokens.text.medium },
  cardBody: {
    paddingHorizontal: rpx(12),
    paddingBottom: rpx(10),
    gap: rpx(6),
  },
  sectionLabel: { fontSize: rnType.badge.size, fontWeight: '600', color: tokens.text.medium },
  sectionGap: { marginTop: rpx(6) },
  // 等宽文本(工具参数/输出、终端命令与输出)
  monoText: {
    fontFamily: Platform.select({ ios: 'Menlo', android: 'monospace', default: 'monospace' }),
    fontSize: rnType.caption.size,
    lineHeight: rnType.label.lineHeight,
    color: tokens.text.medium,
  },
  terminalCommand: {
    flex: 1,
    fontFamily: Platform.select({ ios: 'Menlo', android: 'monospace', default: 'monospace' }),
    fontSize: rnType.caption.size,
    color: tokens.text.primary,
  },
  // 计划步骤行(序号 + 步骤文本 + 状态徽标 + 耗时)
  planRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: rpx(8),
  },
  planIndex: {
    width: 16,
    fontSize: rnType.caption.size,
    color: tokens.text.medium,
  },
  planText: {
    flex: 1,
    fontSize: rnType.label.size,
    lineHeight: rnType.bodySm.lineHeight,
    color: tokens.text.primary,
  },
  // 状态徽标(pending/active/done/failed 四态:底色 + 文字色成对)
  badge: {
    paddingHorizontal: rpx(8),
    paddingVertical: rpx(2),
    borderRadius: rnRadius.md,
  },
  badgeText: { fontSize: rnType.badge.size, fontWeight: '600' },
  badgePending: { backgroundColor: tokens.gray[200] },
  badgePendingText: { color: tokens.text.secondary },
  badgeActive: { backgroundColor: tokens.warning.amberLight },
  badgeActiveText: { color: tokens.warning.amberText },
  badgeDone: { backgroundColor: tokens.success.lighter },
  badgeDoneText: { color: tokens.success.deepText },
  badgeFailed: { backgroundColor: tokens.error.bg },
  badgeFailedText: { color: tokens.danger.deepText },
})

const pickerStyles = StyleSheet.create({
  overlay: {
    flex: 1,
    justifyContent: 'flex-end',
    backgroundColor: rnCssLight.black45,
  },
  sheet: {
    backgroundColor: tokens.surface.card,
    borderTopLeftRadius: rnRadius.xl,
    borderTopRightRadius: rnRadius.xl,
    // 高度由 dialogHeightStyle 统一注入(禁止写百分比上限,见 lib/dialog-geometry.ts)
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: rpx(32),
    paddingVertical: rpx(24),
  },
  title: {
    fontSize: rnType.strong.size,
    fontWeight: '600',
    color: tokens.text.primary,
  },
  close: {
    fontSize: rnType.display.size,
    color: tokens.text.medium,
    lineHeight: rnType.subtitle.lineHeight,
  },
  // sheet 已有确定高度,flex:1 占满 header 之外的剩余空间(不再手写比例)
  listWrap: {
    width: '100%',
    flex: 1,
  },
})
// ⁠​‌​​‌​​‌‍‍​‌​​‌​​​‍‍​‌​‌​‌​‌‍‍​‌​​‌​​‌‍‍​​‌​‌‌​‌‍‍​‌​​​​​‌‍‍​‌​​‌​​‌‍‍‌​‌‌​‌‌‌‍‍‌‌​​‌‌​​‌‌‌‌​‌​‍‍‌‌​‌‌​​​‌​​​‌‌‌‍‍​‌​​​​​‌‍‍​‌​​‌​​‌‍‍‌​‌‌​‌‌‌‍‍‌‌​​‌‌‌​‌​​‌‌‌​‍‍‌‌​​‌‌​​​‌​​‌​‌‍‍‌​‌‌‌​‌‌‌​‌‌‌​‌‍‍‌​‌‌​‌‌‌‍‍​‌​​‌‌​​‍‍​‌​​​​‌‌‍‍‌​‌‌​‌‌‌‍‍​‌‌​​​​‌‍‍​‌‌​‌​​‌‍‍​‌‌‌‌​‌​‍‍​‌‌​‌​​​‍‍​‌‌‌​​‌‌‍‍​​‌​‌‌‌​‍‍​‌‌‌​‌​​‍‍​‌‌​‌‌‌‌‍‍​‌‌‌​​​​‍‍‌​‌‌​‌‌‌‍‍​‌​‌​​​​‍‍​‌​‌​​‌​‍‍​‌​​‌‌‌‌‍‍​‌​‌​‌‌​‍‍​‌​​​‌​‌‍‍​‌​​‌‌‌​‍‍​‌​​​​​‌‍‍​‌​​‌‌‌​‍‍​‌​​​​‌‌‍‍​‌​​​‌​‌‍‍​​‌​‌‌​‌‍‍​​‌‌​​‌​‍‍​​‌‌​​​​‍‍​​‌‌​​‌​‍‍​​‌‌​‌‌​⁠
