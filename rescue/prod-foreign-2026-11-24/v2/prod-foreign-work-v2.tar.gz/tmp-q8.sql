\pset pager off
\echo === Q8a: model_sync 最近日志(时间/ provider / 结果) ===
SELECT * FROM ai_model_sync_log ORDER BY 1 DESC LIMIT 10;

\echo === Q8b: 7 行当前售价/成本/留痕(复核未被回退) ===
SELECT m.id, m.model_id,
  m.input_price_per_1k AS price_in, m.output_price_per_1k AS price_out,
  m.cost_input_price_per_1k AS cost_in, m.cost_output_price_per_1k AS cost_out,
  m.metadata->'priceSource'->>'tier' AS tier, m.updated_at
FROM ai_model_config_models m WHERE m.id IN (189,190,2872,2873,2874,2875,2876)
ORDER BY m.id;
