\pset pager off
\echo === Q6a: 3 行 PATCH 后回读 ===
SELECT m.id, c.provider_code, m.model_id,
  m.input_price_per_1k  AS price_in,  m.output_price_per_1k AS price_out,
  m.cost_input_price_per_1k  AS cost_in,  m.cost_output_price_per_1k AS cost_out,
  round(m.cost_input_price_per_1k*3,6)  AS expect_in,
  round(m.cost_output_price_per_1k*3,6) AS expect_out,
  m.metadata->'priceSource'->>'tier' AS tier, m.updated_at
FROM ai_model_config_models m JOIN ai_model_config c ON m.config_id=c.id
WHERE m.id IN (2872,2873,2874) ORDER BY m.id;

\echo === Q6b: xai 全部 cost 非空行倒挂扫描(price < cost) ===
SELECT m.id, m.model_id, m.cost_input_price_per_1k AS cost_in, m.cost_output_price_per_1k AS cost_out,
  m.input_price_per_1k AS price_in, m.output_price_per_1k AS price_out,
  m.metadata->'priceSource'->>'tier' AS tier
FROM ai_model_config_models m JOIN ai_model_config c ON m.config_id=c.id
WHERE c.provider_code='xai'
  AND m.cost_input_price_per_1k IS NOT NULL
  AND (coalesce(m.input_price_per_1k,0) < m.cost_input_price_per_1k
       OR coalesce(m.output_price_per_1k,0) < m.cost_output_price_per_1k)
ORDER BY m.id;

\echo === Q6c: 0309/4.20 家族全量(含 cost 空行) ===
SELECT m.id, m.model_id,
  CASE WHEN m.cost_input_price_per_1k IS NULL THEN 'NULL' ELSE m.cost_input_price_per_1k::text END AS cost_in,
  CASE WHEN m.cost_output_price_per_1k IS NULL THEN 'NULL' ELSE m.cost_output_price_per_1k::text END AS cost_out,
  m.input_price_per_1k AS price_in, m.output_price_per_1k AS price_out,
  m.metadata->'priceSource'->>'tier' AS tier
FROM ai_model_config_models m JOIN ai_model_config c ON m.config_id=c.id
WHERE c.provider_code='xai' AND (lower(m.model_id) LIKE '%0309%' OR lower(m.model_id) LIKE '%4.20%')
ORDER BY m.id;
