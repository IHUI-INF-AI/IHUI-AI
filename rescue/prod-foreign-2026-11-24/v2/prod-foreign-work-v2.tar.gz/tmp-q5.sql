\pset pager off
\echo === Q5a: 3 个 0309 行现状(cost NULL/0 分清,points/公开/updated_at) ===
SELECT m.id, c.provider_code, m.model_id,
  m.enabled, m.is_relay_public,
  m.relay_price_multiplier AS relay_mult, m.points_multiplier AS points_mult,
  m.input_price_per_1k  AS price_in,  m.output_price_per_1k AS price_out,
  CASE WHEN m.cost_input_price_per_1k  IS NULL THEN 'NULL' ELSE m.cost_input_price_per_1k::text END  AS cost_in,
  CASE WHEN m.cost_output_price_per_1k IS NULL THEN 'NULL' ELSE m.cost_output_price_per_1k::text END AS cost_out,
  m.metadata->'priceSource'->>'tier'  AS tier,
  m.metadata->'priceSource'->>'source' AS src,
  m.updated_at
FROM ai_model_config_models m JOIN ai_model_config c ON m.config_id=c.id
WHERE m.id IN (2872,2873,2874) ORDER BY m.id;

\echo === Q5b: 已修正 4 行对照(现读) ===
SELECT m.id, m.model_id,
  m.cost_input_price_per_1k AS cost_in, m.cost_output_price_per_1k AS cost_out,
  m.input_price_per_1k AS price_in, m.output_price_per_1k AS price_out,
  round(m.cost_input_price_per_1k*3,6) AS expect_in,
  round(m.cost_output_price_per_1k*3,6) AS expect_out,
  m.metadata->'priceSource'->>'tier' AS tier, m.updated_at
FROM ai_model_config_models m WHERE m.id IN (189,190,2875,2876) ORDER BY m.id;

\echo === Q5c: ai_pricing 表 grok-4.20/0309 上游记录 ===
SELECT model_id, billing_mode, input_token_price, output_token_price, per_unit_price, updated_at
FROM ai_pricing
WHERE lower(model_id) LIKE '%0309%' OR lower(model_id) LIKE '%4.20%'
ORDER BY model_id;

\echo === Q5d: xai 全部行倒挂/低于成本扫描(cost 非空口径) ===
SELECT m.id, m.model_id,
  m.cost_input_price_per_1k AS cost_in, m.cost_output_price_per_1k AS cost_out,
  m.input_price_per_1k AS price_in, m.output_price_per_1k AS price_out,
  m.metadata->'priceSource'->>'tier' AS tier
FROM ai_model_config_models m JOIN ai_model_config c ON m.config_id=c.id
WHERE c.provider_code='xai'
  AND m.cost_input_price_per_1k IS NOT NULL
  AND (coalesce(m.input_price_per_1k,0) < m.cost_input_price_per_1k
       OR coalesce(m.output_price_per_1k,0) < m.cost_output_price_per_1k)
ORDER BY m.id;
