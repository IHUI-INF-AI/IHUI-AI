\pset pager off
\echo === Q2a: 17:30:00~17:36:00 窗口 models 命中行按 provider 分布 ===
SELECT c.provider_code, count(*) AS n,
  count(*) FILTER (WHERE c.owner_uuid IS NULL) AS pub,
  min(m.updated_at) AS min_at, max(m.updated_at) AS max_at
FROM ai_model_config_models m JOIN ai_model_config c ON m.config_id=c.id
WHERE m.updated_at >= '2026-11-23 17:30:00+08' AND m.updated_at < '2026-11-23 17:36:00+08'
GROUP BY c.provider_code ORDER BY n DESC;

\echo === Q2b: 17:32:30~17:33:30 秒级明细 ===
SELECT m.id, c.provider_code, m.model_id,
  m.cost_input_price_per_1k AS cost_in, m.cost_output_price_per_1k AS cost_out,
  m.input_price_per_1k AS price_in, m.output_price_per_1k AS price_out,
  m.enabled, m.is_relay_public, m.updated_at
FROM ai_model_config_models m JOIN ai_model_config c ON m.config_id=c.id
WHERE m.updated_at >= '2026-11-23 17:32:30+08' AND m.updated_at < '2026-11-23 17:33:30+08'
ORDER BY m.updated_at, m.id;

\echo === Q2c: 今天 models 表 updated_at 按 5 分钟桶分布(找批量写时刻) ===
SELECT date_trunc('hour', m.updated_at) AS hr,
  extract(minute FROM m.updated_at)::int / 5 AS min5,
  count(*) AS n,
  count(DISTINCT c.provider_code) AS provs
FROM ai_model_config_models m JOIN ai_model_config c ON m.config_id=c.id
WHERE m.updated_at >= '2026-11-23 00:00:00+08'
GROUP BY 1,2 ORDER BY 1,2;

\echo === Q3a: ai_model_price_audit 表结构 ===
SELECT column_name, data_type FROM information_schema.columns
WHERE table_name='ai_model_price_audit' ORDER BY ordinal_position;

\echo === Q3b: 审计表今天 grok-4 全部记录 ===
SELECT id, model_id, config_id, old_input_per_1k, old_output_per_1k,
  new_input_per_1k, new_output_per_1k, change_source, change_tier,
  ref_model, operator_id, note, created_at
FROM ai_model_price_audit
WHERE lower(model_id) LIKE '%grok-4%'
  AND created_at >= '2026-11-23 00:00:00+08'
ORDER BY created_at;

\echo === Q3c: 审计表今天全部记录按 change_source 聚合 ===
SELECT change_source, count(*) AS n, min(created_at) AS first_at, max(created_at) AS last_at
FROM ai_model_price_audit
WHERE created_at >= '2026-11-23 00:00:00+08'
GROUP BY change_source ORDER BY n DESC;
