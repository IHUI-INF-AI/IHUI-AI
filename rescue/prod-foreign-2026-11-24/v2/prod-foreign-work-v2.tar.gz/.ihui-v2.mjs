// 生产签出当前态增量快照 v2（跑完即删）
import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import { execSync } from 'node:child_process'

const PROD = 'D:\\DevEnv\\ihui-prod'
const OUT = 'D:\\IHUI-AI\\rescue\\prod-foreign-2026-11-24\\v2'
const SKIP_DIRS = ['.git-broken-', 'apps/web/.rollback.retired-']
const SKIP_FILES = new Set([
  '.ihui-classify-mod.txt', '.ihui-classify-unt.txt', '.ihui-classify.mjs',
  '.ihui-classify-result.json', '.ihui-pack-list.txt', '.ihui-manifest.mjs',
])

fs.mkdirSync(OUT, { recursive: true })

const st = execSync(`git -C "${PROD}" status --porcelain`, { encoding: 'utf8' })
const items = st.split(/\r?\n/).filter(Boolean).map((l) => ({ xy: l.slice(0, 2), rel: l.slice(3).trim().replace(/^"|"$/g, '') }))
const picked = items.filter(
  (i) => !SKIP_DIRS.some((d) => i.rel.startsWith(d)) && !SKIP_FILES.has(i.rel)
)

const rows = []
let total = 0
for (const it of picked) {
  const abs = path.join(PROD, it.rel.replace(/\//g, '\\'))
  let s
  try { s = fs.statSync(abs) } catch { rows.push({ rel: it.rel, xy: it.xy, present: false }); continue }
  if (s.isDirectory()) { rows.push({ rel: it.rel, xy: it.xy, isDir: true }); continue }
  const b = fs.readFileSync(abs)
  total += b.length
  rows.push({
    rel: it.rel, xy: it.xy, present: true, bytes: b.length, mtime: s.mtime.toISOString(),
    gitBlobSha1: crypto.createHash('sha1').update('blob ' + b.length + '\0').update(b).digest('hex'),
    sha256: crypto.createHash('sha256').update(b).digest('hex'),
  })
}

fs.writeFileSync(path.join(PROD, '.ihui-pack2-list.txt'), picked.filter((i) => !i.rel.endsWith('\\')).map((i) => i.rel).join('\n') + '\n', 'utf8')
fs.writeFileSync(
  path.join(OUT, 'MANIFEST-v2.json'),
  JSON.stringify({
    kind: 'prod-checkout-foreign-work-v2',
    createdAt: new Date().toISOString(),
    source: PROD,
    note: 'v2 增量:首次快照(15:5x)之后新增/变化的改动,含其它会话正在写的 oauth-queries.ts / auth-extended.ts。用于覆盖"快照时点之后仍在变化"的窗口。',
    fileCount: rows.filter((r) => r.present && !r.isDir).length,
    totalBytes: total,
    files: rows,
  }, null, 2),
  'utf8'
)
console.log(`v2 清单 ${picked.length} 项 / 实体 ${rows.filter((r) => r.present && !r.isDir).length} / ${(total / 1024 / 1024).toFixed(2)} MB`)
console.log('新增两个: ' + picked.filter((i) => i.rel.includes('oauth-queries') || i.rel.includes('auth-extended')).map((i) => i.rel).join(', '))

