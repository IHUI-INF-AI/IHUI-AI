// GENERATED FILE — DO NOT EDIT.
// 来源: packages/shared/src/constants/points-multiplier-rules.json
// 重新生成: node scripts/gen-points-multiplier-rules.mjs(改动请改 JSON)

export const POINTS_MULTIPLIER_RULES_DATA = {
  version: 1,
  tiers: {
    free: 0,
    economy: 1,
    standard: 3,
    premium: 10,
    flagship: 30,
    fallback: 1,
  },
  ihuiModelMap: {
    'ihui/auto-model': 3,
    'ihui/minimax-m2.7': 6,
    'ihui/minimax-m2.7-highspeed': 15,
    'ihui/minimax-m3': 15,
    'ihui/deepseek-v4-flash-0731': 15,
    'ihui/glm-5.1': 18,
    'ihui/glm-5.2': 18,
    'ihui/glm-5.3-flash': 18,
    'ihui/kimi-k2.6': 18,
    'ihui/deepseek-v4-pro': 18,
    'ihui/deepseek-v4-pro-0813': 18,
    'ihui/grok-4.5': 18,
    'ihui/glm-5.3': 30,
    'ihui/gpt-5.6': 30,
    'ihui/grok-4.6': 30,
    'ihui/qwen3.7-max': 30,
    'ihui/kimi-k2.7-code': 30,
  },
  orderedRules: [
    {
      tier: 'free',
      containsAny: ['ollama', 'llama', 'llm7', 'pollinations', 'opencode_zen'],
      why: '本地 / 上游 zero_cost provider:先判,避免免费模型被后面的旗舰/标准关键词抬高',
    },
    {
      tier: 'economy',
      containsAny: [
        'mini',
        'nano',
        'haiku',
        'flash',
        'lite',
        'ocr',
        'small',
        'luna',
        'sao10k',
        'smol',
        'hunyuan-2.0-thinking',
      ],
      keywordExclusions: [{ keyword: 'mini', unlessContainsAnyOf: ['gemini'] }],
      why: '轻量后缀优先于父型号家族判定,否则 gpt-5-image-mini 会被 gpt-5 拉到 10x、deepseek-v4.1-flash 会被 deepseek 拉到 3x;gemini 自身含 mini 子串必须排除',
    },
    {
      tier: 'flagship',
      containsAny: [
        'opus',
        'o1-preview',
        'o1',
        'o3',
        'gpt-5.4-pro',
        'gpt-5.5',
        'gpt-5.5-pro',
        'gpt-5.6-sol',
        'gpt-5.6-terra',
      ],
      why: '只认真实旗舰家族;thinking 不再代表旗舰(大量开源 reasoning 模型成本只有 1x/3x)',
    },
    {
      tier: 'premium',
      containsAll: ['gemini', 'pro'],
      why: 'gemini pro 系按高级档,不落标准档',
    },
    {
      tier: 'premium',
      containsAny: ['gpt-5', 'gpt-4-turbo', 'gpt-4.5', 'qwen-max-longcontext'],
      why: 'gpt-5 基础族属高级档(旗舰档只认 gpt-5.4-pro/5.5/5.6-sol 等显式后缀)',
    },
    {
      tier: 'standard',
      containsAny: ['sonnet', 'gpt-4o', 'gpt-4.1', 'deepseek', 'glm-4', 'qwen-max', 'thinking'],
      why: '主流中端模型;低成本 thinking 模型落这一档',
    },
  ],
} as const
