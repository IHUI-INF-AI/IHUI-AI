\pset pager off
\echo === Q3a: 今天 15:00~18:00 models updated_at 按分钟桶分布 ===
SELECT to_char(m.updated_at, 'HH24:MI') AS minute, count(*) AS n,
  count(DISTINCT c.provider_code) AS provs
FROM ai_model_config_models m JOIN ai_model_config c ON m.config_id=c.id
WHERE m.updated_at >= '2026-11-23 15:00:00+08'
GROUP BY 1 ORDER BY 1;

\echo === Q3b: ai_pricing grok-4.* 全量(标零价/占位) ===
SELECT model_id, billing_mode, input_token_price AS in_p, output_token_price AS out_p,
  per_unit_price,
  CASE WHEN input_token_price<=0 OR output_token_price<=0 THEN 'ZERO'
       WHEN input_token_price=1 AND output_token_price=2 THEN 'PLACEHOLDER'
       ELSE 'ok' END AS flag,
  effective_at, updated_at
FROM ai_pricing
WHERE lower(model_id) LIKE '%grok-4%'
ORDER BY model_id, effective_at DESC NULLS LAST;

\echo === Q3c: xai config_id=6 全部行当前值 ===
SELECT m.id, m.model_id,
  m.cost_input_price_per_1k AS cost_in, m.cost_output_price_per_1k AS cost_out,
  m.input_price_per_1k AS price_in, m.output_price_per_1k AS price_out,
  m.enabled, m.is_relay_public, m.updated_at
FROM ai_model_config_models m WHERE m.config_id=6 ORDER BY m.id;

\echo === Q3d: 全表倒挂现状(price < cost 且 cost>0) ===
SELECT c.provider_code, count(*) AS n
FROM ai_model_config_models m JOIN ai_model_config c ON m.config_id=c.id
WHERE coalesce(m.cost_input_price_per_1k,0)>0
  AND (coalesce(m.input_price_per_1k,0) < m.cost_input_price_per_1k
    OR coalesce(m.output_price_per_1k,0) < m.cost_output_price_per_1k)
GROUP BY c.provider_code ORDER BY n DESC;

\echo === Q3e: 倒挂总行数 + 零售价行数 ===
SELECT
  count(*) FILTER (WHERE coalesce(cost_input_price_per_1k,0)>0
    AND (coalesce(input_price_per_1k,0)<cost_input_price_per_1k
      OR coalesce(output_price_per_1k,0)<cost_output_price_per_1k)) AS below_cost,
  count(*) FILTER (WHERE coalesce(input_price_per_1k,0)<=0 OR coalesce(output_price_per_1k,0)<=0) AS zero_price,
  count(*) AS total
FROM ai_model_config_models;
