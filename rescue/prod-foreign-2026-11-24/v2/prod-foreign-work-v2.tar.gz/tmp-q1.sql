\pset pager off
\echo === Q1a: 16:42:00~16:47:00 窗口内 updated_at 命中行按 provider 分布 ===
SELECT c.provider_code,
  count(*) AS n,
  count(*) FILTER (WHERE c.owner_uuid IS NULL) AS pub_rows,
  count(*) FILTER (WHERE c.owner_uuid IS NOT NULL) AS pool_rows,
  min(m.updated_at) AS min_at,
  max(m.updated_at) AS max_at
FROM ai_model_config_models m JOIN ai_model_config c ON m.config_id=c.id
WHERE m.updated_at >= '2026-11-23 16:42:00+08' AND m.updated_at < '2026-11-23 16:47:00+08'
GROUP BY c.provider_code ORDER BY n DESC;

\echo === Q1b: 16:43:30~16:45:00 秒级明细(全部命中行) ===
SELECT m.id, c.provider_code, c.owner_uuid IS NULL AS pub, m.model_id,
  m.cost_input_price_per_1k AS cost_in, m.cost_output_price_per_1k AS cost_out,
  m.input_price_per_1k AS price_in, m.output_price_per_1k AS price_out,
  m.points_multiplier, m.enabled, m.is_relay_public, m.updated_at
FROM ai_model_config_models m JOIN ai_model_config c ON m.config_id=c.id
WHERE m.updated_at >= '2026-11-23 16:43:30+08' AND m.updated_at < '2026-11-23 16:45:00+08'
ORDER BY m.updated_at, m.id;

\echo === Q1c: 15:50:00~15:52:30 窗口(备份原值 updated_at=15:51:07)分布 ===
SELECT c.provider_code, count(*) AS n,
  min(m.updated_at) AS min_at, max(m.updated_at) AS max_at
FROM ai_model_config_models m JOIN ai_model_config c ON m.config_id=c.id
WHERE m.updated_at >= '2026-11-23 15:50:00+08' AND m.updated_at < '2026-11-23 15:52:30+08'
GROUP BY c.provider_code ORDER BY n DESC;

\echo === Q1d: 4 行当前值(2026-11-23 现读) ===
SELECT m.id, c.provider_code, m.model_id,
  m.cost_input_price_per_1k AS cost_in, m.cost_output_price_per_1k AS cost_out,
  m.input_price_per_1k AS price_in, m.output_price_per_1k AS price_out,
  round(m.cost_input_price_per_1k*3,6) AS expect_in,
  round(m.cost_output_price_per_1k*3,6) AS expect_out,
  m.points_multiplier, m.enabled, m.is_relay_public, m.updated_at,
  m.metadata::text AS meta
FROM ai_model_config_models m JOIN ai_model_config c ON m.config_id=c.id
WHERE m.id IN (189,190,2875,2876) ORDER BY m.id;

\echo === Q1e: ai_pricing 表 grok-4.* 记录 ===
SELECT model_id, billing_mode, input_token_price, output_token_price,
  per_unit_price, effective_at, updated_at
FROM ai_pricing
WHERE lower(model_id) LIKE '%grok-4%'
ORDER BY model_id;
