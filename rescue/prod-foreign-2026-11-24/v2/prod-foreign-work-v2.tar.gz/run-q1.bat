@echo off
set PGPASSWORD=fa6ZJRVkG1_vdTDCAGX0fUMZ8y0cDAbi
set PGCLIENTENCODING=UTF8
D:\DevEnv\runtimes\pgsql\bin\psql.exe -h localhost -p 8810 -U ihui -d ihui_dev -f D:\DevEnv\ihui-prod\tmp-q1.sql -A -F|
