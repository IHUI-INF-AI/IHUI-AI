\pset pager off
\echo === Q7: models 表价格/成本列默认值与可空性 ===
SELECT column_name, data_type, column_default, is_nullable
FROM information_schema.columns
WHERE table_name = 'ai_model_config_models'
  AND column_name IN ('input_price_per_1k','output_price_per_1k','cost_input_price_per_1k','cost_output_price_per_1k')
ORDER BY column_name;

\echo === Q7b: 当前 price=0/0 且 cost 空的新形态候选计数(全 provider) ===
SELECT c.provider_code, count(*) AS n
FROM ai_model_config_models m JOIN ai_model_config c ON c.id=m.config_id
WHERE coalesce(m.input_price_per_1k,0)=0 AND coalesce(m.output_price_per_1k,0)=0
  AND m.cost_input_price_per_1k IS NULL AND m.cost_output_price_per_1k IS NULL
GROUP BY c.provider_code ORDER BY n DESC;
