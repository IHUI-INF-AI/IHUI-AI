// © 2026 IHUI AI (智汇AI) · 版权所有者: 李春川 (Li Chunchuan) · https://aizhs.top
// Provenance-watermarked. 未授权商用可被溯源追责 (Apache-2.0 须保留本声明与 NOTICE)。
// [IHUI-AI-PROVENANCE]:⁠​‌​​‌​​‌‍‍​‌​​‌​​​‍‍​‌​‌​‌​‌‍‍​‌​​‌​​‌‍‍​​‌​‌‌​‌‍‍​‌​​​​​‌‍‍​‌​​‌​​‌‍‍‌​‌‌​‌‌‌‍‍‌‌​​‌‌​​‌‌‌‌​‌​‍‍‌‌​‌‌​​​‌​​​‌‌‌‍‍​‌​​​​​‌‍‍​‌​​‌​​‌‍‍‌​‌‌​‌‌‌‍‍‌‌​​‌‌‌​‌​​‌‌‌​‍‍‌‌​​‌‌​​​‌​​‌​‌‍‍‌​‌‌‌​‌‌‌​‌‌‌​‌‍‍‌​‌‌​‌‌‌‍‍​‌​​‌‌​​‍‍​‌​​​​‌‌‍‍‌​‌‌​‌‌‌‍‍​‌‌​​​​‌‍‍​‌‌​‌​​‌‍‍​‌‌‌‌​‌​‍‍​‌‌​‌​​​‍‍​‌‌‌​​‌‌‍‍​​‌​‌‌‌​‍‍​‌‌‌​‌​​‍‍​‌‌​‌‌‌‌‍‍​‌‌‌​​​​‍‍‌​‌‌​‌‌‌‍‍​‌​‌​​​​‍‍​‌​‌​​‌​‍‍​‌​​‌‌‌‌‍‍​‌​‌​‌‌​‍‍​‌​​​‌​‌‍‍​‌​​‌‌‌​‍‍​‌​​​​​‌‍‍​‌​​‌‌‌​‍‍​‌​​​​‌‌‍‍​‌​​​‌​‌‍‍​​‌​‌‌​‌‍‍​​‌‌​​‌​‍‍​​‌‌​​​​‍‍​​‌‌​​‌​‍‍​​‌‌​‌‌​⁠

import { eq, and, desc, sql, isNull, gt } from 'drizzle-orm'
import { db } from './index.js'
import {
  oauthApps,
  oauthSessions,
  oauthUsers,
  oauthAuditLogs,
  oauthScopeMeta,
  userThirdPartyAccounts,
  userSk,
} from '@ihui/database'

// ============================================================================
// OAuth Apps
// ============================================================================

export async function findOAuthAppByClientId(clientId: string) {
  const rows = await db.select().from(oauthApps).where(eq(oauthApps.clientId, clientId)).limit(1)
  return rows[0]
}

export async function createOAuthApp(input: {
  clientId: string
  clientSecret: string
  name: string
  description?: string
  redirectUris: string[]
  scopes?: string[]
  icon?: string
  ownerUuid: string
}) {
  const [app] = await db
    .insert(oauthApps)
    .values({
      clientId: input.clientId,
      clientSecret: input.clientSecret,
      name: input.name,
      description: input.description,
      redirectUris: input.redirectUris,
      scopes: input.scopes ?? [],
      icon: input.icon,
      ownerUuid: input.ownerUuid,
      isActive: 1,
    })
    .returning()
  return app
}

export async function listOAuthApps(ownerUuid: string, page: number, limit: number) {
  const where = eq(oauthApps.ownerUuid, ownerUuid)
  const rows = await db
    .select()
    .from(oauthApps)
    .where(where)
    .orderBy(desc(oauthApps.createdAt))
    .limit(limit)
    .offset((page - 1) * limit)
  const countRows = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(oauthApps)
    .where(where)
  const count = countRows[0]?.count ?? 0
  return { items: rows, total: count }
}

/**
 * 删除 OAuth 应用(按 clientId + ownerUuid 双条件,跨 owner 一律删不到)。
 * 返回库确认已删除的行 id 集合(未命中为空数组,调用方据此判 deleted 真假)。
 */
export async function deleteOAuthApp(clientId: string, ownerUuid: string): Promise<string[]> {
  const rows = await db
    .delete(oauthApps)
    .where(and(eq(oauthApps.clientId, clientId), eq(oauthApps.ownerUuid, ownerUuid)))
    .returning({ id: oauthApps.id })
  return rows.map((r) => r.id)
}

export async function updateOAuthApp(
  clientId: string,
  ownerUuid: string,
  input: {
    name?: string
    description?: string
    redirectUris?: string[]
    scopes?: string[]
    icon?: string
    isActive?: number
  },
) {
  const rows = await db
    .update(oauthApps)
    .set({ ...input, updatedAt: new Date() })
    .where(and(eq(oauthApps.clientId, clientId), eq(oauthApps.ownerUuid, ownerUuid)))
    .returning()
  return rows[0]
}

export async function regenerateOAuthAppSecret(
  clientId: string,
  ownerUuid: string,
  newSecret: string,
) {
  const rows = await db
    .update(oauthApps)
    .set({ clientSecret: newSecret, updatedAt: new Date() })
    .where(and(eq(oauthApps.clientId, clientId), eq(oauthApps.ownerUuid, ownerUuid)))
    .returning()
  return rows[0]
}

// ============================================================================
// OAuth Sessions (授权码)
// ============================================================================

export async function createOAuthSession(input: {
  code: string
  clientId: string
  userId: string
  state: string
  scope?: string
  codeChallenge?: string
  codeChallengeMethod?: string
}) {
  const [session] = await db
    .insert(oauthSessions)
    .values({
      code: input.code,
      clientId: input.clientId,
      userId: input.userId,
      state: input.state,
      scope: input.scope,
      codeChallenge: input.codeChallenge,
      codeChallengeMethod: input.codeChallengeMethod,
      expiresAt: new Date(Date.now() + 5 * 60 * 1000),
    })
    .returning()
  return session
}

export async function findSessionByCode(code: string) {
  const rows = await db.select().from(oauthSessions).where(eq(oauthSessions.code, code)).limit(1)
  return rows[0]
}

/**
 * 原子消费授权码(F-244):把「先查后标」改成单条条件 UPDATE,返回是否抢到。
 * 并发两次换码只有一次能拿到 true,另一路按无效处理 —— 此前两路都能换出 token。
 */
export async function markSessionUsed(code: string): Promise<boolean> {
  const rows = await db
    .update(oauthSessions)
    .set({ isUsed: true })
    .where(
      and(
        eq(oauthSessions.code, code),
        eq(oauthSessions.isUsed, false),
        gt(oauthSessions.expiresAt, new Date()),
      ),
    )
    .returning({ code: oauthSessions.code })
  return rows.length > 0
}

export async function listUserSessions(userId: string) {
  return db
    .select()
    .from(oauthSessions)
    .where(and(eq(oauthSessions.userId, userId), eq(oauthSessions.isUsed, false)))
    .orderBy(desc(oauthSessions.createdAt))
}

/**
 * 删除 OAuth 会话,回报**库侧确认删掉的那批 id**(2026-09-27:原返回 void,
 * 调用方只能事后写死 deleted:true,"0 行变更"与"删成了"同形)。
 *
 * 属主绑定同批补上(守门 117 那一族"认证 ≠ 授权"):原先只按 id 删,
 * 而 `DELETE /auth/oauth/my-authorized/:sessionId` 在 authenticate 之后把请求里
 * 的任意 sessionId 原样交进来 —— 任何已登录用户填别人的会话 id 就能吊销别人的授权,
 * 且响应仍然回 deleted:true,调用方无从分辨"删了自己的"与"删了别人的"。
 * where 里的第二个条件就是这条敞口的唯一收口点,所以它必须出现在 SQL 层而不是
 * 调用方的 if 里(调用方的 if 只能判"存在",判不了"命中")。
 */
export async function deleteSession(id: string, userId: string): Promise<string[]> {
  const rows = await db
    .delete(oauthSessions)
    .where(and(eq(oauthSessions.id, id), eq(oauthSessions.userId, userId)))
    .returning({ id: oauthSessions.id })
  return rows.map((r) => r.id)
}

// ============================================================================
// OAuth Users (provider 映射)
// ============================================================================

export async function findOAuthUser(provider: string, providerUserId: string) {
  const rows = await db
    .select()
    .from(oauthUsers)
    .where(and(eq(oauthUsers.provider, provider), eq(oauthUsers.providerUserId, providerUserId)))
    .limit(1)
  return rows[0]
}

export async function listOAuthUsers(userId: string) {
  return db.select().from(oauthUsers).where(eq(oauthUsers.userId, userId))
}

// ============================================================================
// Scope Meta
// ============================================================================

export async function listActiveScopeMeta() {
  return db
    .select()
    .from(oauthScopeMeta)
    .where(eq(oauthScopeMeta.isActive, 1))
    .orderBy(oauthScopeMeta.sortOrder)
}

// ============================================================================
// Third-party Accounts (绑定)
// ============================================================================

/**
 * 按 (platform, openId) 找**当前有效**的绑定。
 *
 * 必须滤 `deleted_at`(2026-10-22 立):同文件下面的 `listUserBindings` 一直带着
 * `deletedAt IS NULL`,而这一条从来没带 ⇒ 两条查询对"绑没绑"的理解不一致。后果不是报错,
 * 而是错身份:用户在「已绑定账号」页解绑(列表按软删过滤 ⇒ 显示未绑),再扫同一次微信,
 * 这一条仍会命中那枚软删行并把会话登到**旧 user** 上去;`/mini/rebind` 的
 * `existing.userId !== request.userId ⇒ 409` 也会被一枚早已解绑的死行触发。
 *
 * 顺手把 `limit(1)` 补上确定序:此前无 `orderBy`,同键多行时命中哪一行由数据库决定 ——
 * 那是"偶发登错账号"这种最难复现的故障形态。真并发双绑的第二行还需要库里
 * `(platform, tenant_id, open_id) WHERE deleted_at IS NULL` 的部分唯一索引才能结构性堵住。
 *
 * **租户维度(F-271,2026-11-14)**:企业微信 suite 模式返回的 `open_userid` 只在**单个企业内**
 * 唯一,而旧绑定键只有 `(platform, open_id)` —— B 企业里与 A 企业同值的 open_userid 会命中
 * A 的绑定,直接登进 A 的本地账号(跨租户接管)。现把 `tenant_id` 纳入键:`tenantId` 入参给定时
 * 是**精确等值**匹配(缺失/空串的存量行不再被任意租户命中 = fail-closed,存量用户需重新绑定),
 * 未给定(wechat/google/dingtalk 等单租户平台)时维持旧口径,只按 `(platform, open_id)` 查。
 */
export async function findThirdPartyAccount(platform: string, openId: string, tenantId?: string) {
  const conditions = [
    eq(userThirdPartyAccounts.platform, platform),
    eq(userThirdPartyAccounts.openId, openId),
    sql`${userThirdPartyAccounts.deletedAt} IS NULL`,
  ]
  if (tenantId !== undefined) conditions.push(eq(userThirdPartyAccounts.tenantId, tenantId))
  const rows = await db
    .select()
    .from(userThirdPartyAccounts)
    .where(and(...conditions))
    .orderBy(userThirdPartyAccounts.createdAt)
    .limit(1)
  return rows[0]
}

/**
 * 按 (platform, unionId) 找当前有效的第三方绑定。
 *
 * 微信小程序、公众号、移动应用的 openid 各不相同,但同一个微信用户在同一开放平台主体下
 * 的 unionid 相同。小程序首次登录只有小程序 openid 时,先按 unionid 找已有本地账号,
 * 再把新 openid 补绑过去,避免把 admin/老用户变成另一个人。
 *
 * **多账号命中一律返回 undefined**(fail-closed):同一 unionid 对应多个 userId 时不猜。
 */
export async function findThirdPartyAccountByUnionId(platform: string, unionId: string) {
  if (!unionId) return undefined
  const rows = await db
    .select()
    .from(userThirdPartyAccounts)
    .where(
      and(
        eq(userThirdPartyAccounts.platform, platform),
        eq(userThirdPartyAccounts.unionId, unionId),
        isNull(userThirdPartyAccounts.deletedAt),
      ),
    )
    .orderBy(userThirdPartyAccounts.createdAt)
  if (rows.length === 0) return undefined
  const userIds = new Set(rows.map((row) => row.userId))
  if (userIds.size !== 1) return undefined
  return rows[0]
}

/**
 * 存量租户回填(仅自建应用单租户模式调用)。
 *
 * 为什么需要:加入租户维度后,`tenant_id=''` 的存量绑定不会再被任何 corpId 命中。自建应用的
 * corpId 恒等于 `WECOM_CORP_ID`(只服务这一家企业),存量行不可能属于别家企业 ⇒ 把同键活行
 * 改判为该 corpId 不构成跨租户。suite 模式(多企业共用一套凭据)**不**调用本函数,存量行按
 * fail-closed 处理(用户重新绑定即可),宁可要一次重绑,也不要一条能被任意租户命中的老行。
 *
 * 返回被改判的行 id:空 ⇒ 没有可回填的存量行。
 */
export async function adoptLegacyTenantBinding(
  platform: string,
  openId: string,
  tenantId: string,
): Promise<string | undefined> {
  if (!tenantId) return undefined
  const rows = await db
    .update(userThirdPartyAccounts)
    .set({ tenantId, updatedAt: new Date() })
    .where(
      and(
        eq(userThirdPartyAccounts.platform, platform),
        eq(userThirdPartyAccounts.openId, openId),
        eq(userThirdPartyAccounts.tenantId, ''),
        sql`${userThirdPartyAccounts.deletedAt} IS NULL`,
      ),
    )
    .returning({ id: userThirdPartyAccounts.id })
  return rows[0]?.id
}

export async function listUserBindings(userId: string) {
  return db
    .select()
    .from(userThirdPartyAccounts)
    .where(
      and(
        eq(userThirdPartyAccounts.userId, userId),
        sql`${userThirdPartyAccounts.deletedAt} IS NULL`,
      ),
    )
}

export async function createThirdPartyBinding(input: {
  userId: string
  openId: string
  unionId?: string
  platform: string
  /** 租户维度(F-271):企业微信填 corpId;其余平台省略 ⇒ 落空串(单租户)。 */
  tenantId?: string
  accessToken?: string
  refreshToken?: string
}) {
  const [binding] = await db
    .insert(userThirdPartyAccounts)
    .values({
      userId: input.userId,
      openId: input.openId,
      unionId: input.unionId,
      platform: input.platform,
      tenantId: input.tenantId ?? '',
      accessToken: input.accessToken,
      refreshToken: input.refreshToken,
    })
    .returning()
  return binding
}

/**
 * 解绑第三方账号(软删),回报**库侧确认改动的那批 id**。
 * 2026-09-27:where 除主键外还带 userId 归属过滤,所以"这行不是你的"与"解绑成功了"
 * 在旧形态(返回 void)下完全同形 —— returning 的空集就是唯一的反证。
 */
export async function removeBinding(id: string, userId: string): Promise<string[]> {
  const rows = await db
    .update(userThirdPartyAccounts)
    .set({ deletedAt: new Date() })
    .where(and(eq(userThirdPartyAccounts.id, id), eq(userThirdPartyAccounts.userId, userId)))
    .returning({ id: userThirdPartyAccounts.id })
  return rows.map((r) => r.id)
}

/**
 * 解绑指定平台的全部第三方账号(软删),回报**库侧确认改动的那批 id**(2026-09-27)。
 * 旧形态返回 Promise<void> —— 调用方无从区分"真的改了行"与"where 没命中",
 * 于是 `/auth/bindings/remove` 把常量 true 当解绑结果回给前端。
 * G-815962(2026-10-01)写后回读收口两格:
 *  ① where 补 `deletedAt IS NULL` —— 已软删的行不再被重复软删并回报其 id(旧账如实登记过的缺陷);
 *  ② 写后必须回读:更新完成后按活行面重读一次,若该平台仍有活绑定 = 写入静默落空,
 *    当场抛错而不是把"半解绑"当成功留给下一次用户报障。
 */
export async function removeBindingByPlatform(userId: string, platform: string): Promise<string[]> {
  const rows = await db
    .update(userThirdPartyAccounts)
    .set({ deletedAt: new Date() })
    .where(
      and(
        eq(userThirdPartyAccounts.userId, userId),
        eq(userThirdPartyAccounts.platform, platform),
        isNull(userThirdPartyAccounts.deletedAt),
      ),
    )
    .returning({ id: userThirdPartyAccounts.id })
  // 写后回读(not found after write 的反向:"仍 found after delete" 必须是显式断言)
  const stillLive = await db
    .select({ id: userThirdPartyAccounts.id })
    .from(userThirdPartyAccounts)
    .where(
      and(
        eq(userThirdPartyAccounts.userId, userId),
        eq(userThirdPartyAccounts.platform, platform),
        isNull(userThirdPartyAccounts.deletedAt),
      ),
    )
  if (stillLive.length > 0) {
    throw new Error(
      `OAuth binding still live after unbind: userId=${userId} platform=${platform} leftover=${stillLive.map((r) => r.id).join(',')}`,
    )
  }
  return rows.map((r) => r.id)
}

// ============================================================================
// User SK
// ============================================================================

export async function createUserSk(userId: string, key: string) {
  const [sk] = await db.insert(userSk).values({ userId, key, status: 1 }).returning()
  return sk
}

export async function listUserSk(userId: string, page: number, limit: number) {
  const where = eq(userSk.userId, userId)
  const rows = await db
    .select()
    .from(userSk)
    .where(where)
    .orderBy(desc(userSk.createdAt))
    .limit(limit)
    .offset((page - 1) * limit)
  const countRows = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(userSk)
    .where(where)
  const count = countRows[0]?.count ?? 0
  return { items: rows, total: count }
}

export async function updateUserSk(id: string, userId: string, status: number) {
    const changed = { status }
  return (
    db
      .update(userSk)
      .set({ ...changed, updatedAt: new Date() })
      // status-guard-exempt: 通用状态 setter——目标值由调用方传入,终态合法性由服务层/路由层裁决,非固定出向终态写点
      .where(and(eq(userSk.id, id), eq(userSk.userId, userId)))
      .returning({ id: userSk.id })
  )
}

/**
 * 删除用户 SK,回报**库侧确认删掉的那批 id**(2026-09-27:原返回 void;where 带 userId
 * 归属过滤 ⇒ 删别人的 id 与删成功了同形)。
 */
export async function deleteUserSk(id: string, userId: string): Promise<string[]> {
  const rows = await db
    .delete(userSk)
    .where(and(eq(userSk.id, id), eq(userSk.userId, userId)))
    .returning({ id: userSk.id })
  return rows.map((r) => r.id)
}

// ============================================================================
// OAuth Audit Log
// ============================================================================

export async function createAuditLog(input: {
  event: string
  clientId?: string
  userId?: string
  ip?: string
  status?: string
  detail?: string
}) {
  await db.insert(oauthAuditLogs).values(input)
}

export async function findAuditLogList(params: {
  page?: number
  limit?: number
  clientId?: string
  event?: string
  status?: string
  userId?: string
}): Promise<{ items: (typeof oauthAuditLogs.$inferSelect)[]; total: number }> {
  const page = params.page ?? 1
  const limit = params.limit ?? 20
  const conds = []
  if (params.clientId) conds.push(eq(oauthAuditLogs.clientId, params.clientId))
  if (params.event) conds.push(eq(oauthAuditLogs.event, params.event))
  if (params.status) conds.push(eq(oauthAuditLogs.status, params.status))
  if (params.userId) conds.push(eq(oauthAuditLogs.userId, params.userId))
  const where = conds.length ? and(...conds) : undefined
  const [items, totalRows] = await Promise.all([
    db
      .select()
      .from(oauthAuditLogs)
      .where(where)
      .orderBy(desc(oauthAuditLogs.createdAt))
      .limit(limit)
      .offset((page - 1) * limit),
    db
      .select({ count: sql<number>`count(*)::int` })
      .from(oauthAuditLogs)
      .where(where),
  ])
  return { items, total: totalRows[0]?.count ?? 0 }
}

export async function findAuditLogStats(): Promise<{
  total: number
  successCount: number
  failCount: number
}> {
  const rows = await db
    .select({
      total: sql<number>`count(*)::int`,
      successCount: sql<number>`count(*) filter (where ${oauthAuditLogs.status} = 'success')::int`,
      failCount: sql<number>`count(*) filter (where ${oauthAuditLogs.status} != 'success')::int`,
    })
    .from(oauthAuditLogs)
  const r = rows[0]
  return {
    total: r?.total ?? 0,
    successCount: r?.successCount ?? 0,
    failCount: r?.failCount ?? 0,
  }
}
// ⁠​‌​​‌​​‌‍‍​‌​​‌​​​‍‍​‌​‌​‌​‌‍‍​‌​​‌​​‌‍‍​​‌​‌‌​‌‍‍​‌​​​​​‌‍‍​‌​​‌​​‌‍‍‌​‌‌​‌‌‌‍‍‌‌​​‌‌​​‌‌‌‌​‌​‍‍‌‌​‌‌​​​‌​​​‌‌‌‍‍​‌​​​​​‌‍‍​‌​​‌​​‌‍‍‌​‌‌​‌‌‌‍‍‌‌​​‌‌‌​‌​​‌‌‌​‍‍‌‌​​‌‌​​​‌​​‌​‌‍‍‌​‌‌‌​‌‌‌​‌‌‌​‌‍‍‌​‌‌​‌‌‌‍‍​‌​​‌‌​​‍‍​‌​​​​‌‌‍‍‌​‌‌​‌‌‌‍‍​‌‌​​​​‌‍‍​‌‌​‌​​‌‍‍​‌‌‌‌​‌​‍‍​‌‌​‌​​​‍‍​‌‌‌​​‌‌‍‍​​‌​‌‌‌​‍‍​‌‌‌​‌​​‍‍​‌‌​‌‌‌‌‍‍​‌‌‌​​​​‍‍‌​‌‌​‌‌‌‍‍​‌​‌​​​​‍‍​‌​‌​​‌​‍‍​‌​​‌‌‌‌‍‍​‌​‌​‌‌​‍‍​‌​​​‌​‌‍‍​‌​​‌‌‌​‍‍​‌​​​​​‌‍‍​‌​​‌‌‌​‍‍​‌​​​​‌‌‍‍​‌​​​‌​‌‍‍​​‌​‌‌​‌‍‍​​‌‌​​‌​‍‍​​‌‌​​​​‍‍​​‌‌​​‌​‍‍​​‌‌​‌‌​⁠
